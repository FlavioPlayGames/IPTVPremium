# Central IPTV Premium

Site e servidor para **centraliptvpremium.com.br**, com o visual 5 (Player cinema) aprovado. Hospedagem preparada para Cloudflare Workers + D1 no plano gratuito. O pacote não publica nada sozinho nem ativa um plano pago.

## O que está implementado

- Usuário entra com MAC virtual e código de seis dígitos do aplicativo.
- Nome inicial vem do fabricante/modelo enviado pelo Android; o usuário pode renomear sem mudar MAC, código ou licença.
- Envio, edição e exclusão de listas M3U e Xtream Codes.
- Cadastro/edição de chaves pessoais SubDL e SubSource, com instruções e links oficiais.
- Aparência de legendas com três brancos, três amarelos, três fontes, tamanho, fundo e acabamento, com prévia local.
- Sete dias de teste a partir do primeiro cadastro da instalação.
- Oferta padrão e Pix de **licença anual**. Pix manual: copiar, gerar QR ou fazer um pagamento não libera o acesso sozinho.
- QR Code e Pix Copia e Cola com txid único contendo o MAC sem dois-pontos. Nem todo banco mostra o txid da mesma forma. O dono confere no banco e confirma a liberação no painel.
- Administrador acessa os aparelhos, renomeia, bloqueia, redefine código, libera/renova um ano e pode conceder um prazo excepcional em dias, meses, anos ou data final.
- Busca administrativa aceita nome, MAC e referência Pix.

## Publicar na SUA conta Cloudflare

Precisa de um computador com **Node.js 24 LTS**, internet, sua conta Cloudflare e o domínio adicionado nessa conta. Não envie senhas, chave de criptografia ou tokens pelo chat.

1. Extraia o ZIP e abra o PowerShell na pasta `site`.
2. Execute:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Publicar-Painel.ps1
```

O script instala dependências fixadas no lockfile, abre o login oficial do Cloudflare, encontra/cria o banco `central-iptv-premium`, aplica a migração, publica o Worker e pede sua senha administrativa (mínimo de 16 caracteres). A chave de criptografia é gerada localmente e enviada como segredo. Não existe senha padrão.

O primeiro deploy pode mostrar “Servidor aguardando configuração” até que os dois segredos sejam definidos. Ao final, abra o endereço `workers.dev` mostrado pelo Cloudflare. Clique em **Administração → Acesso do administrador** e entre com sua senha.

3. No painel, use **Configurar Pix** para preencher a SUA chave Pix, recebedor, cidade e preço anual. Nenhum valor foi escolhido por você ainda; o site não tem preço nem chave bancária pré-cadastrados. A existência de tarifas de recebimento depende do seu banco.
4. Quando o domínio estiver **Ativo** no Cloudflare, conecte-o executando:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Publicar-Painel.ps1 -ConectarDominio
```

A segunda execução reutiliza banco e segredos existentes. Ela solicita o domínio personalizado `centraliptvpremium.com.br` na sua conta, sem comprar outro domínio. Aguarde a ativação DNS/HTTPS. Confira `https://centraliptvpremium.com.br/api/health`: deve responder `{"status":"ok"}`.

Se o deploy informar falta de permissão ou domínio ainda não ativo, conclua a ativação do domínio no Cloudflare. Alternativamente, em Workers & Pages → central-iptv-premium → Settings → Domains & Routes, adicione **Custom domain** com o domínio comprado. Não adicione um IP inventado no DNS.

**Guarde `.private/APP_KEY.txt` em um backup privado fora deste computador.** Não publique essa pasta. A chave é necessária para migrar ou recuperar MAC/código e os dados cifrados. O script não substitui um APP_KEY que já exista no Cloudflare. Se a conta já tinha o segredo, preserve o backup original. Alterar o APP_KEY sem migração quebra o acesso aos dados criptografados.

Os scripts PowerShell foram preparados para Windows PowerShell 5.1; não foram executados neste ambiente Linux. O Worker, D1 local, fluxos no Chromium e build Android foram executados. Você fará o login e a publicação na própria conta.

## Conectar o aplicativo Android

**Publique e teste o site antes de instalar o APK conectado.**

Na raiz do seu projeto Android, execute o arquivo `Conectar-aplicativo-central.ps1` entregue junto do site:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Conectar-aplicativo-central.ps1
```

O patch valida os trechos esperados, faz backups, adiciona os componentes de comunicação e configura somente a propriedade pública `DEVICE_PORTAL_URL=https://centraliptvpremium.com.br` no seu `local.properties`, preservando as outras propriedades e credenciais locais. Se disser que a versão é diferente, nenhum trecho incompatível deve ser forçado: adapte contra os arquivos atuais.

Depois compile e instale pelo Android Studio. A primeira conexão registra o MAC virtual e o código. Use esses dados para entrar no site. **Configurações → Informações → Sincronizar agora** recebe os envios imediatamente.

A consulta automática ao servidor acontece ao abrir, respeitando intervalo mínimo de 30 minutos, e enquanto o app estiver em primeiro plano. A validade é conferida localmente a cada minuto; verificação local não faz requisição ao Cloudflare. A licença válida em cache permite continuar sem servidor até o prazo conhecido. Primeiro cadastro precisa de internet. Bloqueio/liberação remotos passam a valer na próxima consulta ou na sincronização manual.

Listas e configurações atuais são solicitadas ao aparelho ao entrar na conta ou tocar em Atualizar aparelho. Sem conexão ou sincronização do app, o site não inventa listas nem mostra uma cópia permanente antiga.

## Armazenamento leve

Não existem tabelas permanentes de listas nem de chaves de legendas.

| Informação | Retenção |
|---|---|
| MAC, código protegido, modelo/nome, hash da credencial, teste e licença | Permanente |
| Registro de pagamento e liberação | Permanente, para controle do acesso |
| Lista/chave/estilo aguardando envio | Cifrados na fila; apagados na confirmação; expiram em 48 horas sem entrega |
| Resposta de consulta ao aparelho | Cifrada e disponível por cinco minutos; removida no acesso após expiração ou limpeza agendada |
| Metadados de comandos recebidos/falhos | Aproximadamente um dia |
| Auditoria sem conteúdo das listas/chaves | 30 dias |
| Sessões | Oito horas, com limpeza automática |

A limpeza é executada de hora em hora e também ao consultar os dados de um aparelho. Apagar significa remover do banco operacional; recursos de recuperação/backup do provedor têm sua própria retenção. O servidor nunca recebe a chave privada interna do Android Keystore nem exporta chaves SubDL/SubSource já salvas no aparelho: recebe apenas o estado configurado/não configurado.

Limite de 20 envios pendentes e 30 listas por aparelho. Uma medida sintética real do esquema com 1.000 aparelhos, 1.000 pagamentos e 1.000 liberações ocupou **1,12 MiB**, sem filas, sessões e consultas temporárias. É uma medida de referência, não garantia de capacidade. Acompanhe o uso real do D1.

No Free do D1, o limite é 500 MB por banco e 5 GB na conta. Cotas diárias de chamadas, leituras e escritas também se aplicam. Manter o plano Free não garante disponibilidade ilimitada. O custo mensal não é ativado por este código; depende do plano da sua conta.

## Licenças e Pix

Um ano significa um ano de calendário a partir da confirmação; renovação de licença ainda válida acrescenta um ano ao vencimento atual. Aniversários no fim de mês são ajustados para o último dia válido do mês. Os sete dias de teste não são reiniciados por abrir o app, trocar rede ou registrar de novo a mesma credencial.

Liberação manual excepcional fica somente na administração. Não altera a oferta anual nem o valor do Pix. O Pix precisa ser conferido no extrato do seu banco: o servidor não consulta o banco e não detecta sozinho um pagamento. Confirmação repetida do mesmo Pix não acrescenta anos repetidos. O QR é estático; uma expiração do pedido no painel não impede tecnicamente o banco de executar um Pix com aquele código antigo.

O ID é um MAC **virtual da instalação**, não o MAC físico da placa. O banco verifica exclusividade e atribui outro se uma proposta colidir. A garantia de exclusividade vale neste banco. Não copie o mesmo banco para dois servidores que aceitem novos cadastros independentemente.

Desinstalar ou limpar dados do app remove a credencial privada: pode ser preciso reativar a nova instalação pelo administrador. Esta versão não garante vínculo indestrutível ao hardware, prevenção absoluta de clonagem, nem restauração automática de licença após reinstalação. Não apresente esse mecanismo como DRM ou prova física do aparelho.

## Segurança e acesso

Senha administrativa e chave de criptografia são segredos no Cloudflare. Sessões em cookie HttpOnly/SameSite Strict, Secure sob HTTPS; alterações exigem origem e CSRF válidos. Limites de tentativas por IP/MAC. MAC e seis dígitos dão acesso ao site; o APK usa uma credencial privada de 32 bytes. O servidor armazena só o hash dessa credencial. O código é verificável por HMAC e fica cifrado para recuperação administrativa e envio ao aparelho.

Listas e chaves temporárias ficam cifradas com AES-GCM e vinculadas ao aparelho. Logs de acesso detalhados do Worker estão desabilitados. Não habilite registro de corpos, cookies ou Authorization em ferramentas externas.

Para redefinir senha administrativa:

```powershell
.\node_modules\.bin\wrangler.cmd secret put ADMIN_PASSWORD
.\node_modules\.bin\wrangler.cmd d1 execute central-iptv-premium --remote --command "DELETE FROM sessions"
```

## Backup e migração

```powershell
.\node_modules\.bin\wrangler.cmd d1 export central-iptv-premium --remote --output backup-central.sql
```

Guarde o SQL e o APP_KEY de forma privada, separadamente do ZIP público. Faça backups regulares e teste restauração antes de depender deles. O domínio próprio pode ser apontado para outra hospedagem, preservando endereço e cadastros. D1 usa SQLite; o novo servidor precisará adaptar a API, agendamento e os bindings específicos do Cloudflare. Preserve o APP_KEY e os mesmos MACs/códigos/credenciais. Uma exportação completa também pode conter fila ou consultas temporárias que ainda não tenham expirado.

## Desenvolvimento e validação

```sh
npm ci
npm test
npm run db:local
npm run dev
```

Para testar localmente no Windows, `Preparar-Teste-Local.ps1` cria `.dev.vars` privada e pede uma senha local. Para testes de API, `npm test` usa banco SQLite temporário em memória, sem acesso a clientes reais. O servidor de desenvolvimento usa `.wrangler/local-v1`, separado do banco remoto.

A validação desta entrega executou:
- 17 testes da API: concorrência, MAC duplicado, limites, isolamento, licença, Pix, prazos e remoção de conteúdo após ACK.
- Worker e D1 locais reais via Wrangler, além de empacotamento `deploy --dry-run` sem publicação.
- Chromium real: usuário/admin, lista, chave, estilo, renomeação, QR Pix com MAC, liberação e responsividade.
- `assembleDebug` do aplicativo.
- Código Kotlin real de sincronização executado em JVM contra a API local, com serviços Android adaptados por stubs: cadastro, ACK, listas, chaves, estilo, exclusão e intervalo de consulta.

Ainda é necessário testar o APK numa TV/celular real e confirmar um Pix real com seu banco antes de distribuir comercialmente. O preço e o recebedor das capturas de teste são fictícios; não foram definidos como configuração padrão.
