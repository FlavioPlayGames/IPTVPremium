﻿$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Instale Node.js 22 ou superior em nodejs.org." }
if (-not (Test-Path -LiteralPath "node_modules\wrangler")) {
    & npm.cmd ci
    if ($LASTEXITCODE -ne 0) { throw "Falha ao instalar dependencias." }
}
if (-not (Test-Path -LiteralPath ".dev.vars")) {
    $senha = Read-Host "Crie uma senha de teste para o administrador (minimo 16 caracteres)" -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($senha)
    try { $texto = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
    if ($texto.Length -lt 16 -or $texto.Length -gt 256 -or $texto.Contains('"') -or $texto.Contains("`n")) { throw "Use pelo menos 16 caracteres, sem aspas ou quebras de linha nesta senha local." }
    $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
    $bytes = New-Object byte[] 32
    $rng.GetBytes($bytes)
    $rng.Dispose()
    $chave = ([BitConverter]::ToString($bytes)).Replace("-", "").ToLowerInvariant()
    $utf8 = New-Object Text.UTF8Encoding($false)
    [IO.File]::WriteAllText((Join-Path $PSScriptRoot ".dev.vars"), "APP_KEY=$chave`nADMIN_PASSWORD=`"$texto`"`n", $utf8)
    $texto = $null
}
& npm.cmd run db:local
if ($LASTEXITCODE -ne 0) { throw "Falha ao preparar o banco local." }
Write-Host "Abra http://127.0.0.1:8787 no navegador deste computador." -ForegroundColor Yellow
& npm.cmd run dev
if ($LASTEXITCODE -ne 0) { throw "O servidor local foi encerrado com erro." }
