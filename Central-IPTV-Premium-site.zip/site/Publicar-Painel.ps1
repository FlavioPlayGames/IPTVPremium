﻿param([switch]$ConectarDominio)
$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
function Check-Exit([string]$message) { if ($LASTEXITCODE -ne 0) { throw $message } }
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw "Instale Node.js 22 ou superior em nodejs.org e abra um novo terminal." }
$nodeMajor = [int]((& node --version).TrimStart('v').Split('.')[0])
if ($nodeMajor -lt 22) { throw "Atualize para Node.js 22 ou superior." }
& npm.cmd ci
Check-Exit "Falha ao instalar as dependencias."
$wrangler = Join-Path $PSScriptRoot "node_modules\.bin\wrangler.cmd"
Write-Host "Entre na SUA conta gratuita do Cloudflare pelo navegador." -ForegroundColor Yellow
& $wrangler login
Check-Exit "Nao foi possivel entrar no Cloudflare."
$configPath = Join-Path $PSScriptRoot "wrangler.jsonc"
$config = [IO.File]::ReadAllText($configPath) | ConvertFrom-Json
$utf8 = New-Object Text.UTF8Encoding($false)
if ($config.d1_databases[0].database_id -eq "SUBSTITUIR_PELO_ID_DO_BANCO") {
    $databases = (& $wrangler d1 list --json | Out-String) | ConvertFrom-Json
    Check-Exit "Nao foi possivel consultar os bancos da conta."
    $existing = @($databases | Where-Object { $_.name -eq "central-iptv-premium" })
    if ($existing.Count -eq 1) {
        $databaseId = $existing[0].uuid
    } else {
        $created = & $wrangler d1 create central-iptv-premium --update-config=false 2>&1
        Check-Exit "Nao foi possivel criar o banco de dados."
        $created | ForEach-Object { Write-Host $_ }
        $match = [regex]::Match(($created | Out-String), '"(?:database_id|uuid)"\s*:\s*"([0-9a-fA-F-]{36})"')
        if ($match.Success) { $databaseId = $match.Groups[1].Value } else { $databaseId = Read-Host "Cole somente o database_id informado acima" }
    }
    $parsed = [guid]::Empty
    if (-not [guid]::TryParse([string]$databaseId, [ref]$parsed)) { throw "Identificador do banco invalido." }
    $config.d1_databases[0].database_id = [string]$databaseId
}
if ($ConectarDominio) {
    $routes = @(@{ pattern = "centraliptvpremium.com.br"; custom_domain = $true })
    $config | Add-Member -NotePropertyName routes -NotePropertyValue $routes -Force
}
[IO.File]::WriteAllText($configPath, ($config | ConvertTo-Json -Depth 15), $utf8)
& $wrangler d1 migrations apply central-iptv-premium --remote
Check-Exit "Falha ao preparar o banco remoto."
Write-Host "Publicando o Worker. Ele aguardara a configuracao dos segredos antes de aceitar logins." -ForegroundColor Yellow
& $wrangler deploy
Check-Exit "Falha ao publicar o Worker."
$secretList = (& $wrangler secret list | Out-String) | ConvertFrom-Json
Check-Exit "Nao foi possivel consultar os nomes dos segredos."
$secretNames = @($secretList | ForEach-Object { $_.name })
if ($secretNames -notcontains "APP_KEY") {
    $private = Join-Path $PSScriptRoot ".private"
    [void][IO.Directory]::CreateDirectory($private)
    $backupPath = Join-Path $private "APP_KEY.txt"
    if (Test-Path -LiteralPath $backupPath) {
        $appKey = [IO.File]::ReadAllText($backupPath).Trim()
    } else {
        $rng = [Security.Cryptography.RandomNumberGenerator]::Create()
        $randomBytes = New-Object byte[] 32
        $rng.GetBytes($randomBytes)
        $rng.Dispose()
        $appKey = ([BitConverter]::ToString($randomBytes)).Replace("-", "").ToLowerInvariant()
        [IO.File]::WriteAllText($backupPath, $appKey, $utf8)
    }
    if ($appKey -notmatch '^[0-9a-f]{64}$') { throw "Backup da chave invalido. Nao foi substituido." }
    $appKey | & $wrangler secret put APP_KEY
    Check-Exit "Falha ao configurar a chave de criptografia. Guarde o backup local."
    $appKey = $null
    Write-Host "Guarde uma copia privada de .private\APP_KEY.txt fora deste computador. Ela e necessaria para migrar ou recuperar os dados cifrados."
}
if ($secretNames -notcontains "ADMIN_PASSWORD") {
    $secure = Read-Host "Crie a SUA senha administrativa (minimo 16 caracteres)" -AsSecureString
    $ptr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
    try { $password = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($ptr) } finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ptr) }
    if ($password.Length -lt 16 -or $password.Length -gt 256) { throw "A senha precisa de pelo menos 16 caracteres. Execute o script novamente para concluir." }
    $password | & $wrangler secret put ADMIN_PASSWORD
    Check-Exit "Falha ao configurar a senha administrativa."
    $password = $null
}
Write-Host "Publicacao concluida. Abra o endereco workers.dev informado pelo Cloudflare." -ForegroundColor Green
if ($ConectarDominio) { Write-Host "Dominio solicitado: https://centraliptvpremium.com.br . Aguarde a ativacao DNS/HTTPS, se necessario." }
Write-Host "Entre em Administracao e configure a chave Pix, o recebedor, a cidade e o preco anual."
Write-Host "Nenhum plano pago foi ativado por este script. O consumo segue as cotas do plano da SUA conta."
