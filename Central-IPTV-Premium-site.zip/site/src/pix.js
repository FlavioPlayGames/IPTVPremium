// BR Code static Pix: EMV TLV, additional-data txid and CRC16-CCITT (0xFFFF).
function field(id,value){const n=new TextEncoder().encode(value).length;if(n>99)throw Error('Campo Pix muito longo.');return id+String(n).padStart(2,'0')+value}
function ascii(s){return s.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toUpperCase().replace(/[^A-Z0-9 .-]/g,'').trim()}
export function buildPix({key,name,city,amountCents,txid}){
 if(typeof key!=='string'||!key.trim()||key.length>77||!/^[\x21-\x7E]+$/.test(key)||!Number.isSafeInteger(amountCents)||amountCents<1||amountCents>10000000||!/^[A-Z0-9]{1,25}$/.test(txid))throw Error('Configuração Pix inválida.');
 const merchant=ascii(name).slice(0,25),location=ascii(city).slice(0,15);if(!merchant||!location)throw Error('Dados do recebedor inválidos.');
 const account=field('00','BR.GOV.BCB.PIX')+field('01',key.trim());
 let payload=field('00','01')+field('26',account)+field('52','0000')+field('53','986')+field('54',(amountCents/100).toFixed(2))+field('58','BR')+field('59',merchant)+field('60',location)+field('62',field('05',txid))+'6304';
 let crc=0xFFFF;for(const b of new TextEncoder().encode(payload)){crc^=b<<8;for(let i=0;i<8;i++)crc=(crc&0x8000)?((crc<<1)^0x1021)&0xFFFF:(crc<<1)&0xFFFF}
 return payload+crc.toString(16).toUpperCase().padStart(4,'0');
}
