CREATE TABLE qr_logins (
 token_hash TEXT PRIMARY KEY,
 device_id TEXT NOT NULL UNIQUE REFERENCES devices(id) ON DELETE CASCADE,
 code_hash TEXT NOT NULL,
 expires INTEGER NOT NULL
);
CREATE INDEX qr_logins_expiry ON qr_logins(expires);
