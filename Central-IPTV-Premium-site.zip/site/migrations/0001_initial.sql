PRAGMA foreign_keys=ON;
CREATE TABLE devices (
 id TEXT PRIMARY KEY, credential_hash TEXT NOT NULL UNIQUE, mac TEXT NOT NULL UNIQUE,
 code_hash TEXT NOT NULL, code_cipher TEXT NOT NULL, label TEXT NOT NULL, model TEXT NOT NULL,
 status TEXT NOT NULL DEFAULT 'active' CHECK(status IN ('active','blocked')),
 created_at INTEGER NOT NULL, trial_until INTEGER NOT NULL, license_until INTEGER,
 last_seen INTEGER NOT NULL, release_kind TEXT, release_at INTEGER,
 release_reference TEXT, release_request TEXT);
CREATE TABLE sessions (
 token_hash TEXT PRIMARY KEY, role TEXT NOT NULL CHECK(role IN ('user','admin')),
 device_id TEXT REFERENCES devices(id) ON DELETE CASCADE, csrf TEXT NOT NULL, expires INTEGER NOT NULL);
CREATE INDEX sessions_expires ON sessions(expires);
CREATE TABLE commands (
 seq INTEGER PRIMARY KEY AUTOINCREMENT, id TEXT NOT NULL UNIQUE,
 device_id TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
 kind TEXT NOT NULL, cipher TEXT, state TEXT NOT NULL DEFAULT 'pending',
 result TEXT, created_at INTEGER NOT NULL, expires INTEGER NOT NULL, finished_at INTEGER);
CREATE INDEX commands_device ON commands(device_id,seq);
CREATE INDEX commands_expires ON commands(expires);
CREATE TABLE snapshots (
 device_id TEXT PRIMARY KEY REFERENCES devices(id) ON DELETE CASCADE,
 cipher TEXT NOT NULL, received_at INTEGER NOT NULL, expires INTEGER NOT NULL);
CREATE INDEX snapshots_expires ON snapshots(expires);
CREATE TABLE limits (key TEXT PRIMARY KEY, count INTEGER NOT NULL, expires INTEGER NOT NULL);
CREATE INDEX limits_expires ON limits(expires);
CREATE TABLE audit (id INTEGER PRIMARY KEY AUTOINCREMENT, device_id TEXT, action TEXT NOT NULL, at INTEGER NOT NULL);
CREATE INDEX audit_at ON audit(at);
CREATE TABLE settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE payments (
 id TEXT PRIMARY KEY, device_id TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
 txid TEXT NOT NULL UNIQUE, amount_cents INTEGER NOT NULL,
 status TEXT NOT NULL DEFAULT 'pending' CHECK(status IN ('pending','paid','expired')),
 created_at INTEGER NOT NULL, expires INTEGER NOT NULL, paid_at INTEGER);
CREATE INDEX payments_device ON payments(device_id,created_at);
CREATE TABLE license_grants (
 request_id TEXT PRIMARY KEY, device_id TEXT NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
 valid_until INTEGER NOT NULL, created_at INTEGER NOT NULL, kind TEXT NOT NULL, reference TEXT NOT NULL);
CREATE INDEX license_grants_device ON license_grants(device_id);
