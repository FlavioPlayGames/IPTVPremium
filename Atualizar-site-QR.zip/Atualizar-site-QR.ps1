﻿param([Parameter(Mandatory=$true)][string]$SitePath)
$ErrorActionPreference = "Stop"
$dest = (Resolve-Path -LiteralPath $SitePath).Path
if (-not (Test-Path -LiteralPath (Join-Path $dest "Publicar-Painel.ps1"))) { throw "Escolha a pasta site que voce ja publicou." }
$config = Get-Content -LiteralPath (Join-Path $dest "wrangler.jsonc") -Raw | ConvertFrom-Json
if ($config.d1_databases[0].database_id -eq "SUBSTITUIR_PELO_ID_DO_BANCO") { throw "Essa pasta nao tem o banco publicado configurado. Escolha a pasta site original." }
$files = @("src/worker.js", "public/app.js", "migrations/0002_qr_login.sql", "test/api.test.mjs", "README.md")
foreach ($name in $files) { if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot $name))) { throw "Extraia todo o ZIP antes de executar." } }
$stamp = Get-Date -Format "yyyyMMdd-HHmmssfff"
foreach ($name in $files) {
 $target = Join-Path $dest $name
 if (Test-Path -LiteralPath $target) { Copy-Item -LiteralPath $target -Destination ($target + ".backup-" + $stamp) }
 [void][IO.Directory]::CreateDirectory((Split-Path $target -Parent))
 Copy-Item -LiteralPath (Join-Path $PSScriptRoot $name) -Destination $target -Force
}
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $dest "Publicar-Painel.ps1") -ConectarDominio
if ($LASTEXITCODE -ne 0) { throw "Publicacao nao concluida. Confira o erro acima." }
