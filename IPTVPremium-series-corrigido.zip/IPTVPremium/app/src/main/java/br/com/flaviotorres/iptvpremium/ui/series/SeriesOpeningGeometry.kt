package br.com.flaviotorres.iptvpremium.ui.series

import kotlin.math.max

internal data class SeriesTvBounds(
    val left: Float,
    val top: Float,
    val right: Float,
    val bottom: Float
) {
    val width get() = right - left
    val height get() = bottom - top
    val centerX get() = (left + right) / 2f
    val centerY get() = (top + bottom) / 2f
}

internal data class SeriesTvGeometry(
    val screen: SeriesTvBounds,
    val roomScale: Float,
    val cornerRadius: Float,
    val finalZoom: Float,
    val finalTranslationX: Float,
    val finalTranslationY: Float
)

internal fun seriesTvGeometry(width: Float, height: Float): SeriesTvGeometry {
    require(width.isFinite() && height.isFinite() && width > 0f && height > 0f)

    // Pixels medidos no interior da TV de series_living_room.webp (3840 x 2160).
    // A mesma escala/centralizacao de ContentScale.Crop deve valer para a imagem
    // da sala e para a janela da TV, inclusive fora da proporcao 16:9.
    val scale = max(width / 3840f, height / 2160f)
    val roomLeft = (width - 3840f * scale) / 2f
    val roomTop = (height - 2160f * scale) / 2f
    val screen = SeriesTvBounds(
        left = roomLeft + 1289f * scale,
        top = roomTop + 395f * scale,
        right = roomLeft + 2702f * scale,
        bottom = roomTop + 1194f * scale
    )

    // Aproxima a sala inteira sem esticar a imagem. Ao terminar, nenhuma borda
    // da TV fica dentro do viewport, mesmo em telas de outra proporcao.
    val cornerRadius = 3f * scale
    val finalZoom = max(
        width / (screen.width - 2f * cornerRadius),
        height / (screen.height - 2f * cornerRadius)
    )
    return SeriesTvGeometry(
        screen = screen,
        roomScale = scale,
        cornerRadius = cornerRadius,
        finalZoom = finalZoom,
        finalTranslationX = width / 2f - screen.centerX * finalZoom,
        finalTranslationY = height / 2f - screen.centerY * finalZoom
    )
}

internal data class SeriesTvPowerFrame(
    val widthFraction: Float,
    val heightFraction: Float,
    val pictureAlpha: Float,
    val flashAlpha: Float,
    val sparkAlpha: Float
)

internal fun seriesTvPowerFrame(progress: Float): SeriesTvPowerFrame {
    fun phase(start: Float, end: Float): Float {
        val fraction = ((progress - start) / (end - start)).coerceIn(0f, 1f)
        return fraction * fraction * (3f - 2f * fraction)
    }
    return SeriesTvPowerFrame(
        widthFraction = phase(0.08f, 0.36f),
        heightFraction = phase(0.36f, 0.86f),
        pictureAlpha = phase(0.48f, 0.98f),
        flashAlpha = phase(0f, 0.08f) * (1f - phase(0.48f, 1f)),
        sparkAlpha = phase(0f, 0.05f) * (1f - phase(0.12f, 0.36f))
    )
}
