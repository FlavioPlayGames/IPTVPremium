package br.com.flaviotorres.iptvpremium.core.device

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

internal data class TrialSnapshot(val mac: String, val code: String, val state: String,
    val expiresAt: Long, val licenseUntil: Long, val protocol: Int, val acknowledged: Boolean,
    val validatedNow: Long, val elapsedAtValidation: Long, val clockOffset: Long) {
    fun now() = maxOf(System.currentTimeMillis() + clockOffset,
        validatedNow + (SystemClock.elapsedRealtime() - elapsedAtValidation).coerceAtLeast(0))
    fun expired(now: Long = now()) = TrialNoticePolicy.trialExpired(state, expiresAt, now, licenseUntil)
    fun welcome(now: Long = now()) = TrialNoticePolicy.showWelcome(state, expiresAt, now, protocol, acknowledged)
}

internal data class TrialChoice(val mac: String, val expiresAt: Long, val choice: String)
internal object TrialAcknowledgement {
    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences("iptv_trial_notice_v1", Context.MODE_PRIVATE)
    fun acknowledged(context: Context, mac: String, expiresAt: Long): Boolean {
        val p = prefs(context)
        return p.getString("mac", null) == mac && p.getLong("expires", 0) == expiresAt
    }
    fun mark(context: Context, snapshot: TrialSnapshot, choice: String) {
        require(choice in listOf("now", "due"))
        check(prefs(context).edit().putString("mac", snapshot.mac).putLong("expires", snapshot.expiresAt)
            .putString("choice", choice).putBoolean("pending", true).putLong("retryAfter", 0).putLong("failures", 0).commit())
    }
    fun pending(context: Context): TrialChoice? {
        val p = prefs(context)
        if (!p.getBoolean("pending", false)) return null
        val mac = p.getString("mac", null) ?: return null
        val choice = p.getString("choice", null)?.takeIf { it in listOf("now", "due") } ?: return null
        return TrialChoice(mac, p.getLong("expires", 0), choice)
    }
    fun readyToRetry(context: Context, now: Long = System.currentTimeMillis()) =
        prefs(context).getLong("retryAfter", 0) <= now
    fun failed(context: Context, choice: TrialChoice, now: Long = System.currentTimeMillis()) {
        if (pending(context) != choice) return
        val p = prefs(context)
        val failures = (p.getLong("failures", 0) + 1).coerceAtMost(3)
        val delay = when (failures) { 1L -> 60_000L; 2L -> 300_000L; else -> 1_800_000L }
        check(p.edit().putLong("failures", failures).putLong("retryAfter", now + delay).commit())
    }
    fun clearPending(context: Context, choice: TrialChoice) {
        if (pending(context) == choice) check(prefs(context).edit().putBoolean("pending", false).commit())
    }
}

internal object PortalTrialState {
    val snapshot = MutableStateFlow<TrialSnapshot?>(null)
    fun receive(context: Context, state: JSONObject, now: Long, elapsedNow: Long) {
        val mac = state.optString("mac")
        val license = state.optString("licenseState")
        val expires = state.optLong("trialUntil", 0)
        if (mac.isBlank() || license !in listOf("trial", "expired") || expires <= 0) {
            snapshot.value = null
            return
        }
        val notice = state.optJSONObject("trialNotice")
        val protocol = if (notice?.optLong("expiresAt") == expires) notice.optInt("protocol", 0) else 0
        snapshot.value = TrialSnapshot(mac, state.optString("code"), license, expires,
            state.optLong("licenseUntil", 0), protocol, notice?.optBoolean("acknowledged", false) == true ||
                TrialAcknowledgement.acknowledged(context, mac, expires), now, elapsedNow, state.optLong("clockOffset", 0))
    }
    fun acknowledge(current: TrialSnapshot) {
        val saved = snapshot.value ?: return
        if (saved.mac == current.mac && saved.expiresAt == current.expiresAt)
            snapshot.value = saved.copy(acknowledged = true)
    }
    fun expireIfDue(current: TrialSnapshot) {
        val saved = snapshot.value ?: return
        if (saved.mac == current.mac && saved.expiresAt == current.expiresAt && saved.expired()) {
            snapshot.value = saved.copy(state = "expired")
            PortalAccess.message.value = "Seu período de experiência terminou. Para continuar usando o aplicativo, faça a ativação pela central."
        }
    }
}
