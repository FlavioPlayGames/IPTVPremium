package br.com.flaviotorres.iptvpremium.core.device

/** No local seven-day counter: all decisions use the server's immutable trial deadline. */
internal object TrialNoticePolicy {
    fun showWelcome(state: String, expiresAt: Long, now: Long, protocol: Int, acknowledged: Boolean) =
        state == "trial" && protocol == 1 && expiresAt > now && !acknowledged
    fun trialExpired(state: String, expiresAt: Long, now: Long, licenseUntil: Long) =
        state in listOf("trial", "expired") && licenseUntil == 0L && expiresAt > 0 && now >= expiresAt
}
