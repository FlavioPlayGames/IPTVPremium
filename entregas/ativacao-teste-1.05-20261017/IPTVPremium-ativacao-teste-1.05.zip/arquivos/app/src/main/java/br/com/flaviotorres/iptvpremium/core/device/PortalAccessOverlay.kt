package br.com.flaviotorres.iptvpremium.core.device

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.BuildConfig

@Composable
fun PortalAccessOverlay() {
    val message by PortalAccess.message.collectAsState()
    val trial by PortalTrialState.snapshot.collectAsState()
    if (message != null && trial?.expired() == true) {
        TrialExpiredAccess()
        return
    }
    val context = LocalContext.current
    if (message != null) Dialog(onDismissRequest = {}, properties = DialogProperties(
        dismissOnBackPress = false, dismissOnClickOutside = false, usePlatformDefaultWidth = false)) {
        Box(Modifier.fillMaxSize().background(Color(0xFF08090B)), contentAlignment = Alignment.Center) {
            Column(Modifier.widthIn(max = 520.dp).heightIn(max = LocalConfiguration.current.screenHeightDp.dp)
                .verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(15.dp)) {
                Text("Central IPTV Premium", color = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE6A0), fontSize = 23.sp)
                Text(message.orEmpty(), color = Color.White, fontSize = 16.sp)
                Text("A licença será verificada automaticamente ao abrir ou voltar ao aplicativo e, se permanecer aberto, a cada 24 horas.", color = Color.White, fontSize = 14.sp)
                DeviceIdentityCard(showSyncButton = false)
                if (BuildConfig.DEVICE_PORTAL_URL.isNotBlank()) DevicePortalQr(destination = "payment", compact = true)
                if (BuildConfig.DEVICE_PORTAL_URL.isNotBlank()) {
                    Text("Abrir central de acesso", color = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE6A0), fontSize = 16.sp,
                        modifier = Modifier.fillMaxWidth().background(Color(0xFF292A2D), RoundedCornerShape(8.dp))
                            .clickable {
                                runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(BuildConfig.DEVICE_PORTAL_URL))) }
                            }.padding(15.dp))
                    Text(BuildConfig.DEVICE_PORTAL_URL, color = Color.White, fontSize = 13.sp)
                }
            }
        }
    }
}

// IPTV_RENEWAL_AND_DAILY_SYNC_V1
