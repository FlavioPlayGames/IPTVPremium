package br.com.flaviotorres.iptvpremium.data.cache

import kotlinx.coroutines.*

/** Maintain a bounded reserve while retaining useful in-flight and completed files. */
internal class PosterReservePlan {
    private var anchor: Int? = null
    private var end = 0
    fun reset() { anchor = null; end = 0 }
    fun size(afterVisible: Int): Int {
        val start = afterVisible.coerceAtLeast(0)
        val previous = anchor
        if (previous == null || start < previous || start > end) {
            anchor = start; end = start + BATCH
        } else {
            val rows = (start - previous) / PosterCategoryPolicy.GROUP
            end = (end.toLong() + rows.toLong() * BATCH).coerceAtMost(start.toLong() + MAX_AHEAD).toInt()
            anchor = previous + rows * PosterCategoryPolicy.GROUP
        }
        return (end - start).coerceIn(0, MAX_AHEAD)
    }
    companion object {
        const val BATCH = 15
        const val MAX_AHEAD = 25 // Five rows of five; existing per-kind file cache stays unchanged.
    }
}

/** Confined to the category coroutine context. Only two active jobs, never a full window of queued HTTP locks. */
internal class PosterReserve<T : Any>(
    private val scope: CoroutineScope,
    private val fetch: suspend (T) -> Boolean,
    private val prepare: suspend (List<T>) -> Unit,
    private val report: (Int, Int, Int) -> Unit = { _, _, _ -> }
) {
    private var targets = emptyList<T>()
    private var nearest = emptyList<T>()
    private val done = mutableSetOf<T>()
    private val failed = mutableSetOf<T>()
    private val active = linkedMapOf<T, Job>()
    private var prepareJob: Job? = null
    private var enabled = false

    fun pause() {
        enabled = false
        targets = emptyList(); nearest = emptyList()
        done.clear(); failed.clear()
        active.values.toList().forEach { it.cancel() }
        prepareJob?.cancel()
    }
    fun update(items: List<T>, visible: List<T>) {
        enabled = true
        targets = items.take(PosterReservePlan.MAX_AHEAD).distinct()
        val keep = (targets + visible).toSet()
        done.retainAll(keep); failed.retainAll(keep)
        active.filterKeys { it !in keep }.values.toList().forEach { it.cancel() }
        val next = targets.take(PosterCategoryPolicy.GROUP)
        if (next != nearest) {
            nearest = next
            prepareJob?.cancel()
            prepareJob = scope.launch { prepare(next) } // Cache only; never starts HTTP.
        }
        pump()
        status()
    }
    private fun status() { report(targets.size, targets.count { it in done }, active.size) }
    private fun pump() {
        if (!enabled || !scope.isActive) return
        while (active.size < PosterNetworkBudget.BACKGROUND_REQUESTS) {
            val row = targets.chunked(PosterCategoryPolicy.GROUP).firstOrNull { batch -> batch.any { it !in done && it !in failed } } ?: return
            val url = row.firstOrNull { it !in done && it !in failed && it !in active } ?: return
            val job = scope.launch(start = CoroutineStart.LAZY) {
                try {
                    val success = fetch(url)
                    currentCoroutineContext().ensureActive()
                    if (success) {
                        done += url
                        if (url in nearest) prepare(listOf(url))
                    } else failed += url
                } catch (cancelled: CancellationException) { throw cancelled }
                catch (_: Exception) { failed += url }
            }
            active[url] = job
            // Release slots even if a rapid pause cancels a worker before its body starts.
            job.invokeOnCompletion { active.remove(url); pump(); status() }
            job.start()
        }
    }
}
