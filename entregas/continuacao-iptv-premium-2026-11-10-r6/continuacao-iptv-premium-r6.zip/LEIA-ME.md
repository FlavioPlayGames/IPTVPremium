# IPTV Premium — r6: restauração da antecipação antiga

Atualização incremental sobre a r5, conforme o funcionamento validado com o usuário a partir do java.zip antigo. Modifica seis arquivos Kotlin. Não é uma restauração integral do projeto: mantém as correções de identificação das capas e de histórico das revisões anteriores. A limpeza de código não utilizado fica para a próxima etapa.

## Funcionamento restaurado em Filmes

- Reserva inicial de 15 capas abaixo das visíveis, crescendo até 25 adiante ao navegar.
- Grupos de cinco; termina o grupo antes de avançar para o próximo. Dois trabalhadores de antecipação.
- Prepara as cinco próximas em memória e antecipa as demais como arquivos comprimidos no cache existente.
- Conserva as capas anteriores no LRU normal de memória, sem a expulsão por janela de 30 introduzida na r5.
- Conserva os downloads úteis nas mudanças normais de fileira. Na navegação rápida, pausa e retoma o plano a partir da posição final.
- Mantém os intervalos anteriores: 200 ms para estabilizar a rolagem e pausa rápida de 900 ms.

MoviePosterLoader.kt foi restaurado byte a byte a partir da base antiga enviada. O cálculo PosterReservePlan também é idêntico ao antigo. A fila foi tipada para aceitar identidades de séries, mantendo o comportamento dos grupos; conserva a correção de cancelamento antes do início de uma tarefa, para não deixar vagas presas.

## Mesma regra para Séries

O mesmo plano e a mesma fila de grupos atendem Séries Xtream e M3U, normal e Kids. Havendo capa válida do provedor, usa o fluxo existente. Faltando capa válida, a antecipação usa os dados de título/ano/IDs para a identificação verificada já implementada, grava no mesmo cache e prepara as cinco próximas. Não escolhe capas por popularidade nem volta a usar fotos de episódios rejeitadas.

As consultas antecipadas são locais no catálogo importado, preservando os filtros de categoria, favoritos, pesquisa e controle parental. Como no arquivo antigo, o menu Continuar não inicia uma reserva própria de antecipação; seus cards mantêm o carregamento e as correções de histórico/arte existentes.

A regra ativa deixa de ser a janela da r5 de 30 incluindo os visíveis. As 15 a 25 capas são adicionais às visíveis, como no código antigo validado. Não há mudança da quantidade de colunas ou da disposição da tela.

## Armazenamento e rotação

Preservadas as cotas atuais: cache descartável de 100 MB no total, até 75 MB para imagens e 125 arquivos de capas por tipo. Os arquivos dos algoritmos de armazenamento e rotação não foram modificados. A limpeza em lotes de arquivos antigos, a proteção de leitores/gravações e a contabilização dos temporários continuam no caminho de download existente.

A meta informada de 400 MB para o aplicativo completo não foi ampliada por configuração. Esta revisão não mede o tamanho completo instalado, que também inclui recursos, bancos e dados persistentes. Não cria um cache paralelo.

## Aplicar e instalar na TV

Baixe continuacao-iptv-premium-r6.zip em Downloads e execute no PowerShell:

```powershell
$projeto = "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium"
$pasta = "$env:USERPROFILE\Downloads\continuacao-iptv-premium-r6"
Unblock-File -LiteralPath "$pasta.zip"
Expand-Archive -LiteralPath "$pasta.zip" -DestinationPath $pasta -Force
Set-Location $pasta
powershell -ExecutionPolicy Bypass -File .\Aplicar.ps1 -Projeto "$projeto"
if ($LASTEXITCODE -eq 0) {
    powershell -ExecutionPolicy Bypass -File .\Instalar-TV.ps1 -Projeto "$projeto"
} else {
    throw "A aplicacao falhou. Confira a mensagem antes de compilar/instalar."
}
```

O instalador está na pasta extraída em Downloads. Compila assembleDesempenho com as configurações e a assinatura locais, escolhe a ABI da TV e instala com adb install -r. Não desinstala nem limpa dados. Não precisa reimportar a lista ou apagar caches.

O aplicador confere todos os hashes antes de copiar e cria backup. Se a base for diferente da r5, não force: a mensagem indicará o arquivo divergente. Para desfazer, use o comando e o caminho do backup mostrados na aplicação.

## Conferência na TV

Teste Filmes e Séries em Xtream e M3U: avance uma fileira, aguarde e avance novamente; volte para conferir as capas já vistas; navegue rapidamente e pare em outra fileira. Confira também o modo Kids.

Para registrar enquanto navega, execute na pasta extraída:

```powershell
powershell -ExecutionPolicy Bypass -File .\Coletar-Diagnostico.ps1 -AoVivo
```

Ctrl+C encerra. Saída: Downloads\IPTV-tempos-capas-r6.txt. Os registros PosterAheadPerf mostram batch=15 maxAhead=25 e o estado de navegação rápida. PosterReservePerf mostra target/ready/active; ready representa arquivos obtidos, sem comprovar a imagem final exibida. O filtro retém somente contadores, tempos e IDs públicos, sem URLs ou credenciais. O buffer pode incluir registros anteriores à coleta.

Os testes portáveis usam rede/bitmaps simulados. Não foi medido ganho no aparelho nesta revisão. Veja VALIDACAO.md.
