"""Testes JVM de r6: fontes reais, com adaptadores Android/DAO/rede/bitmap indicados no relatorio."""
from pathlib import Path
import argparse, os, subprocess, tempfile, shutil, urllib.request
cli=argparse.ArgumentParser(description=__doc__)
cli.add_argument('--projeto',type=Path,required=True)
cli.add_argument('--lista',type=Path,help='ZIP M3U completo, opcional')
cli.add_argument('--tools',type=Path,help='Cache local dos JARs Maven')
cli.add_argument('--java',default='java')
a=cli.parse_args();fixtures=Path(__file__).resolve().parent
root=a.projeto.resolve()/'app/src/main/java/br/com/flaviotorres/iptvpremium'
tools=a.tools or fixtures/'.tools';tools.mkdir(parents=True,exist_ok=True)
artifacts=[('org.jetbrains.kotlin','kotlin-compiler-embeddable','2.2.10'),('org.jetbrains.kotlin','kotlin-stdlib','2.2.10'),('org.jetbrains.kotlin','kotlin-script-runtime','2.2.10'),('org.jetbrains.kotlin','kotlin-reflect','1.6.10'),('org.jetbrains.kotlin','kotlin-daemon-embeddable','2.2.10'),('org.jetbrains.kotlinx','kotlinx-coroutines-core-jvm','1.8.0'),('org.jetbrains','annotations','13.0'),('org.json','json','20250517')]
jars=[]
for group,name,version in artifacts:
 dest=tools/f'{name}-{version}.jar'
 if not dest.exists():
  temporary=dest.with_suffix('.download');url=f'https://repo.maven.apache.org/maven2/{group.replace(".","/")}/{name}/{version}/{dest.name}'
  with urllib.request.urlopen(url,timeout=120) as response,temporary.open('wb') as output:shutil.copyfileobj(response,output)
  temporary.replace(dest)
 jars.append(str(dest.resolve()))
cp=os.pathsep.join(jars)
def run(*args):subprocess.run(list(map(str,args)),check=True)
with tempfile.TemporaryDirectory(prefix='iptv-r6-host-') as tmp:
 work=Path(tmp)
 for group in ['shared','poster','parser','common']:
  (work/group).mkdir()
  for p in (fixtures/group).glob('*.kt'):shutil.copyfile(p,work/group/p.name)
 for source,model,fn in [('ui/components/UnifiedMediaCatalog.kt','CatalogPoster','catalogContinuePosters'),('ui/kids/KidsMediaCatalog.kt','KidsPoster','kidsContinuePosters')]:
  text=(root/source).read_text(encoding='utf-8-sig');start=text.index('internal data class '+model+'(');end=text.index('\n\n',start);fstart=text.index('internal fun '+fn+'(');fend=text.index('\n}',fstart)+2
  (work/'shared'/(model+'.kt')).write_text('package host\nimport br.com.flaviotorres.iptvpremium.data.history.WatchHistoryEntry\nimport br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType\n'+text[start:end]+'\n'+text[fstart:fend],encoding='utf-8')
 def compile(name,production,adapters):
  jar=work/(name+'.jar')
  run(a.java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',jar,*[root/f for f in production],*[work/f for f in adapters])
  return str(jar)+os.pathsep+cp
 shared=compile('shared',['data/history/SharedLibraryStore.kt','data/history/WatchHistoryStore.kt','data/history/ContentIdentity.kt','data/history/HistoryWorkPolicy.kt','data/history/HistoryProfile.kt','data/history/HistoryProfileMigration.kt','data/history/PlayerFavoriteMigration.kt','data/history/ProviderMovieIdentity.kt','domain/model/FavoriteScope.kt'],['shared/'+p.name for p in (work/'shared').glob('*.kt')])
 for main in ['SharedMainKt','PolicyMainKt','ArtworkIdentityMainKt','HistoryMainKt']:run(a.java,'-cp',shared,'host.'+main)
 metadata=['data/cache/PosterRequestLocks.kt','data/repository/CatalogMetadataCache.kt','data/repository/CatalogMetadataDiskCache.kt','data/repository/CatalogMetadataIdentity.kt','data/repository/SeriesCatalogPosterResolver.kt','data/repository/SeriesArtworkIdentityResolver.kt']
 poster=compile('poster',['ui/movies/CatalogPosterFallback.kt','data/cache/GenericPosterPolicy.kt','data/cache/PosterCategoryPolicy.kt','data/cache/PosterReserve.kt','data/cache/PosterNetworkBudget.kt']+metadata,['poster/'+p.name for p in (work/'poster').glob('*.kt') if p.name!='StorageMain.kt']+['shared/Context.kt','common/Budget.kt','common/Log.kt','common/CacheMain.kt'])
 run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.ui.movies.VisibleMainKt')
 run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.data.cache.ReserveMainKt')
 for mode in ['write','read']:run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.data.repository.CacheMainKt',mode,work/'metadata-cache')
 parser=compile('parser',['data/m3u/M3uCatalogParser.kt','data/m3u/M3uCatalogFormat.kt','data/m3u/M3uSeriesPosterSelection.kt','data/m3u/M3uSeriesImagePolicy.kt','data/cache/importer/M3uEntryClassifier.kt','data/cache/importer/M3uEntryMetadata.kt','data/m3uepisodes/M3uEpisodeSource.kt','data/cache/entity/CachedEpisodeEntity.kt'],['parser/SelectionMain.kt','common/ParserMain.kt','common/Epg.kt','common/Log.kt','common/Room.kt'])
 run(a.java,'-cp',parser,'br.com.flaviotorres.iptvpremium.data.m3u.SelectionMainKt')
 if a.lista:run(a.java,'-Xmx768m','-cp',parser,'br.com.flaviotorres.iptvpremium.data.m3u.ParserMainKt',a.lista.resolve(),work/'m3u')
 storage=compile('storage',['core/storage/CacheStorageBudget.kt','data/cache/PosterFileLru.kt','data/cache/PosterCategoryPolicy.kt'],['poster/StorageMain.kt'])
 run(a.java,'-cp',storage,'br.com.flaviotorres.iptvpremium.core.storage.StorageMainKt')
print('Testes JVM r6 concluidos. API, imagens reais e TV exigem validacao separada.')
