# Validação — r6

## Referência e escopo

Referência: java.zip antigo enviado pelo usuário, após confirmação explícita de restaurar o funcionamento de Filmes e aplicá-lo a Séries nos dois formatos. Não foi aplicado o ZIP inteiro sobre o projeto. A revisão altera apenas seis arquivos, a partir da r5.

Comparações verificadas:

- MoviePosterLoader.kt: idêntico byte a byte ao carregador do java.zip antigo.
- PosterReservePlan: cálculo/constantes idênticos ao trecho original, incluindo início em 15, crescimento até 25, reset ao voltar/saltar e grupos de cinco.
- CacheStorageBudget.kt: idêntico byte a byte ao arquivo antigo. AppCacheStorage.kt, ImageDiskBudget.kt e PosterFileLru.kt também permanecem iguais aos fontes originais.
- Não foram modificadas as correções r4 de correspondência e/&/nomes, os seletores M3U nem as regras de histórico.

A fila PosterReserve foi generalizada para receber URLs de Filmes ou candidatos de Séries. Conserva a ordem por grupo e mantém a liberação de vagas por callback de conclusão, inclusive quando uma tarefa é cancelada antes de entrar em seu corpo. A antecipação de Séries usa o resolvedor verificado existente, com o mesmo cache. A antecipação em Continuar voltou à regra antiga (sem reserva própria).

A leitura local do repositório voltou ao tamanho antigo de página (50), com seleção de apenas 15 a 25 candidatos pelo plano e até três páginas locais em casos curtos/filtrados, como antes. As páginas continuam transportando os dados de identidade necessários às Séries, sem URLs de reprodução nesse DTO. Não há nova consulta de catálogo ao provedor.

## Testes executados

Fontes reais, com adaptadores Android/DAO e rede/bitmap simulados quando necessário:

- Reserva inicia em 15, cresce até 25 e reinicia ao voltar, saltar ou pausar: passou.
- Dois trabalhadores; bloqueio por grupo de cinco (não inicia a próxima fileira enquanto faltar o último item do grupo); preparação das cinco próximas; preservação de requisições úteis; retomada na posição final: passaram.
- Cancelamento antes de o corpo de uma tarefa iniciar não prende vagas: passou.
- Candidatos tipados de séries, inclusive URL nula, usam a mesma sequência ordenada da reserva: passou.
- Antecipação de série sem URL resolve metadados e prepara arquivo comprimido; card visível reaproveita a identificação. Capas do provedor de Filmes/Séries não iniciam buscas de identidade: passaram.
- Regressões de capas da r4: e/&, três obras distintas de Lei e Ordem com metadados sintéticos, rejeição de ambiguidade/ano/obra conflitante, preferência do provedor, cache de temporadas e prioridades de vídeo/importação: passaram.
- Regressões de histórico/Continuar normal e Kids, compactação de 2200 fatos, mais de 400 fatos, reconciliação, metadados de favoritos, conclusões e sucessores: passaram.
- Cache de metadados entre processos JVM, seleção M3U de imagens estáveis e rejeição de fotos de episódios/paisagem: passaram. Parser não alterado; a lista completa não foi reprocessada nesta revisão.
- Rotação com os algoritmos reais e cotas reduzidas para teste: liberação em lotes, proteção de leitores/gravações, reserva de temporários, recusa de excesso e LRU por quantidade: passaram. Constantes reais preservadas em 100 MB de cache, 75 MB para imagens e 125 capas por tipo. Não é uma medição do tamanho total instalado contra a meta de 400 MB.

Aplicação/reversão/coletor: passaram em PowerShell 7 e com o comportamento de arrays JSON do Windows PowerShell 5.1 simulado. Conferidos hashes, reaplicação, reversão, recusa de base diferente e proteção de edições posteriores. Coletor ADB simulado passou em buffer/ao vivo, preservando os registros de tempo e os novos formatos de reserva/pausa e rejeitando URLs/campos extras. Não executado em Windows ou TV física nesta revisão.

`:app:compileDesempenhoKotlin :app:lintDesempenho` concluídos com BUILD SUCCESSFUL. Lint: zero erros, 178 avisos e 6 sugestões. Mantida a configuração desempenho existente, sem alterar versão/assinatura.

Para repetir os testes JVM:

```powershell
python .\testes\Testar-Host.py --projeto "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium" --tools "PASTA_DOS_JARS"
```

--tools é opcional; sem cache, baixa as dependências Maven. Não foi publicado APK, alterada assinatura, instalado remotamente ou medido ganho na TV. Os testes de metadados/bitmap não substituem a conferência da imagem real e da navegação no aparelho.
