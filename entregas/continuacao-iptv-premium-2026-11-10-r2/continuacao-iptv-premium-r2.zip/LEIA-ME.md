# Continuação IPTV Premium — correções localizadas (r2)

A revisão r2 corrige o aplicador para o comportamento de arrays do Windows PowerShell 5.1. Os fontes Kotlin são os mesmos da primeira entrega.

Este pacote altera sete arquivos Kotlin dos fontes enviados nesta conversa. Mantém a versão 1.13, versionCode 15 da base recebida e a configuração de assinatura. Não contém APK, recursos grandes, listas M3U, local.properties, google-services.json ou credenciais.

## O que mudou

- **Capas M3U:** a primeira imagem de The Dark (2026) [L], Knot (2026) [L] e Krypto Salva o Dia era exatamente a URL usada pelo filme 13 Horas. O parser original preservava essa primeira imagem. A seleção agora evita uma imagem quando a própria importação a associa a um filme e a nomes distintos de séries. Usa a primeira alternativa do provedor entre até oito URLs distintas da série; sem alternativa, usa o fallback genérico existente. Não faz pesquisa TMDB do catálogo, não baixa imagens antecipadamente e não altera Xtream. Depois de aplicar, atualize a lista M3U para regravar as capas.
- **Séries no Continuar:** corrigida a sequência em que um novo checkpoint de um episódio já considerado concluído ficava mais recente que o próximo episódio pendente, ocultando a série. A fila é reafirmada após esses checkpoints e evita regravação quando o próximo episódio já é o mais recente. Não altera o limiar de conclusão de 95% nem a regra de filmes. Outros relatos de desaparecimento ainda exigem teste na TV.
- **Temporada no Continuar:** a apresentação recebe o mesmo título e os mesmos IDs TMDB/IMDb do catálogo usado na preparação da imagem durante a reprodução. O Continuar normal e Kids passa esses IDs e a temporada ao carregador existente, permitindo reencontrar o cache em disco. O IMDb de apresentação é transitório e não muda o formato de persistência do histórico.
- **Atualizar:** a conclusão bem-sucedida do pedido manual persistido agora navega para a Home principal. A atualização silenciosa continua no caminho existente. As regras de controle parental continuam sendo aplicadas à Home.

O cache RAM de temporadas no player, o transporte Xtream e as configurações de vídeo não foram modificados.

## Aplicar no Windows

Feche o aplicativo em execução no Android Studio e extraia este pacote para uma pasta. No PowerShell aberto nessa pasta:

```powershell
& .\Aplicar.ps1 -Projeto "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium"
```

O script verifica SHA-256 dos arquivos originais e do pacote antes de copiar. Se a base divergir, ele recusa a aplicação. Guarda os originais em `.iptv-backups` dentro do projeto e mostra o comando exato para desfazer. Não reaplique pacotes antigos por cima.

Para validar e compilar no seu computador, com a configuração de assinatura que você já usa:

```powershell
Set-Location "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium"
& .\gradlew.bat :app:compileDesempenhoKotlin :app:lintDesempenho
if ($LASTEXITCODE -ne 0) { throw "A validacao falhou. Confira a saida do Gradle." }
& .\gradlew.bat :app:assembleDesempenho
if ($LASTEXITCODE -ne 0) { throw "A compilacao falhou. Confira a saida do Gradle." }
```

A variante desempenho recebida usa a assinatura debug existente. Preserve seu arquivo de assinatura local. Um APK assinado com outra chave não atualiza a instalação atual. Não desinstale o aplicativo para contornar uma recusa de assinatura.

## Instalar na TV

Confira o aparelho com o ADB do seu SDK:

```powershell
& "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe" devices -l
```

Execute o instalador deste pacote, informando o identificador mostrado pelo ADB, depois de compilar localmente:

```powershell
& .\Instalar-TV.ps1 -Serial "IDENTIFICADOR_DA_TV" `
    -PastaApks "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium\app\build\outputs\apk\desempenho"
```

Use o caminho completo do script se estiver na pasta do projeto. O instalador consulta as ABIs, escolhe o APK desempenho compatível ou o universal e usa `adb install -r`. Não pareia aparelhos, não presume IP/porta, não desinstala e não apaga dados.

## Desfazer

Use o caminho de backup informado ao aplicar:

```powershell
& .\Desfazer.ps1 -Backup "CAMINHO_DO_BACKUP"
```

O script recusa sobrescrever edições posteriores. A reversão restaura os fontes; para reverter o aplicativo instalado, compile esses fontes com a mesma assinatura e instale novamente preservando os dados.

## Validar na TV

1. Atualize manualmente a lista M3U. Confira retorno à Home principal, inclusive iniciando o fluxo após visitar Séries/Kids. Confira também que uma atualização silenciosa não troca a tela.
2. Abra os três exemplos de capas. Os testes confirmaram a troca das URLs; o conteúdo visual entregue pelo CDN ainda precisa ser visto na TV.
3. Pause uma série antes de 95%, volte ao Continuar e confira o progresso.
4. Passe de 95%, deixe ocorrerem novos checkpoints, saia e confira o próximo episódio pendente. Teste também a conclusão real e o último episódio disponível.
5. Assista a uma temporada com capa preparada, feche/reabra o aplicativo e confira o Continuar normal e Kids separadamente. Sem imagem disponível, deve ficar a capa do provedor.
6. Atualize/troque a lista e confira histórico e favoritos. A correspondência entre listas continua na implementação existente.
7. Confira Xtream e o cache RAM de temporadas no player. Nenhum teste físico foi executado nesta entrega.

Consulte `VALIDACAO.md` para os resultados e limites reais e `PENDENCIAS-LEGENDAS.md` para a integração com o site.
