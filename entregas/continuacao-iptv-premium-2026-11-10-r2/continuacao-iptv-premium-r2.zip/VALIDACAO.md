# Validação executada — 10/11/2026

## Resultado Android

Executado no projeto reconstruído com os arquivos enviados:

```text
:app:compileDesempenhoKotlin
:app:lintDesempenho
BUILD SUCCESSFUL
```

A compilação Kotlin/Java e o Lint da variante desempenho passaram. O relatório XML do Lint contém **0 erros, 176 avisos e 6 sugestões**. Nenhum apontamento do relatório incide nas linhas inseridas/substituídas por este pacote; os avisos gerais do projeto não foram ocultados ou suprimidos.

Ferramentas: Gradle 9.6.0, AGP 9.4.1, JDK 25 e Android SDK Platform 37.0, com Build Tools 36.0.0 selecionado pelo build. O manifesto mesclado confirmou pacote `br.com.flaviotorres.iptvpremium`, versão 1.13 e versionCode 15.

A preparação do ambiente exigiu instalar ferramentas/SDK e ajustar caminhos locais de cache. Esses ajustes não fazem parte dos arquivos entregues. Não foi gerado APK assinado, não foi executado R8/empacotamento final e não houve instalação física na TV.

## Parser M3U — lista completa fornecida

Executados com o compilador Kotlin JVM os fontes originais e corrigidos do parser e do armazenamento adiado de episódios. O leitor consumiu diretamente o M3U dentro do ZIP de 7.874.814 bytes; o arquivo M3U tem 85.921.420 bytes.

| Registro preparado | Original | Corrigido |
|---|---:|---:|
| Canais | 2.355 | 2.355 |
| Filmes | 44.098 | 44.098 |
| Episódios | 283.538 | 283.538 |
| Séries | 9.804 | 9.804 |
| Categorias | 104 | 104 |

Os 329.991 itens foram mantidos. A comparação de todos os registros binários confirmou alterações **somente na coluna de capa de 514 séries**: 254 receberam uma alternativa do provedor e 260 ficaram com a URL nula para usar o fallback genérico existente. Os arquivos de episódios e seus índices ficaram byte a byte idênticos. IDs, ordem, categorias, títulos, URLs de reprodução e campos restantes não mudaram nessa comparação.

Nos três exemplos, o primeiro logo era a mesma URL do filme 13 Horas, com nome de imagem `K4lEgO47Axbidt5MJo5KljpP3G.jpg`. O parser original escolheu essa URL nos três casos. O corrigido escolheu:

| Série | Imagem selecionada do próprio M3U |
|---|---|
| The Dark (2026) [L] | lQ6VXc4ifWw2CVmY8IcxUa2fzzQ.jpg |
| Knot (2026) [L] | pP81AKx1AwHWRGPwSyAGyDvS9v3.jpg |
| Krypto Salva o Dia | kcIF01S5674EzsvwyNE2oY9Y65Q.jpg |

O teste usa os códigos reais do parser, formato e armazenamento de episódios. As anotações Room, Log Android e descoberta XMLTV foram substituídas por adaptadores de teste JVM. Não houve execução do writer Room/SQLite no Android nem importação em um aparelho. A ligação entre a coluna preparada, o INSERT e os campos de leitura foi inspecionada no código.

O acesso a `image.tmdb.org` retornou bloqueio de CONNECT do proxy (403). Assim, a troca das URLs foi comprovada, mas não a aparência nem a identidade visual dos bytes servidos por cada imagem. O fallback genérico não identifica a obra; ele evita mostrar a imagem detectada como compartilhada com um filme.

## Histórico e capas da temporada — testes isolados

- Reproduzido o desaparecimento: após enfileirar o próximo episódio, um novo checkpoint do episódio concluído fica mais recente e o filtro do Continuar oculta a série.
- Com a chamada corrigida, sucessivos checkpoints mantêm o próximo episódio pendente como mais recente.
- Repetir a fila quando ela já está correta não regrava o checkpoint.
- O progresso já existente do próximo episódio é preservado.
- Um sucessor já concluído não é recolocado na fila.
- Kids e normal usam preferências distintas no teste.
- As regras de exibição de filmes permanecem no teste.
- As funções reais que montam os cards normal/Kids, extraídas dos fontes em teste, preservam TMDB, IMDb e temporada.
- A preparação da capa usou uma resposta TMDB simulada. Outro processo JVM, com RAM vazia, leu a temporada correta do cache JSON real em disco. IDs distintos e temporada sem imagem não reaproveitaram indevidamente a capa.

Esses testes executam WatchHistoryStore e os componentes de metadados, com Context/SharedPreferences e a reserva de armazenamento simulados. O SharedLibraryStore foi substituído por um adaptador local; portanto, não validam por si só correspondência real entre listas, comportamento de Android SharedPreferences, rede TMDB ou reprodução na TV.

O retorno da atualização manual à Home foi revisado no fluxo e incluído na compilação Android/Lint; não foi automatizada a navegação em dispositivo. O caminho de atualização silenciosa não foi alterado.

## Scripts de entrega

Executados em PowerShell 7.5.2 no Linux:

- aplicação numa cópia da base e conferência dos hashes resultantes;
- reaplicação idempotente;
- recusa de base divergente;
- recusa de reversão após edição posterior;
- reversão e restauração exata dos arquivos originais, incluindo remoção do novo arquivo;
- instalação com **ADB simulado**, escolhendo arm64-v8a e usando `install -r`.

Não houve teste de PowerShell no Windows nem instalação real por ADB. Os scripts não executam uninstall ou limpeza de dados.

## Reproduzir os testes JVM

Requer Python 3, Java e acesso ao Maven Central para os JARs do compilador Kotlin 2.2.10 e dependências públicas. Na pasta deste pacote:

```powershell
python .\testes\Testar-Host.py --projeto "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium"
```

Para incluir o teste do parser com a lista completa:

```powershell
python .\testes\Testar-Host.py --projeto "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium" --lista "CAMINHO_DO_Flavio8595-full.zip"
```

O runner usa uma pasta temporária para a preparação do M3U e remove os arquivos ao terminar. Não inclui sua lista ou credenciais no pacote. A comparação original × corrigido foi executada separadamente durante esta entrega; o runner distribuído testa os fontes presentes no caminho indicado.

## Ainda pendente

Validação física dos quatro comportamentos na TV, testes reais com listas diferentes e com ambos os mecanismos de reprodução; integração real com SubDL/OpenSubtitles, fontes atuais do site e estado do Worker publicado. A promoção para a versão oficial permanece posterior à estabilização. Consulte os demais documentos do pacote.

## Revisão r2 — compatibilidade do aplicador

Corrigida a leitura do manifesto JSON em Aplicar.ps1. O uso anterior de `@(comando | ConvertFrom-Json)` podia preservar o array inteiro como um único item no Windows PowerShell 5.1. O acesso a `item.path` então produzia vários caminhos, recusados pelo Join-Path. A falha ocorria na validação inicial, antes de backup/cópia.

Agora o resultado do ConvertFrom-Json é atribuído diretamente e depois normalizado em array por variável. A validação também exige que cada caminho seja uma string. O Desfazer.ps1 recebeu a mesma proteção de tipo para caminhos. Os sete arquivos Kotlin e seus hashes no manifesto permaneceram idênticos aos da primeira entrega.

Executado teste de regressão em PowerShell 7: o script anterior falhou ao simular a saída não enumerada do ConvertFrom-Json do Windows PowerShell 5.1; o corrigido passou tanto com o comportamento nativo do PowerShell 7 quanto com a simulação. Foram conferidos aplicação, reaplicação, hashes, reversão, recusa de base diferente e proteção de edições posteriores. Não foi executado Windows PowerShell 5.1 nativo. A compilação Android anterior continua válida porque os fontes Kotlin não mudaram.
