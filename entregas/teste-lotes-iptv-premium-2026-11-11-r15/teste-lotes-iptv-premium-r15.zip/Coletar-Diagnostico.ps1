﻿[CmdletBinding()]
param(
    [Alias('Tv')][string]$Serial = '',
    [string]$Adb = "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe",
    [string]$Saida = "$env:USERPROFILE\Downloads\IPTV-capas-r15.txt",
    [switch]$AoVivo
)
$ErrorActionPreference = 'Stop'
if (!(Test-Path -LiteralPath $Adb -PathType Leaf)) { throw "ADB nao encontrado: $Adb" }
function Ler-Adb([string[]]$Argumentos) {
    $anterior=$ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        $linhas=@(& $Adb @Argumentos 2>&1)
        $codigo=$LASTEXITCODE
    } finally { $ErrorActionPreference=$anterior }
    if($codigo -ne 0){throw 'Falha ao consultar o ADB.'}
    $linhas | ForEach-Object { "$_" }
}
$conectados=@(Ler-Adb -Argumentos @('devices','-l') | ForEach-Object {
    if($_ -match '^(\S+)\s+device(?:\s+(.*))?$') {[PSCustomObject]@{Serial=$Matches[1];Detalhes=[string]$Matches[2]}}
})
if([string]::IsNullOrWhiteSpace($Serial)) {
    $tv=@($conectados | Where-Object {$_.Detalhes -match '(?:^|\s)(?:model:Smart_TV_Pro|product:G08_4K_GB|device:G08)(?:\s|$)'})
    if($tv.Count -eq 1){$Serial=$tv[0].Serial}
    elseif($tv.Count -eq 0 -and $conectados.Count -eq 1){$Serial=$conectados[0].Serial}
    else{throw 'Nao foi possivel escolher uma unica TV autorizada. Confira adb devices -l ou informe -Serial.'}
}
if($Serial -notmatch '^[A-Za-z0-9._:-]+$' -or @($conectados | Where-Object {$_.Serial -eq $Serial}).Count -ne 1){throw 'TV nao conectada/autorizada.'}
# Only strictly formatted counters, public IDs/hashes and timing fields enter the export.
function Testar-Linha([string]$Linha) {
    $Linha -cmatch '^kind=MOVIES stage=binding event=(?:HIT|SAVED) bindingHash=[0-9a-f]{12}$' -or
    $Linha -cmatch '^endpoint=get_vod_info escopo=(?:completo|categoria) httpMs=-?[0-9]+ parsingMs=-?[0-9]+ totalMs=[0-9]+ fase=(?:http|parsing) status=(?:OK|FALHA|CANCELADO) erro=[A-Za-z0-9_$]+$' -or
    $Linha -cmatch '^kind=(?:MOVIES|SERIES) stage=fallback source=(?:PROVIDER|TMDB|NONE) workHash=[0-9a-f]{12} elapsedMs=[0-9]+$' -or
    $Linha -cmatch '^stage=local phase=(?:CONTINUE|FAVORITES|ALL) kind=(?:movies|series) elapsedMs=[0-9]+$' -or
    $Linha -cmatch '^stage=match phase=(?:CONTINUE|FAVORITES|ALL) kind=(?:movies|series|all) scanned=[0-9]+ matched=[0-9]+$' -or
    $Linha -cmatch '^kind=(?:MOVIES|SERIES) first=[0-9]+ last=[0-9]+ direction=(?:DOWN|UP) visible=[0-9]+ ahead=[0-9]+ behind=[0-9]+ target=[0-9]+ limit=30$' -or
    $Linha -cmatch '^kind=(?:MOVIES|SERIES) target=[0-9]+ ready=[0-9]+ active=[0-9]+$' -or
    $Linha -cmatch '^kind=(?:MOVIES|SERIES) rapid=(?:true|false) batch=15 maxAhead=25$' -or
    $Linha -cmatch '^profile=(?:normal|kids)(?: [a-z_]+=[0-9]+)+$' -or
    $Linha -cmatch '^fonte=tmdb http=[0-9]{3}$' -or
    $Linha -cmatch '^stage=identity status=(?:OK|UNRESOLVED) source=(?:REMOTE|CACHE) workHash=[0-9a-f]{12}(?: tmdbId=[0-9]+)?$' -or
    $Linha -cmatch '^stage=lookup status=(?:OK|UNRESOLVED) source=(?:REMOTE|CACHE) workHash=[0-9a-f]{12} elapsedMs=[0-9]+$' -or
    $Linha -cmatch '^stage=lookup_queue elapsedMs=[0-9]+$' -or
    $Linha -cmatch '^kind=(?:MOVIES|SERIES) stage=load success=(?:true|false) elapsedMs=[0-9]+$' -or
    $Linha -cmatch '^kind=(?:MOVIES|SERIES) stage=ready success=(?:true|false) fileMs=[0-9]+ decodeMs=[0-9]+$' -or
    $Linha -cmatch '^kind=(?:MOVIES|SERIES) stage=download background=(?:true|false) success=(?:true|false) queueMs=[0-9]+ fetchAndPrepareMs=[0-9]+$' -or
    $Linha -cmatch '^kind=(?:MOVIES|SERIES) outcome=(?:unknown|priority_busy|storage_path|storage_directory|http_status|image_too_large|cache_budget|empty_body|image_prepare|success|storage_commit|cancelled|priority_interrupted|activity_interrupted|timeout|io_error|error) background=(?:true|false) httpStatus=[0-9]{1,3} exception=[A-Za-z0-9_$]+$'
}
$argumentos=@('-s',$Serial,'logcat','-v','raw','-s','XtreamEndpointPerf:I','PosterBindingPerf:I','PosterFallbackPerf:I','HistoryHandoffPerf:I','ContinueTrace:I','SeriesPosterPerf:I','SeriesArtwork:D','PosterLoadPerf:D','PosterDownloadResult:D','PosterWindowPerf:D','PosterReservePerf:D','PosterAheadPerf:D','*:S')
if($AoVivo) {
    Set-Content -LiteralPath $Saida -Value @() -Encoding UTF8
    Write-Host "Coletando na TV. Abra o catalogo, aguarde, saia e reabra. Ctrl+C encerra. Arquivo: $Saida"
    $anterior=$ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        & $Adb @argumentos 2>$null | ForEach-Object {
            $linha="$_"
            if(Testar-Linha $linha) {
                Add-Content -LiteralPath $Saida -Value $linha -Encoding UTF8
                Write-Host $linha
            }
        }
    } finally { $ErrorActionPreference=$anterior }
} else {
    $argumentos=@('-s',$Serial,'logcat','-d','-v','raw','-s','XtreamEndpointPerf:I','PosterBindingPerf:I','PosterFallbackPerf:I','HistoryHandoffPerf:I','ContinueTrace:I','SeriesPosterPerf:I','SeriesArtwork:D','PosterLoadPerf:D','PosterDownloadResult:D','PosterWindowPerf:D','PosterReservePerf:D','PosterAheadPerf:D','*:S')
    $contagens=@(Ler-Adb -Argumentos $argumentos | Where-Object {Testar-Linha "$_"})
    if($contagens.Count -eq 0){throw 'Nenhum registro encontrado. Use -AoVivo e reproduza o carregamento dos catalogos na TV.'}
    $contagens | Set-Content -LiteralPath $Saida -Encoding UTF8
    Write-Host "Diagnostico filtrado salvo em: $Saida"
}
