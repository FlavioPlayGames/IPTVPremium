"""Actual Xtream parsers, real JSON, explicit Android JsonReader/Log JVM adapters."""
from pathlib import Path
import argparse,os,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--projeto',type=Path,required=True);p.add_argument('--tools',type=Path,required=True);p.add_argument('--java',default='java');a=p.parse_args();r=a.projeto/'app/src/main/java/br/com/flaviotorres/iptvpremium'
names=['kotlin-compiler-embeddable-2.2.10.jar','kotlin-stdlib-2.2.10.jar','kotlin-script-runtime-2.2.10.jar','kotlin-reflect-1.6.10.jar','kotlin-daemon-embeddable-2.2.10.jar','kotlinx-coroutines-core-jvm-1.8.0.jar','annotations-13.0.jar','json-20250517.jar','gson-2.11.0.jar'];cp=os.pathsep.join(str(a.tools/n)for n in names)
files=[r/s for s in ['data/parser/DefaultXtreamParser.kt','data/parser/XtreamParser.kt','data/parser/XtreamDirectCatalogReader.kt','data/parser/XtreamArrayStream.kt','data/cache/ImportTuningPolicy.kt','data/cache/PosterSourceUrl.kt']]+list((r/'domain/model').glob('*.kt'))+list(Path(__file__).parent.glob('*.kt'))
with tempfile.TemporaryDirectory()as td:
 jar=Path(td)/'batch.jar';subprocess.run([a.java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',str(jar),*map(str,files)],check=True);subprocess.run([a.java,'-Xmx768m','-cp',str(jar)+os.pathsep+cp,'host.xtream.BatchMainKt'],check=True)
