package host.xtream
import br.com.flaviotorres.iptvpremium.data.parser.*
import br.com.flaviotorres.iptvpremium.data.cache.*
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.StringReader
fun main()=runBlocking {
 val parser=DefaultXtreamParser();val profile=ImportProfile.DEFAULT
 check(profile.batchSize==2000&&profile.batchCharacters==2*1024*1024&&profile.m3uBatchSize==500&&profile.m3uBatchCharacters==512*1024)
 check(ImportProfile.stored("XTREAM_500",false)==profile)
 fun rows(count:Int,large:Boolean=false)=JSONArray().also{array->repeat(count){i->array.put(JSONObject().put("stream_id",i+1).put("name",if(large)"Movie $i "+"X".repeat(4000)else"Movie $i").put("tmdb_id",10000+i).put("movie_image","https://cdn.example/$i.jpg"))}}.toString()
 for(count in listOf(0,1,1999,2000,2001,44192)) {
  val text=rows(count);val seen=mutableListOf<Int>();val sizes=mutableListOf<Int>()
  val stats=XtreamDirectCatalogReader.read(StringReader(text),"get_vod_streams",parser){batch->sizes.add(batch.movies.size);seen.addAll(batch.movies.map{it.id.toInt()});delay(1)}
  check(stats.records==count.toLong()&&seen==(1..count).toList())
  check(sizes.all{it in 1..2000}&&sizes.size==(count+1999)/2000)
  check(seen.distinct().size==count)
 }
 println("PASS: actual direct parser retains ordered IDs/covers across 0/1/1999/2000/2001/44192 records; 44192 emits 23 batches")
 val largeSizes=mutableListOf<Int>()
 XtreamDirectCatalogReader.read(StringReader(rows(2200,true)),"get_vod_streams",parser){batch->largeSizes.add(batch.movies.size)}
 check(largeSizes.sum()==2200&&largeSizes.size>2&&largeSizes.max()<2000)
 val framed=mutableListOf<Int>();val ids=mutableListOf<Int>()
 XtreamArrayStream.read(StringReader(rows(44192)),"get_vod_streams"){chunk,count->framed.add(count);val batch=parser.parseCatalogBatch("get_vod_streams",chunk);ids.addAll(batch.movies.map{it.id.toInt()})}
 check(framed==List(22){2000}+192&&ids==(1..44192).toList())
 println("PASS: character threshold flushes large records early; legacy streaming framing shares the 2000 limit and preserves all rows")
 var callbacks=0;val first=CompletableDeferred<Unit>();val release=CompletableDeferred<Unit>()
 val producer=launch{XtreamDirectCatalogReader.read(StringReader(rows(4500)),"get_vod_streams",parser){callbacks++;if(callbacks==1){first.complete(Unit);release.await()}}}
 first.await();delay(30);check(callbacks==1);release.complete(Unit);producer.join();check(callbacks==3)
 val entered=CompletableDeferred<Unit>();val cancelled=launch{XtreamDirectCatalogReader.read(StringReader(rows(4500)),"get_vod_streams",parser){entered.complete(Unit);awaitCancellation()}}
 entered.await();cancelled.cancelAndJoin()
 println("PASS: backpressure pauses producer until consumer completes; cancellation stops import without emitting remaining batches")
}
