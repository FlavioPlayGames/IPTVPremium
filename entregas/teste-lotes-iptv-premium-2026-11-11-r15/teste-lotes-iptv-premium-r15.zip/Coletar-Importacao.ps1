﻿[CmdletBinding()]
param(
    [Alias('Tv')][string]$Serial = '',
    [string]$Adb = "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe",
    [string]$Saida = "$env:USERPROFILE\Downloads\IPTV-importacao-r15.txt",
    [switch]$AoVivo
)
$ErrorActionPreference = 'Stop'
if (!(Test-Path -LiteralPath $Adb -PathType Leaf)) { throw "ADB nao encontrado: $Adb" }
function Ler-Adb([string[]]$Argumentos) {
    $anterior=$ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        $linhas=@(& $Adb @Argumentos 2>&1)
        $codigo=$LASTEXITCODE
    } finally { $ErrorActionPreference=$anterior }
    if($codigo -ne 0){throw 'Falha ao consultar o ADB.'}
    $linhas | ForEach-Object { "$_" }
}
$conectados=@(Ler-Adb -Argumentos @('devices','-l') | ForEach-Object {
    if($_ -match '^(\S+)\s+device(?:\s+(.*))?$') {[PSCustomObject]@{Serial=$Matches[1];Detalhes=[string]$Matches[2]}}
})
if([string]::IsNullOrWhiteSpace($Serial)) {
    $tv=@($conectados | Where-Object {$_.Detalhes -match '(?:^|\s)(?:model:Smart_TV_Pro|product:G08_4K_GB|device:G08)(?:\s|$)'})
    if($tv.Count -eq 1){$Serial=$tv[0].Serial}
    elseif($tv.Count -eq 0 -and $conectados.Count -eq 1){$Serial=$conectados[0].Serial}
    else{throw 'Nao foi possivel escolher uma unica TV autorizada. Confira adb devices -l ou informe -Serial.'}
}
if($Serial -notmatch '^[A-Za-z0-9._:-]+$' -or @($conectados | Where-Object {$_.Serial -eq $Serial}).Count -ne 1){throw 'TV nao conectada/autorizada.'}

function Testar-Importacao([string]$Linha) {
    $Linha -cmatch '^endpoint=(?:get_vod_streams|get_series|get_live_streams) modo=STREAM leitor=(?:JSON_READER|LEGADO) aceitos=[0-9]+ parsingMs=[0-9]+ gravacaoMs=[0-9]+ lotes=[0-9]+ gravacaoPicoMs=[0-9]+ totalMs=[0-9]+ heapKb=[0-9]+ heapPicoObservadoKb=[0-9]+ status=(?:OK|FALHA|CANCELADO)$' -or
    $Linha -cmatch '^endpoint=(?:get_vod_streams|get_series|get_live_streams) records=[0-9]+ characters=[0-9]+ decodeMs=[0-9]+ readerMs=[0-9]+$' -or
    $Linha -cmatch '^type=(?:movies|series) rows=[0-9]+ transactionLimit=2000 durationMs=[0-9]+$' -or
    $Linha -cmatch '^READER_HEADERS endpoint=(?:get_vod_categories|get_vod_streams|get_series_categories|get_series|get_live_categories|get_live_streams) http=-?[0-9]+ ateCabecalhosMs=[0-9]+$' -or
    $Linha -cmatch '^READER endpoint=(?:get_vod_categories|get_vod_streams|get_series_categories|get_series|get_live_categories|get_live_streams) http=-?[0-9]+ ateCabecalhosMs=-?[0-9]+ leitorProntoMs=-?[0-9]+ duracaoMs=[0-9]+$' -or
    $Linha -cmatch '^endpoint=(?:authenticate|get_vod_categories|get_series_categories|get_live_categories) escopo=(?:completo|categoria) httpMs=-?[0-9]+ parsingMs=-?[0-9]+ totalMs=[0-9]+ fase=(?:http|parsing) status=(?:OK|FALHA|CANCELADO) erro=[A-Za-z0-9_$]+$' -or
    $Linha -cmatch '^PERF etapa=XTREAM_TOTAL modo=STREAM duracaoMs=[0-9]+$' -or
    $Linha -cmatch '^SYNC_RESUMO tipo=(?:M3U|XTREAM) resultado=(?:SUCESSO|ERRO|CANCELADA) duracaoMs=[0-9]+ heapAntesKb=[0-9]+ heapDepoisKb=[0-9]+$' -or
    $Linha -cmatch '^revisao=db-r2 perfil=(?:PADRAO|ATUAL|WAL|NORMAL|LOTES|XTREAM_1000|XTREAM_500|XTREAM_650) journal=(?:wal|truncate|delete|persist|memory|off) synchronous=[0-9]+ lote=[0-9]+ limiteCaracteres=[0-9]+ loteM3u=[0-9]+ limiteCaracteresM3u=[0-9]+$' -or
    $Linha -cmatch '^Troca READY -> ACTIVE concluída. duracaoMs=[0-9]+$' -or
    $Linha -cmatch '^etapa=(?:cache_ativacao|cache_consulta|catalogo_importacao|catalogo_finalizacao|abertura_concluida) duracaoMs=[0-9]+$' -or
    $Linha -cmatch '^etapa=interface_liberada totalMs=[0-9]+$' -or
    $Linha -cmatch '^etapa=catalogo_abertura cache=(?:true|false) remoto=(?:true|false) pedidoJaImportado=(?:true|false)$' -or
    $Linha -cmatch '^etapa=selecao_catalogo cache=(?:true|false)$' -or
    $Linha -cmatch '^Fluxo da playlist iniciado\. isAlreadyActive=(?:true|false)$' -or
    $Linha -cmatch '^(?:saveActivePlaylistId\(\) concluída|Estados Compose atualizados|navigate\(Home\) retornou)\. duracaoMs=[0-9]+$' -or
    $Linha -cmatch '^finally concluído\. loadingPlaylistId=null; duracaoMs=[0-9]+$'
}
$argumentos=@('-s',$Serial,'logcat','-T','1','-v','raw','-s','XtreamEndpointPerf:I','XtreamDirectPerf:I','XtreamWritePerf:I','PlaylistConnection:I','M3uSourceSync:I','DbPerf:I','CacheGeneration:I','StartupPerf:I','NavigationPerf:I','*:S')
if(!$AoVivo){$argumentos=@('-s',$Serial,'logcat','-d','-v','raw','-s','XtreamEndpointPerf:I','XtreamDirectPerf:I','XtreamWritePerf:I','PlaylistConnection:I','M3uSourceSync:I','DbPerf:I','CacheGeneration:I','StartupPerf:I','NavigationPerf:I','*:S')}
Set-Content -LiteralPath $Saida -Value 'diagnostico=importacao-r15 tempos=ms memoria=kb' -Encoding UTF8
if($AoVivo) {
    $perfil=@(Ler-Adb -Argumentos @('-s',$Serial,'logcat','-d','-v','raw','-s','DbPerf:I','*:S') | Where-Object {Testar-Importacao "$_"} | Select-Object -Last 1)
    if($perfil.Count -gt 0){Add-Content -LiteralPath $Saida -Value $perfil -Encoding UTF8}
    Write-Host 'Coletando. Atualize a lista Xtream na TV e aguarde a conclusao. Ctrl+C encerra.'
}
try {
    & $Adb @argumentos 2>$null | ForEach-Object {
        $linha="$_"
        if(Testar-Importacao $linha){Add-Content -LiteralPath $Saida -Value $linha -Encoding UTF8;if($AoVivo){Write-Host $linha}}
    }
    if($LASTEXITCODE -ne 0){throw 'Falha ao consultar logcat.'}
} finally { Write-Host "Diagnostico salvo em: $Saida" }
