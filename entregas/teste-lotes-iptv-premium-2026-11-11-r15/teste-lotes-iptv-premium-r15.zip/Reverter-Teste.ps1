[CmdletBinding()]
param(
    [string]$Projeto="$env:USERPROFILE\AndroidStudioProjects\IPTVPremium",
    [string]$Downloads="$env:USERPROFILE\Downloads"
)
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Seguranca.ps1"
$Projeto=Projeto-Valido $Projeto
if(!(Test-Path -LiteralPath $Downloads -PathType Container)){throw 'Pasta de Downloads nao encontrada.'}
$backup=$null
foreach($pasta in @(Get-ChildItem -LiteralPath $Downloads -Directory -Filter 'IPTV-restauracao-r15-*' | Sort-Object Name -Descending)) {
    $arquivo=Join-Path $pasta.FullName 'estado.json'
    if(!(Test-Path -LiteralPath $arquivo -PathType Leaf)){continue}
    $estado=Get-Content -Raw -LiteralPath $arquivo | ConvertFrom-Json
    if($estado.projeto -isnot [string]){continue}
    if([string]::Equals($estado.projeto,$Projeto,[StringComparison]::OrdinalIgnoreCase)) {
        if($estado.desfeito) {
            foreach($item in $estado.arquivos) {
                if((Hash-Arquivo (Caminho-Seguro $Projeto $item.path)) -ne $item.beforeHash){throw 'Fonte alterado apos a restauracao. Confira antes de reinstalar.'}
            }
        }
        $backup=$pasta.FullName;break
    }
}
if($null -eq $backup){throw 'Nenhum backup r15 para este projeto. Use o comando Desfazer.ps1 impresso ao aplicar, se o backup estiver em outra pasta.'}
& "$PSScriptRoot\Desfazer.ps1" -Backup $backup -Instalar
