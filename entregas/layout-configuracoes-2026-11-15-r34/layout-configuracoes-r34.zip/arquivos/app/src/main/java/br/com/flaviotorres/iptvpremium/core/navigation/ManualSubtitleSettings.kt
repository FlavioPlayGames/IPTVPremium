package br.com.flaviotorres.iptvpremium.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.paging.LoadState
import androidx.paging.compose.collectAsLazyPagingItems
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.core.player.*
import br.com.flaviotorres.iptvpremium.data.cache.PlaylistCacheDatabase
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.DeferredM3uEpisodeAccess
import br.com.flaviotorres.iptvpremium.data.remote.DefaultPlaylistHttpClient
import br.com.flaviotorres.iptvpremium.data.repository.*
import br.com.flaviotorres.iptvpremium.data.storage.PlaylistStorage
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import br.com.flaviotorres.iptvpremium.ui.components.*
import br.com.flaviotorres.iptvpremium.ui.kids.KidsSession
import kotlinx.coroutines.*

/** Pick from the active, parentally filtered catalogue; never send the catalogue to the site. */
@Composable
internal fun ManualSubtitleSettingsScreen(onBack:()->Unit) {
    val context=LocalContext.current.applicationContext
    val storage=remember(context){PlaylistStorage(context)}
    val selection by storage.selection.collectAsState(initial=null)
    val source=selection?.playlists?.firstOrNull{it.id==selection?.activeId}
    val access by ParentalPolicy.accessFlow.collectAsState(initial=ParentalPolicy.access())
    val kids by KidsSession.active.collectAsState()
    val dao=remember(context){PlaylistCacheDatabase.getInstance(context).playlistCacheDao()}
    val repository=remember(dao){PlaylistCatalogRepository(dao,context)}
    val scope=rememberCoroutineScope()
    var kind by rememberSaveable{mutableStateOf<String?>(null)}
    var contentId by rememberSaveable{mutableStateOf<String?>(null)}
    var title by rememberSaveable{mutableStateOf("")}
    var year by rememberSaveable{mutableStateOf<Int?>(null)}
    var tmdb by rememberSaveable{mutableStateOf<String?>(null)}
    var season by rememberSaveable{mutableStateOf<Int?>(null)}
    var episode by rememberSaveable{mutableStateOf<Int?>(null)}
    var sendSeason by rememberSaveable{mutableStateOf<Boolean?>(null)}
    var connecting by rememberSaveable{mutableStateOf(false)}
    var episodes by remember{mutableStateOf<List<SeriesEpisodeInfo>>(emptyList())}
    var loading by remember{mutableStateOf(false)}
    var failure by remember{mutableStateOf<String?>(null)}
    var query by rememberSaveable{mutableStateOf("")}
    var keyboard by remember{mutableStateOf(false)}
    var loadRevision by remember{mutableIntStateOf(0)}
    val first=remember{FocusRequester()}
    var appliedSelection by remember{mutableStateOf<String?>(null)}
    LaunchedEffect(selection?.activeId,access) {
        val revision="${selection?.activeId}|$access"
        if(appliedSelection!=null&&appliedSelection!=revision){kind=null;contentId=null;season=null;episode=null;connecting=false;query=""}
        appliedSelection=revision
    }
    val back:()->Unit={
        when {
            keyboard->keyboard=false
            connecting->connecting=false
            contentId!=null->{contentId=null;season=null;episode=null;sendSeason=null;query="";episodes=emptyList();failure=null}
            kind!=null->{kind=null;query=""}
            else->onBack()
        }
    }
    BackHandler(onBack=back)
    LaunchedEffect(kind,contentId,connecting,loading,episodes.size){withFrameNanos{};runCatching{first.requestFocus()}}
    LaunchedEffect(source?.id,contentId,kind,loadRevision) {
        val active=source?:return@LaunchedEffect
        val id=contentId?:return@LaunchedEffect
        if(kind!="series")return@LaunchedEffect
        loading=true;failure=null;episodes=emptyList()
        try {episodes=loadManualSeries(context,dao,active,id)}
        catch(cancelled:CancellationException){throw cancelled}
        catch(_:Exception){failure="Não foi possível carregar os episódios. Tente novamente."}
        finally{loading=false}
    }
    val target=source?.let{active->contentId?.let{id->when {
        kind=="movie"->ManualSubtitleTarget("movie",active.id,id,title,year,tmdb,kids=kids)
        season!=null&&sendSeason==true->ManualSubtitleTarget("season",active.id,id,title,year,tmdb,season=season,
            episodes=episodes.filter{it.seasonNumber==season}.map{it.episodeNumber}.distinct().sorted(),kids=kids)
        season!=null&&episode!=null->ManualSubtitleTarget("episode",active.id,id,title,year,tmdb,season,episode,kids=kids)
        else->null
    }}}
    if(connecting&&target!=null) {
        ManualSubtitleUploadScreen(target,allowed={
            selection?.activeId==target.playlistId &&
                (if(target.kind=="movie")repository.getMovieById(target.playlistId,target.contentId)?.name
                else repository.getSeriesById(target.playlistId,target.contentId)?.name)==target.title
        },onBack={connecting=false})
        return
    }
    SubtitleSettingsFrame(when{contentId!=null->"ENVIO MANUAL > ${title.uppercase()}";kind=="movie"->"ENVIO MANUAL > FILMES";kind=="series"->"ENVIO MANUAL > SÉRIES";else->"ENVIO MANUAL"},"",back) {
        if(source==null){Text("Selecione uma lista com catálogo disponível para escolher o conteúdo.",color=SettingsLook.text);return@SubtitleSettingsFrame}
        when {
            kind==null->Box(Modifier.fillMaxWidth().weight(1f),contentAlignment=androidx.compose.ui.Alignment.Center) { Row(Modifier.widthIn(max=540.dp).fillMaxWidth(),verticalAlignment=androidx.compose.ui.Alignment.CenterVertically,
                horizontalArrangement=Arrangement.spacedBy(18.dp)) {
                SubtitleLandingCard("Filme","Um arquivo para o filme","SRT ou ZIP",SubtitleSettingsIcon.MOVIE,
                    Modifier.weight(1f).heightIn(min=190.dp).focusRequester(first),onClick={kind="movie"})
                SubtitleLandingCard("Série","Temporada ou episódio","SRT ou ZIP",SubtitleSettingsIcon.SERIES,
                    Modifier.weight(1f).heightIn(min=190.dp),onClick={kind="series"})
            }
            }
            contentId==null->{
                SubtitleActionButton(if(query.isBlank())"Buscar ${if(kind=="movie")"filme"else"série"}"else "Buscar: $query",leadingIcon=SubtitleSettingsIcon.SEARCH,modifier=Modifier.fillMaxWidth(.64f).focusRequester(first)){keyboard=!keyboard}
                if(keyboard) {
                    Text(query.ifBlank{"Digite o nome"},color=SettingsLook.text,fontSize=18.sp)
                    AppKeyboard(actionText="PESQUISAR",onCharacter={query=(query+it).take(100)},onBackspace={query=query.dropLast(1)},
                        currentText=query,onReplaceAll={query=it.take(100)},onClearAll={query=""},onAction={keyboard=false})
                }else ManualCatalogPicker(repository,source.id,kind!!,query,scope,access,Modifier.weight(1f)) {id,name,release,external ->
                    contentId=id;title=name;year=release;tmdb=external;sendSeason=if(kind=="series")true else null
                }
            }
            kind=="series"&&loading->Text("Carregando episódios…",color=SubtitleVisual.muted)
            kind=="series"&&episodes.isEmpty()->Column(verticalArrangement=Arrangement.spacedBy(12.dp)) {
                Text(failure?:"Não encontramos episódios disponíveis para esta série.",color=SubtitleVisual.muted)
                SubtitleActionButton("Tentar novamente",modifier=Modifier.focusRequester(first)){loadRevision++}
            }
            kind=="series"->{
                val seasons=episodes.map{it.seasonNumber}.distinct().sorted()
                val activeSeason=season
                Row(Modifier.weight(1f).fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(30.dp)) {
                    LazyColumn(Modifier.weight(.36f).background(SettingsLook.panel,androidx.compose.foundation.shape.RoundedCornerShape(14.dp)).padding(12.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
                        items(seasons,key={it}){number->SubtitleActionButton(if(number==0)"Especiais"else"Temporada $number",
                            selected=number==activeSeason,modifier=Modifier.fillMaxWidth().then(if(number==seasons.first())Modifier.focusRequester(first)else Modifier)){
                            season=number;episode=null
                        }}
                    }
                    Box(Modifier.width(1.dp).fillMaxHeight().background(SubtitleVisual.edge.copy(alpha=.45f)))
                    Column(Modifier.weight(.64f).background(SettingsLook.panel,androidx.compose.foundation.shape.RoundedCornerShape(14.dp)).padding(16.dp),verticalArrangement=Arrangement.spacedBy(12.dp)) {
                        SubtitleActionButton("Enviar para a temporada inteira",selected=sendSeason==true){sendSeason=true;episode=null}
                        SubtitleActionButton("Escolher episódio",selected=sendSeason==false){sendSeason=false}
                        if(activeSeason==null)Text("Selecione a temporada.",color=SubtitleVisual.muted,fontSize=14.sp)
                        else if(sendSeason==false) {
                            val list=episodes.filter{it.seasonNumber==activeSeason}.distinctBy{it.episodeNumber}.sortedBy{it.episodeNumber}
                            LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)) {
                                items(list,key={it.episodeNumber}){item->SubtitleActionButton("Episódio ${item.episodeNumber}",
                                    description=item.title.takeIf{it.isNotBlank()},selected=episode==item.episodeNumber){episode=item.episodeNumber}}
                            }
                        }else Spacer(Modifier.weight(1f))
                        SubtitleActionButton("Continuar",enabled=target!=null){connecting=true}
                    }
                }
            }
            target!=null->Box(Modifier.weight(1f).fillMaxWidth(),contentAlignment=androidx.compose.ui.Alignment.Center) {
                SubtitleSurfacePanel(Modifier.widthIn(max=640.dp).fillMaxWidth()) {
                    Column(verticalArrangement=Arrangement.spacedBy(4.dp)) {
                        Text(target.title,color=SubtitleVisual.ink,fontSize=24.sp,fontWeight=androidx.compose.ui.text.font.FontWeight.Bold)
                        Text(target.description,color=SubtitleVisual.muted,fontSize=14.sp)
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(SubtitleVisual.edge.copy(alpha=.25f)))
                    Text("Anexe SRT ou ZIP pelo celular. Não é necessário renomear os arquivos.",color=SubtitleVisual.ink,fontSize=15.sp)
                    SubtitleActionButton("Conectar para enviar",modifier=Modifier.width(320.dp).focusRequester(first)){connecting=true}
                }
            }

        }
    }
}

@Composable
private fun ManualCatalogPicker(repository:PlaylistCatalogRepository,playlist:String,kind:String,query:String,
    scope:CoroutineScope,access:Any,modifier:Modifier,onChoose:(String,String,Int?,String?)->Unit) {
    val settled by produceState(query,query){delay(350L);value=query}
    var preview by remember(playlist,kind,query){mutableStateOf<Pair<String,Int?>?>(null)}
    Row(modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(26.dp)) {
    val listModifier=Modifier.weight(.60f).fillMaxHeight()
        .background(SettingsLook.panel,androidx.compose.foundation.shape.RoundedCornerShape(14.dp)).padding(12.dp)
    if(kind=="movie") {
        val flow=remember(repository,playlist,settled,access){repository.movies(playlistId=playlist,searchQuery=settled)}
        val paging=flow.collectAsLazyPagingItems()
        LazyColumn(listModifier,verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(paging.itemCount,key={index->paging.peek(index)?.id?:"empty-$index"}){index->
                val item=paging[index]
                if(item!=null)SubtitleActionButton(item.name,thumbnail=br.com.flaviotorres.iptvpremium.ui.movies.peekCatalogPoster(item.posterUrl,
                    if(kind=="movie")br.com.flaviotorres.iptvpremium.data.cache.PosterKind.MOVIES else br.com.flaviotorres.iptvpremium.data.cache.PosterKind.SERIES,
                    item.name,item.year,item.tmdbId,item.imdbId),thumbnailPlaceholder=true,onFocused={preview=item.name to item.year}){onChoose(item.id,item.name,item.year,item.tmdbId)}
            }
            item{ManualPickerStatus(paging.loadState.refresh,paging.itemCount,{paging.retry()})}
        }
    }else {
        val flow=remember(repository,playlist,settled,access){repository.series(playlistId=playlist,searchQuery=settled)}
        val paging=flow.collectAsLazyPagingItems()
        LazyColumn(listModifier,verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(paging.itemCount,key={index->paging.peek(index)?.id?:"empty-$index"}){index->
                val item=paging[index]
                if(item!=null)SubtitleActionButton(item.name,thumbnail=br.com.flaviotorres.iptvpremium.ui.movies.peekCatalogPoster(item.posterUrl,
                    if(kind=="movie")br.com.flaviotorres.iptvpremium.data.cache.PosterKind.MOVIES else br.com.flaviotorres.iptvpremium.data.cache.PosterKind.SERIES,
                    item.name,item.year,item.tmdbId,item.imdbId),thumbnailPlaceholder=true,onFocused={preview=item.name to item.year}){onChoose(item.id,item.name,item.year,item.tmdbId)}
            }
            item{ManualPickerStatus(paging.loadState.refresh,paging.itemCount,{paging.retry()})}
        }
    }
    Box(Modifier.width(1.dp).fillMaxHeight().background(SubtitleVisual.edge.copy(alpha=.45f)))
    Column(Modifier.weight(.40f).background(SettingsLook.panel,androidx.compose.foundation.shape.RoundedCornerShape(14.dp)).padding(20.dp),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text(preview?.first?:"Selecione um conteúdo",color=SubtitleVisual.ink,fontSize=19.sp)
        preview?.second?.let{Text("($it)",color=SubtitleVisual.muted,fontSize=15.sp)}
    }
    }
}
@Composable
private fun ManualPickerStatus(state:LoadState,count:Int,retry:()->Unit) {
    when {state is LoadState.Loading->Text("Carregando…",color=SettingsLook.secondary)
        state is LoadState.Error->SubtitleActionButton("Tentar novamente",onClick=retry)
        count==0->Text("Nenhum resultado encontrado.",color=SettingsLook.secondary)}
}

private suspend fun loadManualSeries(context:android.content.Context,dao:br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao,
    source:PlaylistSource,id:String):List<SeriesEpisodeInfo> = withContext(Dispatchers.IO) {
    val generation=dao.getActiveGeneration(source.id)?.generationId?:return@withContext emptyList()
    if(source is PlaylistSource.M3u)DeferredM3uEpisodeAccess.initialize(context).ensure(dao,source.id,generation,id)
    val local=mutableListOf<SeriesEpisodeInfo>();var offset=0
    while(offset<5000){
        val rows=dao.getEpisodesPage(source.id,generation,id,200,offset);if(rows.isEmpty())break
        local+=rows.mapIndexed{index,item->SeriesEpisodeInfo(item.episodeId,item.seasonNumber?:1,item.episodeNumber?:offset+index+1,
            item.name,item.posterUrl,null,item.durationSeconds?.toInt(),null)}
        offset+=rows.size;if(rows.size<200)break
    }
    if(local.isNotEmpty())return@withContext local
    SeriesEpisodesRepository(DefaultPlaylistHttpClient()).load(source,id,generation)?.episodes.orEmpty()
}
