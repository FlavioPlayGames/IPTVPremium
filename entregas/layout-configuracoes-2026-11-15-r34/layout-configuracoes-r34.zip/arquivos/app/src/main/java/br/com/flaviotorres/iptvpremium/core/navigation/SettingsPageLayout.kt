package br.com.flaviotorres.iptvpremium.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.focusable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.ui.components.*

/** Shared geometry, without its own palette or artwork. */
@Composable
internal fun SettingsPageFrame(title:String,onBack:()->Unit,modifier:Modifier=Modifier,
    backFocus:FocusRequester?=null,breadcrumb:String="Início  ›  Configurações",
    content:@Composable ColumnScope.()->Unit) {
    Box(modifier.fillMaxSize().background(SettingsLook.background)) {
        SettingsBackdrop(Modifier.matchParentSize())
        Column(Modifier.fillMaxSize().padding(horizontal=38.dp,vertical=20.dp),verticalArrangement=Arrangement.spacedBy(18.dp)) {
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.Top,horizontalArrangement=Arrangement.spacedBy(16.dp)) {
                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Text(title.uppercase(),color=SettingsLook.text,fontSize=25.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                    Text(if(breadcrumb.substringAfterLast("›").trim().equals(title,ignoreCase=true))breadcrumb else "$breadcrumb  ›  ${title.lowercase().replaceFirstChar{it.titlecase()}}",color=SettingsLook.secondary,fontSize=11.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                }
                MarbleSettingsButton("‹  Voltar",modifier=Modifier.width(104.dp).then(if(backFocus!=null)Modifier.focusRequester(backFocus)else Modifier),onClick=onBack)
            }
            content()
        }
    }
}

/** Bounds spare horizontal space, while preserving scrolling for large type and small screens. */
@Composable
internal fun SettingsPageBody(maxWidth:Dp=800.dp,modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit) {
    Box(modifier.fillMaxWidth(),contentAlignment=Alignment.Center) {
        Column(Modifier.widthIn(max=maxWidth).fillMaxWidth().verticalScroll(rememberScrollState()).padding(vertical=8.dp),
            verticalArrangement=Arrangement.spacedBy(14.dp),content=content)
    }
}

/** Lets the remote reach and bring each real preview into view below the menu. */
@Composable
internal fun SettingsPreviewCard(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit) {
    var focused by remember { mutableStateOf(false) }
    SettingsCard(modifier.onFocusChanged { focused=it.isFocused }
        .border(if(focused)2.dp else 0.dp,SettingsLook.border(focused),RoundedCornerShape(12.dp))
        .focusable(),content)
}
