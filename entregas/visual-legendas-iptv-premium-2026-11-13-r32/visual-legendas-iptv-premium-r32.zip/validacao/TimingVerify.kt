package br.com.flaviotorres.iptvpremium.core.player

import java.lang.reflect.Proxy
import java.util.concurrent.atomic.AtomicLong
import androidx.media3.exoplayer.Renderer

@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
fun main() {
    check(!subtitleTimingEnabled(false,false))
    check(subtitleTimingEnabled(true,false)&&subtitleTimingEnabled(false,true)&&subtitleTimingEnabled(true,true))
    check(subtitleRendererClockUs(10_000_000L,8000L)==2_000_000L)
    check(subtitleRendererClockUs(10_000_000L,-8000L)==18_000_000L)
    check(subtitleRendererClockUs(1_000_000L,0L)==1_000_000L)
    check(subtitleRendererClockUs(Long.MAX_VALUE,-120000)==Long.MAX_VALUE)
    check(subtitleRendererClockUs(Long.MIN_VALUE,120000)==Long.MIN_VALUE)
    check(subtitleRendererClockUs(200_000_000L,Long.MAX_VALUE)==80_000_000L)
    var clock=0L;var elapsed=0L
    val original=Proxy.newProxyInstance(Renderer::class.java.classLoader,arrayOf(Renderer::class.java)){_,method,args->
        when(method.name){"render"->{clock=args!![0] as Long;elapsed=args[1] as Long;null};"getName"->"text-test";"getTrackType"->3;"isReady"->true;else->null}
    } as Renderer
    val offset=AtomicLong(5000L);val wrapper=SubtitleTimingRenderer(original,offset)
    wrapper.render(20_000_000L,1234L)
    check(clock==15_000_000L&&elapsed==1234L)
    check(wrapper.name=="text-test"&&wrapper.trackType==3&&wrapper.isReady)
    offset.set(-5000L);wrapper.render(20_000_000L,5678L)
    check(clock==25_000_000L&&elapsed==5678L)
    offset.set(0L);wrapper.render(20_000_000L,5678L);check(clock==20_000_000L)
    println("PASS: disabled/active states, offset sign, saturation, limits, real Media3 Renderer delegation, runtime offset and unchanged elapsed/video clock.")
}
