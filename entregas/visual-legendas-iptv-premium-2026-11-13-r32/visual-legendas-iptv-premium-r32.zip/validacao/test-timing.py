from pathlib import Path
import subprocess,os
r=Path('/workspace/iptv-visual-r32');f=r/'app/src/main/java/br/com/flaviotorres/iptvpremium/core/navigation/player';tools=Path('/workspace/iptv-tools');java=str(tools/'jdk25/bin/java')
jars=list(tools.glob('*.jar'))+list(Path('/workspace/.gradle-cache/caches/9.6.0/transforms').glob('*/transformed/*-runtime.jar'))+[Path('/workspace/android-sdk/platforms/android-37/android.jar')]
cp=os.pathsep.join(map(str,jars));jar=r/'validacao/timing-tests.jar'
subprocess.run([java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',str(jar),str(f/'SubtitleTiming.kt'),str(f/'SubtitleTimingRenderer.kt'),str(r/'validacao/TimingVerify.kt')],check=True)
subprocess.run([java,'-cp',str(jar)+os.pathsep+cp,'br.com.flaviotorres.iptvpremium.core.player.TimingVerifyKt'],check=True)
