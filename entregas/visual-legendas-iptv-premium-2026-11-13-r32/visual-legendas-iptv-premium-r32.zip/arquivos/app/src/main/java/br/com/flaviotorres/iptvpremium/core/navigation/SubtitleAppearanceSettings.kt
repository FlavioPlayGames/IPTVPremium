package br.com.flaviotorres.iptvpremium.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.R
import br.com.flaviotorres.iptvpremium.core.player.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
internal fun SubtitleAppearanceSettingsScreen(onBack:()->Unit) {
    val context=LocalContext.current.applicationContext
    val store=remember(context){SubtitleAppearanceStore(context)}
    var appearance by remember{mutableStateOf<SubtitleAppearance?>(null)}
    var editing by remember{mutableStateOf<Int?>(null)}
    val back:()->Unit={if(editing!=null)editing=null else onBack()}
    BackHandler(onBack=back)
    val scope=rememberCoroutineScope();val first=remember{FocusRequester()}
    DisposableEffect(store){val observer=store.observe{scope.launch{appearance=withContext(Dispatchers.IO){store.load()}}};onDispose{observer.close()}}
    LaunchedEffect(store){appearance=withContext(Dispatchers.IO){store.load()}}
    LaunchedEffect(appearance!=null,editing){if(appearance!=null){withFrameNanos{};runCatching{first.requestFocus()}}}
    fun update(value:SubtitleAppearance){appearance=value;store.save(value);editing=null}
    SubtitleSettingsFrame("APARÊNCIA DAS LEGENDAS","",back) {
        val value=appearance
        if(value==null){Text("Carregando preferências…",color=SubtitleVisual.muted);return@SubtitleSettingsFrame}
        Row(Modifier.weight(1f).fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(24.dp)) {
            Column(Modifier.weight(.51f).fillMaxHeight().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp,Alignment.CenterVertically)) {
                val labels=listOf("Cor da letra","Tamanho","Fonte","Fundo","Acabamento")
                val values=listOf(subtitleTextColors.firstOrNull{it.argb==value.textArgb}?.label?:"Personalizada",value.sizeSp.toString(),value.typeface.label,value.background.label,value.edge.label)
                val icons=listOf(SubtitleSettingsIcon.COLOR,SubtitleSettingsIcon.SIZE,SubtitleSettingsIcon.FONT,SubtitleSettingsIcon.BACKGROUND,SubtitleSettingsIcon.EDGE)
                val field=editing
                if(field==null){
                    labels.indices.forEach{index->SubtitleActionButton(labels[index],value=values[index],leadingIcon=icons[index],
                        modifier=Modifier.fillMaxWidth().then(if(index==0)Modifier.focusRequester(first)else Modifier)){editing=index}}
                }else {
                    Text(labels[field],color=SubtitleVisual.ink,fontSize=19.sp,fontWeight=FontWeight.SemiBold)
                    val options=when(field){0->subtitleTextColors.map{it.label};1->subtitleSizeChoices.map{it.toString()};2->SubtitleTypeface.entries.map{it.label};3->SubtitleBackground.entries.map{it.label};else->SubtitleEdge.entries.map{it.label}}
                    val active=when(field){0->subtitleTextColors.indexOfFirst{it.argb==value.textArgb};1->subtitleSizeChoices.indexOf(value.sizeSp);2->value.typeface.ordinal;3->value.background.ordinal;else->value.edge.ordinal}
                    options.forEachIndexed{index,label->SubtitleActionButton(label,selected=index==active,
                        modifier=Modifier.fillMaxWidth().then(if(index==0)Modifier.focusRequester(first)else Modifier)){
                        update(when(field){0->value.copy(textArgb=subtitleTextColors[index].argb);1->value.copy(sizeSp=subtitleSizeChoices[index]);2->value.copy(typeface=SubtitleTypeface.entries[index]);3->value.copy(background=SubtitleBackground.entries[index]);else->value.copy(edge=SubtitleEdge.entries[index])})
                    }}
                }
            }
            Box(Modifier.weight(.49f).aspectRatio(1.35f).clip(RoundedCornerShape(9.dp)).background(Color(0xFF17191B)).border(1.dp,SubtitleVisual.edge,RoundedCornerShape(9.dp))) {
                Image(painterResource(R.drawable.subtitle_preview_scene),null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
                Text("Prévia",color=Color.White,fontSize=12.sp,modifier=Modifier.padding(12.dp))
                StyledSubtitleText("Esta é a sua legenda.",value,Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(90.dp))
            }
        }
        Text("Alterações salvas automaticamente.",color=SubtitleVisual.muted,fontSize=12.sp,modifier=Modifier.align(Alignment.CenterHorizontally))
    }
}
