package br.com.flaviotorres.iptvpremium.ui.settings

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text

@Composable
internal fun SubtitleQrPanel(bitmap:Bitmap?,heading:String,detail:String,steps:List<String>,status:String,
    modifier:Modifier=Modifier,qrDescription:String="Acesso temporário para esta TV",actions:@Composable ColumnScope.()->Unit) {
    Row(modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(40.dp)) {
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(15.dp)) {
            if(heading.isNotBlank())Text(heading,color=SubtitleVisual.ink,fontSize=23.sp,fontWeight=FontWeight.SemiBold)
            if(detail.isNotBlank())Text(detail,color=SubtitleVisual.muted,fontSize=15.sp)
            steps.forEachIndexed{index,step->
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(24.dp).background(SubtitleVisual.accent,RoundedCornerShape(50)),contentAlignment=Alignment.Center){
                        Text("${index+1}",color=Color(0xFF171717),fontWeight=FontWeight.Bold,fontSize=13.sp)
                    }
                    Text(step,color=SubtitleVisual.ink,fontSize=16.sp)
                }
            }
        }
        Column(Modifier.width(240.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(164.dp).background(Color.White,RoundedCornerShape(5.dp)).padding(7.dp),contentAlignment=Alignment.Center) {
                bitmap?.let{Image(it.asImageBitmap(),qrDescription,Modifier.fillMaxSize())}
            }
            Text(status,color=SubtitleVisual.muted,fontSize=12.sp)
            actions()
        }
    }
}
