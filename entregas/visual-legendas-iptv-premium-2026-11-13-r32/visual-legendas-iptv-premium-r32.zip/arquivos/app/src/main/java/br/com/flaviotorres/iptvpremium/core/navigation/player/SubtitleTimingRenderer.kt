package br.com.flaviotorres.iptvpremium.core.player

import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.Renderer
import java.util.concurrent.atomic.AtomicLong

/** Text-only wrapper: delegation preserves lifecycle, formats, messages and renderer capabilities. */
@androidx.annotation.OptIn(UnstableApi::class)
internal class SubtitleTimingRenderer(private val delegate:Renderer,private val offset:AtomicLong):Renderer by delegate {
    override fun render(positionUs:Long,elapsedRealtimeUs:Long){delegate.render(subtitleRendererClockUs(positionUs,offset.get()),elapsedRealtimeUs)}
}
