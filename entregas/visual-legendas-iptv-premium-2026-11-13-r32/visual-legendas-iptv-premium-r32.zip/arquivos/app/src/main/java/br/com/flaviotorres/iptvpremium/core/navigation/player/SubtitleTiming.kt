package br.com.flaviotorres.iptvpremium.core.player

internal const val SUBTITLE_TIMING_LIMIT_MS=120_000L
internal fun subtitleTimingEnabled(externalActive:Boolean,nativeTrackSelected:Boolean)=externalActive||nativeTrackSelected
/** Only the text renderer's clock changes. Positive delay displays cues later; video/audio keep their clocks. */
internal fun subtitleRendererClockUs(positionUs:Long,offsetMs:Long):Long {
    val shift=offsetMs.coerceIn(-SUBTITLE_TIMING_LIMIT_MS,SUBTITLE_TIMING_LIMIT_MS)*1000L
    return if(shift<0&&positionUs>Long.MAX_VALUE+shift)Long.MAX_VALUE
        else if(shift>0&&positionUs<Long.MIN_VALUE+shift)Long.MIN_VALUE else positionUs-shift
}
