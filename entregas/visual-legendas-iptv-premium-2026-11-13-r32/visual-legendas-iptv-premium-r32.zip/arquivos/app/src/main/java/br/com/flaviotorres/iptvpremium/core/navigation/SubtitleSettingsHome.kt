package br.com.flaviotorres.iptvpremium.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.ui.components.CatalogStyle
import br.com.flaviotorres.iptvpremium.ui.theme.MetallicPalette
import br.com.flaviotorres.iptvpremium.ui.theme.MetallicThemeBackdrop

internal object SubtitleVisual {
    val ink get()=if(CatalogStyle.light)Color(0xFF202226)else Color(0xFFF6F6F6)
    val muted get()=if(CatalogStyle.light)Color(0xFF45484D)else Color(0xFFD0D0D0)
    val edge get()=if(CatalogStyle.light)Color(0x9962676D)else Color(0xFF77797C)
    val panel get()=if(CatalogStyle.light)Color(0xDDE5E5E5)else Color(0xC9222426)
    val accent get()=MetallicPalette.accent
    fun surface(focused:Boolean)=Brush.horizontalGradient(if(focused)listOf(
        lerp(panel,accent,.40f),lerp(panel,accent,.18f))else listOf(panel,panel.copy(alpha=.65f)))
}

@Composable
fun SubdlAccountScreen(onBack:()->Unit) {
    var page by rememberSaveable { mutableStateOf("home") }
    var selected by rememberSaveable { mutableIntStateOf(0) }
    val back:()->Unit={if(page=="home")onBack()else page="home"}
    BackHandler(onBack=back)
    when(page) {
        "accounts"->SubtitleAccountsScreen(onBack=back)
        "appearance"->SubtitleAppearanceSettingsScreen(onBack=back)
        "manual"->ManualSubtitleSettingsScreen(onBack=back)
        else->SubtitleSettingsLanding(selected,{selected=it},{selected=it;page=listOf("accounts","manual","appearance")[it]},back)
    }
}

@Composable
internal fun SubtitleSettingsFrame(title:String,description:String,onBack:()->Unit,
    backFocus:FocusRequester?=null,modifier:Modifier=Modifier,breadcrumb:String="Início  ›  Legendas",
    content:@Composable ColumnScope.()->Unit) {
    Box(modifier.fillMaxSize().background(Color(0xFF202124))) {
        MetallicThemeBackdrop(Modifier.matchParentSize())
        Column(Modifier.fillMaxSize().padding(horizontal=38.dp,vertical=20.dp),verticalArrangement=Arrangement.spacedBy(18.dp)) {
            Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.Top,horizontalArrangement=Arrangement.spacedBy(16.dp)) {
                Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Text(title,color=SubtitleVisual.ink,fontSize=25.sp,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                    Text(if(title=="LEGENDAS")breadcrumb else "$breadcrumb  ›  ${title.lowercase().replaceFirstChar{it.titlecase()}}",
                        color=SubtitleVisual.muted,fontSize=11.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
                }
                Row(Modifier.padding(top=5.dp),horizontalArrangement=Arrangement.spacedBy(3.dp)) {
                    Text("IPTV",color=SubtitleVisual.ink,fontSize=12.sp,fontWeight=FontWeight.Bold)
                    Text("PREMIUM",color=SubtitleVisual.accent,fontSize=12.sp,fontWeight=FontWeight.Bold)
                }
                SubtitleActionButton("Voltar",modifier=Modifier.width(96.dp).then(if(backFocus!=null)Modifier.focusRequester(backFocus)else Modifier),
                    compact=true,leadingIcon=SubtitleSettingsIcon.BACK,onClick=onBack)
            }
            content()
        }
    }
}

/** Original vector paths, shared across the subtitle screens; no bitmap decoding or external icon font. */
internal enum class SubtitleSettingsIcon(val path:String) {
    ACCOUNTS("M9 15L7 17A4 4 0 0 1 1.5 11.5L6 7A4 4 0 0 1 11.5 7 M15 9L17 7A4 4 0 0 0 11.5 1.5L7 6 M8 12L12 8"),
    UPLOAD("M3 10V17H19V10 M11 13V1 M6 6L11 1L16 6"),
    APPEARANCE("M2 4H20V17H2Z M10 8C5 4 4 15 10 12 M18 8C13 4 12 15 18 12"),
    MOVIE("M2 3H20V19H2Z M6 3V19 M16 3V19 M2 7H6 M2 12H6 M2 16H6 M16 7H20 M16 12H20 M16 16H20"),
    SERIES("M2 6H20V17H2Z M6 1L11 6L16 1 M8 21H14"),
    PICTURE("M2 3H20V19H2Z M3 16L8 10L12 14L15 11L20 17 M15 7H15.1"),
    SEARCH("M15 9A6 6 0 1 1 3 9A6 6 0 1 1 15 9 M13.5 13.5L20 20"),
    CHEVRON("M8 3L15 11L8 19"),
    BACK("M14 3L7 11L14 19"),
    FILE("M4 1H13L19 7V21H4Z M13 1V7H19 M7 11H15 M7 15H15 M7 18H12"),
    CHECK("M3 11L8 16L19 5"),
    COLOR("M11 2A9 9 0 1 0 20 11C20 5 16 2 11 2 M6 9H6.1 M9 5H9.1 M14 5H14.1 M17 9H17.1"),
    SIZE("M3 4H19 M11 4V20 M7 20H15"),
    FONT("M2 20L9 2L16 20 M5 13H13 M17 10H22 M20 10V20"),
    BACKGROUND("M2 3H20V19H2Z M7 3V19 M13 3V19 M2 8H20 M2 14H20"),
    EDGE("M3 5H17V17H3Z M7 1H21V13"),
    SYNC("M3 8A8 8 0 0 1 18 5 M18 1V6H13 M19 14A8 8 0 0 1 4 17 M4 21V16H9"),
    CLOSE("M4 4L18 18 M18 4L4 18")
}

@Composable
internal fun SubtitleSettingsGlyph(icon:SubtitleSettingsIcon,modifier:Modifier=Modifier.size(32.dp),color:Color=SubtitleVisual.ink) {
    val path=remember(icon){PathParser().parsePathString(icon.path).toPath()}
    Canvas(modifier) {scale(size.width/24f,size.height/24f,pivot=Offset.Zero){drawPath(path,color,style=Stroke(1.55f,cap=StrokeCap.Round,join=StrokeJoin.Round))}}
}

@Composable
private fun SubtitleSettingsLanding(selected:Int,onSelected:(Int)->Unit,onOpen:(Int)->Unit,onBack:()->Unit) {
    val rows=remember{List(3){FocusRequester()}};val back=remember{FocusRequester()}
    LaunchedEffect(Unit){withFrameNanos{};rows[selected.coerceIn(0,2)].requestFocus()}
    SubtitleSettingsFrame("LEGENDAS","",onBack,back) {
        Column(Modifier.weight(1f).fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(12.dp,Alignment.CenterVertically)) {
            val titles=listOf("Contas de legendas","Envio manual","Aparência")
            val details=listOf("SubDL · SubSource · OpenSubtitles","Filme, temporada ou episódio","Fonte, tamanho e cores")
            for(index in 0..2)SubtitleActionButton(titles[index],description=details[index],leadingIcon=SubtitleSettingsIcon.entries[index],
                modifier=Modifier.fillMaxWidth().focusRequester(rows[index]).focusProperties{
                    up=if(index==0)back else rows[index-1];down=if(index==2)FocusRequester.Cancel else rows[index+1]
                },onFocused={onSelected(index)}){onOpen(index)}
        }
    }
}

@Composable
internal fun SubtitleLandingCard(title:String,detail:String,caption:String,icon:SubtitleSettingsIcon,
    modifier:Modifier=Modifier,onFocused:()->Unit={},connected:Boolean?=null,onClick:()->Unit) {
    var focused by remember{mutableStateOf(false)};val shape=RoundedCornerShape(10.dp)
    Column(modifier.onFocusChanged{focused=it.isFocused;if(focused)onFocused()}
        .semantics{contentDescription="$title. $detail. $caption"}
        .background(SubtitleVisual.surface(focused),shape)
        .border(if(focused)2.dp else 1.dp,if(focused)SubtitleVisual.accent else SubtitleVisual.edge,shape)
        .clickable(role=Role.Button,interactionSource=remember{MutableInteractionSource()},indication=null,onClick=onClick)
        .padding(20.dp),horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(13.dp,Alignment.CenterVertically)) {
        SubtitleSettingsGlyph(icon,Modifier.size(42.dp))
        Text(title,color=SubtitleVisual.ink,fontSize=22.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
        Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp)) {
            if(connected!=null)Box(Modifier.size(8.dp).background(if(connected)Color(0xFF62CC20)else Color(0xFF909294),RoundedCornerShape(50)))
            Text(detail,color=SubtitleVisual.muted,fontSize=13.sp,maxLines=2,overflow=TextOverflow.Ellipsis)
        }
    }
}

@Composable
internal fun SubtitleActionButton(label:String,enabled:Boolean=true,modifier:Modifier=Modifier.fillMaxWidth(),
    compact:Boolean=false,description:String?=null,leadingIcon:SubtitleSettingsIcon?=null,value:String?=null,
    thumbnail:ImageBitmap?=null,thumbnailPlaceholder:Boolean=false,
    selected:Boolean?=null,checked:Boolean?=null,onFocused:()->Unit={},onClick:()->Unit) {
    var focused by remember{mutableStateOf(false)};val shape=RoundedCornerShape(if(compact)7.dp else 9.dp)
    Row(modifier.heightIn(min=if(compact)34.dp else if(description!=null)65.dp else 46.dp)
        .alpha(if(enabled)1f else .43f).onFocusChanged{focused=it.isFocused;if(focused)onFocused()}
        .background(SubtitleVisual.surface(focused),shape)
        .border(if(focused)2.dp else 1.dp,if(focused)SubtitleVisual.accent else SubtitleVisual.edge,shape)
        .clickable(enabled=enabled,role=Role.Button,interactionSource=remember{MutableInteractionSource()},indication=null,onClick=onClick)
        .padding(horizontal=if(compact)10.dp else 16.dp,vertical=if(compact)7.dp else 10.dp),
        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(14.dp)) {
        if(thumbnail!=null||thumbnailPlaceholder)Box(Modifier.size(32.dp).clip(RoundedCornerShape(4.dp)).background(Color(0xFF666768)),contentAlignment=Alignment.Center) {
            if(thumbnail!=null)Image(thumbnail,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)
            else SubtitleSettingsGlyph(SubtitleSettingsIcon.PICTURE,Modifier.size(23.dp),Color(0xFFB8B9BA))
        }
        if(leadingIcon!=null&&!thumbnailPlaceholder&&thumbnail==null){SubtitleSettingsGlyph(leadingIcon,Modifier.size(if(compact)16.dp else 27.dp));if(!compact)Box(Modifier.width(1.dp).height(if(description!=null)38.dp else 23.dp).background(SubtitleVisual.edge.copy(alpha=.5f)))}
        if(selected!=null)Canvas(Modifier.size(17.dp)) {drawCircle(if(selected)SubtitleVisual.accent else SubtitleVisual.muted,style=Stroke(1.4.dp.toPx()));if(selected)drawCircle(SubtitleVisual.accent,radius=size.minDimension*.27f)}
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)){
            Text(label,color=SubtitleVisual.ink,fontSize=if(compact)12.sp else if(description!=null)19.sp else 16.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
            if(!description.isNullOrBlank())Text(description,color=SubtitleVisual.muted,fontSize=12.sp,maxLines=2,overflow=TextOverflow.Ellipsis)
        }
        if(!value.isNullOrBlank())Text(value,color=SubtitleVisual.muted,fontSize=14.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.widthIn(max=160.dp))
        if(checked!=null)Box(Modifier.size(23.dp).background(if(checked)Color(0xFF62CC20)else Color.Transparent,RoundedCornerShape(50)),contentAlignment=Alignment.Center) {
            if(checked)SubtitleSettingsGlyph(SubtitleSettingsIcon.CHECK,Modifier.size(15.dp),Color(0xFF173608))
            else SubtitleSettingsGlyph(SubtitleSettingsIcon.CHEVRON,Modifier.size(17.dp))
        }
        if(!compact&&selected==null&&checked==null)SubtitleSettingsGlyph(SubtitleSettingsIcon.CHEVRON,Modifier.size(17.dp))
    }
}
