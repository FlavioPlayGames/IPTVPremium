package br.com.flaviotorres.iptvpremium.data.cache.dao

/** One carrier per batch. Measures elapsed calls, never SQL text or record data. */
class ImportBatchWriteMetrics {
    enum class Stage { CATEGORIES, CHANNELS, MOVIES, SERIES, EPISODES }
    private val stageNanos = LongArray(5)
    private var started = 0L
    private var elapsed = 0L
    var failedStage: Stage? = null
        private set
    var bodyEntered: Boolean = false
        private set
    fun beginBody() { started = System.nanoTime(); elapsed = 0; bodyEntered = true; failedStage = null; stageNanos.fill(0) }
    fun endBody() { if (bodyEntered) elapsed = System.nanoTime() - started }
    suspend fun measure(stage: Stage, operation: suspend () -> Unit) {
        val before = System.nanoTime()
        try { operation() }
        catch (error: Throwable) { failedStage = stage; throw error }
        finally { stageNanos[stage.ordinal] += System.nanoTime() - before }
    }
    fun nanos(stage: Stage): Long = stageNanos[stage.ordinal]
    fun bodyNanos(): Long = elapsed
    fun outsideBodyNanos(totalNanos: Long): Long = (totalNanos - elapsed).coerceAtLeast(0)
}
