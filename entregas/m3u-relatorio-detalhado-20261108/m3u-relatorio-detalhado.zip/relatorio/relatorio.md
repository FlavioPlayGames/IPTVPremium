# Relatório detalhado — importação M3U nativa

## Conclusão

A captura com banco 5 concluiu a importação em 122,44 segundos, ante 142,07 segundos. O ganho observado foi 13,8%. O escritor do banco continua limitando o avanço da fila. Os lotes compostos só por episódios responderam por 104,35 segundos, ou 88,3% das chamadas de gravação medidas. Esses lotes também podem gravar metadados de séries; o log antigo não mede o INSERT de episódios isoladamente.

## 1. Volume processado

As duas capturas têm 329.732 entradas: 2.355 canais, 44.099 filmes e 283.278 episódios. Os episódios são 85,9% das entradas. Há 9.800 séries e 104 categorias. Ambas usam 167 lotes e receberam 85.847.864 bytes (85,85 MB decimais), sem compressão HTTP.

As contagens e o tamanho recebido são iguais. O diagnóstico não contém hash do arquivo; igualdade byte a byte do conteúdo não foi medida.

## 2. Comparação de tempos

| Medição | Anterior | Banco 5 | Redução observada |
|---|---:|---:|---:|
| Importação completa | 142,07 s | 122,44 s | 13,8% |
| Chamadas de gravação Room | 137,80 s | 118,19 s | 14,2% |
| Processamento das linhas | 83,28 s | 80,14 s | 3,8% |
| Espera da fila de escrita | 48,00 s | 31,45 s | 34,5% |

**Não somar essas linhas.** Leitura, processamento e escrita trabalham em pipeline. São tempos decorridos de chamadas, incluindo esperas e possíveis preempções, não medições exclusivas de uso da CPU ou do armazenamento.

## 3. Onde as gravações se concentram — banco 5

| Composição do lote | Lotes | Entradas | Chamadas de gravação |
|---|---:|---:|---:|
| Só canais | 1 | 2.000 | 0,25 s |
| Canais e filmes | 1 | 2.000 | 0,46 s |
| Só filmes | 21 | 40.541 | 12,29 s |
| Filmes e episódios | 1 | 2.000 | 0,83 s |
| Só episódios | 143 | 283.191 | 104,35 s |

A classificação é exclusiva: cada lote entra em uma única linha. A mediana de gravação por lote foi 751 ms, contra 841 ms antes. O maior lote caiu de 1718 para 905 ms. O total de tempo das chamadas Room caiu 19,62 segundos.

## 4. O que acontece durante os dois minutos

O leitor pode manter só um bloco à frente. O parser cria os registros e envia lotes ao escritor, cuja fila também é limitada. Quando essa fila enche, o parser espera; quando o parser deixa de consumir linhas, o leitor também espera. Isso mantém a memória limitada e faz o tempo da requisição HTTP acompanhar o ritmo da gravação.

A leitura de rede contabilizou 2,90 segundos e a espera do leitor pelo parser foi elevada. Esse contador registra apenas o tempo dentro das leituras do stream de rede, não todo o tempo de transferência ponta a ponta; buffers e contrapressão afetam a observação. O relatório sustenta que o processamento/armazenamento do aparelho limita o pipeline, mas não fornece uma medição independente da capacidade da internet.

Na M3U direta, os 283.278 episódios precisam ser processados e persistidos. O Xtream pode consultar os episódios sob demanda e, por isso, faz um trabalho inicial diferente.

## 5. O que ainda não sabemos

O campo gravacaoRoomMs começa antes de chamar o DAO e termina quando ele retorna. Ele reúne aquisição/espera do executor ou conexão, início da transação, inserções, atualização de índices, encerramento/commit e retorno da chamada.

O relatório atual não separa esses componentes. Não permite afirmar quantos segundos foram fsync, contenção com outro acesso, CPU em bindings/SQLite, coleta de lixo ou espera do armazenamento físico. parsingMs também é tempo decorrido por linha; não é CPU exclusiva. O heap registrado é somente Java, não RAM total ou memória nativa do SQLite.

Portanto, não há evidência suficiente para atribuir a demora especificamente à velocidade da flash, a falta de RAM ou a uma falha da rede.

## 6. Medição adicional preparada

A atualização de diagnóstico mede a duração das chamadas de inserção de categorias, canais, filmes, séries e episódios, além do tempo dentro e fora do corpo do método transacional. A unidade registrada é microssegundo, por lote. A medição não registra SQL, valores de conteúdo, URLs ou credenciais e não ocorre por registro individual.

O tempo fora do corpo reúne espera/abertura/fechamento da transação e agendamento; **não é um cronômetro exclusivo de commit**. As chamadas por tipo incluem os bindings, o SQL e as esperas que ocorrerem durante elas. Essa divisão mostrará se a próxima investigação deve priorizar a inserção de episódios ou o entorno da transação. Separar CPU, I/O e fsync fisicamente exigiria outra coleta do sistema.

Não há nova migração: o banco permanece na versão 5. O fluxo de gravação, os lotes, os índices e a ordem continuam iguais; foram acrescentados cronômetros por lote.

## 7. Dados e rastreabilidade

Os arquivos lotes.csv e resumo.json contêm somente as métricas usadas nesta análise. O gráfico comparacao.png mostra as duas capturas. Não foram publicados os logs originais ou dados de cadastro. Este relatório é uma análise de duas capturas, sem repetição controlada suficiente para garantir o mesmo ganho em todas as importações.
