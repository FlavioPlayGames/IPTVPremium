package br.com.flaviotorres.iptvpremium.data.repository

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import org.json.JSONArray
import org.json.JSONObject

/** Resolve official names; presentation always comes from the pt-BR details endpoint. */
internal suspend fun resolveSeriesArtworkIdentity(
    title: String, year: Int?, tmdb: String?, imdb: String?,
    get: suspend (String, Map<String, String>) -> String
): JSONObject? {
    suspend fun json(path: String, query: Map<String, String> = emptyMap()): JSONObject? = try {
        JSONObject(get(path, query))
    } catch (cancelled: CancellationException) { throw cancelled }
    catch (_: Exception) { null }
    suspend fun details(id: Int): JSONObject? = json("/tv/$id", mapOf(
        "language" to "pt-BR", "append_to_response" to "images,translations,external_ids,alternative_titles",
        "include_image_language" to "pt,null,en"
    ))?.takeIf { it.optInt("id", -1) == id }
    tmdb?.trim()?.toIntOrNull()?.takeIf { it > 0 }?.let { id -> details(id)?.let { return it } }
    imdb?.trim()?.takeIf { it.matches(Regex("tt[0-9]+")) }?.let { id ->
        val found = json("/find/$id", mapOf("external_source" to "imdb_id"))?.optJSONArray("tv_results")
        if (found?.length() == 1) found.optJSONObject(0)?.optInt("id", -1)?.takeIf { it > 0 }
            ?.let { resolved -> details(resolved)?.let { return it } }
    }
    val wanted = artworkTitle(title)
    if (wanted.isBlank()) return null
    val tried = mutableSetOf<Int>()
    for (language in listOf("pt-BR", "pt-PT", "en-US")) {
        val response = json("/search/tv", mapOf("query" to wanted, "language" to language, "include_adult" to "false")) ?: continue
        val candidates = response.optJSONArray("results").objects()
            .filter { !it.optBoolean("adult", false) && it.optInt("id", -1) > 0 }
            .filter { year == null || it.optString("first_air_date").take(4).toIntOrNull() == year }
            .distinctBy { it.optInt("id") }
        val exact = candidates.filter { candidate ->
            listOf(candidate.optString("name"), candidate.optString("original_name")).any { artworkTitle(it) == wanted }
        }
        if (exact.size > 1) return null
        if (exact.size == 1) details(exact.single().optInt("id"))?.let { return it }
        // Without year or too many plausible shows, do not guess by a translated title.
        if (year == null || candidates.size > 4) continue
        val checks = candidates.filter { tried.add(it.optInt("id")) }
        val matching = coroutineScope {
            checks.map { candidate -> async {
                details(candidate.optInt("id"))?.takeIf { root ->
                    root.optString("first_air_date").take(4).toIntOrNull() == year &&
                        officialSeriesNames(root).any { artworkTitle(it) == wanted }
                }
            } }.awaitAll().filterNotNull()
        }
        if (matching.size > 1) return null
        if (matching.size == 1) return matching.single()
    }
    return null
}

private fun JSONArray?.objects(): List<JSONObject> = this?.let { a ->
    (0 until a.length()).mapNotNull { a.optJSONObject(it) }
}.orEmpty()

internal fun officialSeriesNames(root: JSONObject): List<String> = (
    listOf(root.optString("original_name"), root.optString("name")) +
        root.optJSONObject("translations")?.optJSONArray("translations").objects()
            .mapNotNull { it.optJSONObject("data")?.optString("name") } +
        root.optJSONObject("alternative_titles")?.optJSONArray("results").objects()
            .map { it.optString("title") }
    ).map(String::trim).filter(String::isNotEmpty).distinct()

/** Query names and response language are separate: original -> English -> pt-BR. */
internal fun preferredSeriesSearchNames(root: JSONObject): List<String> {
    val translations = root.optJSONObject("translations")?.optJSONArray("translations").objects()
    fun translated(language: String, country: String): String? = translations
        .firstOrNull { it.optString("iso_639_1") == language && it.optString("iso_3166_1") == country }
        ?.optJSONObject("data")?.optString("name")?.trim()?.takeIf { it.isNotEmpty() }
    return listOfNotNull(root.optString("original_name").takeIf { it.isNotBlank() },
        translated("en", "US"), translated("pt", "BR") ?: root.optString("name").takeIf { it.isNotBlank() })
        .distinct()
}
