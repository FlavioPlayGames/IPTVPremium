﻿[CmdletBinding()]
param([string]$Site="$env:USERPROFILE\Downloads\site-identidade-aprovada",[string]$Downloads="$env:USERPROFILE\Downloads")
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($Site).TrimEnd('\','/')
function Hash([byte[]]$Bytes){$s=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($s.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()}finally{$s.Dispose()}}
function Destino([string]$Rel){
 if($Rel -notmatch '^(?:[A-Za-z0-9_-]+\.(?:js|json|jsonc|md|ps1|txt)|public/(?:admin/)?[A-Za-z0-9_-]+\.(?:js|html|css)|validacao/[A-Za-z0-9_.-]+\.(?:mjs|md))$' -or $Rel -match '\.\.'){throw 'Arquivo fora do escopo do site.'}
 $p=[IO.Path]::GetFullPath((Join-Path $root $Rel));$cursor=$p
 while($cursor.StartsWith($root,[StringComparison]::OrdinalIgnoreCase)) {
  if((Test-Path -LiteralPath $cursor) -and ((Get-Item -LiteralPath $cursor -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Links de sistema nao sao aceitos para aplicar o patch.'}
  if($cursor -eq $root){break};$cursor=Split-Path -Parent $cursor
 }
 return $p
}
if(!(Test-Path -LiteralPath (Join-Path $root 'package.json') -PathType Leaf)){throw 'Pasta do site nao encontrada ou sem package.json.'}
$backupRoot=[IO.Path]::GetFullPath($Downloads).TrimEnd('\','/')
if($backupRoot -eq $root -or $backupRoot.StartsWith($root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'O backup precisa ficar fora da pasta do site.'}
$items=ConvertFrom-Json -InputObject (Get-Content -LiteralPath "$PSScriptRoot\manifesto-site.json" -Raw)
$items=@($items)
$deps=ConvertFrom-Json -InputObject (Get-Content -LiteralPath "$PSScriptRoot\dependencias-site.json" -Raw)
$deps=@($deps)
foreach($dep in $deps) {
 $depPath=Destino ([string]$dep.path)
 if(!(Test-Path -LiteralPath $depPath -PathType Leaf) -or (Hash ([IO.File]::ReadAllBytes($depPath))) -ne $dep.sha256){throw "Dependencia ausente ou diferente: $($dep.path). Nenhum arquivo alterado. Envie os fontes atuais para adaptar sem perder avancos."}
}
$plan=New-Object System.Collections.Generic.List[object]
foreach($item in $items) {
 $dest=Destino ([string]$item.path)
 [byte[]]$before=@();$current=$null
 if(Test-Path -LiteralPath $dest){if(!(Test-Path -LiteralPath $dest -PathType Leaf)){throw 'Destino inesperado.'};$before=[IO.File]::ReadAllBytes($dest);$current=Hash $before}
 if($current -eq $item.afterHash){continue}
 if($current -ne $item.beforeHash){throw "Base divergente ou arquivo ausente: $($item.path). Nenhum arquivo alterado. Confira a pasta e envie os fontes atuais; nao restaure backups antigos automaticamente."}
 $stream=New-Object IO.MemoryStream
 try {
  $position=0
  foreach($part in @($item.operations)) {
   $offset=[int]$part.offset;$length=[int]$part.length
   if($offset -lt $position -or $length -lt 0 -or $offset+$length -gt $before.Length){throw 'Patch invalido.'}
   $stream.Write($before,$position,$offset-$position)
   $insert=[Convert]::FromBase64String([string]$part.data);$stream.Write($insert,0,$insert.Length);$position=$offset+$length
  }
  $stream.Write($before,$position,$before.Length-$position);[byte[]]$after=$stream.ToArray()
 }finally{$stream.Dispose()}
 if((Hash $after) -ne $item.afterHash){throw 'Integridade do patch invalida.'}
 $plan.Add([PSCustomObject]@{path=[string]$item.path;destino=$dest;antes=$before;depois=$after;beforeHash=$item.beforeHash;afterHash=$item.afterHash})
}
if($plan.Count -eq 0){Write-Host 'Site r29 ja aplicado. Nenhum deploy executado.';return}
$backup=Join-Path $backupRoot ('IPTV-site-restauracao-r29-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $backup -Force|Out-Null
$state=New-Object System.Collections.Generic.List[object]
foreach($item in $plan) {
 if($null -ne $item.beforeHash){$p=Join-Path "$backup\arquivos" $item.path;New-Item -ItemType Directory -Path (Split-Path -Parent $p) -Force|Out-Null;[IO.File]::WriteAllBytes($p,$item.antes);if((Hash ([IO.File]::ReadAllBytes($p))) -ne $item.beforeHash){throw 'Backup nao confere. Nada foi alterado.'}}
 $state.Add([PSCustomObject]@{path=$item.path;beforeHash=$item.beforeHash;afterHash=$item.afterHash})
}
[PSCustomObject]@{site=$root;files=$state.ToArray();desfeito=$false}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $backup 'estado-site.json') -Encoding UTF8
foreach($item in $plan) {
 $now=$null
 if(Test-Path -LiteralPath $item.destino -PathType Leaf){$now=Hash ([IO.File]::ReadAllBytes($item.destino))}
 if($now -ne $item.beforeHash){throw 'Um fonte mudou durante o backup. Nenhum arquivo foi aplicado.'}
}
try {
 foreach($item in $plan){New-Item -ItemType Directory -Path (Split-Path -Parent $item.destino) -Force|Out-Null;[IO.File]::WriteAllBytes($item.destino,$item.depois);if((Hash ([IO.File]::ReadAllBytes($item.destino))) -ne $item.afterHash){throw 'Falha ao conferir a copia.'}}
} catch {
 foreach($item in $plan){if($null -eq $item.beforeHash){if(Test-Path -LiteralPath $item.destino){Remove-Item -LiteralPath $item.destino -Force}}else{[IO.File]::WriteAllBytes($item.destino,$item.antes)}}
 throw
}
Write-Host "Site r29 aplicado localmente. Backup: $backup"
Write-Host "Para desfazer: powershell -ExecutionPolicy Bypass -File '$PSScriptRoot\Desfazer-Site.ps1' -Backup '$backup'"
Write-Host 'Nenhum deploy ou criacao de bucket foi executado. Execute os testes e prepare o R2 antes de publicar.'
