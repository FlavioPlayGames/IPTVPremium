﻿[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Backup)
$ErrorActionPreference='Stop'
function Hash([string]$Path){if(!(Test-Path -LiteralPath $Path -PathType Leaf)){return $null};return (Get-FileHash -LiteralPath $Path -Algorithm SHA256).Hash.ToLowerInvariant()}
$p=Join-Path $Backup 'estado-site.json';$state=Get-Content -LiteralPath $p -Raw|ConvertFrom-Json
if($state.desfeito){Write-Host 'Fontes ja restaurados. Nenhum deploy executado.';return}
$root=[IO.Path]::GetFullPath([string]$state.site).TrimEnd('\','/')
foreach($item in @($state.files)) {
 if($item.path -notmatch '^(?:[A-Za-z0-9_-]+\.(?:js|json|jsonc|md|ps1|txt)|public/(?:admin/)?[A-Za-z0-9_-]+\.(?:js|html|css)|validacao/[A-Za-z0-9_.-]+\.(?:mjs|md))$' -or $item.path -match '\.\.'){throw 'Caminho invalido no backup.'}
 $dest=Join-Path $root $item.path
 if((Hash $dest) -ne $item.afterHash){throw "Arquivo editado depois da aplicacao: $($item.path). Nada foi restaurado."}
 if($null -ne $item.beforeHash -and (Hash (Join-Path "$Backup\arquivos" $item.path)) -ne $item.beforeHash){throw 'Backup nao confere. Nada foi restaurado.'}
}
foreach($item in @($state.files)) {
 $dest=Join-Path $root $item.path
 if($null -eq $item.beforeHash){Remove-Item -LiteralPath $dest -Force}
 else{Copy-Item -LiteralPath (Join-Path "$Backup\arquivos" $item.path) -Destination $dest -Force}
}
$state.desfeito=$true;$state|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $p -Encoding UTF8
Write-Host 'Fontes restaurados. Nenhum deploy, exclusao de bucket ou alteracao no D1 foi executado.'
Write-Host 'Para reverter a versao publicada, execute npx wrangler deploy na pasta do site apos conferir a configuracao.'
