package br.com.flaviotorres.iptvpremium.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors

/** Thin double rim and short colored halo, without blur layers on API 28. */
fun Modifier.reinforcedCatalogFocus(enabled: Boolean, roundedDp: Float = 12f): Modifier =
    if (!enabled) this else drawWithCache {
        val accent = ThemeColors.tone(1f, .90f)
        val reflection = ThemeColors.tone(1f, .28f)
        val metal = Brush.linearGradient(
            0f to reflection, .18f to accent, .48f to reflection,
            .72f to accent, 1f to reflection,
            start = Offset.Zero, end = Offset(size.width, size.height)
        )
        val radius = roundedDp.dp.toPx()
        val outerInset = 1.dp.toPx()
        val gapInset = 2.75.dp.toPx()
        val innerInset = 4.dp.toPx()
        // Precompute strokes; only the focused item draws this small static halo.
        val halo = listOf(10f to .035f, 8f to .055f, 6f to .10f, 4f to .18f)
            .map { (width, alpha) -> Stroke(width.dp.toPx()) to accent.copy(alpha = alpha) }
        val outerStroke = Stroke(2.dp.toPx())
        val separatorStroke = Stroke(1.5.dp.toPx())
        val innerStroke = Stroke(1.dp.toPx())
        onDrawWithContent {
            drawContent()
            if (size.width > innerInset * 2 && size.height > innerInset * 2) {
                for ((stroke, color) in halo) {
                    drawRoundRect(color, topLeft = Offset(outerInset, outerInset),
                        size = Size(size.width - outerInset * 2, size.height - outerInset * 2),
                        cornerRadius = CornerRadius((radius - outerInset).coerceAtLeast(0f)), style = stroke)
                }
                drawRoundRect(metal, topLeft = Offset(outerInset, outerInset),
                    size = Size(size.width - outerInset * 2, size.height - outerInset * 2),
                    cornerRadius = CornerRadius((radius - outerInset).coerceAtLeast(0f)), style = outerStroke)
                drawRoundRect(Color(0xE6000000), topLeft = Offset(gapInset, gapInset),
                    size = Size(size.width - gapInset * 2, size.height - gapInset * 2),
                    cornerRadius = CornerRadius((radius - gapInset).coerceAtLeast(0f)), style = separatorStroke)
                drawRoundRect(metal, topLeft = Offset(innerInset, innerInset),
                    size = Size(size.width - innerInset * 2, size.height - innerInset * 2),
                    cornerRadius = CornerRadius((radius - innerInset).coerceAtLeast(0f)), style = innerStroke)
            }
        }
    }
