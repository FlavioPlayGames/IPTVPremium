package br.com.flaviotorres.iptvpremium.data.parser
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import br.com.flaviotorres.iptvpremium.data.repository.DefaultPlaylistRepository
import br.com.flaviotorres.iptvpremium.data.sync.*
import br.com.flaviotorres.iptvpremium.domain.model.*
import java.io.*
import kotlinx.coroutines.runBlocking
private class Http(var body:String):PlaylistHttpClient {
 var reads=0;var failNetwork=false
 override suspend fun get(url:String)="""{"user_info":{"auth":1}}"""
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit){error("M3U not expected")}
 override suspend fun <T> withReader(url:String,consume:suspend(Reader)->T):T {
  val action=url.substringAfter("&action=").substringBefore('&')
  val text=when(action){
   "get_vod_categories"->"""[{"category_id":1,"category_name":"Movies"}]"""
   "get_vod_streams"->{reads++;if(failNetwork)throw IOException("transport failure");body}
   "get_series_categories","get_series"->"[]"
   else->error("Unexpected endpoint")
  }
  return consume(StringReader(text))
 }
}
private class Sink:XtreamCatalogSink {
 override val includeLive=false
 val movies=mutableListOf<Movie>();var resets=0;var failWrites=false
 override suspend fun append(endpoint:String,content:PlaylistContent){if(failWrites)throw XtreamCatalogWriteException(IOException("write failure"));movies+=content.movies}
 override suspend fun reset(endpoint:String){if(endpoint=="get_vod_streams"){resets++;movies.clear()}}
 override suspend fun stage(endpoint:String)=error("No category fallback expected")
 override suspend fun merge(stage:XtreamCatalogStage)=error("No category merge expected")
 override suspend fun discard(stage:XtreamCatalogStage)=Unit
}
fun main()=runBlocking {
 val source=PlaylistSource.XtreamCodes("id","list",true,"https://example.invalid","user","pass")
 fun repo(http:Http)=DefaultPlaylistRepository(http,DefaultXtreamParser())
 run {
  val payload=(0..649).joinToString(",","[","]"){"{\"stream_id\":$it,\"name\":\"Movie $it\",\"category_id\":1}"}
  val http=Http(payload);val sink=Sink();repo(http).importXtream(source,sink)
  check(http.reads==1 && sink.movies.size==650 && sink.movies.map{it.id}==(0..649).map{it.toString()})
  check(sink.movies.all { it.streamUrl.startsWith("https://example.invalid/movie/") })
  println("PASS: repository imports direct fields, constructs stream URLs and uses one catalog request")
 }
 run {
  val payload=(0..649).joinToString(",","[","]"){if(it==600)"{\"stream_id\":0x1000,\"category_id\":1}"else"{\"stream_id\":$it,\"category_id\":1}"}
  val http=Http(payload);val sink=Sink();val repository=repo(http);repository.importXtream(source,sink)
  check(http.reads==2 && sink.resets==2 && sink.movies.size==650 && sink.movies[600].id=="4096")
  check(sink.movies.map{it.id}.distinct().size==650)
  repository.importXtream(source,sink);check(http.reads==3 && sink.movies.size==650)
  println("PASS: nonstandard numeric ID retries legacy once, clears partial batches, preserves exact IDs and remembers compatibility for next update")
 }
 run {
  val http=Http("[]");http.failNetwork=true
  check(runCatching{repo(http).importXtream(source,Sink())}.exceptionOrNull() is IOException && http.reads==1)
  val writes=Http("[{\"stream_id\":1,\"category_id\":1}]");val sink=Sink();sink.failWrites=true
  check(runCatching{repo(writes).importXtream(source,sink)}.exceptionOrNull() is XtreamCatalogWriteException)
  // The write failure can occur in categories before the movie endpoint is requested.
  check(writes.reads==0)
  println("PASS: transport and database failures are not misclassified as JSON compatibility or retried")
 }
}