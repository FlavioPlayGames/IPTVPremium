$ErrorActionPreference='Stop'
$folder='/workspace/outputs/xtream-restaurar-estavel'
foreach($f in Get-ChildItem -LiteralPath $folder -Filter '*.ps1'){
 $errors=$null;$tokens=$null
 [System.Management.Automation.Language.Parser]::ParseFile($f.FullName,[ref]$tokens,[ref]$errors)>$null
 if($errors.Count){throw ($errors|Out-String)}
}
Write-Output 'PASS PowerShell syntax for all delivered scripts'
$text=[IO.File]::ReadAllText((Join-Path $folder 'Medir-Importacao.ps1'))
$start=$text.IndexOf('function Safe-Metrics');$end=$text.IndexOf('# Exclude the last historical line')
Invoke-Expression $text.Substring($start,$end-$start)
$safe=@(Safe-Metrics @('M3uOfficialPerf: stage=prepare status=OK revision=M3U_OFFICIAL_R1 durationMs=42 url=https://private password=secret','M3uEpisodesPerf: stage=load status=OK episodes=20 durationMs=123','M3uEpisodesPerf: stage=cache status=OK','Other: stage=write status=OK','M3uOfficialPerf: stage=PRIVATE url=private'))
if($safe.Count -ne 3){throw 'Unexpected line count'}
if(($safe -join ' ') -match 'private|secret|https|password|PRIVATE'){throw 'Unexpected data leaked'}
foreach($field in @('revision=M3U_OFFICIAL_R1','stage=prepare','durationMs=42','durationMs=123','episodes=20','stage=cache')){if(-not(($safe -join ' ').Contains($field))){throw ('Missing '+$field)}}
Write-Output 'PASS allowlist preserves official stages and episode load timing while rejecting secrets and unknown fields'
