﻿[CmdletBinding()]
param([string]$Projeto="$env:USERPROFILE\AndroidStudioProjects\IPTVPremium",[string]$Downloads="$env:USERPROFILE\Downloads",[string]$Serial='',[switch]$SemPrepararNdk)
$ErrorActionPreference='Stop'
if(!$SemPrepararNdk){& "$PSScriptRoot\Preparar-Ndk.ps1" -Projeto $Projeto}
& "$PSScriptRoot\Aplicar-Limpeza.ps1" -Projeto $Projeto -Downloads $Downloads
& "$PSScriptRoot\Instalar-TV.ps1" -Projeto $Projeto -Serial $Serial
& "$PSScriptRoot\Limpar-Arquivos.ps1" -Projeto $Projeto -Downloads $Downloads
Write-Host 'Limpeza concluida. O projeto conserva os fontes, recursos em uso e arquivos necessarios a compilacao.'
