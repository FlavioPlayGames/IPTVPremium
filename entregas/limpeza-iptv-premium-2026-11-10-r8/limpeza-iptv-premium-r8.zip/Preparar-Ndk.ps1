﻿[CmdletBinding()]
param([string]$Projeto="$env:USERPROFILE\AndroidStudioProjects\IPTVPremium")
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Seguranca.ps1"
$Projeto=Projeto-Valido $Projeto
$versao='28.2.13676358'
$sdk=$null
$local=Join-Path $Projeto 'local.properties'
if(Test-Path -LiteralPath $local -PathType Leaf) {
    foreach($linha in Get-Content -LiteralPath $local) {
        if($linha -match '^\s*sdk\.dir\s*=\s*(.+)$'){$sdk=$Matches[1].Trim().Replace('\\','\').Replace('\:',':');break}
    }
}
if([string]::IsNullOrWhiteSpace($sdk)){$sdk=$env:ANDROID_HOME}
if([string]::IsNullOrWhiteSpace($sdk)){$sdk="$env:LOCALAPPDATA\Android\Sdk"}
if(![IO.Path]::IsPathRooted($sdk)){$sdk=Join-Path $Projeto $sdk}
if(!(Test-Path -LiteralPath $sdk -PathType Container)){throw 'Android SDK nao encontrado. Confira sdk.dir em local.properties.'}
$ndk=Join-Path $sdk "ndk\$versao"
$strip=Join-Path $ndk 'toolchains\llvm\prebuilt\windows-x86_64\bin\llvm-strip.exe'
function Ndk-Pronto {
    $meta=Join-Path $ndk 'source.properties'
    if(!(Test-Path -LiteralPath $strip -PathType Leaf) -or !(Test-Path -LiteralPath $meta -PathType Leaf)){return $false}
    return (Get-Content -Raw -LiteralPath $meta) -match '(?m)^\s*Pkg\.Revision\s*=\s*28\.2\.13676358\s*$'
}
if(!(Ndk-Pronto)) {
    $candidatos=@((Join-Path $sdk 'cmdline-tools\latest\bin\sdkmanager.bat'))
    $base=Join-Path $sdk 'cmdline-tools'
    if(Test-Path -LiteralPath $base){$candidatos+=@(Get-ChildItem -LiteralPath $base -Directory|ForEach-Object{Join-Path $_.FullName 'bin\sdkmanager.bat'})}
    $manager=@($candidatos|Where-Object{Test-Path -LiteralPath $_ -PathType Leaf}|Select-Object -First 1)
    if($manager.Count -eq 0){throw "Instale NDK (Side by side) $versao pelo Android Studio > SDK Manager > SDK Tools > Show Package Details. Depois feche o Studio e execute novamente. Nenhum fonte foi alterado."}
    if([string]::IsNullOrWhiteSpace($env:JAVA_HOME)) {
        $jbr=Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
        if(Test-Path -LiteralPath (Join-Path $jbr 'bin\java.exe') -PathType Leaf){$env:JAVA_HOME=$jbr}
    }
    Write-Host "Instalando a ferramenta oficial Android NDK $versao no SDK. Isso pode exigir download e aceite de licenca no terminal."
    $anterior=$ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        & $manager[0] "--sdk_root=$sdk" '--install' "ndk;$versao"
        $codigo=$LASTEXITCODE
    } finally {$ErrorActionPreference=$anterior}
    if($codigo -ne 0 -or !(Ndk-Pronto)){throw "NDK $versao nao foi instalado. Confira o SDK Manager. Nenhum fonte foi alterado."}
}
# Invalidate only the generated strip output: an old unstripped result must not remain UP-TO-DATE.
$cache=Caminho-Seguro $Projeto 'app/build/intermediates/stripped_native_libs/desempenho'
if(Test-Path -LiteralPath $cache -PathType Container) {
    $fila=[Collections.Generic.Stack[string]]::new();$fila.Push($cache)
    while($fila.Count -gt 0) {
        foreach($f in @(Get-ChildItem -LiteralPath $fila.Pop() -Force)) {
            if($f.Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Link/juncao encontrado no cache nativo. Nada foi removido.'}
            if($f.PSIsContainer){$fila.Push($f.FullName)}
        }
    }
    Remove-Item -LiteralPath $cache -Recurse -Force
}
Write-Host "NDK $versao pronto. O Gradle podera retirar simbolos de depuracao das bibliotecas, preservando os bindings nativos."
