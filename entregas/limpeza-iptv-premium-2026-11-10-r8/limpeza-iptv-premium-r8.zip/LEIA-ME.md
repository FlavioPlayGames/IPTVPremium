# IPTV Premium — limpeza física, código e recursos (r8)

Base: r7, com pesquisa geral e limpeza de texto funcionando. A análise usa o inventário recebido e os fontes correspondentes. A limpeza não troca as regras de pesquisa, histórico, capas, perfis, assinatura ou cache da TV.

## Resultado do inventário

O projeto informado tem 4.644.172.018 bytes (4,32 GiB, exibidos como GB no Windows):

- 4.334.373.848 bytes em arquivos gerados de compilação/cache.
- 239.205.539 bytes em 144 pastas antigas de backup.
- Aproximadamente 70,6 MB no restante, antes da retirada dos recursos sem uso.

A limpeza de fontes remove 24 imagens sem referências (25.570.633 bytes), três arquivos antigos de antecipação de capas e métodos antigos que só atendiam a caminhos sem chamadas. O plano da reserva ativa de 15 até 25, em grupos de cinco, não foi alterado. Temas e Kids usam os recursos mantidos; não houve recompressão ou redesenho de imagens ativas. Licenças e configuração de serviços foram preservadas.

Após a limpeza física, o inventário indica uma pasta de aproximadamente 45 milhões de bytes (cerca de 43 MB no Windows), sem os gerados e backups, considerando os mesmos arquivos da auditoria. Isso é o tamanho do projeto limpo, não do aplicativo instalado. Compilações futuras recriam os intermediários.

## APK: redução real e limites da comparação

O otimizador já excluía os recursos sem uso do APK. A retirada das imagens melhora a organização e o tamanho dos fontes; não representa uma redução de 25 MB no APK.

Foi encontrada outra causa de peso: sem a ferramenta NDK, o Gradle estava incluindo símbolos de depuração em bibliotecas nativas. Com a ferramenta oficial Android NDK 28.2.13676358, o teste controlado com os mesmos fontes produziu:

| APK | Antes da preparação do NDK | Depois |
|---|---:|---:|
| ARM64 | 104.994.502 bytes | 97.064.646 bytes |
| ARMv7 | 90.152.752 bytes | 90.152.752 bytes |
| x86_64 | 113.215.287 bytes | 105.531.191 bytes |
| x86 | 100.556.488 bytes | 100.556.488 bytes |
| Universal | 259.951.556 bytes | 244.337.604 bytes |

A instalação escolhe o APK da arquitetura informada pela TV. A redução medida depende da arquitetura. O APK universal não é preferido quando há um APK compatível específico.

Foram comparadas as seções carregadas em memória das 20 bibliotecas nativas dos quatro APKs por arquitetura: conteúdo, endereços, tamanhos e tabelas de símbolos dinâmicos permaneceram iguais. O LibVLC principal permaneceu byte a byte igual; foram retiradas informações de depuração fora do código carregado. Não foi alterado codec, bitrate ou resolução.

A redução de tamanho não comprova aumento de FPS ou velocidade da interface. Não foi medida velocidade na TV nesta revisão.

## Preparação do NDK

O fluxo completo prepara o NDK no Android SDK, fora do projeto. Se faltar, tenta instalar pelo sdkmanager existente; o SDK Manager pode solicitar o aceite da licença no terminal. O NDK é uma ferramenta de desenvolvimento grande e ocupa espaço no SDK do computador; não entra no APK.

Se o sdkmanager não estiver instalado, a mensagem orienta abrir Android Studio > SDK Manager > SDK Tools > Show Package Details e instalar NDK (Side by side) 28.2.13676358. Depois feche o Studio e repita o comando. Essa etapa ocorre antes de mudar os fontes.

Se preferir fazer a limpeza sem preparar essa ferramenta agora, acrescente **-SemPrepararNdk** ao comando completo. A limpeza permanece; a redução nativa depende de o Gradle ter a ferramenta disponível. Esse parâmetro não remove um NDK já instalado.

## Executar

Feche o Android Studio e use um PowerShell separado. Mantenha a TV conectada e autorizada no ADB, como nas instalações anteriores.

Baixe limpeza-iptv-premium-r8.zip em Downloads e execute:

```powershell
$pasta = "$env:USERPROFILE\Downloads\limpeza-iptv-premium-r8"
Unblock-File -LiteralPath "$pasta.zip"
Expand-Archive -LiteralPath "$pasta.zip" -DestinationPath $pasta -Force
Set-Location $pasta
powershell -ExecutionPolicy Bypass -File .\Limpeza-Completa.ps1 -Projeto "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium"
```

O fluxo completo:

1. Prepara o NDK e invalida somente a saída gerada de remoção de símbolos para impedir reaproveitar bibliotecas antigas sem tratamento.
2. Confere todos os hashes da base r7 antes de alterar 28 arquivos. Guarda originais fora do projeto em Downloads\IPTV-restauracao-r8-DATA-HORA.
3. Compila desempenho com as configurações/assinatura locais e instala na TV com adb install -r. Se falhar, não executa a limpeza física.
4. Encerra os daemons Gradle, copia e confere os APKs por arquitetura em uma pasta externa de recuperação.
5. Compacta as 144 pastas antigas e a pasta de dois testes antigos de importação 1.07. Confere o conteúdo do ZIP por SHA256 e revalida os originais antes de excluí-los do projeto.
6. Remove somente app/build, build, .gradle e .kotlin, que são gerados e regeneráveis.

O arquivo plano-fisico.json lista explicitamente os caminhos recebidos no inventário. Não existe exclusão genérica de tudo que contenha "backup" ou "teste". Caminhos não previstos, configurações de serviços, arquivos de assinatura, Gradle, wrapper, fontes em uso e configuração do IDE são preservados. Links/junções em alvos da limpeza interrompem a execução.

O processo não apaga dados nem cache da TV, não desinstala o aplicativo e não exige reimportar a lista. Mantém as cotas existentes de cache de 100 MB no total, até 75 MB de imagens e LRU de 125 capas por tipo. A meta de 400 MB do aplicativo completo ainda depende de recursos, bancos e dados persistentes no aparelho; não foi medida remotamente.

## Recuperação e nova instalação

São criadas duas pastas externas em Downloads:

- **IPTV-restauracao-r8-DATA-HORA:** originais dos arquivos de código/recursos retirados, estado e hashes para desfazer a r8. O aplicador mostra o comando de Desfazer-Limpeza.ps1. Depois de desfazer, recompile para restaurar o APK anterior.
- **IPTV-recuperacao-fisica-DATA-HORA:** backups-antigos.zip, APKs-desempenho, tamanhos-apk.csv e instruções. Para recuperar as pastas antigas, extraia o ZIP na raiz do projeto.

Os APKs finais por arquitetura ficam em APKs-desempenho, fora de app/build. Para reinstalar sem recompilar, o instalador aceita -SemCompilar -PastaApks "CAMINHO_DA_RECUPERACAO\APKs-desempenho".

Guarde a recuperação enquanto confere a TV. **Não publique nem envie os ZIPs de recuperação:** backups antigos podem conter configurações privadas. Para conferir o resultado, envie somente tamanhos-apk.csv ou um novo inventário de metadados.

A limpeza libera espaço no projeto; o espaço livre total do PC também depende do arquivo externo de recuperação, dos APKs preservados e da instalação opcional do NDK.

## Correção de compatibilidade Windows PowerShell 5.1

Limpar-Arquivos.ps1 carrega explicitamente System.IO.Compression e System.IO.Compression.FileSystem antes de usar ZipArchiveMode. Se a instalação já terminou e a primeira execução parou nesse tipo, baixe o pacote corrigido e execute somente Limpar-Arquivos.ps1. Não precisa recompilar/reinstalar.

O parâmetro opcional -Recuperacao aceita a pasta externa criada na tentativa interrompida, reaproveitando os APKs ali copiados. Essa pasta não pode ficar dentro do projeto e não pode já conter backups-antigos.zip, para impedir sobrescrever um arquivo de recuperação existente.
