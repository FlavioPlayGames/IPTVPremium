# Validação — r8

## Referências e remoção

- Inventário recebido: 12.238 arquivos, 4.644.172.018 bytes, nenhum aviso de leitura/links. Os tamanhos dos fontes Java/Kotlin conferem com a cópia r7 disponível.
- 24 imagens apontadas pelo Lint foram conferidas contra referências Kotlin, XML e ativos, incluindo resolução dinâmica. Não há chamadas getIdentifier no código do aplicativo. Os arquivos com nomes semelhantes ainda usados pelos temas foram mantidos. Nenhuma imagem ativa foi convertida ou redesenhada.
- Removidos PosterWindow.kt (janela abandonada da r5), PosterAheadQueue.kt e PosterAheadWindow.kt, após retirar as funções sem chamadas que referiam essas classes.
- Em MoviePosterLoader, retirados prefetchCategoryBatch, prefetchPriorityBatch, prefetchAhead, saveRecent e prefetchUnmanaged. Inclui o auxiliar local do antigo prefetchAhead; os caminhos ativos foram mantidos. A fonte total removida, incluindo imagens, soma 25.582.567 bytes.
- Mantidos project_id e cinema_title_license: configuração de serviço e licença não foram eliminadas por um aviso de ausência de referência direta.
- Configurações, controle parental, perfis, pesquisa r7, histórico e políticas de cache não foram alterados. Os arquivos dos algoritmos de armazenamento permanecem idênticos aos originais.

## Android e APK

compileDesempenhoKotlin e lintDesempenho passaram. Lint: zero erros, 154 avisos e 6 sugestões. Os avisos UnusedResources caíram de 26 para 2, referentes à licença/configuração preservadas.

assembleDesempenho passou antes e depois da preparação do NDK oficial 28.2.13676358. A segunda compilação reexecutou a etapa de strip após invalidar somente seu diretório de saída; as outras opções/fontes permaneceram iguais. A tabela de tamanhos em LEIA-ME.md é uma comparação controlada desse ambiente, não dos APKs assinados pelo usuário.

Foram verificadas 20 bibliotecas dos APKs das quatro arquiteturas: seções ELF SHF_ALLOC, seus tipos/flags/endereços/tamanhos e dados byte a byte iguais antes/depois. Isso inclui símbolos e strings dinâmicos. LibVLC principal igual; libc++_shared ARM64 passou de 9.290.184 para 1.374.336 bytes com a retirada de informações de depuração. Não houve alteração de instruções/carregamento de código das seções verificadas.

APKs locais são somente artefatos de teste, assinados com chave de desenvolvimento do ambiente. Não foram publicados nem enviados para instalação. O pacote entregue contém fontes/scripts; o instalador usa as configurações e assinatura locais do usuário.

## Testes portáveis

Passaram as regressões r7 de pesquisa global/limpeza, favoritos/Continuar, debounce, identidade de arte, histórico (incluindo 2.200 fatos e mais de 400 registros), perfis, capas/ambiguidades, fila de metadados/imagens, reserva de 15 até 25, grupos de cinco, cancelamento antes do início, cache entre processos, seleção M3U e armazenamento rotativo.

As respostas de rede, bitmaps e dependências Android/DAO dos testes JVM são adaptadas/simuladas conforme os fontes dos testes. Não comprovam a aparência na TV nem ganho de velocidade do aplicativo.

## Scripts de limpeza

- Aplicador real de 28 arquivos testado com os arquivos originais: aplicação, repetição, backup externo, desfazer e recusa de edições posteriores passaram.
- Comportamento de arrays JSON do Windows PowerShell 5.1 também simulado; aplicação/repetição/restauração passaram.
- Limpeza física testada com árvores pequenas: ZIP com arquivos ocultos, comparação SHA256, exclusão somente depois da verificação, APK preservado, arquivos privados/configurações e pastas não previstas intactos. Link aninhado interrompeu o processo.
- A sequência completa foi testada com dependências simuladas: falha na instalação impede a limpeza física.
- Preparação do NDK testada com SDK Manager simulado: pacote/versionamento oficiais passados corretamente e somente a saída stripped_native_libs/desempenho invalidada; variante debug preservada.
- Testes de scripts em PowerShell 7/Linux, com compatibilidade de sintaxe para Windows PowerShell 5.1; não executados no Windows/TV reais nesta revisão.

A compactação de backups e a preservação de APKs são locais no computador. Nenhum conteúdo desses arquivos é enviado pelo script. Logs de Gradle, configurações privadas, binários/APKs, assinaturas, lista M3U e ZIPs antigos não fazem parte da entrega pública.

## Limites e resultado esperado

A projeção de cerca de 43 MB na pasta limpa usa o inventário recebido, a remoção de gerados/backups/testes antigos e a diferença de fontes/recursos. Não é uma medida final no PC; compilação futura recria intermediários. O NDK ocupa espaço separado no SDK, e a recuperação/APKs ficam em Downloads.

A limpeza de arquivos sem uso não comprova redução de latência/FPS. A melhoria comprovada no APK é a retirada de depuração em arquiteturas que a continham, especialmente ARM64. ARMv7/x86 não tiveram redução nessa comparação. Aparência e reprodução na TV ainda devem ser conferidas.

Correção posterior ao teste no Windows: o PowerShell 5.1 não carregava automaticamente a assembly base de compressão ao carregar FileSystem. Adicionado carregamento explícito das duas assemblies. O erro ocorria antes da criação/verificação do ZIP e das exclusões físicas. Testado novamente o fluxo e o reaproveitamento de uma pasta externa interrompida, sem recompilação/reinstalação.
