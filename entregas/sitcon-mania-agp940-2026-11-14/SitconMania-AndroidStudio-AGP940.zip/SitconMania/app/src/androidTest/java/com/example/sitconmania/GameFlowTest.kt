package com.example.sitconmania

import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.lifecycle.ViewModelProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.example.sitconmania.game.GameViewModel
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

/** Run on a device/emulator with API 28+ using connectedDebugAndroidTest. */
@RunWith(AndroidJUnit4::class)
class GameFlowTest {
    @get:Rule val compose=createAndroidComposeRule<MainActivity>()
    @Test fun startsNativeGameUsesHintAndSurvivesActivityRecreation(){
        compose.onNodeWithText("🎬 Começar o programa").performScrollTo().performClick()
        compose.onNodeWithText("🎬 No ar!").assertExists()
        compose.onNodeWithText("🎭 Dica do Elenco").performScrollTo().performClick()
        compose.onNodeWithText("✅ Dica usada").assertIsNotEnabled()
        var question=""
        compose.runOnIdle{question=ViewModelProvider(compose.activity)[GameViewModel::class.java].state.question!!.text}
        compose.activityRule.scenario.recreate()
        compose.onNodeWithText(question).assertExists()
        compose.onNodeWithText("✅ Dica usada").assertExists()
    }
}
