package com.example.sitconmania.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sitconmania.model.QuizState
import com.example.sitconmania.ui.components.*
import com.example.sitconmania.ui.theme.SitcomColors as C

@Composable
fun ResultsScreen(state:QuizState,onAgain:()->Unit,onHome:()->Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(15.dp)) {
        ComicPanel(Modifier.fillMaxWidth()) {
            Text(if(state.tied)"👏"else"🏆",fontSize=62.sp,modifier=Modifier.align(Alignment.CenterHorizontally))
            Text("FIM DE TEMPORADA",color=Color(0xFFAF5147),fontWeight=FontWeight.Black,letterSpacing=1.sp,fontSize=12.sp,modifier=Modifier.align(Alignment.CenterHorizontally))
            Text(if(state.tied)"Elenco empatado!"else"A estrela da noite é ${state.ranking.firstOrNull()?.name.orEmpty()}!",
                color=C.Ink,fontSize=33.sp,lineHeight=39.sp,fontWeight=FontWeight.Black,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
            Text("Fim da temporada: placar final do elenco.",color=C.Muted,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
            state.ranking.forEachIndexed{index,player->
                Row(Modifier.fillMaxWidth().background(Color.White,RoundedCornerShape(12.dp)).border(1.dp,Color(0xFFE4DFD5),RoundedCornerShape(12.dp)).padding(12.dp),
                    verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                    Text("#${index+1}",color=C.Ink,fontWeight=FontWeight.Bold)
                    Text(player.avatar,fontSize=24.sp)
                    Text(player.name,color=C.Ink,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f),maxLines=1,overflow=TextOverflow.Ellipsis)
                    Text("${player.score} pts",color=Color(0xFFB94E47),fontWeight=FontWeight.Bold)
                }
            }
            ComicButton("🔁 Jogar outra vez",onAgain,Modifier.fillMaxWidth())
            ComicButton("🏠 Início",onHome,Modifier.fillMaxWidth(),primary=false)
        }
    }
}
