package com.example.sitconmania.data

import com.example.sitconmania.model.Question

/** The 40 original questions, kept separate from the rules and screen layouts. */
object QuestionBank {
    val all:List<Question> = listOf(
        Question(0,"Friends","☕","Em qual cafeteria o grupo costuma se encontrar?","Central Perk",listOf("Central Perk","Monk's Café","MacLaren's Pub","Café Nervosa")),
        Question(1,"Friends","☕","Qual é a profissão de Monica no começo da série?","Chef",listOf("Chef","Paleontóloga","Atriz","Advogada")),
        Question(2,"Friends","☕","Qual personagem é paleontólogo?","Ross Geller",listOf("Ross Geller","Chandler Bing","Joey Tribbiani","Gunther")),
        Question(3,"Friends","☕","Qual é o bordão de Joey ao flertar?","How you doin'?",listOf("How you doin'?","Bazinga!","Suit up!","Yada yada yada!")),
        Question(4,"The Big Bang Theory","🧪","Em qual cidade californiana a série se passa principalmente?","Pasadena",listOf("Pasadena","San Diego","Sacramento","San Francisco")),
        Question(5,"The Big Bang Theory","🧪","Quem divide o apartamento 4A com Leonard?","Sheldon Cooper",listOf("Sheldon Cooper","Howard Wolowitz","Raj Koothrappali","Stuart Bloom")),
        Question(6,"The Big Bang Theory","🧪","Onde Penny trabalha como garçonete no começo?","The Cheesecake Factory",listOf("The Cheesecake Factory","Central Perk","Monk's Café","Dunder Mifflin")),
        Question(7,"The Big Bang Theory","🧪","Qual expressão Sheldon usa para revelar uma pegadinha?","Bazinga!",listOf("Bazinga!","How you doin'?","Suit up!","Yada yada yada!")),
        Question(8,"Eu, a Patroa e as Crianças","🏠","Qual é o nome do pai da família Kyle?","Michael Kyle",listOf("Michael Kyle","Frank Lambert","Julius Rock","Philip Banks")),
        Question(9,"Eu, a Patroa e as Crianças","🏠","Qual atriz interpreta Jay, esposa de Michael?","Tisha Campbell",listOf("Tisha Campbell","Tracee Ellis Ross","Kim Fields","Janet Jackson")),
        Question(10,"Eu, a Patroa e as Crianças","🏠","Como a família chama o filho mais velho, Michael Jr.?","Junior",listOf("Junior","Franklin","Frankie","J.J.")),
        Question(11,"Eu, a Patroa e as Crianças","🏠","Qual é o nome da filha caçula dos Kyle?","Kady",listOf("Kady","Claire","Ashley","Vanessa")),
        Question(12,"The Office (EUA)","📎","Como se chama a empresa de papel em que trabalham?","Dunder Mifflin",listOf("Dunder Mifflin","Staples","Bluth Company","Sterling Cooper")),
        Question(13,"The Office (EUA)","📎","Em qual cidade fica a filial da série?","Scranton",listOf("Scranton","Pittsburgh","Albany","Buffalo")),
        Question(14,"The Office (EUA)","📎","Quem é o gerente regional no começo da série?","Michael Scott",listOf("Michael Scott","Jim Halpert","Dwight Schrute","David Wallace")),
        Question(15,"The Office (EUA)","📎","Qual colega trabalha na recepção no início?","Pam Beesly",listOf("Pam Beesly","Angela Martin","Kelly Kapoor","Erin Hannon")),
        Question(16,"Brooklyn Nine-Nine","🚔","Em qual distrito de Nova York trabalham os detetives?","Brooklyn",listOf("Brooklyn","Queens","Manhattan","Bronx")),
        Question(17,"Brooklyn Nine-Nine","🚔","Qual é o número do distrito policial da equipe?","99º",listOf("99º","21º","12º","47º")),
        Question(18,"Brooklyn Nine-Nine","🚔","Quem é o detetive brincalhão que adora resolver casos?","Jake Peralta",listOf("Jake Peralta","Raymond Holt","Charles Boyle","Terry Jeffords")),
        Question(19,"Brooklyn Nine-Nine","🚔","Qual é o nome do capitão da delegacia?","Raymond Holt",listOf("Raymond Holt","Kevin Cozner","Jake Peralta","Doug Judy")),
        Question(20,"Modern Family","👨‍👩‍👧‍👦","Qual é o sobrenome do patriarca Jay?","Pritchett",listOf("Pritchett","Dunphy","Tucker","Delgado")),
        Question(21,"Modern Family","👨‍👩‍👧‍👦","Quem é o marido de Claire Dunphy?","Phil",listOf("Phil","Mitchell","Cameron","Manny")),
        Question(22,"Modern Family","👨‍👩‍👧‍👦","Qual é o nome do filho de Gloria de seu relacionamento anterior?","Manny",listOf("Manny","Luke","Alex","Joe")),
        Question(23,"Modern Family","👨‍👩‍👧‍👦","Quem forma um casal com Mitchell?","Cameron",listOf("Cameron","Phil","Jay","Javier")),
        Question(24,"How I Met Your Mother","🍻","Quem conta aos filhos a história de como conheceu a mãe deles?","Ted Mosby",listOf("Ted Mosby","Barney Stinson","Marshall Eriksen","Carl MacLaren")),
        Question(25,"How I Met Your Mother","🍻","Em qual bar o grupo costuma se reunir?","MacLaren's Pub",listOf("MacLaren's Pub","Central Perk","Monk's Café","The Cheesecake Factory")),
        Question(26,"How I Met Your Mother","🍻","Qual personagem populariza a frase “Suit up!”?","Barney Stinson",listOf("Barney Stinson","Ted Mosby","Marshall Eriksen","Ranjit")),
        Question(27,"How I Met Your Mother","🍻","Qual integrante do grupo nasceu no Canadá?","Robin Scherbatsky",listOf("Robin Scherbatsky","Lily Aldrin","Tracy McConnell","Victoria")),
        Question(28,"Um Maluco no Pedaço","🏀","De onde Will se muda para Bel-Air?","West Philadelphia",listOf("West Philadelphia","Queens","Compton","South Central Los Angeles")),
        Question(29,"Um Maluco no Pedaço","🏀","Qual é o nome do tio de Will?","Philip Banks",listOf("Philip Banks","Carl Winslow","Michael Kyle","Jay Pritchett")),
        Question(30,"Um Maluco no Pedaço","🏀","Qual primo é conhecido por dançar ao som de Tom Jones?","Carlton",listOf("Carlton","Hilary","Ashley","Nicky")),
        Question(31,"Um Maluco no Pedaço","🏀","Qual é o nome do mordomo da família Banks?","Geoffrey",listOf("Geoffrey","Alfonso","Jeeves","Franklin")),
        Question(32,"Seinfeld","🎙️","Qual é a profissão do personagem Jerry Seinfeld?","Comediante de stand-up",listOf("Comediante de stand-up","Detetive","Paleontólogo","Chef")),
        Question(33,"Seinfeld","🎙️","Qual é o sobrenome do melhor amigo de Jerry, George?","Costanza",listOf("Costanza","Kramer","Benes","Peterman")),
        Question(34,"Seinfeld","🎙️","Qual é o sobrenome do vizinho excêntrico Cosmo?","Kramer",listOf("Kramer","Costanza","Seinfeld","Newman")),
        Question(35,"Seinfeld","🎙️","Qual celebração fictícia George e seu pai associam a um poste de alumínio?","Festivus",listOf("Festivus","Life Day","Festivale","The Human Fund")),
        Question(36,"Two and a Half Men","🎹","Qual é o trabalho de Charlie Harper?","Compositor de jingles",listOf("Compositor de jingles","Médico","Detetive","Professor universitário")),
        Question(37,"Two and a Half Men","🎹","Qual é a profissão de Alan Harper?","Quiroprático",listOf("Quiroprático","Advogado","Engenheiro","Chef")),
        Question(38,"Two and a Half Men","🎹","Quem é Jake em relação a Charlie?","Sobrinho",listOf("Sobrinho","Irmão","Primo","Vizinho")),
        Question(39,"Two and a Half Men","🎹","Onde fica a casa de Charlie no começo da série?","Malibu",listOf("Malibu","Manhattan","Texas","Scranton"))
    )
}
