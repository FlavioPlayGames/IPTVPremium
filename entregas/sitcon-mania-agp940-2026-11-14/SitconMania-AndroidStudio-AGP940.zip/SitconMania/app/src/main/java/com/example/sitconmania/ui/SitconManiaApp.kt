package com.example.sitconmania.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.dp
import com.example.sitconmania.audio.GameAudio
import com.example.sitconmania.game.GameViewModel
import com.example.sitconmania.model.Phase
import com.example.sitconmania.ui.components.*
import com.example.sitconmania.ui.screens.*

@Composable
fun SitconManiaApp(model:GameViewModel,audio:GameAudio) {
    val state=model.state
    val view=LocalView.current
    val playing=state.phase !in listOf(Phase.HOME,Phase.RESULTS)
    DisposableEffect(view,playing){val previous=view.keepScreenOn;view.keepScreenOn=playing;onDispose{view.keepScreenOn=previous}}
    var lastSound by remember{mutableLongStateOf(state.soundVersion)}
    SideEffect{audio.update(state.soundEnabled,state.phase==Phase.HOME)}
    LaunchedEffect(state.soundVersion){if(lastSound!=state.soundVersion){state.sounds.forEach(audio::play);lastSound=state.soundVersion}}
    BackHandler(enabled=state.phase!=Phase.HOME,onBack=model::requestExit)
    PartyBackground {
        Column(Modifier.align(Alignment.TopCenter).widthIn(max=1000.dp).fillMaxSize().safeDrawingPadding().imePadding().padding(14.dp),
            verticalArrangement=Arrangement.spacedBy(14.dp)) {
            AppHeader(state.soundEnabled,model::toggleSound)
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when(state.phase){
                    Phase.HOME->HomeScreen(state,model::name,model::avatar,model::rounds,model::start)
                    Phase.RESULTS->ResultsScreen(state,model::rematch,model::home)
                    else->GameScreen(state,model::answer,model::hint)
                }
            }
        }
        if(state.phase==Phase.COMMERCIAL&&!state.exitConfirmation)CommercialDialog(state.seconds,state.feedback,model::requestExit)
        if(state.exitConfirmation)AlertDialog(onDismissRequest=model::cancelExit,
            title={Text("Voltar ao início?")},text={Text("A partida atual será encerrada. Você pode começar outra depois.")},
            confirmButton={TextButton(onClick=model::home){Text("Encerrar partida")}},
            dismissButton={TextButton(onClick=model::cancelExit){Text("Continuar jogando")}})
    }
}
