package com.example.sitconmania.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sitconmania.model.QuizState
import com.example.sitconmania.ui.components.*
import com.example.sitconmania.ui.theme.SitcomColors as C

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HomeScreen(state:QuizState,onName:(Int,String)->Unit,onAvatar:(Int,String)->Unit,onRounds:(Int)->Unit,onStart:()->Unit) {
    val focus=LocalFocusManager.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide=maxWidth>=700.dp
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(14.dp)) {
            ComicPanel(Modifier.fillMaxWidth()) {
                Text("A NOITE DE COMÉDIA COMEÇA AGORA",color=Color(0xFFAF5147),fontSize=11.sp,fontWeight=FontWeight.Black,letterSpacing=1.sp)
                Row(verticalAlignment=Alignment.CenterVertically) {
                    Text("SITCOM\nMANIA",color=C.Navy,fontWeight=FontWeight.Black,fontSize=if(wide)76.sp else 58.sp,lineHeight=if(wide)65.sp else 51.sp,
                        letterSpacing=(-3).sp,style=TextStyle(shadow=Shadow(C.Yellow,Offset(3f,4f),0f)),modifier=Modifier.weight(1f))
                    if(wide)Text("🛋️🎬",fontSize=65.sp)
                }
                Text("Reúna o elenco, aqueça a memória e dispute quem conhece melhor as séries que viraram parte da família.",color=Color(0xFF506174),fontSize=16.sp,lineHeight=23.sp)
                FlowRow(horizontalArrangement=Arrangement.spacedBy(7.dp),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    Badge("☕ Friends");Badge("🧪 The Big Bang Theory")
                    Badge("🏠 Eu, a Patroa e as Crianças");Badge("🎬 +7 clássicos")
                }
            }
            if(wide)Row(horizontalArrangement=Arrangement.spacedBy(14.dp)) {
                SetupPanel(state,onName,onAvatar,onRounds,{focus.clearFocus();onStart()},Modifier.weight(1.1f))
                RulesPanel(Modifier.weight(.9f))
            }else {
                SetupPanel(state,onName,onAvatar,onRounds,{focus.clearFocus();onStart()},Modifier.fillMaxWidth())
                RulesPanel(Modifier.fillMaxWidth())
            }
            Text("Feito para fãs de sitcoms · alternativas embaralhadas em cada partida",color=Color.White.copy(alpha=.65f),fontSize=11.sp,
                modifier=Modifier.align(Alignment.CenterHorizontally).padding(vertical=8.dp))
        }
    }
}

@Composable
private fun Badge(text:String){Text(text,color=C.Ink,fontSize=11.sp,fontWeight=FontWeight.Bold,
    modifier=Modifier.background(Color.White,RoundedCornerShape(30.dp)).border(1.dp,Color(0xFFE8DFD0),RoundedCornerShape(30.dp)).padding(horizontal=9.dp,vertical=7.dp))}

@Composable
private fun SetupPanel(state:QuizState,onName:(Int,String)->Unit,onAvatar:(Int,String)->Unit,onRounds:(Int)->Unit,onStart:()->Unit,modifier:Modifier) {
    ComicPanel(modifier) {
        Text("Monte seu elenco",fontSize=23.sp,fontWeight=FontWeight.Bold,color=C.Ink)
        Text("De 2 a 4 jogadores. Campos vazios serão ignorados.",fontSize=14.sp,color=C.Muted)
        state.drafts.forEachIndexed{index,draft->
            var expanded by remember{mutableStateOf(false)}
            Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(9.dp)) {
                Box {
                    TextButton(onClick={expanded=true},contentPadding=PaddingValues(0.dp),modifier=Modifier.size(48.dp)) {Text(draft.avatar,fontSize=26.sp)}
                    DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}) {
                        listOf("☕","🛋️","🎤","📺","🍕","🎭","⭐","🎬").forEach{icon->DropdownMenuItem(text={Text(icon,fontSize=24.sp)},onClick={onAvatar(index,icon);expanded=false})}
                    }
                }
                OutlinedTextField(value=draft.name,onValueChange={onName(index,it)},singleLine=true,
                    label={Text("Jogador ${index+1}")},modifier=Modifier.weight(1f),shape=RoundedCornerShape(10.dp))
            }
        }
        Text("Episódios por jogador:",color=C.Ink,fontWeight=FontWeight.Bold,fontSize=14.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            listOf(5,8).forEach{n->FilterChip(selected=state.rounds==n,onClick={onRounds(n)},label={Text("$n episódios")})}
        }
        state.formError?.let{Text(it,color=C.Failure,fontWeight=FontWeight.Bold,fontSize=14.sp)}
        ComicButton("🎬 Começar o programa",onStart,Modifier.fillMaxWidth())
    }
}

@Composable
private fun RulesPanel(modifier:Modifier) {
    val rules=listOf("⏱️" to "20 segundos para responder cada pergunta.","⭐" to "Acerto vale 2 pontos; nos primeiros 5 segundos, ganha +1.",
        "📣" to "A cada 5 perguntas, um episódio especial vale +2 pontos.","🎭" to "Cada jogador tem uma Dica do Elenco para cortar duas alternativas erradas.",
        "📺" to "Erro ou tempo esgotado abre intervalo comercial de 15 segundos.","🏆" to "Vence quem tiver mais pontos ao fim. Perguntas não se repetem na partida.")
    ComicPanel(modifier) {
        Text("Como jogar",color=C.Ink,fontSize=23.sp,fontWeight=FontWeight.Bold)
        rules.forEach{(icon,copy)->Row(horizontalArrangement=Arrangement.spacedBy(9.dp)){Text(icon,fontSize=20.sp);Text(copy,color=Color(0xFF506174),fontSize=14.sp,lineHeight=21.sp)}}
    }
}
