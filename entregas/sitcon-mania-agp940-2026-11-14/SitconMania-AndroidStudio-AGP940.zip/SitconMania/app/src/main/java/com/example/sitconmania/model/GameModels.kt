package com.example.sitconmania.model

import java.io.Serializable

enum class Phase { HOME, QUESTION, FEEDBACK, COMMERCIAL, RESULTS }
enum class SoundEffect { MOVE, CORRECT, WRONG, TICK, WIN, HINT }
data class PlayerDraft(val name:String,val avatar:String):Serializable
data class Player(val name:String,val avatar:String,val score:Int=0,val hintUsed:Boolean=false):Serializable
data class Question(val id:Int,val show:String,val icon:String,val text:String,val correct:String,val options:List<String>):Serializable {
    val correctIndex:Int get()=options.indexOf(correct)
}
data class QuizState(
    val drafts:List<PlayerDraft> = listOf(PlayerDraft("Jogador 1","☕"),PlayerDraft("Jogador 2","🛋️"),PlayerDraft("","🎤"),PlayerDraft("","📺")),
    val rounds:Int=8,
    val soundEnabled:Boolean=true,
    val phase:Phase=Phase.HOME,
    val players:List<Player> = emptyList(),
    val deck:List<Question> = emptyList(),
    val position:Int=0,
    val remainingMillis:Long=20_000L,
    val selectedAnswer:Int?=null,
    val frozenSeconds:Int=20,
    val hiddenAnswers:Set<Int> = emptySet(),
    val feedback:String="",
    val correctFeedback:Boolean=false,
    val formError:String?=null,
    val exitConfirmation:Boolean=false,
    val soundVersion:Long=0,
    val sounds:List<SoundEffect> = emptyList()
):Serializable {
    val activeIndex:Int get()=if(players.isEmpty())0 else position%players.size
    val question:Question? get()=deck.getOrNull(position)
    val activePlayer:Player? get()=players.getOrNull(activeIndex)
    val episode:Int get()=if(players.isEmpty())1 else position/players.size+1
    val special:Boolean get()=(position+1)%5==0
    val seconds:Int get()=((remainingMillis+999)/1000).toInt().coerceAtLeast(0)
    val ranking:List<Player> get()=players.sortedByDescending{it.score}
    val tied:Boolean get()=players.count{it.score==ranking.firstOrNull()?.score}>1
}
