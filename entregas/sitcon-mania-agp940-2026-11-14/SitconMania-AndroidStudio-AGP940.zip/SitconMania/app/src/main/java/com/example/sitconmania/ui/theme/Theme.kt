package com.example.sitconmania.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

@Composable
fun SitconManiaTheme(content:@Composable ()->Unit) {
    MaterialTheme(colorScheme=lightColorScheme(primary=SitcomColors.Coral,secondary=SitcomColors.Teal,
        tertiary=SitcomColors.Yellow,background=SitcomColors.Navy,surface=SitcomColors.Cream,
        onSurface=SitcomColors.Ink,onBackground=androidx.compose.ui.graphics.Color.White),typography=Typography,content=content)
}
