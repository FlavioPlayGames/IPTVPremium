package com.example.sitconmania.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sitconmania.model.*
import com.example.sitconmania.ui.components.*
import com.example.sitconmania.ui.theme.SitcomColors as C

@Composable
fun GameScreen(state:QuizState,onAnswer:(Int)->Unit,onHint:()->Unit) {
    val question=state.question?:return
    val scroll=remember(state.position){ScrollState(0)}
    BoxWithConstraints(Modifier.fillMaxSize()) {
        val wide=maxWidth>=650.dp
        Column(Modifier.fillMaxSize().verticalScroll(scroll),verticalArrangement=Arrangement.spacedBy(14.dp)) {
            Row(verticalAlignment=Alignment.CenterVertically) {
                Text("🎬 No ar!",color=Color.White,fontSize=23.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f))
                Text("Episódio ${state.episode} de ${state.rounds}",color=Color.White,fontSize=13.sp,
                    modifier=Modifier.border(1.dp,Color.White.copy(alpha=.35f),RoundedCornerShape(30.dp)).padding(10.dp))
            }
            LazyRow(horizontalArrangement=Arrangement.spacedBy(8.dp),contentPadding=PaddingValues(bottom=4.dp)) {
                itemsIndexed(state.players){index,player->
                    Column(Modifier.widthIn(min=125.dp,max=205.dp).background(C.Cream,RoundedCornerShape(13.dp))
                        .border(2.dp,if(index==state.activeIndex)C.Yellow else Color.Transparent,RoundedCornerShape(13.dp)).padding(11.dp)) {
                        Text("${player.avatar} ${player.name}",color=C.Ink,fontWeight=FontWeight.Bold,maxLines=1,overflow=TextOverflow.Ellipsis)
                        Text("${player.score} pts",color=Color(0xFFBC5149),fontSize=22.sp,fontWeight=FontWeight.Black)
                    }
                }
            }
            ComicPanel(Modifier.fillMaxWidth(),stripe=true) {
                Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    Text("${question.icon} ${question.show}",fontSize=17.sp,fontWeight=FontWeight.Bold,color=Color(0xFF526678),modifier=Modifier.weight(1f))
                    if(wide)TimeBar((if(state.phase==Phase.QUESTION)state.remainingMillis/1000f else state.frozenSeconds.toFloat())/20f,Modifier.width(150.dp))
                    Text("⏱ ${if(state.phase==Phase.QUESTION)state.seconds else state.frozenSeconds}",color=Color(0xFFAF4742),fontSize=20.sp,fontWeight=FontWeight.Bold)
                }
                if(state.special)Text("✨ Episódio especial · +2 pontos",color=Color(0xFF875600),fontSize=12.sp,fontWeight=FontWeight.Bold,
                    modifier=Modifier.align(Alignment.CenterHorizontally).background(Color(0xFFFFF0BB),RoundedCornerShape(30.dp)).padding(8.dp))
                Text(question.text,color=C.Ink,fontWeight=FontWeight.Bold,fontSize=if(wide)27.sp else 22.sp,lineHeight=30.sp,
                    textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth().padding(vertical=8.dp))
                question.options.indices.toList().chunked(if(wide)2 else 1).forEach{row->
                    Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                        row.forEach{index->AnswerOption(index,question.options[index],state,onAnswer,Modifier.weight(1f))}
                    }
                }
                Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
                    ComicButton(if(state.activePlayer?.hintUsed==true)"✅ Dica usada"else"🎭 Dica do Elenco",onHint,primary=false,
                        enabled=state.phase==Phase.QUESTION&&state.activePlayer?.hintUsed==false)
                    Text("Vez de ${state.activePlayer?.name.orEmpty()}",color=C.Muted,fontSize=13.sp,modifier=Modifier.weight(1f),textAlign=TextAlign.End)
                }
                Text(state.feedback,color=when(state.phase){Phase.FEEDBACK->C.Success;Phase.COMMERCIAL->C.Failure;else->C.Muted},
                    textAlign=TextAlign.Center,fontWeight=FontWeight.Bold,fontSize=14.sp,modifier=Modifier.fillMaxWidth().heightIn(min=24.dp))
            }
            val answered=state.position+if(state.phase==Phase.QUESTION)0 else 1
            Canvas(Modifier.fillMaxWidth().height(20.dp)) {
                val count=state.deck.size;val gap=minOf(11.dp.toPx(),size.width/(count+1));val start=(size.width-(count-1)*gap)/2
                repeat(count){index->drawCircle(when{index<answered->C.Teal;index==state.position->C.Coral;else->Color(0xFFD5DCE2)},3.3.dp.toPx(),androidx.compose.ui.geometry.Offset(start+index*gap,size.height/2))}
            }
        }
    }
}

@Composable
private fun AnswerOption(index:Int,text:String,state:QuizState,onAnswer:(Int)->Unit,modifier:Modifier) {
    val revealed=state.phase!=Phase.QUESTION
    val good=revealed&&index==state.question?.correctIndex
    val bad=revealed&&index==state.selectedAnswer&&!good
    val hidden=index in state.hiddenAnswers
    val shape=RoundedCornerShape(13.dp)
    val edge=when{good->Color(0xFF48B397);bad->Color(0xFFE97870);else->Color(0xFFE7E2D9)}
    Row(modifier.heightIn(min=60.dp).alpha(if(hidden).35f else 1f)
        .background(when{good->Color(0xFFE8F9F3);bad->Color(0xFFFFF0EF);else->Color.White},shape)
        .border(2.dp,edge,shape).semantics(mergeDescendants=true){stateDescription=when{good->"Resposta correta";bad->"Resposta incorreta";hidden->"Alternativa eliminada";else->"Alternativa disponível"}}
        .clickable(enabled=!revealed&&!hidden,role=Role.Button){onAnswer(index)}.padding(12.dp),
        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(29.dp).background(if(good||bad)edge else Color(0xFFF0EDE6),RoundedCornerShape(8.dp)),contentAlignment=Alignment.Center){
            Text(if(hidden)"×"else('A'+index).toString(),color=if(good||bad)Color.White else C.Ink,fontWeight=FontWeight.Bold)
        }
        Text(text,color=C.Ink,fontWeight=FontWeight.SemiBold,fontSize=15.sp,textDecoration=if(hidden)TextDecoration.LineThrough else TextDecoration.None)
    }
}
