package com.example.sitconmania.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.sitconmania.ui.components.ComicPanel
import com.example.sitconmania.ui.components.TimeBar
import com.example.sitconmania.ui.theme.SitcomColors as C

@Composable
fun CommercialDialog(seconds:Int,answerMessage:String,onExit:()->Unit) {
    Dialog(onDismissRequest=onExit,properties=DialogProperties(dismissOnClickOutside=false,usePlatformDefaultWidth=false)) {
        Box(Modifier.fillMaxWidth().padding(18.dp),contentAlignment=Alignment.Center) {
            ComicPanel(Modifier.widthIn(max=420.dp).fillMaxWidth()) {
                Text("📺",fontSize=52.sp,modifier=Modifier.align(Alignment.CenterHorizontally))
                Text("Intervalo comercial",color=C.Ink,fontSize=27.sp,fontWeight=FontWeight.Bold,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
                Text(answerMessage,color=C.Failure,textAlign=TextAlign.Center,fontWeight=FontWeight.SemiBold,modifier=Modifier.fillMaxWidth())
                Text("A próxima pergunta começa em $seconds segundos. Respire e prepare a resposta!",color=C.Muted,textAlign=TextAlign.Center,modifier=Modifier.fillMaxWidth())
                Text("$seconds",color=C.Coral,fontSize=44.sp,fontWeight=FontWeight.Black,modifier=Modifier.align(Alignment.CenterHorizontally))
                TimeBar(seconds/15f,Modifier.fillMaxWidth())
            }
        }
    }
}
