package com.example.sitconmania.game

import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import com.example.sitconmania.data.QuestionBank
import com.example.sitconmania.model.*

/** State survives rotation and SavedStateHandle recreation; elapsedRealtime prevents countdown drift. */
class GameViewModel(private val savedState:SavedStateHandle):ViewModel() {
    private val engine=GameEngine(QuestionBank.all)
    var state by mutableStateOf(savedState.get<QuizState>("quiz")?:QuizState())
        private set
    private var lastTick:Long?=null
    private fun save(value:QuizState){state=value;savedState["quiz"]=value}
    fun resumeClock(){lastTick=SystemClock.elapsedRealtime()}
    fun pauseClock(){tick();lastTick=null}
    fun tick(){
        val now=SystemClock.elapsedRealtime();val previous=lastTick?:return;lastTick=now
        val next=engine.advance(state,(now-previous).coerceAtLeast(0))
        if(next!=state)save(next)
    }
    fun name(index:Int,value:String){save(state.copy(drafts=state.drafts.mapIndexed{i,p->if(i==index)p.copy(name=value.take(18))else p},formError=null))}
    fun avatar(index:Int,value:String){save(state.copy(drafts=state.drafts.mapIndexed{i,p->if(i==index)p.copy(avatar=value)else p}))}
    fun rounds(value:Int){if(value in listOf(5,8))save(state.copy(rounds=value))}
    fun toggleSound(){save(state.copy(soundEnabled=!state.soundEnabled))}
    fun start(){save(engine.start(state));lastTick=SystemClock.elapsedRealtime()}
    fun answer(index:Int){tick();save(engine.answer(state,index));lastTick=SystemClock.elapsedRealtime()}
    fun hint(){tick();save(engine.hint(state))}
    fun requestExit(){
        if(state.phase==Phase.RESULTS){home();return}
        if(state.phase==Phase.HOME)return
        tick();save(state.copy(exitConfirmation=true));lastTick=SystemClock.elapsedRealtime()
    }
    fun cancelExit(){save(state.copy(exitConfirmation=false));lastTick=SystemClock.elapsedRealtime()}
    fun home(){save(engine.home(state));lastTick=SystemClock.elapsedRealtime()}
    fun rematch(){save(engine.rematch(state));lastTick=SystemClock.elapsedRealtime()}
}
