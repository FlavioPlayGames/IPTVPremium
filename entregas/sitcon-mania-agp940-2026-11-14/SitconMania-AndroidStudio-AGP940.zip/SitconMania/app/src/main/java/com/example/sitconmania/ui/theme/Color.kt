package com.example.sitconmania.ui.theme

import androidx.compose.ui.graphics.Color

object SitcomColors {
    val Navy=Color(0xFF172F49)
    val NavyDeep=Color(0xFF14283F)
    val NavyLight=Color(0xFF2A4562)
    val Cream=Color(0xFFFFFAF0)
    val Coral=Color(0xFFFF675E)
    val Yellow=Color(0xFFFFD166)
    val Teal=Color(0xFF54C7BD)
    val Ink=Color(0xFF1B3048)
    val Muted=Color(0xFF66788B)
    val Success=Color(0xFF23806F)
    val Failure=Color(0xFFB34A45)
}
