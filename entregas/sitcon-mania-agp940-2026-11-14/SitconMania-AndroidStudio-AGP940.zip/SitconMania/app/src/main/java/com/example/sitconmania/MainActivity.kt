package com.example.sitconmania

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.sitconmania.audio.GameAudio
import com.example.sitconmania.game.GameViewModel
import com.example.sitconmania.model.Phase
import com.example.sitconmania.ui.SitconManiaApp
import com.example.sitconmania.ui.theme.SitconManiaTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class MainActivity:ComponentActivity() {
    private lateinit var model:GameViewModel
    private lateinit var audio:GameAudio
    override fun onCreate(savedInstanceState:Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        model=ViewModelProvider(this)[GameViewModel::class.java]
        audio=GameAudio(this)
        audio.update(model.state.soundEnabled,model.state.phase==Phase.HOME)
        setContent{SitconManiaTheme{SitconManiaApp(model,audio)}}
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.RESUMED) {
                model.resumeClock()
                try{while(isActive){delay(100);model.tick()}}
                finally{model.pauseClock()}
            }
        }
    }
    override fun onResume(){super.onResume();audio.setActive(true)}
    override fun onPause(){audio.setActive(false);super.onPause()}
    override fun onDestroy(){audio.release();super.onDestroy()}
}
