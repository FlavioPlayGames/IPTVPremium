package com.example.sitconmania.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.SoundPool
import com.example.sitconmania.R
import com.example.sitconmania.model.SoundEffect

/** Local synthesized WAVs; lifecycle and audio focus stop music when the app leaves the foreground. */
class GameAudio(context:Context) {
    private val app=context.applicationContext
    private val manager=app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val attributes=AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
    private val pool=SoundPool.Builder().setMaxStreams(6).setAudioAttributes(attributes).build()
    private val loaded=mutableSetOf<Int>()
    private val sounds=mutableMapOf<SoundEffect,Int>()
    private var music:MediaPlayer?=null
    private var active=false
    private var enabled=true
    private var home=true
    private var focused=false
    private var requested=false
    private var released=false
    private val focusRequest=AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
        .setAudioAttributes(attributes).setOnAudioFocusChangeListener{change->
            focused=change==AudioManager.AUDIOFOCUS_GAIN
            if(change==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK)music?.setVolume(.08f,.08f)
            else applyPlayback()
        }.build()
    init {
        pool.setOnLoadCompleteListener{_,id,status->if(status==0)loaded.add(id)}
        mapOf(SoundEffect.MOVE to R.raw.effect_move,SoundEffect.CORRECT to R.raw.effect_correct,
            SoundEffect.WRONG to R.raw.effect_wrong,SoundEffect.TICK to R.raw.effect_tick,
            SoundEffect.WIN to R.raw.effect_win,SoundEffect.HINT to R.raw.effect_hint).forEach{(effect,res)->sounds[effect]=pool.load(app,res,1)}
    }
    fun update(soundEnabled:Boolean,homeScreen:Boolean){
        if(enabled==soundEnabled&&home==homeScreen)return
        enabled=soundEnabled;home=homeScreen;configureFocus()
    }
    fun setActive(value:Boolean){if(active==value)return;active=value;configureFocus()}
    private fun configureFocus(){
        if(released)return
        if(active&&enabled){
            if(!requested){requested=true;focused=manager.requestAudioFocus(focusRequest)==AudioManager.AUDIOFOCUS_REQUEST_GRANTED}
        }else {
            if(requested)manager.abandonAudioFocusRequest(focusRequest)
            requested=false;focused=false
        }
        applyPlayback()
    }
    private fun applyPlayback(){
        if(released)return
        if(active&&enabled&&focused&&home){
            if(music==null)music=MediaPlayer.create(app,R.raw.home_music,attributes,0).apply{isLooping=true}
            music?.setVolume(.25f,.25f);music?.start()
        }else music?.pause()
        if(!active||!enabled||!focused)pool.autoPause()
    }
    fun play(effect:SoundEffect){
        if(released||!active||!enabled||!focused)return
        val id=sounds[effect]?:return
        if(id in loaded)pool.play(id,.7f,.7f,1,0,1f)
    }
    fun release(){
        if(released)return
        if(requested)manager.abandonAudioFocusRequest(focusRequest)
        music?.release();music=null;pool.release();released=true
    }
}
