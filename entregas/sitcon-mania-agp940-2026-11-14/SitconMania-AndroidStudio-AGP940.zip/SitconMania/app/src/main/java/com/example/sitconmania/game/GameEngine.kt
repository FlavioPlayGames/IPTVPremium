package com.example.sitconmania.game

import com.example.sitconmania.model.*
import kotlin.random.Random

/** Pure, deterministic when given a seeded Random. Contains no Activity, timers, sound or Compose. */
class GameEngine(private val bank:List<Question>,private val random:Random=Random.Default) {
    fun start(state:QuizState):QuizState {
        val players=state.drafts.filter{it.name.trim().isNotEmpty()}.map{Player(it.name.trim().take(18),it.avatar)}
        if(players.size !in 2..4)return state.copy(formError="Informe pelo menos dois jogadores.")
        if(state.rounds !in listOf(5,8))return state.copy(formError="Escolha 5 ou 8 episódios por jogador.")
        val turns=players.size*state.rounds
        if(bank.size<turns)return state.copy(formError="Não há perguntas suficientes para esta partida.")
        val deck=bank.shuffled(random).take(turns).map{it.copy(options=it.options.shuffled(random))}
        return state.copy(players=players,deck=deck,phase=Phase.QUESTION,position=0,remainingMillis=20_000,
            selectedAnswer=null,hiddenAnswers=emptySet(),feedback="",formError=null,exitConfirmation=false,
            soundVersion=state.soundVersion+1,sounds=listOf(SoundEffect.MOVE))
    }
    fun rematch(state:QuizState):QuizState=start(state)
    fun home(state:QuizState):QuizState=state.copy(phase=Phase.HOME,players=emptyList(),deck=emptyList(),position=0,
        selectedAnswer=null,hiddenAnswers=emptySet(),feedback="",exitConfirmation=false,formError=null,
        soundVersion=state.soundVersion+1,sounds=listOf(SoundEffect.MOVE))
    fun answer(state:QuizState,index:Int):QuizState {
        if(state.phase!=Phase.QUESTION||state.exitConfirmation||index !in -1..3||index in state.hiddenAnswers)return state
        val question=state.question?:return state
        val correct=index==question.correctIndex
        if(correct) {
            val fast=state.remainingMillis>=15_000L
            val points=2+(if(fast)1 else 0)+(if(state.special)2 else 0)
            val message=(if(fast)"Resposta relâmpago! +3 pontos."else"Acertou! +2 pontos.")+(if(state.special)" Episódio especial: +2!"else"")
            return state.copy(phase=Phase.FEEDBACK,players=state.players.mapIndexed{i,p->if(i==state.activeIndex)p.copy(score=p.score+points)else p},
                remainingMillis=1_500,frozenSeconds=state.seconds,selectedAnswer=index,feedback=message,correctFeedback=true,
                soundVersion=state.soundVersion+1,sounds=listOf(SoundEffect.CORRECT))
        }
        return state.copy(phase=Phase.COMMERCIAL,remainingMillis=15_000,frozenSeconds=state.seconds,selectedAnswer=index,
            feedback=(if(index<0)"Tempo esgotado! "else"Quase! ")+"Resposta: ${question.correct}.",correctFeedback=false,
            soundVersion=state.soundVersion+1,sounds=listOf(SoundEffect.WRONG,SoundEffect.MOVE))
    }
    fun hint(state:QuizState):QuizState {
        if(state.phase!=Phase.QUESTION||state.exitConfirmation||state.activePlayer?.hintUsed!=false)return state
        val question=state.question?:return state
        val hidden=question.options.indices.filter{it!=question.correctIndex}.shuffled(random).take(2).toSet()
        return state.copy(players=state.players.mapIndexed{i,p->if(i==state.activeIndex)p.copy(hintUsed=true)else p},hiddenAnswers=hidden,
            feedback="Duas alternativas foram eliminadas!",correctFeedback=false,soundVersion=state.soundVersion+1,sounds=listOf(SoundEffect.HINT))
    }
    fun advance(state:QuizState,elapsedMillis:Long):QuizState {
        if(state.phase in listOf(Phase.HOME,Phase.RESULTS)||state.exitConfirmation||elapsedMillis<=0)return state
        val remaining=(state.remainingMillis-elapsedMillis).coerceAtLeast(0)
        if(remaining>0) {
            val next=state.copy(remainingMillis=remaining)
            return if(state.phase==Phase.QUESTION&&next.seconds<state.seconds&&next.seconds in 1..5)
                next.copy(soundVersion=state.soundVersion+1,sounds=listOf(SoundEffect.TICK))else next
        }
        if(state.phase==Phase.QUESTION)return answer(state.copy(remainingMillis=0),-1)
        val position=state.position+1
        return if(position>=state.deck.size)state.copy(phase=Phase.RESULTS,remainingMillis=0,exitConfirmation=false,
            soundVersion=state.soundVersion+1,sounds=listOf(SoundEffect.WIN))
        else state.copy(phase=Phase.QUESTION,position=position,remainingMillis=20_000,selectedAnswer=null,
            hiddenAnswers=emptySet(),feedback="",correctFeedback=false)
    }
}
