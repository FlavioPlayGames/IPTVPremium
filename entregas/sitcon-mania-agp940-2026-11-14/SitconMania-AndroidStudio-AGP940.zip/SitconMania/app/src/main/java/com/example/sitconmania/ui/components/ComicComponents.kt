package com.example.sitconmania.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sitconmania.ui.theme.SitcomColors as C

@Composable
fun PartyBackground(content:@Composable BoxScope.()->Unit) {
    Box(Modifier.fillMaxSize().background(Brush.linearGradient(listOf(C.NavyDeep,C.NavyLight,C.Navy)))) {
        Canvas(Modifier.matchParentSize()) {
            val gap=44.dp.toPx();val second=61.dp.toPx()
            var y=12.dp.toPx()
            while(y<size.height){var x=10.dp.toPx();while(x<size.width){drawCircle(C.Yellow.copy(alpha=.18f),1.6.dp.toPx(),Offset(x,y));x+=gap};y+=gap}
            y=31.dp.toPx()
            while(y<size.height){var x=42.dp.toPx();while(x<size.width){drawCircle(C.Teal.copy(alpha=.20f),1.6.dp.toPx(),Offset(x,y));x+=second};y+=second}
        }
        content()
    }
}

@Composable
fun ComicPanel(modifier:Modifier=Modifier,stripe:Boolean=false,content:@Composable ColumnScope.()->Unit) {
    val shape=RoundedCornerShape(23.dp)
    Box(modifier.shadow(10.dp,shape).background(C.Cream,shape).border(4.dp,Color.White,shape)) {
        if(stripe)Canvas(Modifier.fillMaxWidth().height(7.dp).padding(horizontal=18.dp)) {
            val colors=listOf(C.Coral,C.Yellow,C.Teal,Color(0xFF69A9FF));val width=30.dp.toPx()
            for(i in 0..(size.width/width).toInt())drawRect(colors[i%colors.size],Offset(i*width,0f),Size(width,size.height))
        }
        Column(Modifier.padding(horizontal=20.dp,vertical=if(stripe)25.dp else 20.dp),verticalArrangement=Arrangement.spacedBy(12.dp),content=content)
    }
}

@Composable
fun ComicButton(label:String,onClick:()->Unit,modifier:Modifier=Modifier,primary:Boolean=true,enabled:Boolean=true) {
    val shape=RoundedCornerShape(12.dp)
    Box(modifier.heightIn(min=48.dp).shadow(if(primary&&enabled)3.dp else 0.dp,shape)
        .background(if(!enabled)Color(0xFFE2E5E4)else if(primary)C.Coral else Color(0xFFE7F6F3),shape)
        .clickable(enabled=enabled,role=Role.Button,onClick=onClick).padding(horizontal=16.dp,vertical=13.dp),contentAlignment=Alignment.Center) {
        Text(label,color=if(!enabled)C.Muted else if(primary)Color.White else Color(0xFF26675F),fontWeight=FontWeight.Bold,fontSize=15.sp,textAlign=TextAlign.Center)
    }
}

@Composable
fun TimeBar(progress:Float,modifier:Modifier=Modifier) {
    Box(modifier.height(8.dp).background(Color(0xFFE9E3D9),RoundedCornerShape(20.dp))) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(progress.coerceIn(0f,1f))
            .background(Brush.horizontalGradient(listOf(C.Teal,C.Yellow,C.Coral)),RoundedCornerShape(20.dp)))
    }
}

@Composable
fun AppHeader(soundEnabled:Boolean,onSound:()->Unit) {
    Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Box(Modifier.size(43.dp).background(C.Yellow,RoundedCornerShape(12.dp)),contentAlignment=Alignment.Center){Text("📺",fontSize=25.sp)}
        Text("SITCOM MANIA",color=Color.White,fontWeight=FontWeight.Black,fontSize=16.sp,letterSpacing=1.sp,modifier=Modifier.weight(1f))
        Text(if(soundEnabled)"🔊 Som ligado"else"🔇 Som desligado",color=Color.White,fontSize=12.sp,fontWeight=FontWeight.Bold,
            modifier=Modifier.border(1.dp,Color.White.copy(alpha=.35f),RoundedCornerShape(40.dp))
                .clickable(role=Role.Button,onClick=onSound).padding(horizontal=12.dp,vertical=12.dp))
    }
}
