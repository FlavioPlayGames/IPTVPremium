package com.example.sitconmania

import com.example.sitconmania.data.QuestionBank
import com.example.sitconmania.game.GameEngine
import com.example.sitconmania.model.*
import org.junit.Assert.*
import org.junit.Test
import java.io.*
import kotlin.random.Random

class GameEngineTest {
    private fun engine()=GameEngine(QuestionBank.all,Random(42))
    private fun start(e:GameEngine=engine(),players:Int=2,rounds:Int=5):QuizState=e.start(QuizState(rounds=rounds,
        drafts=List(4){PlayerDraft(if(it<players)"Pessoa ${it+1}"else"","⭐")}))
    @Test fun originalBankIsCompleteAndValid(){
        assertEquals(40,QuestionBank.all.size)
        assertEquals(40,QuestionBank.all.map{it.id}.toSet().size)
        QuestionBank.all.forEach{assertEquals(4,it.options.distinct().size);assertTrue(it.correct in it.options)}
    }
    @Test fun invalidPlayersStayAtHome(){
        val s=engine().start(QuizState(drafts=List(4){PlayerDraft("  ","⭐")}))
        assertEquals(Phase.HOME,s.phase);assertNotNull(s.formError)
    }
    @Test fun emptyPlayersAreIgnoredAndNamesAreTrimmed(){
        val s=engine().start(QuizState(drafts=listOf(PlayerDraft(" Ana ","☕"),PlayerDraft("Beto","⭐"),PlayerDraft("  ","🎭"),PlayerDraft("","📺"))))
        assertEquals(listOf("Ana","Beto"),s.players.map{it.name})
    }
    @Test fun fourPlayersEightRoundsHasNoRepeats(){
        val s=start(players=4,rounds=8);assertEquals(32,s.deck.size);assertEquals(32,s.deck.map{it.id}.toSet().size)
    }
    @Test fun speedBonusHasExactBoundary(){
        val e=engine();val s=start(e)
        assertEquals(3,e.answer(s.copy(remainingMillis=15_000),s.question!!.correctIndex).players[0].score)
        assertEquals(2,e.answer(s.copy(remainingMillis=14_999),s.question!!.correctIndex).players[0].score)
    }
    @Test fun fifthQuestionIsSpecialAndTurnsAlternate(){
        val e=engine();var s=start(e)
        repeat(4){assertEquals(it%2,s.activeIndex);s=e.advance(e.answer(s,s.question!!.correctIndex),1_500)}
        assertTrue(s.special);val prior=s.activePlayer!!.score
        assertEquals(prior+5,e.answer(s,s.question!!.correctIndex).players[s.activeIndex].score)
    }
    @Test fun wrongAnswerAndTimeoutStartFifteenSecondBreak(){
        val e=engine();val s=start(e)
        val wrong=e.answer(s,(s.question!!.correctIndex+1)%4)
        assertEquals(Phase.COMMERCIAL,wrong.phase);assertEquals(15_000L,wrong.remainingMillis);assertEquals(0,wrong.players[0].score)
        assertEquals(Phase.COMMERCIAL,e.advance(wrong,14_999).phase)
        assertEquals(1,e.advance(wrong,15_000).position)
        val timeout=e.advance(s,20_000);assertEquals(Phase.COMMERCIAL,timeout.phase);assertEquals(-1,timeout.selectedAnswer)
    }
    @Test fun feedbackFreezesQuestionTimerAndDuplicateAnswerIsIgnored(){
        val e=engine();val s=start(e);val scored=e.answer(s.copy(remainingMillis=17_000),s.question!!.correctIndex)
        assertEquals(17,scored.frozenSeconds);assertEquals(scored,e.answer(scored,s.question!!.correctIndex))
        assertEquals(Phase.FEEDBACK,e.advance(scored,1_499).phase);assertEquals(Phase.QUESTION,e.advance(scored,1_500).phase)
    }
    @Test fun hintRemovesOnlyTwoWrongAnswersAndCannotBeUsedAgain(){
        val e=engine();val s=start(e);val hinted=e.hint(s)
        assertEquals(2,hinted.hiddenAnswers.size);assertFalse(s.question!!.correctIndex in hinted.hiddenAnswers)
        assertEquals(hinted,e.hint(hinted));assertEquals(hinted,e.answer(hinted,hinted.hiddenAnswers.first()))
        var next=e.advance(e.answer(hinted,hinted.question!!.correctIndex),1_500)
        next=e.advance(e.answer(next,next.question!!.correctIndex),1_500)
        assertTrue(next.activePlayer!!.hintUsed);assertEquals(next,e.hint(next))
    }
    @Test fun exitConfirmationPausesAllPhasesAndHomeNeverResurrectsGame(){
        val e=engine();val s=start(e).copy(exitConfirmation=true)
        assertEquals(s,e.advance(s,90_000))
        val home=e.home(s);assertEquals(home,e.advance(home,90_000));assertTrue(home.deck.isEmpty())
    }
    @Test fun completeMatchAndRematchResetScoresAndHints(){
        val e=engine();var s=start(e);s=e.hint(s)
        repeat(s.deck.size){s=e.advance(e.answer(s,s.question!!.correctIndex),1_500)}
        assertEquals(Phase.RESULTS,s.phase);assertEquals(2,s.ranking.size)
        val again=e.rematch(s);assertEquals(Phase.QUESTION,again.phase);assertTrue(again.players.all{it.score==0&&!it.hintUsed})
    }
    @Test fun finalWrongAnswerStillHasBreakAndTieIsDetected(){
        val e=engine();var s=start(e)
        repeat(s.deck.size){s=e.advance(e.answer(s,-1),15_000)}
        assertEquals(Phase.RESULTS,s.phase);assertTrue(s.tied)
    }
    @Test fun sessionCanBeSerializedAndRestoredWithSameQuestionAndRemainingTime(){
        val e=engine();val s=e.hint(e.advance(start(e),5_100))
        val data=ByteArrayOutputStream().also{ObjectOutputStream(it).use{stream->stream.writeObject(s)}}.toByteArray()
        val restored=ObjectInputStream(ByteArrayInputStream(data)).use{it.readObject() as QuizState}
        assertEquals(s,restored);assertEquals(s.question?.text,restored.question?.text)
        assertEquals(s.remainingMillis-100,e.advance(restored,100).remainingMillis)
    }
}
