from pathlib import Path
b=Path('/workspace/backup-reviewed-build/app/src/main/java/br/com/flaviotorres/iptvpremium/core/navigation/player')
s=(b/'PlaybackCatalogBrowser.kt').read_text()
assert 'remember(playlistId,kids,access,selectedSeries?.id){PlayerSeasonArtworkCache' in s
assert 'onDispose{seasonArtworkCache.clear()}'in s
assert s.count('seasonCache=seasonArtworkCache')==1
assert 'seasonCacheKey="${selectedSeries?.id}:$number"'in s
print('PASS session belongs only to the open player browser and selected series/profile; only season rows opt in; disposal releases it')
assert 'val sessionKey=seasonCacheKey?.let{"$it:${width}x$height"}'in s
assert 'produceState<ImageBitmap?>(sessionBitmap?:if(images==null)'in s
assert s.index('if(sessionBitmap!=null){value=sessionBitmap;return@produceState}')<s.index('if(!openingBusy && !moving) {',s.index('val sessionBitmap'))
print('PASS cached thumbnail paints immediately and bypasses loading even during directional scrolling')
assert 'if(sessionKey!=null)seasonCache?.put(sessionKey,it)'in s
assert 'value=null\n                            br.com.flaviotorres.iptvpremium.data.repository.loadEpisodeThumbnail'not in s
print('PASS completed thumbnails are retained before row recycling and loading does not blank an existing image')
s=(b/'PlaybackScreen.kt').read_text();assert 'if(catalogVisible && catalogContent!=null && !isLive)'in s
print('PASS closing the player catalogue removes the browser composition and releases its temporary RAM cache')
