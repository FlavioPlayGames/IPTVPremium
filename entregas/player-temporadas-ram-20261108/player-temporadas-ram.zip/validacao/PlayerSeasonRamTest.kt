package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.core.player.PlayerSeasonArtworkCache
fun main(){
 data class Image(val name:String,val bytes:Long)
 val cache=PlayerSeasonArtworkCache<Image>(100){it.bytes}
 check(cache.peek("a:1:58x87")==null)
 val first=Image("first",20);cache.put("a:1:58x87",first)
 check(cache.peek("a:1:58x87")===first);println("PASS scrolling back to a loaded season returns the same bitmap reference without loading again")
 cache.put("a:2:58x87",Image("second",20));check(cache.peek("a:1:58x87")===first)
 check(cache.peek("b:1:58x87")==null&&cache.peek("a:1:87x130")==null);println("PASS series, season and dimensions do not share an unrelated thumbnail")
 cache.put("a:1:58x87",Image("replacement",30));cache.put("a:3:58x87",Image("third",50))
 check(cache.peek("a:1:58x87")?.name=="replacement"&&cache.peek("a:2:58x87")!=null);println("PASS replacement accounts for the previous allocation instead of growing the byte total")
 cache.peek("a:1:58x87");cache.put("a:4:58x87",Image("fourth",30))
 check(cache.peek("a:2:58x87")!=null&&cache.peek("a:3:58x87")==null&&cache.peek("a:1:58x87")!=null)
 println("PASS memory limit evicts least-recently-used seasons while retaining recently visited ones")
 cache.put("too-large",Image("large",101));check(cache.peek("too-large")==null&&cache.peek("a:1:58x87")!=null);println("PASS a single oversized image cannot exceed the session memory limit")
 cache.clear();check(cache.peek("a:1:58x87")==null&&cache.peek("a:4:58x87")==null)
 val reopened=PlayerSeasonArtworkCache<Image>(100){it.bytes};check(reopened.peek("a:1:58x87")==null);println("PASS leaving the browser clears references and reopening starts with an empty session")
 val bounded=PlayerSeasonArtworkCache<Image>(Long.MAX_VALUE){it.bytes}
 repeat(300){bounded.put(it.toString(),Image("tiny",0))};check((0 until 300).count{bounded.peek(it.toString())!=null}==256)
 println("PASS entry limit also bounds malformed or zero-sized accounting")
}
