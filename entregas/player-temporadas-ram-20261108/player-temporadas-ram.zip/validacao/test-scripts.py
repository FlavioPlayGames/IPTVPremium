from pathlib import Path
import os,subprocess
w=Path('/workspace/player-temporadas-ram');o=Path('/workspace/outputs/player-temporadas-ram');pw='/workspace/storage-toolchain/powershell/pwsh'
env=dict(os.environ,XDG_CACHE_HOME='/workspace/storage-toolchain/xdg-cache',XDG_DATA_HOME='/workspace/storage-toolchain/xdg-data',XDG_CONFIG_HOME='/workspace/storage-toolchain/xdg-config')
for p in o.glob('*.ps1'):
 command="$err=$null;$tokens=$null;[System.Management.Automation.Language.Parser]::ParseFile('"+str(p)+"',[ref]$tokens,[ref]$err)|Out-Null;if($err.Count){$err|Out-String|Write-Output;exit 1}"
 r=subprocess.run([pw,'-NoProfile','-Command',command],capture_output=True,text=True,env=env);assert r.returncode==0,(p,r.stdout,r.stderr)
print('PASS all three PowerShell scripts parse')
