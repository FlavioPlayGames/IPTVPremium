package br.com.flaviotorres.iptvpremium.core.player

/** Only owned by one open player browser/series. Small decoded thumbnails, never full-size posters. */
internal class PlayerSeasonArtworkCache<T>(private val limitBytes:Long=8L*1024*1024,private val sizeOf:(T)->Long) {
    private val entries=LinkedHashMap<String,Pair<T,Long>>(16,.75f,true)
    private var bytes=0L
    @Synchronized fun peek(key:String):T?=entries[key]?.first
    @Synchronized fun put(key:String,value:T) {
        val size=sizeOf(value).coerceAtLeast(1)
        if(size>limitBytes)return
        entries.remove(key)?.let{bytes-=it.second}
        entries[key]=value to size;bytes+=size
        while(bytes>limitBytes||entries.size>256){
            val iterator=entries.entries.iterator();if(!iterator.hasNext())break
            bytes-=iterator.next().value.second;iterator.remove()
        }
    }
    @Synchronized fun clear(){entries.clear();bytes=0L}
}
