import br.com.flaviotorres.iptvpremium.ui.theme.PremiumTheme;
import br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors;
public class SoftThemePalette {
  static long color(long source, PremiumTheme theme) { return ThemeColors.INSTANCE.accentArgb$app(source,theme); }
  static int peak(long c) { return Math.max((int)(c>>16&255),Math.max((int)(c>>8&255),(int)(c&255))); }
  static double luminance(long c) {
    double sum=0; double[] w={.2126,.7152,.0722};
    for(int i=0;i<3;i++) { double s=((c>>(16-i*8))&255)/255.0; sum+=w[i]*(s<=.04045?s/12.92:Math.pow((s+.055)/1.055,2.4)); }
    return sum;
  }
  public static void main(String[] args) {
    java.util.Random random=new java.util.Random(17);
    for(int i=0;i<10000;i++) { long s=Integer.toUnsignedLong(random.nextInt()); if(color(s,PremiumTheme.GOLD)!=s) throw new AssertionError("Gold changed"); }
    for(PremiumTheme t:PremiumTheme.values()) if(t!=PremiumTheme.GOLD) {
      for(int a=0;a<256;a++) if((color(((long)a<<24)|0xFFE6A0,t)>>>24)!=a) throw new AssertionError("Alpha changed");
      int last=-1; for(int v=0;v<256;v++) { int p=peak(color(0xFF000000L|((long)v<<16)|((long)v<<8)|v,t)); if(p<last) throw new AssertionError("Reversed metal gradient"); last=p; }
      if(last>=200 || last<=150) throw new AssertionError("Highlight not softened");
      // Primary pale text remains readable on the established dark background.
      if((luminance(color(0xFFFFE6A0L,t))+.05)/(luminance(0xFF080A0CL)+.05)<4.5) throw new AssertionError("Pale text contrast");
    }
    System.out.println("PASS: gold unchanged (10000 ARGB samples); six themes preserve alpha and metallic gradient order; highlights softened; primary pale text contrast >=4.5 on #080A0C.");
  }
}
