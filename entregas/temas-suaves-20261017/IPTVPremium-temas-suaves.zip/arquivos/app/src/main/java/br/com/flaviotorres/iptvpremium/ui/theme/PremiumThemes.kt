package br.com.flaviotorres.iptvpremium.ui.theme

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import java.util.concurrent.ConcurrentHashMap

/** Paletas da interface; as imagens de cada tema sao arquivos proprios. */
enum class PremiumTheme(val key: String, val label: String, val hue: Float) {
    GOLD("gold", "Dourado · Padrão", 45f),
    BLUE("blue", "Azul", 223.8f),
    PURPLE("purple", "Roxo", 283.34f),
    RED("red", "Vermelho", 356.92f),
    PINK("pink", "Rosa", 345.45f),
    EMERALD("emerald", "Verde esmeralda", 152.0f),
    CYAN("cyan", "Ciano / Turquesa", 182.74f);
    companion object { fun fromKey(key: String?) = entries.firstOrNull { it.key == key } ?: GOLD }
}

object ThemeState {
    var selected by mutableStateOf(PremiumTheme.GOLD)
        private set
    fun initialize(context: Context) {
        selected = PremiumTheme.fromKey(context.applicationContext.getSharedPreferences("iptvpremium_settings_v2", Context.MODE_PRIVATE).getString("visual_theme", "gold"))
    }
    fun choose(context: Context, theme: PremiumTheme) {
        context.applicationContext.getSharedPreferences("iptvpremium_settings_v2", Context.MODE_PRIVATE)
            .edit().putString("visual_theme", theme.key).apply()
        selected = theme
    }
}

/** Cores de bordas/controles, sem qualquer filtro nos bitmaps, capas ou video. */
object ThemeColors {
    private val cache = ConcurrentHashMap<Pair<PremiumTheme, Long>, Color>()
    fun color(goldArgb: Long): Color {
        val theme = ThemeState.selected
        if (theme == PremiumTheme.GOLD) return Color(goldArgb)
        return cache.getOrPut(theme to goldArgb) { Color(accentArgb(goldArgb, theme)) }
    }
    internal fun accentArgb(source: Long, theme: PremiumTheme): Long {
        if (theme == PremiumTheme.GOLD) return source
        val r = ((source shr 16) and 255).toFloat() / 255f
        val g = ((source shr 8) and 255).toFloat() / 255f
        val b = (source and 255).toFloat() / 255f
        val originalValue = maxOf(r, g, b)
        // Compress highlights, retaining the order of the metallic gradient stops.
        // Gold returns above, before this curve. Alpha and hue remain unchanged.
        val value = originalValue * (0.96f - 0.22f * originalValue)
        val saturation = if (originalValue == 0f) 0f else ((originalValue - minOf(r, g, b)) / originalValue * 1.05f).coerceIn(0f, 1f)
        val c = value * saturation
        val h = theme.hue / 60f
        val x = c * (1f - kotlin.math.abs(h % 2f - 1f))
        val m = value - c
        val rgb = when (h.toInt()) {
            0 -> floatArrayOf(c,x,0f); 1 -> floatArrayOf(x,c,0f); 2 -> floatArrayOf(0f,c,x)
            3 -> floatArrayOf(0f,x,c); 4 -> floatArrayOf(x,0f,c); else -> floatArrayOf(c,0f,x)
        }
        fun channel(index: Int) = ((rgb[index] + m) * 255f + .5f).toLong().coerceIn(0L,255L)
        return (source and 0xFF000000L) or (channel(0) shl 16) or (channel(1) shl 8) or channel(2)
    }
}
