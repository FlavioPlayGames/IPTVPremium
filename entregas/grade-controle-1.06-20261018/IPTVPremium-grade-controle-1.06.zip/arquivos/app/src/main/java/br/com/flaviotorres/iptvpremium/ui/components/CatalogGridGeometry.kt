package br.com.flaviotorres.iptvpremium.ui.components

/** Two complete rows; metadata and gaps are reserved before sizing the poster. */
internal fun catalogTwoRowAspect(width: Float, height: Float, columns: Int,
    spacing: Float, metadata: Float): Float {
    if (width <= 0 || height <= 0 || columns <= 0) return .72f
    val cellWidth = ((width - 16f - spacing * (columns - 1)) / columns).coerceAtLeast(1f)
    val posterHeight = ((height - 18f - spacing) / 2f - metadata).coerceAtLeast(1f)
    return (cellWidth / posterHeight).coerceAtLeast(.67f)
}
