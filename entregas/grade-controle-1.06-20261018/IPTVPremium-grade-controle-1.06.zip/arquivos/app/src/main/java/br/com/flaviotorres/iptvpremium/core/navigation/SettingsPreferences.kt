package br.com.flaviotorres.iptvpremium.ui.settings

import android.content.Context
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import br.com.flaviotorres.iptvpremium.core.player.PlaybackEngine
import br.com.flaviotorres.iptvpremium.core.player.PlaybackSettings

internal class SettingsPreferences(context: Context) {
    val prefs = context.applicationContext.getSharedPreferences("iptvpremium_settings_v2", Context.MODE_PRIVATE)
    fun playback(): PlaybackSettings = PlaybackSettings(
        preferredEngine = if (prefs.getString("engine", "media3") == "vlc") PlaybackEngine.VLC else PlaybackEngine.MEDIA3,
        autoPlayNextEpisode = prefs.getBoolean("auto_next", true)
    )
    fun catalogColumns(): Int = prefs.getInt("catalog_columns", 5).let { if (it == 4) 4 else 5 }
    fun setCatalogColumns(value: Int) { require(value == 4 || value == 5); prefs.edit().putInt("catalog_columns", value).apply() }
    fun textScale(): Float = prefs.getFloat("text_scale", 1f).coerceIn(1f, 1.2f)
    fun setEngine(value: String) { require(value in listOf("media3", "vlc")); prefs.edit().putString("engine", value).apply() }
    fun setAutoNext(value: Boolean) { prefs.edit().putBoolean("auto_next", value).apply() }
    fun setTextScale(value: Float) { require(value in listOf(1f, 1.1f, 1.2f)); prefs.edit().putFloat("text_scale", value).apply() }
    fun categoryOrder(type: String): String = prefs.getString("order_$type", "default").orEmpty()
    fun setCategoryOrder(type: String, value: String) {
        require(type in listOf("LIVE_TV", "MOVIES", "SERIES") && value in listOf("default", "az", "za"))
        prefs.edit().putString("order_$type", value).apply()
        CategoryOrderSettings.orders[type] = value
    }
}

internal object CategoryOrderSettings {
    val orders = java.util.concurrent.ConcurrentHashMap<String, String>()
    fun initialize(context: Context) {
        val settings = SettingsPreferences(context)
        listOf("LIVE_TV", "MOVIES", "SERIES").forEach { orders[it] = settings.categoryOrder(it) }
    }
}

@Composable
internal fun rememberSettingsPreferences(): SettingsPreferences {
    val context = LocalContext.current.applicationContext
    val settings = remember(context) { SettingsPreferences(context) }
    var change by remember { mutableIntStateOf(0) }
    DisposableEffect(settings) {
        val listener = android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> change++ }
        settings.prefs.registerOnSharedPreferenceChangeListener(listener)
        onDispose { settings.prefs.unregisterOnSharedPreferenceChangeListener(listener) }
    }
    // Register the read in the calling composition so preferences redraw immediately.
    @Suppress("UNUSED_VARIABLE") val revision = change
    return settings
}
