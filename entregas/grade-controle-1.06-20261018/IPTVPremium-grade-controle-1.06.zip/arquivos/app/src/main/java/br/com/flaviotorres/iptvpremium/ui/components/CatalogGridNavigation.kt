package br.com.flaviotorres.iptvpremium.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.flaviotorres.iptvpremium.data.cache.CatalogVerticalIntent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first

/** One pending destination for repeated DPAD commands, including not-yet-composed rows. */
internal class CatalogGridNavigator(private val grid: LazyGridState, private val scope: CoroutineScope,
    private val columns: Int, private val count: () -> Int, private val load: (Int) -> Unit,
    private val manual: () -> Unit) {
    private val requesters = mutableMapOf<Int, FocusRequester>()
    private val revision = MutableStateFlow(0L)
    private val intent = CatalogVerticalIntent(columns)
    private var job: Job? = null
    val host = FocusRequester()
    private var currentIndex = 0
    private var lastCount = -1
    fun attach(index: Int, requester: FocusRequester) { requesters[index] = requester; revision.value++ }
    fun detach(index: Int, requester: FocusRequester) { if (requesters[index] === requester) requesters.remove(index) }
    fun focused(index: Int) {
        // A late focus event from a previous row cannot replace the current command.
        if (intent.desired == null || intent.desired == index) currentIndex = index
        intent.focused(index)
    }
    fun cancel() { job?.cancel(); job = null; intent.clear() }
    fun hostKey(event: KeyEvent): Boolean = key(currentIndex, event)
    fun key(index: Int, event: KeyEvent): Boolean {
        val direction = event.key
        val arrow = direction == Key.DirectionDown || direction == Key.DirectionUp ||
            direction == Key.DirectionLeft || direction == Key.DirectionRight
        if (!arrow) return job?.isActive == true && (direction == Key.DirectionCenter || direction == Key.Enter)
        val total = count()
        if (lastCount != total) { currentIndex = currentIndex.coerceIn(0, (total - 1).coerceAtLeast(0)); lastCount = total }
        val anchor = (intent.desired ?: currentIndex).coerceIn(0, (total - 1).coerceAtLeast(0))
        // Only an explicit LEFT at column zero may leave the grid.
        if (direction == Key.DirectionLeft && anchor % columns == 0) {
            if (event.type == KeyEventType.KeyDown) { cancel(); manual() }
            return false
        }
        if (event.type != KeyEventType.KeyDown) return true
        if (total == 0) return true
        manual()
        val target = when (direction) {
            Key.DirectionDown -> intent.request(anchor, total, true)
            Key.DirectionUp -> intent.request(anchor, total, false)
            Key.DirectionLeft -> (anchor - 1).also { intent.clear() }
            Key.DirectionRight -> if (anchor % columns < columns - 1 && anchor + 1 < total) (anchor + 1).also { intent.clear() } else null
            else -> null
        } ?: return true
        currentIndex = target
        job?.cancel()
        // Keep a stable focus owner while the origin card is recycled by LazyGrid.
        // Repeated keys are received here, rather than by a category chosen by Android.
        runCatching { host.requestFocus() }
        job = scope.launch {
            if (target !in 0 until count()) { intent.clear(); return@launch }
            load(target)
            val layout = grid.layoutInfo
            val visible = layout.visibleItemsInfo
            val item = visible.firstOrNull { it.index == target }
            val fullyVisible = item != null && item.offset.y >= layout.viewportStartOffset &&
                item.offset.y + item.size.height <= layout.viewportEndOffset
            if (!fullyVisible) {
                val fullRows = visible.filter { it.offset.y >= layout.viewportStartOffset &&
                    it.offset.y + it.size.height <= layout.viewportEndOffset }.map { it.index / columns }.distinct()
                val rows = fullRows.size.coerceAtLeast(1)
                val firstRow = (visible.firstOrNull()?.index ?: target) / columns
                val row = target / columns
                val startRow = if (row >= firstRow) (row - rows + 1).coerceAtLeast(0) else row
                grid.scrollToItem(startRow * columns)
            }
            val ready = withTimeoutOrNull(2_500L) { revision.first { requesters[target] != null } }
            if (ready == null) { intent.clear(); return@launch }
            repeat(3) {
                withFrameNanos { }
                ensureActive()
                if (currentIndex != target) return@launch
                val focused = runCatching { requesters[target]?.requestFocus() == true }.getOrDefault(false)
                if (focused) return@launch
            }
            intent.clear()
        }
        return true
    }
}

/** Parent remains composed even when a held key moves beyond the loaded rows. */
internal fun Modifier.catalogGridHost(navigator: CatalogGridNavigator): Modifier =
    this.focusRequester(navigator.host).onPreviewKeyEvent { navigator.hostKey(it) }.focusable()

internal fun Modifier.catalogGridNavigation(navigator: CatalogGridNavigator?, index: Int, requester: FocusRequester): Modifier =
    this.then(if (navigator == null) Modifier else Modifier.onPreviewKeyEvent { navigator.key(index, it) })

@Composable
internal fun BindCatalogFocus(navigator: CatalogGridNavigator?, index: Int, requester: FocusRequester) {
    DisposableEffect(navigator, index, requester) {
        navigator?.attach(index, requester)
        onDispose { navigator?.detach(index, requester) }
    }
}

@Composable
internal fun CatalogPosterPlaceholder(aspect: Float) {
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().aspectRatio(aspect).background(Color(0xFF0B1020)))
        Spacer(Modifier.height(34.dp))
    }
}
