package br.com.flaviotorres.iptvpremium.data.cache

/** A nonblank search covers all categories of the current media catalogue, never other profiles/lists. */
internal data class CatalogSearchScope(val categoryId: String?, val favoritesOnly: Boolean)
internal fun catalogSearchScope(query: String, categoryId: String?, favoritesOnly: Boolean): CatalogSearchScope =
    if(query.isNotBlank()) CatalogSearchScope(null, false) else CatalogSearchScope(categoryId, favoritesOnly)
internal fun catalogHistoryMode(menu: String, query: String): Boolean = menu == "continue" && query.isBlank()
