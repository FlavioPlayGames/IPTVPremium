# Validação — r7

## Escopo

Base: r6. Alterados MoviesViewModel, SeriesViewModel, UnifiedMediaCatalog, KidsMediaCatalog e AppKeyboard; adicionado CatalogSearchScope. Pesquisa não vazia usa categoria nula e favoritesOnly=false nos dois ViewModels e na consulta de antecipação de capas. A categoria/filtro original permanece guardada e volta a valer quando o texto fica em branco.

Continuar usa seu histórico local somente quando não há pesquisa; durante a busca usa o Pager do catálogo completo daquele tipo de conteúdo. A chave efetiva de Paging reflete esse escopo geral. Tocar em uma categoria encerra a pesquisa. Durante pesquisa iniciada em Favoritos, remover um favorito não trata o card como removido dos resultados gerais.

Limpar foi ligado ao campo e ao teclado do catálogo. O teclado mantém uma tecla estável mesmo depois de limpar; cancela seleção lógica/acento pendente, e os handlers zeram texto/cursor sem fechar o teclado. O botão na barra devolve o foco ao campo após a remoção do próprio botão. Esse comportamento de recomposição/foco precisa ser conferido fisicamente na TV.

## Testes JVM

Passaram testes com expressões reais de construção de opções extraídas de ambos os ViewModels, os DTOs reais e o debounce real de 350 ms:

- Pesquisa sai da categoria selecionada e ignora Favoritos enquanto houver texto.
- Seleção original, conjunto de IDs favoritos e ordenação são preservados e retomados ao limpar.
- Alterações de favoritos durante busca geral não alteram as opções efetivas de pesquisa.
- Texto pendente é cancelado ao limpar antes do debounce; branco é aplicado sem a espera de digitação.
- Espaços em branco retomam o filtro original.
- Continuar alterna entre histórico local e resultados gerais corretamente pelo auxiliar de modo.
- Chave real de Paging é a mesma para a mesma pesquisa geral iniciada em categoria ou Favoritos.

Passaram os handlers reais changeSearch/clearSearch dos catálogos normal e Kids, extraídos para um harness JVM com dependências de foco/frame simuladas: texto/cursor zerados, teclado preservado quando aberto, substituição de texto, ausência de callback duplicado para uma limpeza já vazia. Isso não simula a interface Compose completa.

Também passaram as regressões portáveis de histórico/Continue, metadados nulos de arte, identificação de capas, fila de busca/download, reserva de 15 até 25, grupos de cinco, retomada após cancelamento, cache entre processos e rotação de armazenamento.

## Preservação

O repositório/DAO e seus filtros de lista/perfil/controle parental não foram modificados. Os arquivos de download, reserva de capas, cache e armazenamento também não foram modificados nesta revisão. Cotas existentes de 100 MB de cache descartável, até 75 MB de imagens e 125 capas por tipo preservadas, sem cache adicional. Não foi medido o tamanho completo instalado contra a meta de 400 MB.

Aplicação/reversão/coletor: passaram em PowerShell 7 e com o comportamento de arrays JSON do Windows PowerShell 5.1 simulado. Conferidos hashes, reaplicação, reversão incluindo remoção do auxiliar novo, recusa de base diferente e proteção de edições posteriores. Coletor ADB simulado passou em buffer/ao vivo. Não executado em Windows ou TV física nesta revisão.

`:app:compileDesempenhoKotlin :app:lintDesempenho` passaram. Lint: zero erros, 178 avisos e 6 sugestões, a mesma contagem da r6. Após o ajuste final de transição entre Continuar e pesquisa, compileDesempenhoKotlin foi executado novamente com os fontes estáveis e concluiu com BUILD SUCCESSFUL. Configuração desempenho existente, sem alteração de versão/assinatura.

Para repetir os testes:

```powershell
python .\testes\Testar-Host.py --projeto "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium" --tools "PASTA_DOS_JARS"
```

--tools é opcional; sem cache, baixa dependências Maven. Os testes Android independentes usam adaptadores de rede/bitmap/DAO indicados no código. Não foi publicado APK, alterada assinatura ou feita instalação remota na TV. Aparência, foco remoto e pesquisa sobre o catálogo real ainda precisam de conferência no aparelho.
