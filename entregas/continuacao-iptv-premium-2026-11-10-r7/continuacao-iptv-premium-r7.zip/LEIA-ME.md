# IPTV Premium — r7: pesquisa geral e limpeza em um toque

Atualização incremental sobre a r6. Modifica cinco arquivos Kotlin e adiciona um auxiliar de escopo, com conferência de hashes e backup antes de aplicar.

## Pesquisa

Em Filmes, pesquisa todos os filmes permitidos da lista ativa. Em Séries, pesquisa todas as séries permitidas da lista ativa. Funciona para os catálogos importados por Xtream e M3U, nos modos normal e Kids.

Enquanto houver texto, a pesquisa ignora a categoria selecionada e o filtro Favoritos. O menu selecionado permanece guardado para ser retomado ao limpar. Pesquisar a partir de Continuar também abre os resultados gerais daquele tipo de conteúdo, em vez de filtrar somente o histórico.

A seleção da lista, o perfil e o controle parental continuam no caminho existente de acesso ao repositório. A alteração usa a busca SQLite já existente e preserva a pausa de 350 ms de digitação. Não carrega o catálogo inteiro em memória nem faz uma busca nova no servidor do provedor.

A antecipação de capas usa o mesmo escopo da pesquisa. A reserva antiga restaurada na r6 (15 até 25 capas adiante, grupos de cinco e dois trabalhadores) e o cache rotativo não foram alterados.

## Limpar em um toque

- Botão **Limpar** ao lado do campo de pesquisa quando houver texto.
- Tecla **LIMPAR** no teclado virtual do catálogo. Apaga tudo sem fechar o teclado, para permitir outra pesquisa.
- Suporte já existente de seleção/substituição do texto no teclado físico foi ligado ao texto atual do campo.

Limpar apaga o texto, zera o cursor e retoma a categoria, Favoritos ou Continuar selecionado anteriormente, mantendo a ordenação atual. A limpeza em branco é imediata e cancela qualquer pesquisa ainda aguardando a pausa de digitação. Ao clicar explicitamente em outra categoria, a pesquisa termina e abre essa categoria.

Não apaga histórico, favoritos, listas, configurações ou caches. O botão opcional do teclado foi habilitado somente nesses catálogos; os demais formulários mantêm seu teclado anterior.

## Aplicar e instalar na TV

Baixe continuacao-iptv-premium-r7.zip em Downloads e execute no PowerShell:

```powershell
$projeto = "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium"
$pasta = "$env:USERPROFILE\Downloads\continuacao-iptv-premium-r7"
Unblock-File -LiteralPath "$pasta.zip"
Expand-Archive -LiteralPath "$pasta.zip" -DestinationPath $pasta -Force
Set-Location $pasta
powershell -ExecutionPolicy Bypass -File .\Aplicar.ps1 -Projeto "$projeto"
if ($LASTEXITCODE -eq 0) {
    powershell -ExecutionPolicy Bypass -File .\Instalar-TV.ps1 -Projeto "$projeto"
} else {
    throw "A aplicacao falhou. Confira a mensagem antes de compilar/instalar."
}
```

O instalador fica na pasta extraída em Downloads. Usa as configurações e a assinatura locais, compila assembleDesempenho, escolhe a ABI e instala com adb install -r. Não desinstala nem limpa dados. Não precisa reimportar a lista. Se o aplicador recusar uma base diferente da r6, não force a substituição; confira o arquivo indicado.

O aplicador mostra o backup e o comando para desfazer. O pacote não contém APK, lista M3U, credenciais ou arquivos privados.

## Conferência na TV

1. Escolha uma categoria e pesquise um título conhecido de outra categoria. Confira se ele aparece, desde que permitido pelo perfil.
2. Use Limpar e confira o retorno à categoria anterior e ao campo de pesquisa.
3. Abra o teclado, digite e use LIMPAR: confira texto vazio e teclado aberto para pesquisar novamente.
4. Repita a partir de Favoritos e Continuar, e nos catálogos de Filmes/Séries dos dois formatos.
5. Confira o comportamento de foco com o controle remoto, também no modo Kids.

Os testes de escopo e limpeza usam trechos reais dos fontes. A apresentação e o foco no aparelho ainda exigem conferência na TV. Veja VALIDACAO.md.
