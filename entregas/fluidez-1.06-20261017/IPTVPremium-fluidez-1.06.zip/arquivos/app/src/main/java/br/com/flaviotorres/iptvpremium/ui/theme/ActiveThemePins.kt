package br.com.flaviotorres.iptvpremium.ui.theme

/** Retains the active theme's small fixed set; normal LRU traffic cannot evict these entries. */
internal class ActiveThemePins<T>(private val budget: Int, private val sizeOf: (T) -> Int) {
    private data class Entry<T>(val group: String, val value: T, val size: Int)
    private var theme: String? = null
    private val items = linkedMapOf<String, Entry<T>>()
    @Synchronized fun activate(value: String): Boolean {
        if (theme == value) return false
        theme = value; items.clear(); return true
    }
    @Synchronized fun get(value: String, key: String): T? = if (theme == value) items[key]?.value else null
    @Synchronized fun put(value: String, key: String, group: String, image: T): Boolean {
        if (theme != value) return false // An old theme can finish decoding after a new selection.
        val bytes = sizeOf(image)
        val kept = items.values.filter { it.group != group }.sumOf { it.size }
        if (bytes > budget || kept + bytes > budget) return false
        items.entries.removeAll { it.value.group == group }
        items[key] = Entry(group, image, bytes)
        return true
    }
    @Synchronized fun reset() { theme = null; items.clear() }
    @Synchronized fun size(): Int = items.values.sumOf { it.size }
}

internal fun seriesOpeningCanStart(detailsReady: Boolean, backdropSettled: Boolean, roomReady: Boolean): Boolean =
    detailsReady && backdropSettled && roomReady

internal suspend fun awaitSeriesOpeningReady(timeoutMs: Long, ready: () -> Boolean, failed: () -> Boolean): Boolean =
    kotlinx.coroutines.withTimeoutOrNull(timeoutMs) {
        while (!ready() && !failed()) kotlinx.coroutines.delay(32L)
        ready() && !failed()
    } == true

/** A one-byte marker is disposable with Android's cache; preferences and user data are never touched. */
internal class ArtworkCacheResetMarker(private val marker: java.io.File) {
    private var observed = false
    @Synchronized fun check(): Boolean {
        val exists = marker.isFile
        val cleared = observed && !exists
        if (!exists) {
            marker.parentFile?.mkdirs()
            try { marker.writeText("1") } catch (_: java.io.IOException) { return cleared }
        }
        observed = marker.isFile
        return cleared
    }
}
