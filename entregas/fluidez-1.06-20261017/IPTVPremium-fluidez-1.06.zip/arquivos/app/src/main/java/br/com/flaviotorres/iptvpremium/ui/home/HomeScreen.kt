package br.com.flaviotorres.iptvpremium.ui.home

import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import br.com.flaviotorres.iptvpremium.ui.theme.themePainterResource as painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.tv.material3.MaterialTheme
import br.com.flaviotorres.iptvpremium.R
import br.com.flaviotorres.iptvpremium.ui.components.HomeMenuCard

// Mesmo dourado metálico usado no contorno dos ícones principais.
private val MetallicGoldBrush get() = Brush.linearGradient(
    colors = listOf(
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFF8A6414),
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFD4AF37),
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE991),
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFF4BD),
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFE3B83F),
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFF9E761B)
    )
)

@Composable
fun HomeScreen(
    onLiveTvClick: () -> Unit,
    onMoviesClick: () -> Unit,
    onSeriesClick: () -> Unit,
    onListaClick: () -> Unit = {},
    onAtualizarClick: () -> Unit = {},
    onConfiguracoesClick: () -> Unit = {}
) {
    val artworkReady = br.com.flaviotorres.iptvpremium.ui.theme.rememberHomeArtworkReady()
    if (!artworkReady) {
        Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background), contentAlignment = Alignment.Center) {
            androidx.tv.material3.Text("Preparando seu tema…", color = Color.White)
        }
        return
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Image(
            painter = painterResource(
                id = R.drawable.home_background
            ),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        /*
         * ESCURECIMENTO DO FUNDO
         *
         * Antes: 0.50f
         * Agora: 0.20f
         */
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Color.Black.copy(
                        alpha = 0.20f
                    )
                )
        )

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            val isWideScreen =
                maxWidth >= 700.dp

            /*
             * LOGO IPTV PREMIUM
             */
            HomeScaledResourceImage(
                imageResId = R.drawable.iptv_premium_logo,
                contentDescription = "IPTV Premium",
                targetWidth = if (isWideScreen) 220.dp else 165.dp,
                targetHeight = if (isWideScreen) 105.dp else 80.dp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(
                        top = if (isWideScreen) {
                            0.dp
                        } else {
                            18.dp
                        }
                    )
                    .width(
                        if (isWideScreen) {
                            220.dp
                        } else {
                            165.dp
                        }
                    )
                    .height(
                        if (isWideScreen) {
                            105.dp
                        } else {
                            80.dp
                        }
                    ),
                contentScale = ContentScale.Fit
            )

            /*
             * ÍCONES DO TOPO DIREITO
             */
            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd),
                horizontalArrangement =
                    Arrangement.spacedBy(
                        if (isWideScreen) {
                            10.dp
                        } else {
                            8.dp
                        }
                    ),
                verticalAlignment =
                    Alignment.CenterVertically
            ) {
                HomeTopIconButton(
                    imageResId = R.drawable.icon_atualizar,
                    contentDescription = "Atualizar",
                    isWideScreen = isWideScreen,
                    onClick = onAtualizarClick
                )

                HomeTopIconButton(
                    imageResId = R.drawable.icon_configuracoes,
                    contentDescription = "Configurações",
                    isWideScreen = isWideScreen,
                    onClick = onConfiguracoesClick
                )
            }

            if (isWideScreen) {
                Row(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(y = 38.dp),
                    horizontalArrangement =
                        Arrangement.spacedBy(20.dp),
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {
                    HomeMenuCard(
                        title = "Canais",
                        imageResId =
                            R.drawable.home_channels,
                        onClick = onLiveTvClick
                    )

                    HomeMenuCard(
                        title = "Filmes",
                        imageResId =
                            R.drawable.home_movies,
                        onClick = onMoviesClick
                    )

                    HomeMenuCard(
                        title = "Séries",
                        imageResId =
                            R.drawable.home_series,
                        onClick = onSeriesClick
                    )

                    HomeMenuCard(
                        title = "Listas",
                        imageResId = R.drawable.icon_lista,
                        onClick = onListaClick
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(y = 38.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        HomeMenuCard(
                            title = "Canais",
                            imageResId = R.drawable.home_channels,
                            onClick = onLiveTvClick
                        )
                        HomeMenuCard(
                            title = "Filmes",
                            imageResId = R.drawable.home_movies,
                            onClick = onMoviesClick
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        HomeMenuCard(
                            title = "Séries",
                            imageResId = R.drawable.home_series,
                            onClick = onSeriesClick
                        )
                        HomeMenuCard(
                            title = "Listas",
                            imageResId = R.drawable.icon_lista,
                            onClick = onListaClick
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeTopIconButton(
    imageResId: Int,
    contentDescription: String,
    isWideScreen: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember {
        mutableStateOf(false)
    }

    val touchAreaSize =
        if (isWideScreen) {
            46.dp
        } else {
            40.dp
        }

    val iconSize =
        if (isWideScreen) {
            33.dp
        } else {
            28.6.dp
        }

    // Fundo transparente; foco indicado pelo aumento suave do ícone.
    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = Modifier
            .size(touchAreaSize)
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        HomeScaledResourceImage(
            imageResId = imageResId,
            contentDescription = contentDescription,
            targetWidth = iconSize * 1.12f,
            targetHeight = iconSize * 1.12f,
            modifier = Modifier
                .size(iconSize)
                .scale(if (isFocused) 1.12f else 1f),
            contentScale = ContentScale.Fit
        )
    }
}

/** Home artwork is sampled once at physical pixel size, with headroom for focus. */
@Composable
private fun HomeScaledResourceImage(
    @DrawableRes imageResId: Int,
    contentDescription: String?,
    targetWidth: Dp,
    targetHeight: Dp,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Fit
) {
    val density = LocalDensity.current
    val size = with(density) { androidx.compose.ui.unit.IntSize(
        (targetWidth * 1.12f).roundToPx().coerceAtLeast(1), (targetHeight * 1.12f).roundToPx().coerceAtLeast(1)) }
    Image(painter = painterResource(imageResId, size), contentDescription = contentDescription,
        modifier = modifier, contentScale = contentScale)
}
