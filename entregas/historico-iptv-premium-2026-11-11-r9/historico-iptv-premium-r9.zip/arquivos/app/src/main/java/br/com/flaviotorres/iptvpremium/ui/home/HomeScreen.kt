package br.com.flaviotorres.iptvpremium.ui.home

import androidx.annotation.DrawableRes
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.LinearEasing
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import br.com.flaviotorres.iptvpremium.ui.theme.themePainterResource as painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.tv.material3.MaterialTheme
import br.com.flaviotorres.iptvpremium.R
import br.com.flaviotorres.iptvpremium.ui.components.HomeMenuCard

// Mesmo dourado metálico usado no contorno dos ícones principais.
private val MetallicGoldBrush get() = Brush.linearGradient(
    colors = listOf(
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFF8A6414),
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFD4AF37),
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE991),
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFF4BD),
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFE3B83F),
        br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFF9E761B)
    )
)

@Composable
fun HomeScreen(
    onLiveTvClick: () -> Unit,
    onMoviesClick: () -> Unit,
    onSeriesClick: () -> Unit,
    onListaClick: () -> Unit = {},
    onAtualizarClick: () -> Unit = {},
    onConfiguracoesClick: () -> Unit = {},
    onKidsClick: () -> Unit = {},
    normalEnabled: Boolean = true
) {
    MarbledHomeScreen(onLiveTvClick,onMoviesClick,onSeriesClick,onKidsClick,onListaClick,
        onAtualizarClick,onConfiguracoesClick,normalEnabled)
}



/** Home artwork is sampled once at physical pixel size, with headroom for focus. */
@Composable
private fun HomeScaledResourceImage(
    @DrawableRes imageResId: Int,
    contentDescription: String?,
    targetWidth: Dp,
    targetHeight: Dp,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Fit
) {
    val density = LocalDensity.current
    val size = with(density) { androidx.compose.ui.unit.IntSize(
        (targetWidth * 1.12f).roundToPx().coerceAtLeast(1), (targetHeight * 1.12f).roundToPx().coerceAtLeast(1)) }
    Image(painter = painterResource(imageResId, size), contentDescription = contentDescription,
        modifier = modifier, contentScale = contentScale)
}



