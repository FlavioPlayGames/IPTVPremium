package br.com.flaviotorres.iptvpremium.data.history

import java.net.URI
import java.security.MessageDigest
import java.util.Locale

private val providerAssetIdPattern = Regex("[0-9]{1,20}")
private const val IDENTITY_HEX = "0123456789abcdef"

internal data class ProviderMovieIdentity(val key:String,val id:String)

/** Only the exact provider asset is linked. Credentials/query/title are not persisted. */
internal fun providerMovieIdentity(url:String?):ProviderMovieIdentity? = providerAssetIdentity(url,"movie")
private fun providerAssetIdentity(url:String?,type:String):ProviderMovieIdentity? = runCatching {
    val uri=URI(url ?: return null)
    val scheme=uri.scheme?.lowercase(Locale.ROOT)?.takeIf {it=="http" || it=="https"} ?: return null
    val host=uri.host?.lowercase(Locale.ROOT) ?: return null
    val parts=uri.rawPath.orEmpty().split('/').filter {it.isNotEmpty()}
    if(parts.size<4 || parts[parts.size-4]!=type) return null
    val file=parts.last()
    val id=file.substringBeforeLast('.',"").takeIf {it.matches(providerAssetIdPattern)} ?: return null
    val namespace=parts.dropLast(3).joinToString("/")
    val port=if(uri.port==-1) {if(scheme=="https")443 else 80} else uri.port
    val value="$scheme|$host|$port|$namespace|$id"
    val digest=MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
    val key=CharArray(digest.size*2).also { chars ->
        digest.forEachIndexed { index, byte ->
            val value=byte.toInt() and 255
            chars[index*2]=IDENTITY_HEX[value ushr 4];chars[index*2+1]=IDENTITY_HEX[value and 15]
        }
    }.concatToString()
    ProviderMovieIdentity(key,id)
}.getOrNull()
