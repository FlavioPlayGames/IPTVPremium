package br.com.flaviotorres.iptvpremium.data.history

import android.content.Context
import br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import br.com.flaviotorres.iptvpremium.data.repository.SeriesEpisodeInfo
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

/** Device-local identity links. No server requests, video URLs, passwords or catalogue copies. */
class SharedLibraryStore private constructor(context: Context, private val kids:Boolean=false) {
    private val app = context.applicationContext
    private val legacyPrefs = app.getSharedPreferences(HistoryProfile.preferences("iptvpremium_shared_library_v1",kids), Context.MODE_PRIVATE)
    private val prefs = app.getSharedPreferences(HistoryProfile.preferences("iptvpremium_library_handoff_v2",kids), Context.MODE_PRIVATE)
    private val lock = Any()
    private val reconcileLock = Mutex()
    private var lastFavoriteReservation=0L
    val changes = MutableStateFlow(0L)
    private data class Record(val key: String, val playlist: String, val id: String,
        val identity: ContentIdentity, val tracked: Boolean, val favorite: Boolean?, val changed: Long,
        val hiddenUntil: Long = 0L, val aliasesVersion: Int = 0)
    private data class Link(val id: String, val title: String, val poster: String?, val order: Int? = null)
    // Opening the app only creates the store; decoding/searching history waits for catalogue readiness.
    private var loadedRecords:MutableMap<String,Record>?=null
    private var records:MutableMap<String,Record>
        get()=synchronized(lock) {loadedRecords?:readRecords().also {loadedRecords=it}}
        set(value) {synchronized(lock) {loadedRecords=value}}
    @Volatile private var selectedPlaylist: String? = null
    fun selectTarget(playlist:String?) { selectedPlaylist=playlist }
    private var linkedPlaylist: String? = null
    private var linkedGeneration: String? = null
    private val linkedSignatures = mutableMapOf<String, String>()
    private var links = emptyMap<String, List<Link>>()
    private var linkedHistory = emptyList<WatchHistoryEntry>()
    private val episodeAttempts = mutableMapOf<String, Long>()
    private val episodeMaps = mutableMapOf<String, Map<Pair<Int, Int>, SeriesEpisodeInfo>>()

    private fun key(playlist: String, kind: String, id: String) = "${playlist.length}:$playlist:$kind:$id"
    private fun identity(row: SharedCatalogIdentity, kind: String):ContentIdentity {
        val asset=if(kind=="movies")providerMovieIdentity(row.streamUrl)else null
        return ContentIdentity(kind,row.title,row.year,row.imdb,row.tmdb,providerAssetKey=asset?.key,providerAssetId=asset?.id)
    }
    private fun changed() { changes.value = changes.value + 1L }
    private fun readRecords(): MutableMap<String, Record> = synchronized(lock) {
        val result = linkedMapOf<String, Record>()
        val array = try { JSONArray(prefs.getString("identities", legacyPrefs.getString("identities", "[]"))) } catch (_: Exception) { JSONArray() }
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val kind = o.optString("kind"); if (kind !in listOf("movies", "series")) continue
            val playlist = o.optString("playlist"); val id = o.optString("id")
            if (playlist.isBlank() || id.isBlank()) continue
            val k = key(playlist, kind, id)
            result[k] = Record(k, playlist, id, ContentIdentity(kind, o.optString("title"),
                o.optInt("year").takeIf { it > 0 }, o.optString("imdb"), o.optString("tmdb"),
                    o.optJSONArray("aliases")?.let { a -> (0 until minOf(a.length(), 32)).map { a.optString(it) }.filter { it.isNotBlank() && it.length <= 160 } }.orEmpty(), providerAssetKey=o.optString("providerAssetKey").takeIf {it.matches(Regex("[0-9a-f]{64}"))},
                    providerAssetId=o.optString("providerAssetId").takeIf {it.matches(Regex("[0-9]{1,20}"))}),
                o.optBoolean("tracked"), if (o.has("favorite")) o.optBoolean("favorite") else null,
                o.optLong("changed"), o.optLong("hiddenUntil"), o.optInt("aliasesVersion"))
        }
        result
    }
    private fun persist() {
        val a = JSONArray()
        records.values.forEach { r -> a.put(JSONObject().apply {
            put("playlist", r.playlist); put("id", r.id); put("kind", r.identity.kind)
            put("title", r.identity.title); put("year", r.identity.year ?: 0)
            put("imdb", r.identity.imdb ?: ""); put("tmdb", r.identity.tmdb ?: "")
            put("aliases", JSONArray(r.identity.alternateTitles.take(32)))
            put("providerAssetKey",r.identity.providerAssetKey ?: "");put("providerAssetId",r.identity.providerAssetId ?: "")
            put("tracked", r.tracked); r.favorite?.let { put("favorite", it) }
            put("changed", r.changed); put("hiddenUntil", r.hiddenUntil); put("aliasesVersion", r.aliasesVersion)
        }) }
        // Keep only small identity records, never the catalogue or playback addresses.
        if (!prefs.edit().putString("identities", a.toString()).commit()) {
            records = readRecords()
            error("Falha ao salvar vínculos locais")
        }
    }
    private suspend fun ensureRecord(dao: PlaylistCacheDao, playlist: String, kind: String, id: String,
        fallback: ContentIdentity? = null, refresh: Boolean = false): Record? {
        val k = key(playlist, kind, id)
        if (!refresh) synchronized(lock) {
            records[k]?.takeIf { it.tracked && (kind!="movies" || it.identity.providerAssetKey!=null) }?.let { current ->
                // A favorite may have been recorded before playback supplied a year or external ID.
                val known=current.identity
                if(fallback!=null && !historyIdentityConflict(known,fallback)) {
                    val enriched=known.copy(year=known.year?:fallback.year,
                        imdb=known.imdbKey?:fallback.imdbKey,tmdb=known.tmdbKey?:fallback.tmdbKey)
                    if(enriched!=known)records[k]=current.copy(identity=enriched)
                }
                return records[k]!!
            }
        }
        val basic = if (kind == "movies") dao.getActiveMovieById(playlist, id)?.let {
            providerMovieIdentity(it.streamUrl).let { asset ->
                ContentIdentity(kind,it.name,it.year,providerAssetKey=asset?.key,providerAssetId=asset?.id)
            }
        } else dao.getActiveGeneration(playlist)?.let { g ->
            dao.getParentalSeriesById(playlist, g.generationId, id)?.let {
                ContentIdentity(kind, it.name, it.year, it.imdbId, it.tmdbId)
            }
        }
        return synchronized(lock) {
            val previous = records[k]
            val known = previous?.identity
            val value = if (known != null) known.copy(
                title = known.title.takeIf{it.isNotBlank()} ?: fallback?.title ?: basic?.title.orEmpty(),
                year = known.year ?: basic?.year ?: fallback?.year,
                imdb = known.imdbKey ?: basic?.imdbKey ?: fallback?.imdbKey,
                tmdb = known.tmdbKey ?: basic?.tmdbKey ?: fallback?.tmdbKey,
                providerAssetKey=basic?.providerAssetKey ?: known.providerAssetKey,
                providerAssetId=basic?.providerAssetId ?: known.providerAssetId
            ) else basic?.copy(year=basic.year?:fallback?.year,imdb=basic.imdbKey?:fallback?.imdbKey,tmdb=basic.tmdbKey?:fallback?.tmdbKey) ?: fallback ?: return@synchronized null
            val record = previous?.copy(tracked = true, identity = value) ?: Record(k, playlist, id, value, true, null, 0)
            records[k] = record
            record
        }
    }
    fun reserveFavoriteEdit():Long=synchronized(lock) {
        val migrated=if(kids)0L else app.getSharedPreferences("iptvpremium_favorites_v1",Context.MODE_PRIVATE).all.filterKeys{it.startsWith("player_migration_time:")}.values.mapNotNull{it as? Long}.maxOrNull()?:0L
        maxOf(System.currentTimeMillis(),(records.values.maxOfOrNull{it.changed}?:0L)+1,lastFavoriteReservation+1,migrated+1).also{lastFavoriteReservation=it}
    }
    suspend fun setFavorite(dao: PlaylistCacheDao, playlist: String, kind: String, id: String, favorite: Boolean, editStamp:Long?=null) {
        ensureRecord(dao, playlist, kind, id) ?: return
        synchronized(lock) {
            val k = key(playlist, kind, id); val r = records[k] ?: return
            val stamp=editStamp?:reserveFavoriteEdit()
            if(stamp<=r.changed)return@synchronized
            records[k] = r.copy(favorite = favorite, changed = stamp)
            persist(); changed()
        }
    }
    private fun mergeExternal(playlist: String, id: String, value: ContentIdentity): Boolean {
        if (playlist.isBlank() || id.isBlank()) return false
        val k = key(playlist, value.kind, id); val old = records[k]
        if(old!=null && historyIdentityConflict(old.identity,value)) {
            val scope="${playlist.length}:$playlist:${id.length}:$id"
            if(value.kind=="movies")app.getSharedPreferences(HistoryProfile.preferences("iptvpremium_movies_assistir_v1",kids),Context.MODE_PRIVATE).edit().remove("movie:$scope").apply()
            else {
                val legacy=app.getSharedPreferences(HistoryProfile.preferences("iptvpremium_series_assistir_v1",kids),Context.MODE_PRIVATE)
                val edit=legacy.edit().remove("last:$scope")
                legacy.all.keys.filter{it.startsWith("position:$scope:")}.forEach{edit.remove(it)};edit.apply()
            }
        }
        val merged = value.copy(providerAssetKey=value.providerAssetKey ?: old?.identity?.providerAssetKey,
            providerAssetId=value.providerAssetId ?: old?.identity?.providerAssetId, imdb = value.imdbKey ?: old?.identity?.imdbKey,
            tmdb = value.tmdbKey ?: old?.identity?.tmdbKey, year = value.year ?: old?.identity?.year,
            alternateTitles = (value.alternateTitles + old?.identity?.alternateTitles.orEmpty())
                .filter { it.isNotBlank() && it.length <= 160 }.distinct().take(32))
        if (old?.identity == merged) return false
        if (old == null && records.values.count { !it.tracked } >= 512) {
            records.entries.firstOrNull { !it.value.tracked }?.key?.let { records.remove(it) }
        }
        records[k] = old?.copy(identity = merged) ?: Record(k, playlist, id, merged, false, null, 0)
        return true
    }
    fun rememberExternal(playlist: String, id: String, value: ContentIdentity) = synchronized(lock) {
        if (mergeExternal(playlist, id, value)) { persist(); changed() }
    }
    /** Capture legacy ID-only favourites before a catalogue can be deleted. No matching/network. */
    suspend fun captureBeforeRemoval(dao:PlaylistCacheDao,playlist:String,history:List<WatchHistoryEntry>) = reconcileLock.withLock {
        val favoritePrefs=app.getSharedPreferences("iptvpremium_favorites_v1",Context.MODE_PRIVATE)
        for(kind in listOf("movies","series")) {
            val ids=favoritePrefs.getStringSet(HistoryProfile.favorite(playlist,kind,kids),emptySet()).orEmpty().toSet()
            for(id in ids) {
                val record=ensureRecord(dao,playlist,kind,id)?:continue
                synchronized(lock) { records[record.key]?.let {
                    if(it.favorite==null)records[it.key]=it.copy(favorite=true)
                } }
            }
        }
        for(h in history.filter{it.playlistId==playlist}.distinctBy{it.contentType to (it.seriesId?:it.contentId)}) {
            val kind=if(h.contentType==PlaybackContentType.MOVIE)"movies"else if(h.contentType==PlaybackContentType.EPISODE)"series"else continue
            ensureRecord(dao,playlist,kind,h.seriesId?:h.contentId,
                ContentIdentity(kind,if(kind=="movies")h.title else h.seriesTitle.orEmpty(),h.year,tmdb=h.tmdbId))
        }
        synchronized(lock) {persist()}
    }

    enum class HandoffPhase { CONTINUE, FAVORITES, ALL }

    private var cacheRestored = false
    private fun restoreTargetCache(playlist: String, generation: String) = synchronized(lock) {
        if (cacheRestored) return@synchronized
        cacheRestored = true
        if (prefs.getString("target", null) != playlist || prefs.getString("generation", null) != generation) return@synchronized
        val saved = try { JSONObject(prefs.getString("target_cache", "{}") ?: "{}") } catch (_: Exception) { return@synchronized }
        linkedPlaylist = playlist; linkedGeneration = generation
        val array = saved.optJSONArray("links") ?: JSONArray()
        links = buildMap {
            for (i in 0 until array.length()) {
                val o = array.optJSONObject(i) ?: continue
                put(o.optString("key"), listOf(Link(o.optString("id"), o.optString("title"),
                    o.optString("poster").takeIf { it.isNotBlank() }, o.optInt("order", -1).takeIf { it >= 0 })))
            }
        }
        val signatures = saved.optJSONObject("signatures") ?: JSONObject()
        signatures.keys().forEach { linkedSignatures[it] = signatures.getString(it) }
    }
    private fun persistTargetCache() {
        val array = JSONArray()
        links.forEach { (key, value) -> value.forEach { link -> array.put(JSONObject().apply {
            put("key", key); put("id", link.id); put("title", link.title); put("poster", link.poster ?: ""); put("order", link.order ?: -1)
        }) } }
        val cache = JSONObject().put("links", array).put("signatures", JSONObject(linkedSignatures.toMap()))
        check(prefs.edit().putString("target", linkedPlaylist).putString("generation", linkedGeneration)
            .putString("target_cache", cache.toString()).commit()) { "Falha ao salvar correspondencias" }
    }
    suspend fun reconcile(dao: PlaylistCacheDao, playlist: String, history: List<WatchHistoryEntry>, force: Boolean = false, reuseUnchanged: Boolean = false, kind: String? = null, phase: HandoffPhase = HandoffPhase.ALL) = reconcileLock.withLock {
        require(kind == null || kind in listOf("movies", "series"))
        if(selectedPlaylist!=null && selectedPlaylist!=playlist)return@withLock
        val generation = dao.getActiveGeneration(playlist)?.generationId ?: return@withLock
        val effective=effectiveHistory(history)
        PlayerFavoriteMigration.run(app)
        val favoritePrefs = app.getSharedPreferences("iptvpremium_favorites_v1", Context.MODE_PRIVATE)
        // Existing 1.05 favorites are imported as timestamp-zero facts, never overwrite an explicit removal.
        val importedFavorites = prefs.getStringSet("imported_favorites", emptySet()).orEmpty().toMutableSet()
        if(phase!=HandoffPhase.CONTINUE) favoritePrefs.all.forEach { (name, raw) ->
            if (name in importedFavorites) return@forEach
            val prefix=if(kids)"kids_"else""
            val recordKind = when { name.startsWith("${prefix}movies_") -> "movies"; name.startsWith("${prefix}series_") -> "series"; else -> return@forEach }
            if (kind != null && kind != recordKind) return@forEach
            val source = name.removePrefix("${prefix}${recordKind}_")
            (raw as? Set<*>)?.filterIsInstance<String>()?.forEach { id ->
                currentCoroutineContext().ensureActive()
                val r = ensureRecord(dao, source, recordKind, id, refresh = force) ?: return@forEach
                synchronized(lock) { val latest = records[r.key]!!
                    val migrated=if(kids)emptySet<String>()else favoritePrefs.getStringSet("player_migration_pending:$recordKind:$source",emptySet()).orEmpty()
                    val stamp=favoritePrefs.getLong("player_migration_time:$recordKind:$source",0L)
                    if(latest.favorite==null || id in migrated && latest.changed<=stamp)records[r.key]=latest.copy(favorite=true,changed=if(id in migrated)stamp else latest.changed)
                }
            }
            importedFavorites.add(name)
        }
        // Mark legacy favourites imported only after their portable identities are durable.
        synchronized(lock) { persist() }
        check(prefs.edit().putStringSet("imported_favorites", importedFavorites).commit())
        val activeHistoryTitles = effective.filter { it.inProgress }.map {
            ContentIdentity(if (it.contentType == PlaybackContentType.MOVIE) "movies" else "series",
                if (it.contentType == PlaybackContentType.EPISODE) it.seriesTitle.orEmpty() else it.title)
        } + synchronized(lock) { records.values.filter { it.favorite == true }.map { it.identity } }
        effective.distinctBy { h ->
            Triple(h.playlistId, h.contentType,
                if (h.contentType == PlaybackContentType.EPISODE) h.seriesId ?: h.contentId else h.contentId)
        }.forEach { h ->
            currentCoroutineContext().ensureActive()
            val recordKind = if (h.contentType == PlaybackContentType.MOVIE) "movies" else if (h.contentType == PlaybackContentType.EPISODE) "series" else return@forEach
            if (kind != null && kind != recordKind) return@forEach
            val id = if (recordKind == "series") h.seriesId ?: return@forEach else h.contentId
            if (kind != null && !h.inProgress && synchronized(lock) { records[key(h.playlistId, recordKind, id)] == null } &&
                activeHistoryTitles.none { it.kind == recordKind && it.sharesTitle(ContentIdentity(recordKind,
                    if (recordKind == "series") h.seriesTitle.orEmpty() else h.title)) }) return@forEach
            ensureRecord(dao, h.playlistId, recordKind, id, ContentIdentity(recordKind, if (recordKind == "series") h.seriesTitle.orEmpty() else h.title,h.year,tmdb=h.tmdbId), refresh = force)
        }
        val snapshot = synchronized(lock) { persist(); records.values.toList() }
        fun historyKey(h:WatchHistoryEntry)=key(h.playlistId,if(h.contentType==PlaybackContentType.MOVIE)"movies"else"series",h.seriesId?:h.contentId)
        val newest=effective.sortedByDescending{it.updatedAtMs}.distinctBy{historyKey(it)}
        val progressKeys=newest.filter{it.inProgress}.map{historyKey(it)}.toSet()
        val favoriteRepresentatives=canonicalHistoryRepresentatives(snapshot.filter{it.favorite!=null}.map{HistoryWorkLink(it.key,it.identity,it.changed)})
        val favoriteKeys=snapshot.filter{it.favorite==true && favoriteRepresentatives[it.key]==it.key}.map{it.key}.toSet()
        val seeds = snapshot.filter { it.tracked && (kind == null || it.identity.kind == kind) &&
            (when (phase) {
                HandoffPhase.CONTINUE -> it.key in progressKeys
                HandoffPhase.FAVORITES -> it.key in favoriteKeys
                HandoffPhase.ALL -> it.key in favoriteKeys || it.key in progressKeys
            }) }
        // Negative favorite/completion facts of the same titles must still supersede old progress.
        val tracked = snapshot.filter { r -> r.tracked && (kind == null || r.identity.kind == kind) &&
            (r in seeds || seeds.any { seed -> seed.identity.sharesTitle(r.identity) ||
                seed.identity.imdbKey != null && seed.identity.imdbKey == r.identity.imdbKey ||
                seed.identity.tmdbKey != null && seed.identity.tmdbKey == r.identity.tmdbKey }) }
        val scope = "${kind ?: "all"}:$phase"
        val signature = java.security.MessageDigest.getInstance("SHA-256").digest(
            tracked.joinToString("\n") { "${it.key}:${it.identity}" }.toByteArray()).joinToString("") { "%02x".format(it) }
        restoreTargetCache(playlist, generation)
        if ((!force || reuseUnchanged) && synchronized(lock) { linkedPlaylist == playlist && linkedGeneration == generation && linkedSignatures[scope] == signature }) {
            synchronized(lock) { linkedHistory = effective.toList() }; return@withLock
        }
        val result = mutableMapOf<String, List<Link>>()
        var scanned=0
        for (mediaKind in (kind?.let { listOf(it) } ?: listOf("movies", "series"))) {
            val wanted = tracked.filter { it.identity.kind == mediaKind }
            if (wanted.isEmpty()) continue
            val matcher = LibraryHandoffMatcher(wanted.map {
                LibraryHandoffMatcher.Source(it.key, it.identity, it.id.takeIf { _ -> it.playlist == playlist })
            })
            val overrides = snapshot.filter { it.playlist == playlist && it.identity.kind == mediaKind }.associateBy { it.id }
            var after = ""
            while (true) {
                currentCoroutineContext().ensureActive()
                val page = if (mediaKind == "movies") dao.handoffMoviePage(playlist, generation, after)
                    else dao.handoffSeriesPage(playlist, generation, after)
                if (page.isEmpty()) break
                scanned+=page.size
                for (row in page) {
                    val base = identity(row, mediaKind)
                    val known = overrides[row.contentId]?.identity?.takeIf {
                        !historyIdentityConflict(base, it) && (base.sharesTitle(it) || base.confidence(it) > 0)
                    }
                    matcher.accept(row, base.copy(year = base.year ?: known?.year,
                        imdb = base.imdbKey ?: known?.imdbKey, tmdb = base.tmdbKey ?: known?.tmdbKey,
                        alternateTitles = known?.alternateTitles.orEmpty()))
                }
                after = page.last().contentId
                kotlinx.coroutines.yield()
            }
            matcher.result().forEach { (k, row) ->
                result[k] = listOf(Link(row.contentId, row.title, row.poster, row.providerOrder))
            }
        }
        // All source editions of one work point to a single real target edition.
        val priorities=effective.groupBy {h->key(h.playlistId,if(h.contentType==PlaybackContentType.MOVIE)"movies"else"series",h.seriesId?:h.contentId)}
            .mapValues{(_,events)->events.maxOf{it.updatedAtMs}}
        val representatives=canonicalHistoryRepresentatives(tracked.filter{!result[it.key].isNullOrEmpty()}.map{HistoryWorkLink(it.key,it.identity,priorities[it.key]?:it.changed)})
        val canonical=result.toMap()
        for((source,representative)in representatives)canonical[representative]?.let{result[source]=it}
        if (dao.getActiveGeneration(playlist)?.generationId != generation ||
            (selectedPlaylist!=null && selectedPlaylist!=playlist)) return@withLock
        synchronized(lock) {
            if (linkedPlaylist != playlist || linkedGeneration != generation) {
                episodeMaps.clear(); episodeAttempts.clear(); links = emptyMap(); linkedSignatures.clear()
            }
            linkedHistory = effective.toList()
            linkedPlaylist = playlist; linkedGeneration = generation; linkedSignatures[scope] = signature
            val replacedKeys = tracked.map { it.key }.toSet()
            links = links.filterKeys { it !in replacedKeys } + result
            persistTargetCache()
            changed()
        }
        android.util.Log.i("HistoryHandoffPerf","stage=match phase=$phase kind=${kind?:"all"} scanned=$scanned matched=${result.size}")
    }
    private fun latestSeriesHistory(raw: List<WatchHistoryEntry>) = raw
        .filter { it.contentType == PlaybackContentType.EPISODE && it.seriesId != null }
        .sortedByDescending { it.updatedAtMs }.distinctBy { it.playlistId to it.seriesId }

    /** A newer watch on any linked list supersedes older progress for the same target series. */
    private fun targetSeriesHistory(playlist: String, raw: List<WatchHistoryEntry>): List<Pair<Link, WatchHistoryEntry>> =
        latestSeriesHistory(raw).flatMap { h ->
            val targets = links[key(h.playlistId,"series",h.seriesId!!)].orEmpty()
            targets.map { it to h }
        }.sortedByDescending { it.second.updatedAtMs }.distinctBy { it.first.id }

    /** Hydrate only linked in-progress series, using real target-provider episode coordinates. */
    suspend fun importEpisodeLinks(playlist: String, refresh: Boolean = false,
        load: suspend (String) -> List<SeriesEpisodeInfo>): Boolean {
        val requests = synchronized(lock) {
            if (linkedPlaylist != playlist) return false
            targetSeriesHistory(playlist, linkedHistory).filter { (link, h) ->
                (h.playlistId != playlist || h.seriesId!=link.id) && h.inProgress && h.seasonNumber != null && (h.episodeNumber ?: 0) > 0
            }.filter { (link, h) -> episodeMaps[link.id]?.get(h.seasonNumber to h.episodeNumber) == null &&
                (refresh || System.currentTimeMillis() - (episodeAttempts[link.id] ?: 0L) >= 60_000L)
            }.map { it.first.id }
        }
        var updated = false
        for (batch in requests.chunked(2)) {
            val found = coroutineScope {
                batch.map { id -> async {
                    synchronized(lock) { episodeAttempts[id] = System.currentTimeMillis() }
                    val episodes = try { kotlinx.coroutines.withTimeoutOrNull(8_000L) { load(id) } }
                        catch (cancelled: kotlinx.coroutines.CancellationException) {
                            synchronized(lock) { episodeAttempts.remove(id) }; throw cancelled
                        }
                        catch (_: Exception) { null }
                    id to episodes
                } }.awaitAll()
            }
            for ((id, episodes) in found) if (!episodes.isNullOrEmpty()) {
                registerEpisodes(playlist, id, episodes, notify = false); updated = true
            }
        }
        return updated
    }
    fun favorites(playlist: String, kind: String, existing: Set<String>): Set<String> = synchronized(lock) {
        if (linkedPlaylist != playlist) return@synchronized existing
        val events = records.values.filter { it.identity.kind == kind && it.favorite != null }
            .flatMap { r -> links[r.key].orEmpty().map { it.id to r } }.groupBy({ it.first }, { it.second })
        existing.flatMap{id->links[key(playlist,kind,id)].orEmpty().map{it.id}}.toMutableSet().apply {
            events.forEach { (id, choices) ->
                if (choices.maxBy { it.changed }.favorite == true) add(id) else remove(id)
            }

        }.toSet()
    }
    fun registerEpisodes(playlist: String, series: String, episodes: List<SeriesEpisodeInfo>, notify: Boolean = true) = synchronized(lock) {
        if (playlist != linkedPlaylist) return@synchronized
        // Retain only coordinates needed by shared history, not whole anime seasons in RAM.
        val wanted = targetSeriesHistory(playlist, linkedHistory)
            .filter { (link, h) -> link.id == series && (h.playlistId != playlist || h.seriesId!=link.id) && h.inProgress }
            .map { (_, h) -> h.seasonNumber to h.episodeNumber }.toSet()
        val mapped = episodes.filter { it.seasonNumber >= 0 && it.episodeNumber > 0 &&
            (it.seasonNumber to it.episodeNumber) in wanted }
            .groupBy { it.seasonNumber to it.episodeNumber }.filterValues { it.size == 1 }.mapValues { it.value.single() }
        if (episodeMaps[series] != mapped) {
            episodeMaps[series] = mapped
            if (notify) changed()
        }
    }
    private fun eventIdentity(h:WatchHistoryEntry):ContentIdentity {
        val kind=if(h.contentType==PlaybackContentType.MOVIE)"movies"else"series"
        val saved=ContentIdentity(kind,if(kind=="movies")h.title else h.seriesTitle.orEmpty(),h.year,tmdb=h.tmdbId)
        val known=records[key(h.playlistId,kind,h.seriesId?:h.contentId)]?.identity?:return saved
        if(saved.normalizedYear!=null && known.normalizedYear!=null && saved.normalizedYear!=known.normalizedYear)return saved
        if(saved.tmdbKey!=null && known.tmdbKey!=null && saved.tmdbKey!=known.tmdbKey)return saved
        return known.copy(year=known.year?:saved.year,tmdb=known.tmdbKey?:saved.tmdbKey)

    }
    /** Keep one latest fact per confirmed work (and per episode coordinate), never by a loose title. */
    fun compactHistory(raw:List<WatchHistoryEntry>):List<WatchHistoryEntry> = synchronized(lock) {
        compactHistoryFacts(raw,::eventIdentity)
    }
    /** Hidden facts remain persisted, so an older playlist cannot resurrect a removed title. */
    fun effectiveHistory(raw:List<WatchHistoryEntry>):List<WatchHistoryEntry> = synchronized(lock) {
        compactHistory(raw).filter { h->
            val identity=eventIdentity(h)
            val eventKey=key(h.playlistId,if(h.contentType==PlaybackContentType.MOVIE)"movies"else"series",h.seriesId?:h.contentId)
            val hidden=records.values.filter{it.hiddenUntil>0 && (it.key==eventKey || sameHistoryWork(identity,it.identity))}.maxOfOrNull{it.hiddenUntil}?:0L
            h.updatedAtMs>hidden
        }
    }
    fun allowLegacyResume(playlist:String,media:br.com.flaviotorres.iptvpremium.core.player.PlaybackMedia,raw:List<WatchHistoryEntry>):Boolean=synchronized(lock) {
        val kind=if(media.type==PlaybackContentType.MOVIE)"movies"else"series"
        val actual=ContentIdentity(kind,if(kind=="movies")media.title else media.subtitleSearchTitle.orEmpty(),media.year,tmdb=media.tmdbId)
        val known=records[key(playlist,kind,media.seriesId?:media.id)]?.identity
        if(known!=null && historyIdentityConflict(actual,known))return@synchronized false
        raw.none{it.playlistId==playlist && it.contentType==media.type && it.contentId==media.id && historyIdentityConflict(actual,eventIdentity(it))}
    }
    /** Explicit playback may read local completed facts even when the title no longer needs a catalog search. */
    fun resumeEntry(playlist:String,media:br.com.flaviotorres.iptvpremium.core.player.PlaybackMedia,raw:List<WatchHistoryEntry>):WatchHistoryEntry? = synchronized(lock) {
        val kind=if(media.type==PlaybackContentType.MOVIE)"movies"else"series"
        val targetKey=key(playlist,kind,media.seriesId?:media.id)
        val record=records[targetKey]?:records.values.firstOrNull{linkedPlaylist==playlist && links[it.key].orEmpty().any{target->target.id==(media.seriesId?:media.id)}}
        val actual=ContentIdentity(kind,if(kind=="movies")media.title else media.subtitleSearchTitle.orEmpty(),media.year,tmdb=media.tmdbId)
        val identity=record?.identity?.takeUnless{historyIdentityConflict(it,actual)}?:actual
        val hidden=records.values.filter{it.hiddenUntil>0 && (it.key==record?.key || sameHistoryWork(identity,it.identity))}.maxOfOrNull{it.hiddenUntil}?:0L
        raw.sortedByDescending{it.updatedAtMs}.firstOrNull{h->h.contentType==media.type && !historyIdentityConflict(identity,eventIdentity(h)) &&
            (media.type==PlaybackContentType.MOVIE || h.seasonNumber==media.seasonNumber && h.episodeNumber==media.episodeNumber && media.seasonNumber!=null && media.episodeNumber!=null) &&
            ((h.playlistId==playlist && h.contentId==media.id) ||
                key(h.playlistId,kind,h.seriesId?:h.contentId)==record?.key ||
                linkedPlaylist==playlist && links[key(h.playlistId,kind,h.seriesId?:h.contentId)].orEmpty().any{it.id==(media.seriesId?:media.id)} ||
                sameHistoryWork(identity,eventIdentity(h)))}?.let{h->
            h.copy(playlistId=playlist,contentId=media.id,seriesId=media.seriesId,
                positionMs=if(h.updatedAtMs<=hidden)0L else h.positionMs,pendingNext=if(h.updatedAtMs<=hidden)false else h.pendingNext,
                sharedFromPlaylist=if(h.playlistId!=playlist || h.contentId!=media.id)h.playlistId else h.sharedFromPlaylist)
        }
    }

    fun projectHistory(playlist: String, raw: List<WatchHistoryEntry>): List<WatchHistoryEntry> = synchronized(lock) {
        if (playlist != linkedPlaylist) return@synchronized raw.filter { it.playlistId == playlist }
        val latest = targetSeriesHistory(playlist, raw).associate { it.first.id to it.second }
        val mapped = raw.flatMap { h ->
            val kind = if (h.contentType == PlaybackContentType.MOVIE) "movies" else if (h.contentType == PlaybackContentType.EPISODE) "series" else return@flatMap emptyList()
            val id = if (kind == "series") h.seriesId ?: return@flatMap emptyList() else h.contentId
            val r = records[key(h.playlistId, kind, id)]
            val targets = r?.let { links[it.key] }.orEmpty()
            if(targets.isEmpty() && h.playlistId==playlist) {
                val identity=eventIdentity(h)
                val hidden=records.values.filter { it.hiddenUntil>0 &&
                    (it.key==key(playlist,kind,id) || sameHistoryWork(identity,it.identity)) }.maxOfOrNull{it.hiddenUntil}?:0L
                // The catalogue repository verifies presence/identity before displaying this local fact.
                // A pending cross-list reconciliation must not hide a newly saved own-list checkpoint.
                return@flatMap if(h.updatedAtMs>hidden)listOf(h.copy(localProjectionFallback=true))else emptyList()
            }
            targets.mapNotNull { link ->
                if (kind == "series" && (h.playlistId != playlist || h.seriesId!=link.id) && latest[link.id] != h) return@mapNotNull null
                val hidden = records.values.filter { it.identity.kind == kind &&
                    (links[it.key].orEmpty().any { target -> target.id == link.id } || (it.playlist == playlist && it.id == link.id))
                }.maxOfOrNull { it.hiddenUntil } ?: 0
                if (h.updatedAtMs <= hidden) return@mapNotNull null
                if (h.playlistId == playlist && id==link.id) return@mapNotNull h
                if (kind == "movies") h.copy(playlistId = playlist, contentId = link.id, title = link.title,
                    posterUrl = link.poster, sharedFromPlaylist = h.playlistId)
                else {
                    val episode = episodeMaps[link.id]?.get(h.seasonNumber to h.episodeNumber)
                    if (episode == null && episodeMaps.containsKey(link.id)) return@mapNotNull null
                    if (episode == null) return@mapNotNull h.copy(playlistId = playlist, seriesId = link.id,
                        contentId = link.id, title = link.title, seriesTitle = link.title, seriesPosterUrl = link.poster,
                        positionMs = 0L, durationMs = null, seriesOnly = true, sharedFromPlaylist = h.playlistId)
                    h.copy(playlistId = playlist, seriesId = link.id, seriesTitle = link.title, seriesPosterUrl = link.poster,
                        contentId = episode.id, title = episode.title, positionMs = h.positionMs,
                        durationMs = h.durationMs, seasonNumber = h.seasonNumber, episodeNumber = h.episodeNumber,
                        seriesOnly = false, sharedFromPlaylist = h.playlistId)
                }
            }
        }
        mapped.sortedByDescending { it.updatedAtMs }.distinctBy { it.contentType to it.contentId }
    }
    fun hide(playlist: String, type: PlaybackContentType, contentId: String, raw: List<WatchHistoryEntry>) = synchronized(lock) {
        val entry = projectHistory(playlist, raw).firstOrNull { it.contentType == type && it.contentId == contentId } ?: return@synchronized
        val kind = if (type == PlaybackContentType.MOVIE) "movies" else "series"
        val id = if (kind == "movies") entry.contentId else entry.seriesId ?: return@synchronized
        val until = maxOf(System.currentTimeMillis(),raw.maxOfOrNull{it.updatedAtMs}?:0L)
        val ownKey=key(playlist,kind,id)
        if(records[ownKey]==null)records[ownKey]=Record(ownKey,playlist,id,eventIdentity(entry),true,null,0L,hiddenUntil=until)
        records.replaceAll { _, r -> if (r.identity.kind == kind &&
            ((r.playlist == playlist && r.id == id) || (linkedPlaylist == playlist && links[r.key].orEmpty().any { it.id == id }))) r.copy(hiddenUntil = until) else r }
        persist(); changed()
    }
    fun historySource():String? = prefs.getString("completed_history_source", legacyPrefs.getString("completed_history_source",null))?.takeIf {it.isNotBlank()}
    /** Move confirmed matches forward; unmatched works remain in the portable history. */
    fun checkpointCompletedHistory(playlist:String, historyStore:WatchHistoryStore) {
        val favoritePrefs=app.getSharedPreferences("iptvpremium_favorites_v1",Context.MODE_PRIVATE)
        val movieFavorites=favorites(playlist,"movies",emptySet())
        val seriesFavorites=favorites(playlist,"series",emptySet())
        val mappedKeys = synchronized(lock) {
            check(linkedPlaylist==playlist) {"Vinculos de outra lista"}
            val mapped=records.values.toList().flatMap {r->links[r.key].orEmpty().map {r to it}}
                .groupBy {(r,link)->r.identity.kind to link.id}
            mapped.forEach { (target,candidates)->
                val (source,link)=candidates.maxBy {it.first.changed}
                val k=key(playlist,target.first,target.second)
                val own=records[k]
                records[k]=source.copy(key=k,playlist=playlist,id=target.second,
                    identity=source.identity.copy(title=link.title,
                        alternateTitles=(listOf(source.identity.title)+source.identity.alternateTitles+own?.identity?.alternateTitles.orEmpty()).distinct().take(32),
                        year=source.identity.year?:own?.identity?.year,
                        imdb=source.identity.imdbKey?:own?.identity?.imdbKey,tmdb=source.identity.tmdbKey?:own?.identity?.tmdbKey),
                    tracked=true,hiddenUntil=candidates.maxOf {it.first.hiddenUntil})
                links=links + (k to listOf(link))
            }
            // Save target identities before rebasing events: an interrupted migration remains readable.
            persist()
            links.keys.toSet()
        }
        val remaining=historyStore.rebaseHandoff { raw -> synchronized(lock) {
            raw.map { h ->
                val kind=if(h.contentType==PlaybackContentType.MOVIE)"movies"else"series"
                val identity=eventIdentity(h)
                val link=links[key(h.playlistId,kind,h.seriesId?:h.contentId)]?.firstOrNull()
                val enriched=h.copy(year=h.year?:identity.year,tmdbId=h.tmdbId?:identity.tmdbKey)
                if(link==null || h.playlistId==playlist)return@map enriched
                if(kind=="movies")enriched.copy(playlistId=playlist,contentId=link.id,title=link.title,posterUrl=link.poster,sharedFromPlaylist=null)
                else episodeMaps[link.id]?.get(h.seasonNumber to h.episodeNumber)?.let { episode ->
                    enriched.copy(playlistId=playlist,seriesId=link.id,seriesTitle=link.title,seriesPosterUrl=link.poster,
                        contentId=episode.id,title=episode.title,seriesOnly=false,sharedFromPlaylist=null)
                } ?: enriched
            }
        } }
        synchronized(lock) {
            val retained=remaining.map{key(it.playlistId,if(it.contentType==PlaybackContentType.MOVIE)"movies"else"series",it.seriesId?:it.contentId)}.toSet()
            // Old matched favourites/history are not replicated for every previous list.
            records.entries.removeAll { (k,r) -> r.playlist!=playlist && k in mappedKeys && k !in retained }
            links=links.filterKeys{it in records}
            linkedHistory=effectiveHistory(remaining)
            persist(); persistTargetCache(); changed()
        }
        check(favoritePrefs.edit().putStringSet(HistoryProfile.favorite(playlist,"movies",kids),movieFavorites)
            .putStringSet(HistoryProfile.favorite(playlist,"series",kids),seriesFavorites).commit()) {"Falha ao salvar favoritos"}
        check(prefs.edit().putString("completed_history_source",playlist).commit()) {"Falha ao concluir historico"}
    }

    companion object {
        fun resumePosition(entry: WatchHistoryEntry?, position: Long, duration: Long?): Long {
            if (entry?.seriesOnly == true || entry?.completed == true || duration?.takeIf{it>0L}?.let{position.toDouble()/it>=.95}==true) return 0L
            if (entry?.sharedFromPlaylist != null && duration != null && duration > 0 &&
                (position >= duration || (entry.durationMs != null &&
                kotlin.math.abs(entry.durationMs - duration) > maxOf(90_000L, duration / 10)))) return 0L
            return position.coerceAtLeast(0L)
        }
        @Volatile private var instance: SharedLibraryStore? = null
        @Volatile private var kidsInstance: SharedLibraryStore? = null
        fun get(context: Context,kids:Boolean=false): SharedLibraryStore {
            if(!kids)return instance ?: synchronized(this) {instance ?: SharedLibraryStore(context,false).also{instance=it}}
            return kidsInstance ?: synchronized(this) {kidsInstance ?: SharedLibraryStore(context,true).also{kidsInstance=it}}
        }
    }
}

