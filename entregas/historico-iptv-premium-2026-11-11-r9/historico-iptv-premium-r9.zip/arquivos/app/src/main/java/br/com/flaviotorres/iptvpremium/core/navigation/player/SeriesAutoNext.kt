package br.com.flaviotorres.iptvpremium.core.player

import br.com.flaviotorres.iptvpremium.data.repository.SeriesEpisodeInfo

/** Provider IDs are not episode numbers. Retain order for ties; never loop at the end. */
internal fun adjacentSeriesEpisode(episodes: List<SeriesEpisodeInfo>, currentId: String, direction: Int): SeriesEpisodeInfo? {
    if (direction != 1 && direction != -1) return null
    val ordered = episodes.filter { it.id.isNotBlank() }.distinctBy { it.id }
        .sortedWith(compareBy<SeriesEpisodeInfo> { it.seasonNumber }.thenBy { it.episodeNumber })
    val index = ordered.indexOfFirst { it.id == currentId }
    return if (index < 0) null else ordered.getOrNull(index + direction)
}

// IPTV_AUTOMATIC_DOLBY_AND_EPISODE_CONTROLS_USER26_V2
