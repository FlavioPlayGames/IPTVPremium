package br.com.flaviotorres.iptvpremium.data.history

import android.content.Context

/** Retire the historical reset migration without deleting progress on older installations. */
internal object HistoryProfileMigration {
    private val lock=Any()
    fun run(context:Context)=synchronized(lock) {
        val marker=context.applicationContext.getSharedPreferences("iptvpremium_history_profiles_v1",Context.MODE_PRIVATE)
        if(!marker.getBoolean("continue_reset_v1",false)) {
            check(marker.edit().putBoolean("continue_reset_v1",true).commit()) {
                "Falha ao preservar a migracao do historico"
            }
        }
    }
}
