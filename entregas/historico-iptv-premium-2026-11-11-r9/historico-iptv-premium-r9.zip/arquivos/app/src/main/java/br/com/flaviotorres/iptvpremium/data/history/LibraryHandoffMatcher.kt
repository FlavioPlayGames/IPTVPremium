package br.com.flaviotorres.iptvpremium.data.history

/** One bounded catalogue pass per phase, indexed by saved works rather than one SQL scan per title. */
internal class LibraryHandoffMatcher(private val sources: List<Source>) {
    data class Source(val key: String, val identity: ContentIdentity, val ownId: String?)
    private data class Hit(val row: SharedCatalogIdentity, val identity: ContentIdentity, val score: Int)
    private val byTitle = sources.flatMap { s -> s.identity.normalizedTitles.map { it to s } }.groupBy({ it.first }, { it.second })
    private val byImdb = sources.filter { it.identity.imdbKey != null }.groupBy { it.identity.imdbKey }
    private val byTmdb = sources.filter { it.identity.tmdbKey != null }.groupBy { it.identity.tmdbKey }
    private val byAsset = sources.filter { it.identity.providerAssetKey != null }.groupBy { it.identity.providerAssetKey }
    private val byOwnId = sources.filter { it.ownId != null }.groupBy { it.ownId }
    private val hits = mutableMapOf<String, MutableList<Hit>>()
    private val overflow = mutableSetOf<String>()

    fun accept(row: SharedCatalogIdentity, identity: ContentIdentity) {
        val possible = (identity.normalizedTitles.flatMap { byTitle[it].orEmpty() } +
            byImdb[identity.imdbKey].orEmpty() + byTmdb[identity.tmdbKey].orEmpty() +
            byAsset[identity.providerAssetKey].orEmpty() + byOwnId[row.contentId].orEmpty()).distinctBy { it.key }
        for (source in possible) {
            if (source.key in overflow || historyIdentityConflict(source.identity, identity)) continue
            val score = when {
                source.ownId == row.contentId && source.identity.sharesTitle(identity) -> 4
                else -> source.identity.confidence(identity).takeIf { it > 0 } ?: if (
                    source.identity.normalizedTitles.isNotEmpty() && source.identity.sharesTitle(identity)
                ) 1 else 0
            }
            if (score == 0) continue
            val list = hits.getOrPut(source.key) { mutableListOf() }
            if (list.size == 64) { overflow.add(source.key); hits.remove(source.key) }
            else list.add(Hit(row, identity, score))
        }
    }

    fun result(): Map<String, SharedCatalogIdentity> = buildMap {
        for (source in sources) {
            val all = hits[source.key].orEmpty()
            val score = all.maxOfOrNull { it.score } ?: continue
            val best = all.filter { it.score == score }
            val identities = best.map { it.identity }
            // A title lacking a year must never bridge known remakes or conflicting external IDs.
            if (identities.mapNotNull { it.normalizedYear }.distinct().size > 1 ||
                identities.mapNotNull { it.imdbKey }.distinct().size > 1 ||
                identities.mapNotNull { it.tmdbKey }.distinct().size > 1) continue
            if (score == 1 && source.identity.normalizedYear == null &&
                source.identity.normalizedTitles.flatMap { byTitle[it].orEmpty() }.mapNotNull { it.identity.normalizedYear }.distinct().size > 1) continue
            val preferred = preferredHistoryVariantIndex(source.identity.title, best.map { it.row.title to it.row.providerOrder }) ?: continue
            put(source.key, best[preferred].row)
        }
    }
}
