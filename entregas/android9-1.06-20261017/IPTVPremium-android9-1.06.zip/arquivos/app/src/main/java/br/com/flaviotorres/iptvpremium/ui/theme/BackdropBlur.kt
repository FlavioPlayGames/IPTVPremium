package br.com.flaviotorres.iptvpremium.ui.theme

/** Small static wallpaper only. Three bounded box passes approximate a soft Gaussian blur. */
internal fun blurBackdropPixels(pixels: IntArray, width: Int, height: Int, radius: Int): IntArray {
    require(width > 0 && height > 0 && pixels.size == width * height)
    val r = radius.coerceIn(0, 24)
    if (r == 0) return pixels.copyOf()
    var source = pixels.copyOf()
    var target = IntArray(source.size)
    val count = 2 * r + 1
    repeat(3) {
        for (horizontal in listOf(true, false)) {
            val rows = if (horizontal) height else width
            val length = if (horizontal) width else height
            for (row in 0 until rows) {
                fun index(column: Int): Int = if (horizontal) row * width + column.coerceIn(0, width - 1)
                    else column.coerceIn(0, height - 1) * width + row
                var a = 0; var red = 0; var green = 0; var blue = 0
                fun accumulate(pixel: Int, sign: Int) {
                    a += (pixel ushr 24) * sign; red += ((pixel ushr 16) and 255) * sign
                    green += ((pixel ushr 8) and 255) * sign; blue += (pixel and 255) * sign
                }
                for (i in -r..r) accumulate(source[index(i)], 1)
                for (column in 0 until length) {
                    target[index(column)] = ((a / count) shl 24) or ((red / count) shl 16) or ((green / count) shl 8) or (blue / count)
                    accumulate(source[index(column - r)], -1)
                    accumulate(source[index(column + r + 1)], 1)
                }
            }
            val swap = source; source = target; target = swap
        }
    }
    return source
}
