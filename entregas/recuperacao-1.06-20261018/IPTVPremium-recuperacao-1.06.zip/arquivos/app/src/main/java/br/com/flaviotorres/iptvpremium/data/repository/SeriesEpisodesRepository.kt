
package br.com.flaviotorres.iptvpremium.data.repository

import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import br.com.flaviotorres.iptvpremium.data.resolver.M3uXtreamResolver
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.URLEncoder

/** Temporada realmente informada pelo provedor. */
data class SeriesSeasonInfo(
    val number: Int,
    val title: String,
    val coverUrl: String?,
    val episodeCount: Int
)

/** Episodio real do provedor: o ID nao e o numero do episodio. */
data class SeriesEpisodeInfo(
    val id: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val title: String,
    val thumbnailUrl: String?,
    val synopsis: String?,
    val durationSeconds: Int?,
    val containerExtension: String?
)

/** Dados reais de uma unica serie, carregados sob demanda. */
data class SeriesEpisodesResult(
    val seriesId: String,
    val title: String?,
    val plot: String?,
    val backdropUrl: String?,
    val posterUrl: String?,
    val trailerUrl: String?,
    val seasons: List<SeriesSeasonInfo>,
    val episodes: List<SeriesEpisodeInfo>
)

/**
 * Consulta apenas a serie aberta. Nunca baixa a lista de todas as series.
 *
 * - Xtream direto: get_series_info.
 * - M3U Xtream-compatible: mesmo endpoint, credenciais so em memoria.
 * - M3U generica: retorna null, pois nao ha endpoint estruturado.
 *
 * Nenhuma temporada ou episodio demonstrativo e criado.
 */
class SeriesEpisodesRepository(
    private val httpClient: PlaylistHttpClient,
    private val monotonicNanos: () -> Long = System::nanoTime
) {
    suspend fun load(
        source: PlaylistSource,
        seriesId: String
    ): SeriesEpisodesResult? {
        val xtream = when (source) {
            is PlaylistSource.XtreamCodes -> source
            is PlaylistSource.M3u -> M3uXtreamResolver.resolve(source)
        } ?: return null

        val id = seriesId.trim()
        if (id.isEmpty() || !id.all(Char::isDigit)) return null

        val server = xtream.serverUrl.trim().trimEnd('/')
        if (server.isEmpty()) return null

        val baseUrl = when {
            server.startsWith("https://", ignoreCase = true) -> server
            server.startsWith("http://", ignoreCase = true) -> server
            else -> "http://$server"
        }

        // A URL contem credenciais: nunca registra-la em logs ou mensagens.
        val url = "$baseUrl/player_api.php" +
                "?username=${encode(xtream.username)}" +
                "&password=${encode(xtream.password)}" +
                "&action=get_series_info" +
                "&series_id=${encode(id)}"

        return loadWithRetry(url, id)
    }

    /** Recuperacao automatica limitada; timeout tambem e uma falha transitoria.
     * A tela continua em Loading durante as pausas. Nunca repete autorizacao
     * negada nem cancelamento. O orcamento limita o inicio de novas chamadas,
     * sem interromper uma resposta valida que ja esteja chegando.
     */
    private suspend fun loadWithRetry(
        url: String,
        seriesId: String
    ): SeriesEpisodesResult? {
        var last: SeriesEpisodesResult? = null
        val recoveryStarted = monotonicNanos()
        var slowFailures = 0
        for (attempt in 1..MAX_ATTEMPTS) {
            val startedNs = monotonicNanos()
            var emptyResponse = false
            try {
                val response = httpClient.get(url)
                val parsed = withContext(Dispatchers.Default) {
                    parseResponse(seriesId, response)
                }
                if (parsed != null && parsed.episodes.isNotEmpty()) return parsed
                last = parsed ?: last
                emptyResponse = parsed != null
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                if (!isTransient(error)) throw error
                if ((monotonicNanos() - startedNs) / 1_000_000L >= SLOW_FAILURE_MS) slowFailures++
                if (!canRetry(attempt, recoveryStarted, slowFailures)) throw error
                delay(RETRY_DELAYS_MS[attempt - 1])
                continue
            }
            if ((monotonicNanos() - startedNs) / 1_000_000L >= SLOW_FAILURE_MS) slowFailures++
            if (emptyResponse && attempt >= EMPTY_RESPONSE_ATTEMPTS) break
            if (!canRetry(attempt, recoveryStarted, slowFailures)) break
            delay(RETRY_DELAYS_MS[attempt - 1])
        }
        return last
    }

    private fun canRetry(attempt: Int, recoveryStarted: Long, slowFailures: Int): Boolean =
        attempt < MAX_ATTEMPTS && slowFailures < MAX_SLOW_FAILURES &&
            (monotonicNanos() - recoveryStarted) / 1_000_000L + RETRY_DELAYS_MS[attempt - 1] < RETRY_START_BUDGET_MS

    private fun isTransient(error: Exception): Boolean {
        if (error is IOException) return true
        if (error is IllegalStateException) {
            val status = Regex("Erro HTTP (\\d{3})")
                .find(error.message.orEmpty())
                ?.groupValues?.get(1)?.toIntOrNull()
            return status != null && (status == 408 || status == 429 || status in 500..599)
        }
        return false
    }

    private companion object {
        const val MAX_ATTEMPTS = 4
        const val EMPTY_RESPONSE_ATTEMPTS = 3
        const val SLOW_FAILURE_MS = 10_000L
        const val MAX_SLOW_FAILURES = 2
        const val RETRY_START_BUDGET_MS = 45_000L
        val RETRY_DELAYS_MS = longArrayOf(400L, 1_200L, 3_000L)
    }

    private fun parseResponse(
        seriesId: String,
        response: String
    ): SeriesEpisodesResult? {
        val root = runCatching {
            JSONObject(response)
        }.getOrNull() ?: return null

        val info = root.optJSONObject("info")
        val entries = ArrayList<SeriesEpisodeInfo>()
        val episodesNode = root.opt("episodes")

        fun addEpisodes(
            array: JSONArray,
            groupSeason: Int?
        ) {
            for (index in 0 until array.length()) {
                val item = array.optJSONObject(index) ?: continue

                val episodeId =
                    item.stringValue("id", "episode_id") ?: continue

                val seasonNumber =
                    item.intValue(
                        "season",
                        "season_num",
                        "season_number"
                    ) ?: groupSeason ?: 1

                if (seasonNumber < 0) continue

                val episodeNumber =
                    item.intValue(
                        "episode_num",
                        "episode_number",
                        "number"
                    ) ?: (index + 1)

                if (episodeNumber <= 0) continue

                val itemInfo = item.optJSONObject("info")

                val rawTitle = item.stringValue(
                    "title",
                    "name",
                    "episode_name"
                )

                val name = rawTitle
                    ?.replace(Regex("^\\s*\\d+\\s*[-–.]\\s*"), "")
                    ?.trim()
                    ?.takeIf { it.isNotEmpty() }
                    ?: "Episódio ${episodeNumber.toString().padStart(2, '0')}"

                val duration =
                    itemInfo?.durationSeconds()
                        ?: item.durationSeconds()

                entries += SeriesEpisodeInfo(
                    id = episodeId,
                    seasonNumber = seasonNumber,
                    episodeNumber = episodeNumber,
                    title = name,
                    thumbnailUrl = itemInfo?.image(
                        "movie_image",
                        "cover_big",
                        "cover",
                        "still_path", "episode_image", "thumbnail", "thumbnail_url", "image", "stream_icon"
                    ) ?: item.image(
                        "movie_image",
                        "cover_big",
                        "cover", "still_path", "episode_image", "thumbnail", "thumbnail_url", "image", "stream_icon"
                    ),
                    synopsis = itemInfo?.stringValue(
                        "plot",
                        "overview",
                        "description"
                    ) ?: item.stringValue(
                        "plot",
                        "overview",
                        "description"
                    ),
                    durationSeconds = duration,
                    containerExtension =
                        item.stringValue("container_extension")
                )
            }
        }

        when (episodesNode) {
            is JSONObject -> {
                val keys = episodesNode.keys()

                while (keys.hasNext()) {
                    val seasonKey = keys.next()
                    val items =
                        episodesNode.optJSONArray(seasonKey) ?: continue

                    addEpisodes(
                        items,
                        seasonKey.toIntOrNull()
                    )
                }
            }

            is JSONArray -> {
                addEpisodes(episodesNode, null)
            }
        }

        val episodes = entries
            .distinctBy { it.seasonNumber to it.id }
            .sortedWith(
                compareBy<SeriesEpisodeInfo> { it.seasonNumber }
                    .thenBy { it.episodeNumber }
            )

        val seasonMetadata =
            LinkedHashMap<Int, Pair<String?, String?>>()

        val seasonArray =
            root.optJSONArray("seasons") ?: JSONArray()

        for (index in 0 until seasonArray.length()) {
            val season =
                seasonArray.optJSONObject(index) ?: continue

            val number =
                season.intValue("season_number", "number")
                    ?: continue

            if (number < 0) continue

            seasonMetadata[number] =
                season.stringValue("name") to season.image(
                    "cover_big",
                    "cover",
                    "poster_path"
                )
        }

        // Usa apenas temporadas existentes na resposta do provedor.
        val numbers = (
                episodes.map { it.seasonNumber }
                ).distinct().sorted()

        val counts =
            episodes.groupingBy { it.seasonNumber }.eachCount()

        val seasons = numbers.map { number ->
            val metadata = seasonMetadata[number]

            SeriesSeasonInfo(
                number = number,
                title = metadata?.first
                    ?: if (number == 0) {
                        "Especiais"
                    } else {
                        "Temporada $number"
                    },
                coverUrl = metadata?.second,
                episodeCount = counts[number] ?: 0
            )
        }

        return SeriesEpisodesResult(
            seriesId = seriesId,
            title = info?.stringValue("name", "title"),
            plot = info?.stringValue(
                "plot",
                "description",
                "overview"
            ),
            backdropUrl =
                info?.firstImage("backdrop_path")
                    ?: info?.image("backdrop"),
            posterUrl = info?.image(
                "cover_big",
                "cover",
                "stream_icon"
            ),
            trailerUrl = info?.stringValue(
                "youtube_trailer",
                "trailer",
                "trailer_url"
            ),
            seasons = seasons,
            episodes = episodes
        )
    }

    private fun encode(value: String): String =
        URLEncoder.encode(value, "UTF-8")

    private fun JSONObject.stringValue(
        vararg keys: String
    ): String? {
        for (key in keys) {
            val value = optString(key).trim()

            if (
                value.isNotEmpty() &&
                !value.equals("null", ignoreCase = true)
            ) {
                return value
            }
        }
        return null
    }

    private fun JSONObject.intValue(
        vararg keys: String
    ): Int? =
        keys.firstNotNullOfOrNull { key ->
            stringValue(key)?.toIntOrNull()
        }

    private fun JSONObject.image(
        vararg keys: String
    ): String? =
        keys.asSequence().mapNotNull { stringValue(it) }.firstOrNull {
            it.startsWith("https://", true) || it.startsWith("http://", true)
        }

    private fun JSONObject.firstImage(
        key: String
    ): String? {
        val array = optJSONArray(key)

        if (array != null) {
            for (index in 0 until array.length()) {
                val value = array.optString(index).trim()

                if (
                    value.startsWith("http://", true) ||
                    value.startsWith("https://", true)
                ) {
                    return value
                }
            }
        }

        return image(key)
    }

    private fun JSONObject.durationSeconds(): Int? {
        intValue(
            "duration_secs",
            "duration_seconds",
            "runtime_secs"
        )?.takeIf { it > 0 }?.let {
            return it
        }

        val value =
            stringValue("duration", "runtime") ?: return null

        val parts =
            value.split(':').mapNotNull(String::toIntOrNull)

        return when (parts.size) {
            3 -> (
                    parts[0] * 3600 +
                            parts[1] * 60 +
                            parts[2]
                    ).takeIf { it > 0 }

            2 -> (
                    parts[0] * 60 +
                            parts[1]
                    ).takeIf { it > 0 }

            else ->
                value.toIntOrNull()
                    ?.takeIf { it > 0 }
                    ?.times(60)
        }
    }
}
