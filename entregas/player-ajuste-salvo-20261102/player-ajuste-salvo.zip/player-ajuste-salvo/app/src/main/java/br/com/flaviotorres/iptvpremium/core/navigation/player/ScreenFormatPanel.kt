package br.com.flaviotorres.iptvpremium.core.player

import android.view.KeyEvent as AndroidKey
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.focus.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.key.*
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text

import kotlinx.coroutines.delay

private enum class FormatPage { MENU,ZOOM,MANUAL }
private enum class Triangle { UP,DOWN,LEFT,RIGHT }

/** No selection dismisses this panel: only Back or five seconds with no input. */
@Composable
internal fun ScreenFormatPanel(layout:PlaybackVideoLayout,onChange:(PlaybackVideoLayout)->Unit,
    onClose:()->Unit,modifier:Modifier=Modifier,initialFocus:FocusRequester?=null) {
    var page by remember { mutableStateOf(FormatPage.MENU) }
    var activity by remember { mutableIntStateOf(0) }
    var direction by remember { mutableStateOf(Triangle.UP) }
    val focus=initialFocus ?: remember { FocusRequester() }
    val menuFocus=remember(focus){listOf(focus)+List(3){FocusRequester()}}
    val close by rememberUpdatedState(onClose)
    val current by rememberUpdatedState(layout)
    val change by rememberUpdatedState(onChange)
    val accent=playerThemeAccent()
    fun touch(){activity++}
    fun adjust(arrow:Triangle) {
        touch();direction=arrow
        val m=current.manual
        val next=if(page==FormatPage.ZOOM) m.copy(zoom=ScreenAdjustmentPolicy.step(m.zoom,if(arrow==Triangle.UP)1 else -1))
        else when(arrow) {
            Triangle.UP->m.copy(heightScale=ScreenAdjustmentPolicy.step(m.heightScale,1))
            Triangle.DOWN->m.copy(heightScale=ScreenAdjustmentPolicy.step(m.heightScale,-1))
            Triangle.LEFT->m.copy(widthScale=ScreenAdjustmentPolicy.step(m.widthScale,-1))
            Triangle.RIGHT->m.copy(widthScale=ScreenAdjustmentPolicy.step(m.widthScale,1))
        }
        change(PlaybackVideoLayout(PlaybackAspectMode.MANUAL,next))
    }
    LaunchedEffect(activity) {delay(ScreenAdjustmentPolicy.IDLE_MS);close()}
    LaunchedEffect(page) { direction=Triangle.UP; withFrameNanos {}; focus.requestFocus() }
    BackHandler { close() }
    BoxWithConstraints(modifier.fillMaxSize()) {
    val manual=page!=FormatPage.MENU
    val placement=if(manual)Modifier.align(Alignment.Center).width(280.dp)
        else Modifier.align(Alignment.CenterEnd).fillMaxHeight().width((maxWidth*.32f).coerceIn(220.dp,320.dp))
    Column(placement
        .onPreviewKeyEvent { event ->
            val code=event.nativeKeyEvent.keyCode
            if(event.type==KeyEventType.KeyDown)touch()
            if(page==FormatPage.MENU)return@onPreviewKeyEvent false
            val arrow=when(code) {
                AndroidKey.KEYCODE_DPAD_UP->Triangle.UP
                AndroidKey.KEYCODE_DPAD_DOWN->Triangle.DOWN
                AndroidKey.KEYCODE_DPAD_LEFT->Triangle.LEFT
                AndroidKey.KEYCODE_DPAD_RIGHT->Triangle.RIGHT
                else->null
            }
            val ok=code in listOf(AndroidKey.KEYCODE_DPAD_CENTER,AndroidKey.KEYCODE_ENTER,AndroidKey.KEYCODE_NUMPAD_ENTER)
            if(arrow!=null) {
                if(event.type==KeyEventType.KeyDown && (page==FormatPage.MANUAL || arrow==Triangle.UP || arrow==Triangle.DOWN))adjust(arrow)
                true
            } else if(ok) {
                if(event.type==KeyEventType.KeyDown && event.nativeKeyEvent.repeatCount==0){page=FormatPage.MENU;touch()}
                true
            } else false
        }
        .then(if(page!=FormatPage.MENU)Modifier.focusRequester(focus).focusable()else Modifier)
        .then(if(manual)Modifier else Modifier.background(NeutralPlayerPalette.menu).verticalScroll(rememberScrollState()))
        
        .padding(if(manual)10.dp else 16.dp),
        horizontalAlignment=if(manual)Alignment.CenterHorizontally else Alignment.Start,
        verticalArrangement=Arrangement.spacedBy(if(manual)4.dp else 6.dp)) {
        run {
            Text(if(manual)if(page==FormatPage.ZOOM)"Zoom"else"Ajuste manual"else"Tela",color=if(manual)Color.White else NeutralPlayerPalette.text,fontSize=if(manual)24.sp else 15.sp,fontWeight=FontWeight.Bold)
        }
        if(page==FormatPage.MENU) {
            FormatOption("Normal","Proporção original",layout.mode==PlaybackAspectMode.NORMAL,menuFocus[0],menuFocus[0],menuFocus[1]) {
                touch();change(layout.copy(mode=PlaybackAspectMode.NORMAL))
            }
            FormatOption("Ajuste automático","Estica para preencher, sem zoom ou corte",layout.mode==PlaybackAspectMode.STRETCH,menuFocus[1],menuFocus[0],menuFocus[2]) {
                touch();change(PlaybackVideoLayout(mode=PlaybackAspectMode.STRETCH))
            }
            FormatOption("Zoom","Aumente ou diminua com ▲ e ▼",false,menuFocus[2],menuFocus[1],menuFocus[3]) {
                touch();change(layout.copy(mode=PlaybackAspectMode.MANUAL,manual=layout.manual.copy(offsetX=0f,offsetY=0f)));page=FormatPage.ZOOM
            }
            FormatOption("Ajuste manual","Ajuste largura e altura com as setas",layout.mode==PlaybackAspectMode.MANUAL,menuFocus[3],menuFocus[2],menuFocus[3]) {
                touch();change(layout.copy(mode=PlaybackAspectMode.MANUAL,manual=layout.manual.copy(offsetX=0f,offsetY=0f)));page=FormatPage.MANUAL
            }
        } else Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(4.dp)) {
            Column(horizontalAlignment=Alignment.CenterHorizontally,verticalArrangement=Arrangement.spacedBy(1.dp)) {
                TriangleButton(Triangle.UP,direction==Triangle.UP,accent){adjust(Triangle.UP)}
                if(page==FormatPage.ZOOM)Text("${(layout.manual.zoom*100).toInt()}%",color=Color.White,fontSize=24.sp,fontWeight=FontWeight.Bold,modifier=Modifier.padding(vertical=5.dp))
                if(page==FormatPage.MANUAL) Row(verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(1.dp)) {
                    TriangleButton(Triangle.LEFT,direction==Triangle.LEFT,accent){adjust(Triangle.LEFT)}
                    Box(Modifier.size(56.dp).focusProperties{canFocus=false}
                        .clickable(interactionSource=remember{MutableInteractionSource()},indication=null){touch();page=FormatPage.MENU},contentAlignment=Alignment.Center) {
                        Text("OK",color=Color.White,fontSize=20.sp,fontWeight=FontWeight.Bold)
                    }
                    TriangleButton(Triangle.RIGHT,direction==Triangle.RIGHT,accent){adjust(Triangle.RIGHT)}
                }
                TriangleButton(Triangle.DOWN,direction==Triangle.DOWN,accent){adjust(Triangle.DOWN)}
            }
            if(page==FormatPage.MANUAL)Text("L ${(layout.manual.widthScale*100).toInt()}% · A ${(layout.manual.heightScale*100).toInt()}%",color=Color.White,fontSize=21.sp,fontWeight=FontWeight.Bold)
        }
    }
    }
}

@Composable
private fun FormatOption(label:String,description:String,selected:Boolean,focus:FocusRequester?=null,above:FocusRequester?=null,below:FocusRequester?=null,onClick:()->Unit) {
    var focused by remember {mutableStateOf(false)}
    val accent=playerThemeAccent()
    Row(Modifier.fillMaxWidth().then(if(focus!=null)Modifier.focusRequester(focus)else Modifier)
        .onFocusChanged{focused=it.isFocused}
        .focusProperties{left=FocusRequester.Cancel;right=FocusRequester.Cancel;if(above!=null)up=if(above===focus)FocusRequester.Cancel else above;if(below!=null)down=if(below===focus)FocusRequester.Cancel else below}
        .semantics{this.selected=selected}
        .clickable(interactionSource=remember{MutableInteractionSource()},indication=null,onClick=onClick)
        .padding(vertical=12.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(9.dp)) {
        Spacer(Modifier.width(5.dp))
        PlayerMenuGlyphDrawing(PlayerMenuGlyph.SCREEN,if(focused)accent else NeutralPlayerPalette.icon,Modifier.size(19.dp),monochrome=true)
        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(3.dp)) {
            Text(label,color=if(focused)accent else NeutralPlayerPalette.text,fontSize=14.sp,fontWeight=FontWeight.Medium)
            if(selected)Text("Selecionado",color=NeutralPlayerPalette.secondary,fontSize=11.sp)
        }
        Spacer(Modifier.width(8.dp))
    }
}

@Composable
private fun TriangleButton(arrow:Triangle,active:Boolean,accent:Color,onClick:()->Unit) {
    val label=when(arrow){Triangle.UP->"Aumentar altura ou zoom";Triangle.DOWN->"Diminuir altura ou zoom";Triangle.LEFT->"Diminuir largura";Triangle.RIGHT->"Aumentar largura"}
    Box(Modifier.size(56.dp).focusProperties{canFocus=false}.semantics{contentDescription=label;role=Role.Button}
        .clickable(interactionSource=remember{MutableInteractionSource()},indication=null,onClick=onClick).padding(10.dp)) {
        val turn=when(arrow){Triangle.RIGHT->0f;Triangle.DOWN->90f;Triangle.LEFT->180f;Triangle.UP->-90f}
        NeutralPlayerGlyph(PlayerGlyph.PLAY,if(active)accent else Color.White,Modifier.fillMaxSize().rotate(turn))
    }
}
