package br.com.flaviotorres.iptvpremium.data.m3u

import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import br.com.flaviotorres.iptvpremium.data.parser.*
import br.com.flaviotorres.iptvpremium.data.repository.artworkTitle
import br.com.flaviotorres.iptvpremium.data.repository.seriesArtworkLookupTitle
import br.com.flaviotorres.iptvpremium.data.resolver.M3uXtreamResolver
import br.com.flaviotorres.iptvpremium.domain.model.*
import kotlinx.coroutines.*
import java.io.*
import java.net.URI
import java.net.URLEncoder

/** Optional provider metadata only: never switches the catalogue transport or stream URLs. */
internal object M3uProviderSeriesCovers {
    private const val FILE="series-covers.index"
    private data class Request(val id:String,val title:String,val year:Int?,val category:String?)
    private data class Cover(val url:String,val year:Int?,val category:String?)
    private fun name(s:String)=artworkTitle(seriesArtworkLookupTitle(s))
    private fun url(s:String)=s.length<=8192&&(s.startsWith("http://",true)||s.startsWith("https://",true))
    fun catalogueImage(s:String):Boolean {
        if(!url(s))return false
        val uri=runCatching{URI(s)}.getOrNull()?:return false
        if(!uri.host.equals("image.tmdb.org",true))return true
        val path=uri.path.orEmpty()
        if(path.startsWith("/t/p/w1280/"))return false
        val m=Regex("/w([0-9]+)_and_h([0-9]+)[^/]*/").find(path)?:return true
        return (m.groupValues[2].toLongOrNull()?:0)>(m.groupValues[1].toLongOrNull()?:Long.MAX_VALUE)
    }
    suspend fun prepare(http:PlaylistHttpClient,spool:File,playlist:String,generation:String,sourceUrl:String):Int {
        val api=M3uXtreamResolver.resolve(PlaylistSource.M3u(playlist,"",playlistUrl=sourceUrl))?:return 0
        val requests=mutableListOf<Request>();val categories=hashMapOf<String,String>()
        DataInputStream(BufferedInputStream(spool.inputStream(),256*1024)).use{input->
            check(input.readInt()==0x4D335331)
            while(true){
                currentCoroutineContext().ensureActive()
                val (kind,r)=M3uCatalogParser.read(input)?:break
                if(kind==0&&r[4]=="SERIES")categories[r[2]as String]=r[3]as String
                if(kind==3)requests+=Request(r[2]as String,r[3]as String,(r[7]as Long?)?.toInt(),categories[r[4]])
            }
        }
        if(requests.isEmpty())return 0
        val wanted=requests.map{ name(it.title) }.toHashSet()
        val selected=try {withTimeoutOrNull(12_000L){
            val parser=DefaultXtreamParser();val apiCategories=hashMapOf<String,String>()
            val candidates=hashMapOf<String,MutableSet<Cover>>()
            fun endpoint(action:String)=api.serverUrl.trimEnd('/')+"/player_api.php?username="+URLEncoder.encode(api.username,"UTF-8")+"&password="+URLEncoder.encode(api.password,"UTF-8")+"&action="+action
            http.withReader(endpoint("get_series_categories")){reader->
                XtreamArrayStream.read(reader,"get_series_categories"){chunk,_->
                    parser.parseCatalogBatch("get_series_categories",chunk).categories.forEach{apiCategories[it.id]=it.name}
                }
            }
            http.withReader(endpoint("get_series")){reader->
                XtreamDirectCatalogReader.read(reader,"get_series",parser){batch->
                    for(s in batch.series){
                        currentCoroutineContext().ensureActive()
                        val image=s.posterUrl?.takeIf(::url)?:continue
                        val key=name(s.name).takeIf{it.isNotBlank()&&it in wanted}?:continue
                        candidates.getOrPut(key){linkedSetOf()}.add(Cover(image,s.year,apiCategories[s.categoryId]))
                    }
                }
            }
            val imageOwners=hashMapOf<String,MutableSet<String>>()
            val imageYears=hashMapOf<String,MutableSet<Int>>()
            for((title,entries)in candidates)for(c in entries){
                imageOwners.getOrPut(c.url){hashSetOf()}.add(title)
                c.year?.let{imageYears.getOrPut(c.url){hashSetOf()}.add(it)}
            }
            buildMap<String,String>{
                for(r in requests){
                    currentCoroutineContext().ensureActive()
                    val matching=candidates[name(r.title)].orEmpty().filter{r.year==null||it.year==null||r.year==it.year}
                    val scoped=matching.filter{it.category!=null&&it.category==r.category}.ifEmpty{matching}
                    val years=scoped.mapNotNull{it.year}.distinct()
                    if(r.year==null&&years.size>1)continue
                    val image=scoped.map{it.url}.distinct().singleOrNull()?:continue
                    // API metadata must not reintroduce an image already shared by different works.
                    if(imageOwners[image]?.size!=1||(imageYears[image]?.size?:0)>1)continue
                    put(r.id,image)
                }
            }
        }}catch(cancelled:CancellationException){throw cancelled}
        catch(error:Exception){android.util.Log.w("M3uOfficialPerf","stage=series_covers status=ERROR error=${error.javaClass.simpleName}");null}
        if(selected.isNullOrEmpty())return 0
        currentCoroutineContext().ensureActive()
        val target=File(spool.parentFile,FILE);val temp=File(spool.parentFile,"$FILE.tmp")
        try{
            DataOutputStream(BufferedOutputStream(temp.outputStream())).use{out->
                out.writeInt(0x434F5631);out.writeUTF(playlist);out.writeUTF(generation);out.writeInt(selected.size)
                for((id,image)in selected){currentCoroutineContext().ensureActive();out.writeUTF(id);out.writeUTF(image)}
            }
            check(temp.renameTo(target)){"COVER_INDEX"}
        }finally{temp.delete()}
        return selected.size
    }
    fun read(spool:File,playlist:String,generation:String):Map<String,String> {
        val file=File(spool.parentFile,FILE);if(!file.exists())return emptyMap()
        return DataInputStream(BufferedInputStream(file.inputStream())).use{input->
            check(input.readInt()==0x434F5631&&input.readUTF()==playlist&&input.readUTF()==generation){"COVER_IDENTITY"}
            val count=input.readInt();check(count in 0..1_000_000)
            val result=buildMap{repeat(count){val id=input.readUTF();val image=input.readUTF();check(id.isNotBlank()&&url(image));put(id,image)}}
            check(input.read()==-1);result
        }
    }
}
