package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.m3u.*
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.*
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import br.com.flaviotorres.iptvpremium.data.sync.*
import br.com.flaviotorres.iptvpremium.domain.model.*
import br.com.flaviotorres.iptvpremium.domain.repository.PlaylistRepository
import kotlinx.coroutines.*
import org.json.*
import java.io.*
import java.nio.file.Files
private class Store:M3uTransportStore{val data=hashMapOf<String,String>();override suspend fun read(key:String)=data[key];override suspend fun write(key:String,value:String){data[key]=value}}
private class Http(val fail:Boolean,val sharedApi:Boolean=false):PlaylistHttpClient {
 val rows=JSONArray(File("/workspace/capas-series-m3u/related-private.json").readText());val groups=linkedMapOf<String,String>();val works=linkedMapOf<Pair<String,String>,Int>();var nativeReads=0;val actions=mutableListOf<String>()
 init{repeat(rows.length()){i->val r=rows.getJSONArray(i);val g=r.getString(1);groups.getOrPut(g){groups.size.toString()};works.getOrPut(g to r.getString(0).replace(Regex("\\s*S\\d+E\\d+\\b"),"").trim()){works.size+1}}}
 override suspend fun get(url:String):String=error("No whole-body get")
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit){nativeReads++;onLine("#EXTM3U");repeat(rows.length()){i->val r=rows.getJSONArray(i);onLine("#EXTINF:-1 group-title=\"${r.getString(1)}\" tvg-logo=\"${r.getString(2)}\",${r.getString(0)}");onLine("http://example.invalid/series/$i")}}
 override suspend fun <T> withReader(url:String,consume:suspend(Reader)->T):T {
  val action=url.substringAfter("action=").substringBefore('&');actions+=action;if(fail)throw IOException("unavailable")
  val array=JSONArray()
  when(action){
   "get_series_categories"->groups.forEach{(name,id)->array.put(JSONObject().put("category_id",id).put("category_name",name))}
   "get_series"->works.forEach{(key,id)->val aia=key.second.contains("Aia",true);array.put(JSONObject().put("series_id",id).put("category_id",groups[key.first]).put("name",key.second).put("year",if(aia)2017 else 2020).put("cover",if(sharedApi)"http://example.invalid/shared-root.jpg"else if(aia)"http://example.invalid/aia-official.jpg"else"http://example.invalid/fox-official.jpg"))}
   else->error("Unexpected full import or other lookup: $action")
  };return consume(StringReader(array.toString()))
 }
}
private const val URL="http://example.invalid/get.php?username=u&password=p&type=m3u_plus&output=mpegts"
fun main()=runBlocking {
 val root=Files.createTempDirectory("cached-native-covers").toFile()
 try{
  for(mode in listOf("ok","unavailable","shared-api")){
   val unavailable=mode=="unavailable";val sharedApi=mode=="shared-api"
   val dir=File(root,mode).also{it.mkdirs()}
   RealSqlDb(File(dir,"db").toPath()).use{d->
    d.c.createStatement().execute("INSERT INTO playlist_cache_generations VALUES('p','old','ACTIVE',0,0,1)")
    val h=Http(unavailable,sharedApi);val policy=M3uTransportPolicy(Store()){error("Do not renegotiate an existing native catalogue")};val source=PlaylistSource.M3u("p","Automatic",playlistUrl=URL,forceM3u=false);policy.rememberNative(source)
    val manager=PlaylistCacheGenerationManager(d.dao);val episodes=DeferredM3uEpisodes(File(dir,"episodes"));val bridge=NativeBridge(d.c)
    val importer=M3uCacheImporter(h,d.dao,manager,episodes,File(dir,"work"),{_,_,_->}){spool,p,g,c,ensure->
     d.c.autoCommit=false;try{M3uCatalogWriter.write(bridge.database,spool,p,g,c,ensure);d.c.commit()}catch(e:Throwable){d.c.rollback();throw e}finally{d.c.autoCommit=true}
    }
    val repo=object:PlaylistRepository{override suspend fun loadContent(source:PlaylistSource):PlaylistContent=error("No full Xtream import expected")}
    val g=M3uSourceSynchronizer(repo,importer,d.dao,manager,policy).sync(source)
    check(h.nativeReads==1&&h.actions.isNotEmpty()&&policy.actualTransport(source)=="m3u")
    val found=d.c.createStatement().executeQuery("SELECT name,posterUrl FROM cached_series WHERE generationId='$g'").use{r->buildList{while(r.next())add(r.getString(1) to r.getString(2))}}
    check(found.size==3&&episodes.sourceCounts("p",g)==(3 to 161L)&&d.count("cached_episodes",g)==0)
    if(sharedApi){check(found.all{it.second==null});println("PASS API cover reused by distinct works cannot reintroduce a wrong image into the M3U catalogue")}
    else if(unavailable){check(found.all{it.second==null});println("PASS unavailable cover API rejects the logo shared by O Conto da Aia and Raposa instead of publishing wrong native series covers")}
    else{check(h.actions==listOf("get_series_categories","get_series"));check(found.all{it.second==if(it.first.contains("Aia",true))"http://example.invalid/aia-official.jpg"else"http://example.invalid/fox-official.jpg"});println("PASS existing automatic native M3U (forceM3u=false) fetches correct provider covers through the actual synchronizer, using all 161 real fixture records")}
    check(d.dao.generationStatus("p","old")=="ACTIVE"&&d.dao.generationStatus("p",g)=="READY");check(File(dir,"work").listFiles().orEmpty().isEmpty())
   }
  }
  println("PASS cover refresh preserves native transport, active generation, deferred episodes and staging cleanup")
 }finally{root.deleteRecursively()}
 Unit
}
