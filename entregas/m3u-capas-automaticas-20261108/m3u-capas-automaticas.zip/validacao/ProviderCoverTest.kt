package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.m3u.*
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.*
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import kotlinx.coroutines.*
import java.io.*
import java.nio.file.Files
private class Http:PlaylistHttpClient {
 var reads=0;var api=0;var unavailable=false;var year=2017;var ambiguous=false;var hold=false
 val entered=CompletableDeferred<Unit>()
 override suspend fun get(url:String):String=error("No whole-body get")
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit){reads++;listOf("#EXTM3U", """#EXTINF:-1 group-title="Source" tvg-logo="https://image.tmdb.org/t/p/w1280/ep1.jpg",O Conto Da Aia 2017 (2017) S01E01""","http://example.invalid/series/ep1", """#EXTINF:-1 group-title="Source" tvg-logo="https://image.tmdb.org/t/p/w1280/ep2.jpg",O Conto Da Aia 2017 (2017) S01E02""","http://example.invalid/series/ep2").forEach{onLine(it)}}
 override suspend fun <T> withReader(url:String,consume:suspend(Reader)->T):T {
  api++;entered.complete(Unit);if(hold)awaitCancellation();if(unavailable)throw IOException("API unavailable")
  val action=url.substringAfter("action=")
  val body=when(action){
   "get_series_categories"->"""[{"category_id":"source","category_name":"Source"},{"category_id":"other","category_name":"Other"}]"""
   "get_series"->"""[{"series_id":1,"category_id":"source","name":"O Conto da Aia","year":$year,"cover":"http://example.invalid/official.jpg"},{"series_id":2,"category_id":"other","name":"O Conto da Aia","year":$year,"cover":"http://example.invalid/other-edition.jpg"} ${if(ambiguous)",{\"series_id\":3,\"category_id\":\"source\",\"name\":\"O Conto da Aia\",\"year\":$year,\"cover\":\"http://example.invalid/ambiguous.jpg\"}"else""}]"""
   else->error("Unexpected metadata endpoint")
  };return consume(StringReader(body))
 }
}
private const val LIST="http://example.invalid/get.php?username=u&password=p&type=m3u_plus&output=mpegts"
fun main()=runBlocking {
 val root=Files.createTempDirectory("provider-cover").toFile()
 fun pass(s:String)=println("PASS $s")
 try{
  suspend fun runCase(label:String,http:Http,enabled:Boolean=true,expected:String?){
   val dir=File(root,label).also{it.mkdirs()}
   RealSqlDb(File(dir,"db").toPath()).use{d->
    val store=DeferredM3uEpisodes(File(dir,"episodes"));val bridge=NativeBridge(d.c)
    val g=M3uCacheImporter(http,d.dao,PlaylistCacheGenerationManager(d.dao),store,File(dir,"work"),{_,_,_->}){spool,p,g,c,ensure->
     if(label=="ok")check(runCatching{M3uProviderSeriesCovers.read(spool,"other",g)}.isFailure)
     d.c.autoCommit=false
     try{M3uCatalogWriter.write(bridge.database,spool,p,g,c,ensure);d.c.commit()}catch(e:Throwable){d.c.rollback();throw e}finally{d.c.autoCommit=true}
    }.import("p",LIST,apiCovers=enabled)
    val row=d.c.createStatement().executeQuery("SELECT name,posterUrl FROM cached_series").use{check(it.next());it.getString(1) to it.getString(2)}
    check(row.first=="O Conto Da Aia 2017 (2017)"&&row.second==expected){"$label $row"}
    check(http.reads==1&&d.count("cached_episodes")==0&&store.sourceCounts("p",g)==(1 to 2L))
    check(File(dir,"work").listFiles().orEmpty().isEmpty())
   }
  }
  val ok=Http();runCase("ok",ok,expected="http://example.invalid/official.jpg");check(ok.api==2);pass("native M3U uses the provider's Xtream series cover with exact category/name/year matching, preserving titles and deferred episodes")
  val missing=Http().also{it.unavailable=true};runCase("unavailable",missing,expected=null);pass("unavailable metadata API does not break native M3U import or publish an episode still as series cover")
  runCase("year",Http().also{it.year=2020},expected=null);pass("provider cover from a conflicting release year is not assigned to the M3U work")
  runCase("ambiguous",Http().also{it.ambiguous=true},expected=null);pass("multiple conflicting covers within the matching provider category remain unresolved")
  val disabled=Http();runCase("disabled",disabled,enabled=false,expected=null);check(disabled.api==0);pass("automatic native fallback skips metadata API after negotiation already determined it unavailable")
  val dir=File(root,"cancel").also{it.mkdirs()};RealSqlDb(File(dir,"db").toPath()).use{d->
   val h=Http().also{it.hold=true};val store=DeferredM3uEpisodes(File(dir,"episodes"));val m=PlaylistCacheGenerationManager(d.dao)
   val job=launch{M3uCacheImporter(h,d.dao,m,store,File(dir,"work"),{_,_,_->}){_,_,_,_,_->error("Must not publish")}.import("p",LIST)}
   h.entered.await();job.cancelAndJoin();check(d.count("cached_series")==0&&d.count("playlist_cache_generations")==0&&File(dir,"work").listFiles().orEmpty().isEmpty())
   pass("cancelling provider metadata lookup prevents READY publication and cleans staging")
  }
 }finally{root.deleteRecursively()}
 Unit
}
