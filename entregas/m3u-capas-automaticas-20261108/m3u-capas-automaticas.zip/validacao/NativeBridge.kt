package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import androidx.sqlite.db.*
import androidx.room.RoomOpenDelegate
import android.database.Cursor
import java.io.*
import java.nio.file.*
import java.lang.reflect.Proxy
import java.sql.*
import kotlinx.coroutines.*

internal class NativeBridge(val connection:Connection){
 var success=false;var transactions=0
 val database=Proxy.newProxyInstance(SupportSQLiteDatabase::class.java.classLoader,arrayOf(SupportSQLiteDatabase::class.java)){_,m,a0->
  val a=a0.orEmpty()
  when(m.name){
   "beginTransactionNonExclusive"->{check(connection.autoCommit);connection.autoCommit=false;success=false;transactions++;null}
   "setTransactionSuccessful"->{success=true;null}
   "endTransaction"->{if(success)connection.commit()else connection.rollback();connection.autoCommit=true;null}
   "execSQL"->{connection.prepareStatement(a[0]as String).use{s->if(a.size>1)(a[1]as Array<*>).forEachIndexed{i,v->s.setObject(i+1,v)};s.execute()};null}
   "compileStatement"->{val s=connection.prepareStatement(a[0]as String)
    Proxy.newProxyInstance(SupportSQLiteStatement::class.java.classLoader,arrayOf(SupportSQLiteStatement::class.java)){_,method,args0->val args=args0.orEmpty();when(method.name){
     "bindString"->{s.setString(args[0]as Int,args[1]as String);null}
     "bindLong"->{s.setLong(args[0]as Int,args[1]as Long);null}
     "bindNull"->{s.setNull(args[0]as Int,Types.NULL);null}
     "executeInsert"->{s.executeUpdate();1L}
     "close"->{s.close();null}
     else->error("statement ${method.name}")
    }}as SupportSQLiteStatement}
   "query"->{val s=connection.prepareStatement(a[0]as String);if(a.size>1)(a[1]as Array<*>).forEachIndexed{i,v->s.setObject(i+1,v)};val r=s.executeQuery()
    Proxy.newProxyInstance(Cursor::class.java.classLoader,arrayOf(Cursor::class.java)){_,method,args->when(method.name){
     "moveToFirst","moveToNext"->r.next()
     "getString"->r.getString((args!![0]as Int)+1)
     "getLong"->r.getLong((args!![0]as Int)+1)
     "getInt"->r.getInt((args!![0]as Int)+1)
     "close"->{r.close();s.close();null}
     else->error("cursor ${method.name}")
    }}as Cursor}
   else->error("database ${m.name}")
  }
 } as SupportSQLiteDatabase
}