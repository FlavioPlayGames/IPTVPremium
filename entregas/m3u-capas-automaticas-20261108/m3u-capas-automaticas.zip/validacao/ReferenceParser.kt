package br.com.flaviotorres.iptvpremium.data.cache

import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uEntryClassifier
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uEntryMetadata
import java.io.*
import java.util.UUID

/** Catalog semantics only: no Room calls, coroutine writer, or legacy importer is executed. */
internal object ReferenceParser {
    data class Counts(val channels:Long,val movies:Long,val episodes:Long,val series:Int,val categories:Int) {
        val entries:Long get()=channels+movies+episodes
    }
    private class Series(val id:String,val name:String,val category:String,var poster:String?,val year:Int?,val order:Int)
    private val compact=Regex("""(?i)\bS(\d{1,3})\s*E(\d{1,6})\b""")
    private val verbose=Regex("""(?i)\b(?:temporada|season)\s*(\d{1,3}).*?\b(?:epis[oó]dio|episode|ep)\s*(\d{1,6})\b""")
    private val trailing=Regex("""[\s._\-–—|]+$""")
    private val year=Regex("""\b(19|20)\d{2}\b""")
    private fun id(value:String)=UUID.nameUUIDFromBytes(value.toByteArray(Charsets.UTF_8)).toString()

    fun prepare(reader:BufferedReader,output:DataOutputStream,playlist:String,generation:String,
                ensure:()->Unit={},episodeSource:br.com.flaviotorres.iptvpremium.data.m3uepisodes.M3uEpisodeSource.Builder?=null,progress:(Long)->Unit={}):Counts {
        val categories=LinkedHashMap<String,Array<Any?>>()
        val categoryIds=HashMap<String,String>()
        val series=LinkedHashMap<String,Series>()
        var lastGroup:String?=null;var lastName:String?=null;var lastSeries:Series?=null
        var pending:String?=null;var ext=false;var channels=0L;var movies=0L;var episodes=0L
        output.writeInt(0x4D335331)
        while(true){
            ensure()
            val raw=reader.readLine()?:break
            val line=raw.removePrefix("\uFEFF").trim()
            if(line.startsWith("#EXTINF",true)){pending=line;ext=true;continue}
            if(line.isBlank()||line.startsWith('#'))continue
            val header=pending?:continue;pending=null
            val name=header.substringAfterLast(',',"").trim().ifBlank{"Conteúdo"}
            val m=M3uEntryMetadata.parse(header)
            val group=m.group?.trim()?.takeIf{it.isNotBlank()}?:"Sem categoria"
            val poster=m.logo?.trim()?.takeIf{it.isNotBlank()}
            val tvg=m.tvgId?.trim()?.takeIf{it.isNotBlank()}
            val kind=M3uEntryClassifier.classify(line,group,name,m.hasXuiId,m.tvgId!=null)
            val type=when(kind){M3uEntryClassifier.Kind.LIVE_TV->"LIVE_TV";M3uEntryClassifier.Kind.MOVIE->"MOVIES";else->"SERIES"}
            val key="$type:$group"
            val category=categoryIds.getOrPut(key){id("category:$type:$group").also{c->categories[key]=arrayOf(playlist,generation,c,group,type,"M3U")}}
            when(kind){
                M3uEntryClassifier.Kind.LIVE_TV->{channels++;check(channels<=Int.MAX_VALUE)
                    record(output,1,arrayOf(playlist,generation,id("channel:$line:$name:${tvg.orEmpty()}"),name,category,poster,line,tvg,channels))}
                M3uEntryClassifier.Kind.MOVIE->{movies++
                    record(output,2,arrayOf(playlist,generation,id("movie:$line:$name"),name,category,poster,null,line,year.find(name)?.value?.toLongOrNull(),null,null,null,(movies-1).coerceAtMost(Int.MAX_VALUE.toLong())))}
                M3uEntryClassifier.Kind.SERIES->{
                    episodes++
                    val c=compact.find(name);val v=if(c==null)verbose.find(name)else null;val match=c?:v
                    val sn=(if(c!=null)name.removeRange(c.range)else if(v!=null)name.substring(0,v.range.first)else name).replace(trailing,"").trim().ifBlank{name}
                    val slot=if(lastGroup==group&&lastName==sn)checkNotNull(lastSeries)else{
                        val sid=id("series:$group:$sn")
                        series.getOrPut(sid){Series(sid,sn,category,poster,year.find(sn)?.value?.toIntOrNull(),series.size)}.also{lastGroup=group;lastName=sn;lastSeries=it}
                    }
                    slot.poster=poster // Last occurrence wins, including an explicitly missing poster.
                    val season=match?.groupValues?.getOrNull(1)?.toIntOrNull()
                    val episode=match?.groupValues?.getOrNull(2)?.toIntOrNull()
                    if(episodeSource!=null)episodeSource.append(slot.id,season,episode,name,poster,line)
                    else record(output,4,arrayOf(playlist,generation,id("episode:$line:$name"),slot.id,season?.toLong(),episode?.toLong(),name,line,poster,null))
                }
            }
            val total=channels+movies+episodes
            if(total%5000L==0L)progress(total)
        }
        require(ext&&channels+movies+episodes>0){"INVALID_M3U"}
        categories.values.forEach{ensure();record(output,0,it)}
        series.values.forEach{s->ensure();record(output,3,arrayOf(playlist,generation,s.id,s.name,s.category,s.poster,null,s.year?.toLong(),null,null,null,null,null,null,null,null,null,s.order.toLong()))}
        output.writeByte(-1);output.flush()
        return Counts(channels,movies,episodes,series.size,categories.size)
    }
    private fun record(out:DataOutputStream,kind:Int,values:Array<Any?>){
        check(values.size==ReferenceSchema.columns[kind]);out.writeByte(kind)
        for(v in values)when(v){
            null->out.writeByte(0)
            is String->{out.writeByte(1);val bytes=v.toByteArray(Charsets.UTF_8);out.writeInt(bytes.size);out.write(bytes)}
            is Number->{out.writeByte(2);out.writeLong(v.toLong())}
            else->error("INVALID_FIELD")
        }
    }
    fun read(input:DataInputStream):Pair<Int,Array<Any?>>? {
        val kind=input.readByte().toInt()
        if(kind == -1){check(input.read()==-1){"TRAILING_DATA"};return null}
        require(kind in 0..4){"INVALID_RECORD"}
        val row=arrayOfNulls<Any>(ReferenceSchema.columns[kind])
        for(i in row.indices)row[i]=when(input.readByte().toInt()){
            0->null
            1->{val size=input.readInt();require(size>=0&&size<=64*1024*1024){"INVALID_FIELD_LENGTH"};ByteArray(size).also{input.readFully(it)}.toString(Charsets.UTF_8)}
            2->input.readLong()
            else->error("INVALID_FIELD")
        }
        return kind to row
    }
}
