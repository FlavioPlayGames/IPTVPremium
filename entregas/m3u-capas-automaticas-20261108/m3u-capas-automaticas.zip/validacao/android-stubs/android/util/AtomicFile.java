package android.util;
import java.io.*;
import java.nio.file.*;
/** JVM test double for the Android AtomicFile contract; not a power-loss test of Android. */
public class AtomicFile {
 private final File base,next,backup;
 public AtomicFile(File f){base=f;next=new File(f+".new");backup=new File(f+".bak");}
 public FileInputStream openRead() throws IOException {if(backup.exists())Files.move(backup.toPath(),base.toPath(),StandardCopyOption.REPLACE_EXISTING);return new FileInputStream(base);}
 public FileOutputStream startWrite() throws IOException {if(base.exists())Files.copy(base.toPath(),backup.toPath(),StandardCopyOption.REPLACE_EXISTING);return new FileOutputStream(next);}
 public void finishWrite(FileOutputStream s) throws IOException {if(Boolean.getBoolean("atomicfile.fail"))throw new IOException("marker failure");s.flush();s.getFD().sync();s.close();Files.move(next.toPath(),base.toPath(),StandardCopyOption.REPLACE_EXISTING,StandardCopyOption.ATOMIC_MOVE);backup.delete();}
 public void failWrite(FileOutputStream s) {try{s.close();next.delete();if(backup.exists())Files.move(backup.toPath(),base.toPath(),StandardCopyOption.REPLACE_EXISTING);}catch(IOException e){throw new RuntimeException(e);}}
}
