package br.com.flaviotorres.iptvpremium.data.cache

/** Exact version-5 schema, verified against Room generated schema in tests. */
internal object ReferenceSchema {
    val tables = listOf(
        "CREATE TABLE IF NOT EXISTS `playlist_cache_generations` (`playlistId` TEXT NOT NULL, `generationId` TEXT NOT NULL, `status` TEXT NOT NULL, `createdAtEpochMillis` INTEGER NOT NULL, `completedAtEpochMillis` INTEGER, `activatedAtEpochMillis` INTEGER, PRIMARY KEY(`playlistId`, `generationId`))",
        "CREATE TABLE IF NOT EXISTS `cached_categories` (`playlistId` TEXT NOT NULL, `generationId` TEXT NOT NULL, `categoryId` TEXT NOT NULL, `name` TEXT NOT NULL, `type` TEXT NOT NULL, `source` TEXT NOT NULL, PRIMARY KEY(`playlistId`, `generationId`, `categoryId`, `type`))",
        "CREATE TABLE IF NOT EXISTS `cached_channels` (`playlistId` TEXT NOT NULL, `generationId` TEXT NOT NULL, `channelId` TEXT NOT NULL, `name` TEXT NOT NULL, `categoryId` TEXT, `logoUrl` TEXT, `streamUrl` TEXT NOT NULL, `epgChannelId` TEXT, `channelNumber` INTEGER NOT NULL, PRIMARY KEY(`playlistId`, `generationId`, `channelId`))",
        "CREATE TABLE IF NOT EXISTS `cached_movies` (`playlistId` TEXT NOT NULL, `generationId` TEXT NOT NULL, `movieId` TEXT NOT NULL, `name` TEXT NOT NULL, `categoryId` TEXT, `posterUrl` TEXT, `backdropUrl` TEXT, `streamUrl` TEXT NOT NULL, `year` INTEGER, `rating` REAL, `durationSeconds` INTEGER, `addedAtEpochSeconds` INTEGER, `providerOrder` INTEGER, PRIMARY KEY(`playlistId`, `generationId`, `movieId`))",
        "CREATE TABLE IF NOT EXISTS `cached_series` (`playlistId` TEXT NOT NULL, `generationId` TEXT NOT NULL, `seriesId` TEXT NOT NULL, `name` TEXT NOT NULL, `categoryId` TEXT, `posterUrl` TEXT, `backdropUrl` TEXT, `year` INTEGER, `rating` REAL, `plot` TEXT, `titleLogoUrl` TEXT, `imdbId` TEXT, `tmdbId` TEXT, `ratingSource` TEXT, `durationSeconds` INTEGER, `genres` TEXT, `trailerUrl` TEXT, `providerOrder` INTEGER, PRIMARY KEY(`playlistId`, `generationId`, `seriesId`))",
        "CREATE TABLE IF NOT EXISTS `cached_episodes` (`playlistId` TEXT NOT NULL, `generationId` TEXT NOT NULL, `episodeId` TEXT NOT NULL, `seriesId` TEXT NOT NULL, `seasonNumber` INTEGER, `episodeNumber` INTEGER, `name` TEXT NOT NULL, `streamUrl` TEXT NOT NULL, `posterUrl` TEXT, `durationSeconds` INTEGER, PRIMARY KEY(`playlistId`, `generationId`, `episodeId`))"
    )
    val indexes = listOf(
        "CREATE INDEX IF NOT EXISTS `index_playlist_cache_generations_playlistId_status` ON `playlist_cache_generations` (`playlistId`, `status`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_categories_playlistId_generationId_type` ON `cached_categories` (`playlistId`, `generationId`, `type`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_categories_playlistId_generationId_categoryId` ON `cached_categories` (`playlistId`, `generationId`, `categoryId`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_channels_playlistId_generationId_categoryId` ON `cached_channels` (`playlistId`, `generationId`, `categoryId`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_channels_playlistId_generationId_name` ON `cached_channels` (`playlistId`, `generationId`, `name`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_movies_playlistId_generationId_categoryId` ON `cached_movies` (`playlistId`, `generationId`, `categoryId`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_movies_playlistId_generationId_name` ON `cached_movies` (`playlistId`, `generationId`, `name`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_movies_playlistId_generationId_addedAtEpochSeconds` ON `cached_movies` (`playlistId`, `generationId`, `addedAtEpochSeconds`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_movies_playlistId_generationId_providerOrder` ON `cached_movies` (`playlistId`, `generationId`, `providerOrder`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_series_playlistId_generationId_categoryId` ON `cached_series` (`playlistId`, `generationId`, `categoryId`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_series_playlistId_generationId_name` ON `cached_series` (`playlistId`, `generationId`, `name`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_series_playlistId_generationId_providerOrder` ON `cached_series` (`playlistId`, `generationId`, `providerOrder`)",
        "CREATE INDEX IF NOT EXISTS `index_cached_episodes_playlistId_generationId_seriesId_seasonNumber` ON `cached_episodes` (`playlistId`, `generationId`, `seriesId`, `seasonNumber`)"
    )
    val inserts = listOf(
        "INSERT OR REPLACE INTO cached_categories VALUES (?,?,?,?,?,?)",
        "INSERT OR REPLACE INTO cached_channels VALUES (?,?,?,?,?,?,?,?,?)",
        "INSERT OR REPLACE INTO cached_movies VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        "INSERT OR REPLACE INTO cached_series VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        "INSERT OR REPLACE INTO cached_episodes VALUES (?,?,?,?,?,?,?,?,?,?)"
    )
    val names = listOf("cached_categories", "cached_channels", "cached_movies", "cached_series", "cached_episodes")
    val columns = intArrayOf(6,9,13,18,10)
}
