package br.com.flaviotorres.iptvpremium.data.repository

import androidx.compose.foundation.gestures.scrollBy
import kotlinx.coroutines.runBlocking
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.*
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.unit.dp
import br.com.flaviotorres.iptvpremium.ui.components.*
import java.util.concurrent.atomic.AtomicInteger
import org.junit.Assert.*
import org.junit.Rule
import org.junit.Test

@OptIn(ExperimentalTestApi::class, androidx.compose.foundation.ExperimentalFoundationApi::class)
class CatalogSmoothScrollDeviceTest {
    @get:Rule val compose = createComposeRule()
    private lateinit var navigation: CatalogGridNavigator
    private lateinit var grid: LazyGridState
    private val focused = AtomicInteger(-1)
    private fun setup(columns: Int, realFrame: Boolean = false) {
        compose.setContent {
            grid = rememberLazyGridState()
            val scope = rememberCoroutineScope()
            val navigator = remember { CatalogGridNavigator(grid, scope, columns, { 200 }, {}, {}) }
            SideEffect { navigation = navigator }
            DisposableEffect(navigator) { onDispose { navigator.cancel() } }
            val content: @Composable () -> Unit = { LazyVerticalGrid(GridCells.Fixed(columns), Modifier.width(600.dp).height(if (realFrame) 343.dp else 226.dp)
                .catalogGridHost(navigator).testTag("smooth-grid"), grid,
                contentPadding = PaddingValues(8.dp), verticalArrangement = Arrangement.spacedBy(if (realFrame) LocalCatalogRowSpacing.current else 10.dp)) {
                items(200, key = { it }) { index ->
                    val requester = remember { FocusRequester() }
                    BindCatalogFocus(navigator, index, requester)
                    LaunchedEffect(index) {
                        if (index == 2 && focused.get() < 0) { withFrameNanos {}; requester.requestFocus() }
                    }
                    Box(Modifier.height(if (realFrame) LocalCatalogCardHeight.current else 100.dp).testTag("smooth-$index").focusRequester(requester)
                        .catalogGridNavigation(navigator, index, requester)
                        .onFocusChanged { if (it.isFocused) { focused.set(index); navigator.focused(index) } }
                        .focusable())
                }
            }
            }
            if (realFrame) Box(Modifier.width(600.dp).height(343.dp)) {
                CatalogTwoRowFrame(true, columns) { content() }
            } else CompositionLocalProvider(
                androidx.compose.foundation.gestures.LocalBringIntoViewSpec provides CatalogRowBringIntoViewSpec
            ) { content() }

        }
        compose.waitUntil(5_000) { focused.get() == 2 }
    }
    private fun position(columns: Int): Float = compose.runOnIdle {
        val item = grid.layoutInfo.visibleItemsInfo.first()
        val step = item.size.height + grid.layoutInfo.mainAxisItemSpacing
        (grid.firstVisibleItemIndex / columns * step + grid.firstVisibleItemScrollOffset).toFloat()
    }
    private fun assertTwoRows(columns: Int) = compose.runOnIdle {
        val layout = grid.layoutInfo
        val full = layout.visibleItemsInfo.count {
            it.offset.y >= layout.viewportStartOffset && it.offset.y + it.size.height <= layout.viewportEndOffset
        }
        assertEquals(columns * 2, full)
        assertEquals(0, grid.firstVisibleItemScrollOffset)
    }
    private fun rowSlides(columns: Int, realFrame: Boolean = false) {
        setup(columns, realFrame)
        assertTwoRows(columns)
        compose.mainClock.autoAdvance = false
        compose.onNodeWithTag("smooth-2").performKeyInput { pressKey(Key.DirectionDown); pressKey(Key.DirectionDown) }
        compose.mainClock.advanceTimeBy(64)
        val step = compose.runOnIdle { grid.layoutInfo.visibleItemsInfo.first().size.height + grid.layoutInfo.mainAxisItemSpacing }
        val middle = position(columns)
        assertTrue("An intermediate frame must move without jumping the whole row: $middle", middle > 0f && middle < step)
        compose.runOnIdle { assertTrue("The destination must remain highlighted while sliding",
            navigation.isMovingSelection(2 + columns * 2)) }
        compose.mainClock.advanceTimeBy(700)
        compose.onNodeWithTag("smooth-${2 + columns * 2}").assertIsFocused()
        assertEquals(columns, compose.runOnIdle { grid.firstVisibleItemIndex })
        assertTwoRows(columns)
    }
    private fun repeatAndReverse(columns: Int) {
        setup(columns)
        compose.mainClock.autoAdvance = false
        compose.onNodeWithTag("smooth-2").performKeyInput { repeat(12) { pressKey(Key.DirectionDown) } }
        compose.mainClock.advanceTimeBy(64)
        val before = position(columns)
        assertTrue(before > 0f)
        compose.onNodeWithTag("smooth-grid").performKeyInput { repeat(12) { pressKey(Key.DirectionUp) } }
        compose.mainClock.advanceTimeBy(16)
        assertTrue("Retargeting must not snap to the first row", position(columns) > 0f)
        compose.mainClock.advanceTimeBy(900)
        compose.onNodeWithTag("smooth-2").assertIsFocused()
        assertEquals(0f, position(columns), 1f)
        assertTwoRows(columns)
    }
    private fun wheelSettles(columns: Int, realFrame: Boolean = false) {
        setup(columns, realFrame)
        compose.mainClock.autoAdvance = false
        val stepPx = compose.runOnIdle {
            grid.layoutInfo.visibleItemsInfo.first().size.height + grid.layoutInfo.mainAxisItemSpacing
        }
        // scrollBy uses physical pixels, while the fixture dimensions use dp.
        val wheelDistancePx = stepPx * 0.6f
        compose.runOnIdle { runBlocking { grid.scrollBy(wheelDistancePx) } }
        assertEquals(wheelDistancePx, position(columns), 1f)
        compose.mainClock.advanceTimeBy(1000)
        assertEquals("stepPx=$stepPx wheelPx=$wheelDistancePx", columns, compose.runOnIdle { grid.firstVisibleItemIndex })
        assertTwoRows(columns)
    }
    @Test fun wheelStopsOnEightWholeCards() = wheelSettles(4)
    @Test fun wheelStopsOnTenWholeCards() = wheelSettles(5)
    @Test fun actualFrameWheelStopsOnEightWholeCards() = wheelSettles(4, true)
    @Test fun actualFrameWheelStopsOnTenWholeCards() = wheelSettles(5, true)
    @Test fun actualFrameFourColumnsNeverStopsWithClippedSecondRow() = rowSlides(4, true)
    @Test fun actualFrameFiveColumnsNeverStopsWithClippedSecondRow() = rowSlides(5, true)
    @Test fun fourColumnsSlideAndSettleWithEightCards() = rowSlides(4)
    @Test fun fiveColumnsSlideAndSettleWithTenCards() = rowSlides(5)
    @Test fun fourColumnsRetargetRepeatedArrowsWithoutJumping() = repeatAndReverse(4)
    @Test fun fiveColumnsRetargetRepeatedArrowsWithoutJumping() = repeatAndReverse(5)
}
