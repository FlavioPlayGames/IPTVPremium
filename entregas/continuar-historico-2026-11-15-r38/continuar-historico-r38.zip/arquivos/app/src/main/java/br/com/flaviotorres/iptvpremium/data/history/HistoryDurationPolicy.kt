package br.com.flaviotorres.iptvpremium.data.history

/** Reject a provisional/foreign short duration without changing a real end-of-stream event. */
internal fun historyDurationMs(positionMs: Long, reported: Long?, metadata: Long?, previous: Long?, ended: Boolean = false): Long? {
    val known = previous?.takeIf { it > 0L } ?: metadata?.takeIf { it > 0L }
    fun usable(value: Long?): Long? = value?.takeIf { duration ->
        duration > 0L && (ended || duration > positionMs) &&
            (ended || known == null || duration.toDouble() >= known.toDouble() * 0.9)
    }
    return usable(reported) ?: usable(known) ?: usable(metadata)
}
