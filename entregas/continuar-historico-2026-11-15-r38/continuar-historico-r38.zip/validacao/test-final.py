from pathlib import Path
import subprocess, os
v=Path('/workspace/continuar-auditoria-r38'); t=Path('/workspace/iptv-tools'); c=Path('/workspace/iptv-visual-r32/app/build/intermediates/built_in_kotlinc/desempenho/compileDesempenhoKotlin/classes')
cp=os.pathsep.join(map(str,[Path('/workspace/iptv-visual-r32/validacao/r37/preferences-host'),c]+list(t.glob('*.jar'))+list(Path('/workspace/.gradle-cache/caches/9.6.0/transforms').glob('*/transformed/*-runtime.jar'))+[Path('/workspace/android-sdk/platforms/android-37.0/android.jar')]))
for cmd in [[str(t/'jdk25/bin/javac'),'-cp',cp,'-d',str(v),str(v/'HistoryVerify.java')],[str(t/'jdk25/bin/java'),'-cp',str(v)+os.pathsep+cp,'HistoryVerify']]:
 p=subprocess.run(cmd,capture_output=True,text=True);print(p.stdout+p.stderr);assert p.returncode==0
