import java.util.*;
import java.lang.reflect.*;
import br.com.flaviotorres.iptvpremium.data.history.*;
import br.com.flaviotorres.iptvpremium.core.player.*;
import br.com.flaviotorres.iptvpremium.data.repository.SeriesEpisodeInfo;
public class HistoryVerify {
 static int count;
 static Object make(Class<?> c,Object... a)throws Exception {for(var k:c.getDeclaredConstructors())if(k.getParameterCount()==a.length){k.setAccessible(true);return k.newInstance(a);}throw new RuntimeException(c.toString());}
 static void set(Object o,String n,Object v)throws Exception{var f=o.getClass().getDeclaredField(n);f.setAccessible(true);f.set(o,v);}
 static void check(boolean ok,String reason){if(!ok)throw new AssertionError(reason);count++;System.out.println("PASS "+reason);}
 static PlaybackMedia media(String id,boolean series,Long duration){return new PlaybackMedia(id,series?PlaybackContentType.EPISODE:PlaybackContentType.MOVIE,"Title","https://example.invalid/video",null,null,null,duration,series?"source":null,series?5:null,series?6:null,null,null,series?"Series":null,2020);}
 static WatchHistoryEntry entry(boolean series,String poster,long duration)throws Exception{return (WatchHistoryEntry)make(WatchHistoryEntry.class,"A",series?PlaybackContentType.EPISODE:PlaybackContentType.MOVIE,"media",series?"source":null,"Title",poster,series?"Series":null,poster,series?5:null,series?6:null,600000L,Long.valueOf(duration),1000L,false,null,false,false,2020,null,null,null,false,null);}
 public static void main(String[] args)throws Exception {
  android.content.Context context=new android.content.Context();
  WatchHistoryStore history=new WatchHistoryStore(context,false);
  for(boolean series:new boolean[]{false,true}) {
   String id=series?"episode":"movie"; PlaybackMedia media=media(id,series,null);
   WatchHistoryEntry saved=history.save("A",media,600000L,3600000L,"Series",null,false);
   check(saved.getInProgress(),"initial progress series="+series);
   saved=history.save("A",media,610000L,620000L,"Series",null,false);
   check(saved.getInProgress()&&saved.getDurationMs()==3600000L,"short duration cannot prematurely finish series="+series);
   saved=history.save("A",media,620000L,null,"Series","https://image/season",false);
   check(saved.getInProgress()&&saved.getDurationMs()==3600000L,"missing duration and changed poster retain checkpoint series="+series);
   check(new WatchHistoryStore(context,false).allLocal().stream().anyMatch(h->h.getContentId().equals(id)&&h.getInProgress()),"reopening retains progress series="+series);
   saved=history.save("A",media,3420000L,3600000L,"Series",null,false);
   check(saved.getCompleted(),"real 95 percent completion preserved series="+series);
   saved=history.save("A",media,100000L,3600000L,"Series",null,false);
   check(saved.getInProgress(),"replay earlier in content reenters Continue series="+series);
   saved=history.save("A",media,700000L,700000L,"Series",null,true);
   check(saved.getFinished()&&saved.getCompleted(),"explicit playback end preserved series="+series);
  }
  check(new WatchHistoryStore(context,true).allLocal().isEmpty(),"normal and Kids remain isolated");
  WatchHistoryEntry provisional=history.save("A",media("unknown",false,null),600000L,600000L,null,null,false);
  check(provisional.getInProgress()&&provisional.getDurationMs()==null,"duration at/below current position without real end cannot finish");
  provisional=history.save("A",media("metadata",false,3600000L),600000L,620000L,null,null,false);
  check(provisional.getInProgress()&&provisional.getDurationMs()==3600000L,"metadata anchors first short decoder sample");
  var store=(SharedLibraryStore)make(SharedLibraryStore.class,new android.content.Context(),false);
  set(store,"linkedPlaylist","B");
  var identity=new ContentIdentity("series","Series",2020,null,null,Collections.emptyList(),null,null);
  Class<?> record=Class.forName(SharedLibraryStore.class.getName()+"$Record"),link=Class.forName(SharedLibraryStore.class.getName()+"$Link");
  String key="1:A:series:source";
  Object r=make(record,key,"A","source",identity,true,null,0L,0L,0);
  set(store,"loadedRecords",new LinkedHashMap<>(Map.of(key,r)));
  set(store,"links",Map.of(key,List.of(make(link,"target","Series",null,null))));
  var raw=List.of(entry(true,null,3600000L));set(store,"linkedHistory",raw);
  check(store.projectHistory("B",raw).size()==1,"shared series initially visible");
  store.registerEpisodes("B","target",Collections.emptyList(),false);
  check(store.projectHistory("B",raw).size()==1,"loading empty response cannot hide shared series");
  SeriesEpisodeInfo ep=new SeriesEpisodeInfo("real-episode",5,6,"Episode 6",null,null,3600,null);
  store.registerEpisodes("B","target",List.of(ep),false);
  check(store.projectHistory("B",raw).get(0).getContentId().equals("real-episode"),"complete episode response maps real provider ID");
  store.registerEpisodes("B","target",Collections.emptyList(),false);
  check(store.projectHistory("B",raw).get(0).getContentId().equals("real-episode"),"later loading response preserves known mapping");
  store.registerEpisodes("OTHER","target",List.of(new SeriesEpisodeInfo("wrong",5,6,"Other",null,null,3600,null)),false);
  check(store.projectHistory("B",raw).get(0).getContentId().equals("real-episode"),"foreign playlist cannot replace mapping");
  history.save("A",media("ep6",true,100000L),95000L,100000L,"Series",null,false);
  SeriesEpisodeInfo next=new SeriesEpisodeInfo("ep7",5,7,"Episode 7",null,null,100,null);
  history.queueNext("A",media("ep6",true,100000L),next,"Series",null);
  WatchHistoryEntry queued=history.allLocal().stream().filter(h->h.getContentId().equals("ep7")).findFirst().orElseThrow();
  check(queued.getPendingNext()&&queued.getInProgress(),"completed episode retains pending next episode");
  check(entry(false,null,3600000L).getInProgress()&&entry(false,"https://image/new",3600000L).getInProgress(),"movie poster cannot hide progress");
  System.out.println("TOTAL "+count+" checks passed on compiled production classes");
 }
}
