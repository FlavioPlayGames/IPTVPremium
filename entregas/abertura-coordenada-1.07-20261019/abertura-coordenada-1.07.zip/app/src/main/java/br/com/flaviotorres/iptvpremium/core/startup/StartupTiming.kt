package br.com.flaviotorres.iptvpremium.core.startup

import android.os.SystemClock
import android.util.Log
import java.util.concurrent.atomic.AtomicBoolean

internal object StartupTiming {
    @Volatile private var startedAt = 0L
    private val homeReported = AtomicBoolean(false)
    fun begin() { startedAt = SystemClock.elapsedRealtime(); homeReported.set(false) }
    fun checkpoint(stage: String) {
        Log.i("StartupPerf", "etapa=$stage totalMs=${SystemClock.elapsedRealtime() - startedAt}")
    }
    fun homeReady() {
        if (homeReported.compareAndSet(false, true)) {
            Log.i("StartupPerf", "etapa=interface_liberada totalMs=${SystemClock.elapsedRealtime() - startedAt}")
        }
    }
    inline fun <T> measure(stage: String, block: () -> T): T {
        val start = SystemClock.elapsedRealtime()
        try { return block() }
        finally { Log.i("StartupPerf", "etapa=$stage duracaoMs=${SystemClock.elapsedRealtime() - start}") }
    }
    suspend fun <T> measureSuspend(stage: String, block: suspend () -> T): T {
        val start = SystemClock.elapsedRealtime()
        try { return block() }
        finally { Log.i("StartupPerf", "etapa=$stage duracaoMs=${SystemClock.elapsedRealtime() - start}") }
    }
}
