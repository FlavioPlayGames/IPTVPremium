package br.com.flaviotorres.iptvpremium.core.startup

import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import br.com.flaviotorres.iptvpremium.data.storage.PlaylistStorage
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.UUID

class PortalCatalogReceiptDeviceTest {
    private fun fixture(check: suspend (PlaylistStorage, PlaylistStorage) -> Unit) = runBlocking {
        val root = androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>().cacheDir
        val file = File(root, "receipt-${UUID.randomUUID()}.preferences_pb")
        val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        val store = PreferenceDataStoreFactory.create(scope = scope, produceFile = { file })
        try { check(PlaylistStorage(store), PlaylistStorage(store)) }
        finally { scope.coroutineContext[Job]!!.cancelAndJoin(); file.delete() }
    }
    private val source = PlaylistSource.M3u("fixture", "Fixture", playlistUrl = "https://example.invalid/list.m3u")
    @Test fun completedRequestSurvivesNewStorageInstance() = fixture { storage, reopened ->
        storage.applyPortalOperation(source.id, source)
        val request = storage.portalLoadRequest.first()!!
        assertFalse(storage.isPortalCatalogReady(request)); storage.markPortalCatalogReady(request)
        assertTrue(reopened.isPortalCatalogReady(request))
    }
    @Test fun newCommandInvalidatesOldCompletion() = fixture { storage, _ ->
        storage.applyPortalOperation(source.id, source); val old = storage.portalLoadRequest.first()!!
        storage.markPortalCatalogReady(old); storage.applyPortalOperation(source.id, source)
        val next = storage.portalLoadRequest.first()!!
        assertNotEquals(old, next); assertFalse(storage.isPortalCatalogReady(next))
        storage.markPortalCatalogReady(old); assertFalse(storage.isPortalCatalogReady(next))
    }
    @Test fun oldFinishCannotDiscardNewPendingCommand() = fixture { storage, _ ->
        storage.applyPortalOperation(source.id, source); val old = storage.portalLoadRequest.first()!!
        storage.applyPortalOperation(source.id, source); val next = storage.portalLoadRequest.first()!!
        storage.finishPortalLoad(old); assertEquals(next, storage.portalLoadRequest.first())
        storage.markPortalCatalogReady(next); storage.finishPortalLoad(next)
        assertNull(storage.portalLoadRequest.first()); assertFalse(storage.isPortalCatalogReady(next))
    }
    @Test fun clearRemovesPendingAndCompletedReceipt() = fixture { storage, _ ->
        storage.applyPortalOperation(source.id, source); val request = storage.portalLoadRequest.first()!!
        storage.markPortalCatalogReady(request); storage.clear()
        assertNull(storage.portalLoadRequest.first()); assertFalse(storage.isPortalCatalogReady(request))
    }
}
