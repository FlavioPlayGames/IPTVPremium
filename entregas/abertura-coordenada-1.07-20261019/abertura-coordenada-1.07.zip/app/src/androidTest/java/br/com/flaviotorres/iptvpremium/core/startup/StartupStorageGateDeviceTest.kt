package br.com.flaviotorres.iptvpremium.core.startup

import br.com.flaviotorres.iptvpremium.core.storage.ForegroundStorageGate
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test

class StartupStorageGateDeviceTest {
    @Test fun openingBlocksMaintenance() = runBlocking {
        val gate = ForegroundStorageGate(); val entered = CompletableDeferred<Unit>()
        val job = launch { gate.maintenanceAfterIdle(1) { entered.complete(Unit) } }
        assertNull(withTimeoutOrNull(50) { entered.await() }); job.cancelAndJoin()
    }
    @Test fun usableInterfaceReleasesMaintenance() = runBlocking {
        val gate = ForegroundStorageGate(); val entered = CompletableDeferred<Unit>()
        val job = launch { gate.maintenanceAfterIdle(1) { entered.complete(Unit) } }
        gate.homeReady(); withTimeout(2_000) { entered.await(); job.join() }
    }
    @Test fun activeImportBlocksMaintenance() = runBlocking {
        val gate = ForegroundStorageGate(); gate.homeReady()
        val importStarted = CompletableDeferred<Unit>(); val release = CompletableDeferred<Unit>()
        val importer = launch { gate.foreground { importStarted.complete(Unit); release.await() } }
        importStarted.await(); val entered = CompletableDeferred<Unit>()
        val cleaner = launch { gate.maintenanceAfterIdle(1) { entered.complete(Unit) } }
        assertNull(withTimeoutOrNull(50) { entered.await() })
        release.complete(Unit); withTimeout(2_000) { importer.join(); cleaner.join() }; assertTrue(entered.isCompleted)
    }
    @Test fun importPreemptsCleanupAndWaitsForCleanupFinally() = runBlocking {
        val gate = ForegroundStorageGate(); gate.homeReady()
        val entered = CompletableDeferred<Unit>(); val cancelled = CompletableDeferred<Unit>()
        val cleaner = launch { gate.maintenanceAfterIdle(1) {
            entered.complete(Unit)
            try { awaitCancellation() } finally { cancelled.complete(Unit) }
        } }
        withTimeout(2_000) { entered.await() }
        gate.foreground { assertTrue(cancelled.isCompleted) }
        cleaner.cancelAndJoin()
    }
    @Test fun cancelledImportDoesNotBlockFutureCleanup() = runBlocking {
        val gate = ForegroundStorageGate(); gate.homeReady()
        val started = CompletableDeferred<Unit>()
        val importer = launch { gate.foreground { started.complete(Unit); awaitCancellation() } }
        started.await(); importer.cancelAndJoin()
        withTimeout(2_000) { gate.maintenanceAfterIdle(1) { } }
    }
    @Test fun failedImportDoesNotBlockFutureCleanup() = runBlocking {
        val gate = ForegroundStorageGate(); gate.homeReady()
        runCatching { gate.foreground { throw IllegalStateException("fixture") } }
        withTimeout(2_000) { gate.maintenanceAfterIdle(1) { } }
    }
    @Test fun overlappingImportsMustBothFinishBeforeCleanup() = runBlocking {
        val gate = ForegroundStorageGate(); gate.homeReady()
        val a = CompletableDeferred<Unit>(); val b = CompletableDeferred<Unit>()
        val first = launch(start = CoroutineStart.UNDISPATCHED) { gate.foreground { a.await() } }
        val second = launch(start = CoroutineStart.UNDISPATCHED) { gate.foreground { b.await() } }
        val entered = CompletableDeferred<Unit>()
        val cleaner = launch { gate.maintenanceAfterIdle(1) { entered.complete(Unit) } }
        a.complete(Unit); first.join(); assertNull(withTimeoutOrNull(50) { entered.await() })
        b.complete(Unit); withTimeout(2_000) { second.join(); cleaner.join() }; assertTrue(entered.isCompleted)
    }
    @Test fun openingAgainPausesCleanupUntilInterfaceIsReadyAgain() = runBlocking {
        val gate = ForegroundStorageGate(); gate.homeReady()
        val entered = CompletableDeferred<Unit>(); var passes = 0
        val cleaner = launch { gate.maintenanceAfterIdle(1) { passes++; entered.complete(Unit); awaitCancellation() } }
        withTimeout(2_000) { entered.await() }; gate.openingStarted(); delay(30)
        assertEquals(1, passes); gate.homeReady()
        withTimeout(2_000) { while (passes < 2) yield() }; cleaner.cancelAndJoin()
    }
}
