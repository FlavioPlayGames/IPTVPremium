package br.com.flaviotorres.iptvpremium.ui.movies

import br.com.flaviotorres.iptvpremium.core.network.MovieOpeningAttempt
import kotlinx.coroutines.*
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException


/** One budget for metadata and decoded principal images, reserving the final animation. */
internal object MovieOpeningPolicy {
    const val attempts = 3
    const val preparationMs = 15_000L
    const val remoteMs = 12_000L
    const val artworkMs = 1_000L
    const val minimumLoadingMs = 3_000L
    const val rotationCardsPerSecond = 1.5f
    const val alignNanos = 1_100_000_000L
    const val pressNanos = 260_000_000L
    const val expandNanos = 600_000_000L
    fun remainingMs(elapsedMs: Long): Long = (preparationMs - elapsedMs.coerceAtLeast(0L)).coerceAtLeast(0L)
    // Artwork readiness never shortens the mandatory three-second loading stage.
    @Suppress("UNUSED_PARAMETER")
    fun minimumWaitMs(elapsedMs: Long, artworkReady: Boolean): Long =
        (minimumLoadingMs - elapsedMs.coerceAtLeast(0L)).coerceAtLeast(0L)
    /** Cancel the old request without waiting for a blocking socket's teardown. */
    private suspend fun <T> separateAttempt(block: suspend () -> T): T {
        val context = currentCoroutineContext()
        return suspendCancellableCoroutine { continuation ->
            val requestJob = Job()
            continuation.invokeOnCancellation { requestJob.cancel() }
            CoroutineScope(context.minusKey(Job) + requestJob).launch {
                try {
                    val result = block()
                    currentCoroutineContext().ensureActive()
                    if (continuation.isActive) continuation.resume(result)
                } catch (error: Throwable) {
                    if (continuation.isActive) continuation.resumeWithException(error)
                } finally {
                    requestJob.complete()
                }
            }
        }
    }

    /** One deadline: a valid slow response is not discarded every five seconds. */
    suspend fun <T:Any> prepare(block:suspend ()->T?):T? = kotlinx.coroutines.withTimeoutOrNull(preparationMs) {
        repeat(attempts) { index ->
            val result = try {
                separateAttempt {
                    withContext(MovieOpeningAttempt(index + 1)) { block() }
                }
            } catch(cancelled:CancellationException) { throw cancelled }
              catch(_:Exception) { null }
            if(result!=null)return@withTimeoutOrNull result
            if(index < attempts - 1) delay(200L)
        }
        null
    }
}
