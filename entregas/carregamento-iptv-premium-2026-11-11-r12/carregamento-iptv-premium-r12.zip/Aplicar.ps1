﻿[CmdletBinding()]
param([string]$Projeto="$env:USERPROFILE\AndroidStudioProjects\IPTVPremium",[string]$Downloads="$env:USERPROFILE\Downloads")
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Seguranca.ps1"
$Projeto=Projeto-Valido $Projeto
$itens=ConvertFrom-Json -InputObject (Get-Content -Raw -LiteralPath "$PSScriptRoot\manifesto.json")
$itens=@($itens)
$baseR10=$true
$baseR11=$true
$tudoPronto=$true
$pendentes=@()
foreach($item in $itens) {
    if($item.path -notmatch '^app/src/main/java/[A-Za-z0-9_/]+\.kt$'){throw 'Manifesto invalido.'}
    $p=Caminho-Seguro $Projeto $item.path
    if((Test-Path -LiteralPath $p) -and !(Test-Path -LiteralPath $p -PathType Leaf)){throw 'Destino inesperado.'}
    if($null -ne $item.afterHash -and (Hash-Arquivo (Join-Path "$PSScriptRoot\arquivos" $item.path)) -ne $item.afterHash){throw 'Conteudo do pacote alterado.'}
    $hash=Hash-Arquivo $p
    $compativel=($item.keepOnUndo -and $hash -eq $item.afterHash)
    $baseR10=($baseR10 -and ($hash -eq $item.beforeHash -or $compativel))
    $baseR11=($baseR11 -and ($hash -eq $item.r11BeforeHash -or $compativel))
    if($hash -ne $item.afterHash){$tudoPronto=$false;$pendentes += $item}
}
if($tudoPronto){Write-Host 'Atualizacao r12 ja aplicada.';return}
if(!$baseR10 -and !$baseR11){throw 'Base diferente ou aplicacao parcial. Nenhum fonte foi alterado. Este pacote aceita as bases completas r10 e r11.'}
$itens=@($pendentes)
foreach($item in $itens){$item.beforeHash=Hash-Arquivo (Join-Path $Projeto $item.path)}
$backup=Destino-Externo $Projeto $Downloads 'IPTV-restauracao-r12-'
foreach($item in $itens) {
    $destino=Join-Path "$backup\arquivos" $item.path
    New-Item -ItemType Directory -Path (Split-Path $destino) -Force | Out-Null
    if($null -ne $item.beforeHash){Copy-Item -LiteralPath (Join-Path $Projeto $item.path) -Destination $destino}
    if((Hash-Arquivo $destino) -ne $item.beforeHash){throw 'Backup nao confere; nada foi alterado.'}
}
@{projeto=$Projeto;arquivos=$itens;desfeito=$false}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$backup\estado.json" -Encoding UTF8
try {
    foreach($item in $itens) {
        $p=Join-Path $Projeto $item.path
        if($null -eq $item.afterHash){Remove-Item -LiteralPath $p -Force}
        else {
            New-Item -ItemType Directory -Path (Split-Path $p) -Force | Out-Null
            Copy-Item -LiteralPath (Join-Path "$PSScriptRoot\arquivos" $item.path) -Destination $p -Force}
        if((Hash-Arquivo $p) -ne $item.afterHash){throw 'Resultado da copia/exclusao nao confere.'}
    }
} catch {
    foreach($item in $itens){
        $p=Join-Path $Projeto $item.path
        if($null -eq $item.beforeHash){if(Test-Path -LiteralPath $p -PathType Leaf){Remove-Item -LiteralPath $p -Force}}
        else {Copy-Item -LiteralPath (Join-Path "$backup\arquivos" $item.path) -Destination $p -Force}
    }
    throw
}
Write-Host "Atualizacao r12 aplicada. Recuperacao externa: $backup"
Write-Host "Para desfazer: powershell -ExecutionPolicy Bypass -File '$PSScriptRoot\Desfazer.ps1' -Backup '$backup'"
