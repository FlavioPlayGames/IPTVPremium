package br.com.flaviotorres.iptvpremium.data.repository

import androidx.compose.runtime.*
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.test.*
import androidx.compose.ui.test.junit4.createComposeRule
import androidx.navigation.NavHostController
import androidx.navigation.compose.*
import androidx.paging.PagingData
import androidx.paging.compose.collectAsLazyPagingItems
import br.com.flaviotorres.iptvpremium.domain.model.Movie
import br.com.flaviotorres.iptvpremium.domain.model.Series
import br.com.flaviotorres.iptvpremium.ui.movies.MoviesScreen
import br.com.flaviotorres.iptvpremium.ui.series.SeriesScreen
import br.com.flaviotorres.iptvpremium.ui.theme.IPTVPremiumTheme
import kotlinx.coroutines.flow.flowOf
import org.junit.Rule
import org.junit.Test

/** Real catalog composables and NavHost save/restore; no provider/network dependency. */
class CatalogReturnDeviceTest {
    @get:Rule val compose = createComposeRule()
    private lateinit var nav: NavHostController

    private fun returnsToCard(series: Boolean) {
        val movieFlow = flowOf(PagingData.from((0 until 60).map {
            Movie("movie-$it", "Return movie $it", null, null, null, "", null, null, null)
        }))
        val seriesFlow = flowOf(PagingData.from((0 until 60).map {
            Series("series-$it", "Return series $it", null, null, null, null, null, null)
        }))
        val prefix = if (series) "Return series " else "Return movie "
        compose.setContent {
            nav = rememberNavController()
            IPTVPremiumTheme {
                NavHost(nav, startDestination = "catalog") {
                    composable("catalog") {
                        if (series) SeriesScreen(pagedSeries = seriesFlow.collectAsLazyPagingItems(),
                            totalSeriesCount = 60, onSeriesClick = { nav.navigate("details") })
                        else MoviesScreen(pagedMovies = movieFlow.collectAsLazyPagingItems(),
                            totalMovieCount = 60, onMovieClick = { nav.navigate("details") })
                    }
                    composable("details") { Box(Modifier.fillMaxSize().testTag("opened-details")) }
                }
            }
        }
        val grid = compose.onNode(hasScrollToIndexAction() and hasAnyDescendant(hasText(prefix + "0")))
        compose.waitUntil(5_000) {
            compose.onAllNodes(hasScrollToIndexAction() and hasAnyDescendant(hasText(prefix + "0"))).fetchSemanticsNodes().isNotEmpty()
        }
        grid.performScrollToIndex(15)
        val card = compose.onNode(hasClickAction() and hasAnyDescendant(hasText(prefix + "17")))
        card.performClick()
        compose.onNodeWithTag("opened-details").assertExists()
        compose.waitUntil(5_000) {
            compose.onAllNodes(hasText(prefix + "17")).fetchSemanticsNodes().isEmpty()
        }
        compose.runOnIdle { nav.popBackStack() }
        compose.waitUntil(5_000) {
            compose.onAllNodes(hasClickAction() and hasAnyDescendant(hasText(prefix + "17")) and isFocused()).fetchSemanticsNodes().isNotEmpty()
        }
        compose.onNode(hasClickAction() and hasAnyDescendant(hasText(prefix + "17"))).assertIsFocused()
    }
    @Test fun moviesReturnToLastOpenedCardBeyondFirstRows() = returnsToCard(false)
    @Test fun seriesReturnToLastOpenedCardBeyondFirstRows() = returnsToCard(true)
}
