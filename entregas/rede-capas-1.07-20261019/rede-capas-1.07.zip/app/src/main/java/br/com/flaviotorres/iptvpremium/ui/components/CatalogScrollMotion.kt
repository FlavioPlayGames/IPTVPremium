package br.com.flaviotorres.iptvpremium.ui.components

/** Reused for an entire gesture: targets may change without resetting momentum. */
internal class CatalogScrollMotion {
    var velocity: Float = 0f
        private set

    fun advance(distance: Float, elapsedSeconds: Float, rowHeight: Float): Float {
        val dt = elapsedSeconds.coerceIn(.001f, .05f)
        val omega = 18f
        val error = -distance
        val decay = kotlin.math.exp(-omega * dt)
        val nextError = (error + (velocity + omega * error) * dt) * decay
        val nextVelocity = (velocity - omega * (velocity + omega * error) * dt) * decay
        val limit = rowHeight.coerceAtLeast(1f) * 6f
        val requested = nextError - error
        val delta = requested.coerceIn(-limit * dt, limit * dt)
        velocity = if (delta != requested) delta / dt else nextVelocity.coerceIn(-limit, limit)
        return delta
    }
}
