package br.com.flaviotorres.iptvpremium.data.cache

import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

/** Shares six downloads without allowing anticipation to occupy every connection. */
internal class PosterNetworkBudget {
    private val total = Semaphore(TOTAL_REQUESTS)
    private val anticipation = Semaphore(BACKGROUND_REQUESTS)

    suspend fun <T> run(background: Boolean, operation: suspend () -> T): T =
        if (background) anticipation.withPermit { total.withPermit { operation() } }
        else total.withPermit { operation() }

    companion object {
        const val TOTAL_REQUESTS = 6
        const val BACKGROUND_REQUESTS = 2
    }
}
