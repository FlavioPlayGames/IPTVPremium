# Importação Xtream progressiva

Complemento para o projeto atual com os pacotes de armazenamento e catálogos órfãos aplicados. O instalador confere todos os hashes antes de alterar fontes, cria backup e restaura os arquivos caso a cópia falhe. Não inclui configurações locais, credenciais, assinatura, APKs ou mudanças de versões do Gradle/SDK.

## O que muda

O cliente de produção fornece um Reader conectado à resposta HTTP. O catálogo é enquadrado e interpretado em lotes de até 250 entradas ou aproximadamente 262 mil caracteres de texto, em vez de virar uma String e um JSONArray completos. Um registro individual muito grande pode ultrapassar esse orçamento; ele não é cortado nem descartado por tamanho.

A conversão dos campos continua usando o parser atual. O importador grava cada lote na geração IMPORTING, com pressão de retorno: não lê o próximo lote enquanto o anterior está sendo gravado. A geração só vira READY depois de todas as etapas obrigatórias concluídas. Falhas e cancelamento descartam a geração incompleta e preservam a ativa.

Autenticação, construção de URLs, metadados, ordem do provedor, tratamento de campos ausentes, recuperação de colchete final ausente dentro dos limites anteriores, duas tentativas de JSON completo e até três tentativas por categoria foram preservados.

A recuperação por categoria prepara no máximo três respostas em gerações IMPORTING separadas no Room. Respostas incompletas são descartadas/reiniciadas; as válidas são reunidas na ordem original, preservando a primeira ocorrência dos IDs repetidos. A leitura dessas gerações utiliza paginação por ordem do provedor, sem OFFSET crescente. Os registros temporários são apagados no sucesso, na falha ou no cancelamento; se o processo for encerrado à força, a manutenção existente poderá removê-los como importações abandonadas. Essas gerações nunca viram READY por conta própria.

As categorias extras aprendidas de uma resposta completa recente e o modo adaptativo de recuperação de séries continuam disponíveis. Listas M3U reconhecidas como Xtream usam o mesmo caminho; a recuperação M3U nativa permanece disponível.

Não houve mudanças no visual, teclado, player, upscale, controle parental, limites de imagens ou SharedSync. Os esquemas e índices das tabelas não mudaram; não há migração nem limpeza de favoritos/histórico.

## Instalação

Execute o script de entrega na raiz do projeto. Ele aplica o complemento, compila assembleDebug e abre a pasta de APKs. Instale o APK da mesma variante por cima da versão atual, mantendo a assinatura. Não desinstale para aplicar esta atualização.

## Diagnóstico opcional durante o uso

Quando quiser comparar uma atualização de lista no aparelho, conecte-o com depuração USB autorizada e execute:

```powershell
powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Medir-importacao.ps1 -Serial CODIGO_DO_CELULAR
```

O TXT reúne apenas as métricas dos endpoints e da sincronização, sem exportar o logcat geral. modo=STREAM identifica o novo fluxo. parsingMs mede a conversão dos lotes; gravacaoMs inclui o consumo do lote e sua persistência; totalMs inclui toda a operação desse endpoint. heapPicoObservadoKb é a maior amostra tomada entre lotes, não uma medição contínua ou memória total do Android.

## Resultados e limites

- assembleDebug passou, incluindo KSP/Room e empacotamento.
- 16 cenários de integração com repositório, sincronizador e gravador reais, usando persistência simulada: equivalência de campos/URLs/ordem, lotes, recuperação, categorias extras, modo adaptativo, 32 pedidos compartilhados, falhas locais/remotas e cancelamento.
- 7 cenários de enquadramento e equivalência com JSON Android, incluindo comentários, Unicode, limites de recuperação, caracteres fragmentados e entradas ignoradas.
- 4 cenários do cliente HTTP real com servidor local: UTF-8, redirecionamento, status de erro, falha de callback e cancelamento.
- Consultas de primeira ocorrência e paginação das duas tabelas de catálogo testadas em SQLite real.
- Ensaio sintético de 80.000 filmes, resposta de 163.828.891 caracteres ASCII, terminou com heap JVM limitado a 128 MiB. O mesmo caminho anterior de String integral esgotou esse limite, resultado esperado do controle. O ensaio usa rede simulada e um consumidor de contagem, sem medir gravação Room real nem desempenho de TV.

O pacote reduz a necessidade de manter o catálogo completo em RAM. Mantém conjuntos de IDs para auditoria e deduplicação; portanto o consumo não é absolutamente constante para catálogos arbitrários. A recuperação temporária e as gerações de importação ainda exigem espaço em disco. A janela limitada de preparação pode alterar o tempo da recuperação por categorias; não foi afirmado ganho de velocidade no aparelho sem comparação em condições equivalentes.

Instalador: verificacao sem alterar, aplicacao, reaplicacao, rejeicao de versao divergente e restauracao apos falha de copia testadas no PowerShell 7.5.4/Linux. O script autonomo tambem foi testado com seu pacote embutido e arquivo danificado. A execucao no Windows e no aparelho continua a cargo do usuario.
