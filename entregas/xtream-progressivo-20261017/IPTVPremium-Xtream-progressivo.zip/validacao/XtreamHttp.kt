package br.com.flaviotorres.iptvpremium.data.remote
import com.sun.net.httpserver.HttpServer
import java.net.InetSocketAddress
import java.util.concurrent.Executors
import kotlinx.coroutines.*

fun main()=runBlocking {
 val executor=Executors.newCachedThreadPool();val server=HttpServer.create(InetSocketAddress("127.0.0.1",0),0)
 server.executor=executor
 server.createContext("/data"){e->val body="[{\"name\":\"Coração\"}]".toByteArray(Charsets.UTF_8);e.sendResponseHeaders(200,body.size.toLong());e.responseBody.use{it.write(body)}}
 server.createContext("/redirect"){e->e.responseHeaders.add("Location","/data");e.sendResponseHeaders(302,-1);e.close()}
 server.createContext("/fail"){e->e.sendResponseHeaders(503,-1);e.close()}
 server.start()
 try {
  val client=DefaultPlaylistHttpClient();val base="http://127.0.0.1:${server.address.port}"
  check(client.withReader("$base/redirect"){it.readText()}.contains("Coração"));println("PASS production HTTP reader redirects and UTF-8")
  check(runCatching{client.withReader("$base/fail"){it.readText()}}.exceptionOrNull() is IllegalStateException);println("PASS production HTTP rejects non-success status")
  check(runCatching{client.withReader("$base/data"){error("callback failed")}}.isFailure);println("PASS production HTTP propagates callback failure")
  val outcome=runCatching{withTimeout(50){client.withReader("$base/data"){delay(5000)}}}
  check(outcome.exceptionOrNull() is CancellationException);println("PASS production HTTP propagates cancellation")
 }finally{server.stop(0);executor.shutdownNow()}
}
