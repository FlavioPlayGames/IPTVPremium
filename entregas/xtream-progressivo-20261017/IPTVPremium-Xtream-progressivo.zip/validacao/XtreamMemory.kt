package br.com.flaviotorres.iptvpremium.data.sync

import br.com.flaviotorres.iptvpremium.data.parser.*
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import br.com.flaviotorres.iptvpremium.data.repository.DefaultPlaylistRepository
import br.com.flaviotorres.iptvpremium.domain.model.*
import kotlinx.coroutines.runBlocking
import java.io.*

private class GeneratedCatalog(private val count:Int):Reader(){
 var index=0;var text="[";var offset=0;var done=false;var chars=0L
 private val padding="x".repeat(2000)
 override fun close(){}
 override fun read(out:CharArray,start:Int,length:Int):Int {
  if(done)return -1
  var written=0
  while(written<length){
   if(offset==text.length){
    if(index<count){text=(if(index>0)"," else "")+"{\"stream_id\":${index++},\"name\":\"$padding\",\"category_id\":\"1\"}";offset=0}
    else if(text!="]"){text="]";offset=0}
    else{done=true;break}
   }
   val n=minOf(length-written,text.length-offset)
   text.toCharArray(out,start+written,offset,offset+n);offset+=n;written+=n;chars+=n
  }
  return if(written==0)-1 else written
 }
}
private class BenchHttp:PlaylistHttpClient {
 var characters=0L
 private fun reader(url:String):Reader=when(url.substringAfter("&action=","auth")){
  "get_vod_streams" -> GeneratedCatalog(80_000)
  "get_live_categories","get_vod_categories","get_series_categories" -> StringReader("[{\"category_id\":1,\"category_name\":\"Category\"}]")
  "auth" -> StringReader("{\"user_info\":{\"auth\":1}}")
  else->StringReader("[]")
 }
 override suspend fun get(url:String):String=reader(url).use{it.readText()}
 override suspend fun <T> withReader(url:String,consume:suspend(Reader)->T):T=reader(url).use{
  val result=consume(it);if(it is GeneratedCatalog)characters+=it.chars;result
 }
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit){error("not expected")}
}
private class Counter: XtreamCatalogSink {
 var movies=0;var largest=0
 override suspend fun append(endpoint:String,content:PlaylistContent){movies+=content.movies.size;largest=maxOf(largest,content.movies.size)}
 override suspend fun reset(endpoint:String){if(endpoint=="get_vod_streams")movies=0}
 override suspend fun stage(endpoint:String):XtreamCatalogStage=error("not expected")
 override suspend fun merge(stage:XtreamCatalogStage)=error("not expected")
 override suspend fun discard(stage:XtreamCatalogStage)=error("not expected")
}
fun main(args:Array<String>){
 val mode=args.firstOrNull()?:"stream";val http=BenchHttp();val counter=Counter()
 val repo=DefaultPlaylistRepository(http,object:M3uParser{override fun parse(content:String)=PlaylistContent()},DefaultXtreamParser())
 val source=PlaylistSource.XtreamCodes("benchmark","test",true,"http://benchmark.test","user","password")
 val start=System.nanoTime()
 try{
  runBlocking{if(mode=="legacy")check(repo.loadContent(source).movies.size==80_000) else repo.importXtream(source,counter)}
  if(mode!="legacy")check(counter.movies==80_000 && counter.largest<=250)
  println("BENCH mode=$mode characters=${http.characters} movies=${counter.movies} largestBatch=${counter.largest} maxHeapBytes=${Runtime.getRuntime().maxMemory()} elapsedMs=${(System.nanoTime()-start)/1_000_000}")
 }catch(e:OutOfMemoryError){println("EXPECTED_LIMIT_FAILURE mode=$mode heapBytes=${Runtime.getRuntime().maxMemory()}");kotlin.system.exitProcess(86)}
}
