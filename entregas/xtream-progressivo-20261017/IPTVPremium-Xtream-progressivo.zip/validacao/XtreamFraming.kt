package br.com.flaviotorres.iptvpremium.data.parser

import java.io.*
import kotlinx.coroutines.*

fun main()=runBlocking {
 val parser=DefaultXtreamParser();var passed=0
 suspend fun test(name:String,block:suspend()->Unit){block();passed++;println("PASS $name")}
 suspend fun parse(raw:String,oneChar:Boolean=false):List<br.com.flaviotorres.iptvpremium.domain.model.Movie> {
  val output=ArrayList<br.com.flaviotorres.iptvpremium.domain.model.Movie>()
  val reader=if(oneChar)object:Reader(){var at=0;override fun close(){};override fun read(b:CharArray,o:Int,l:Int):Int{if(at==raw.length)return -1;b[o]=raw[at++];return 1}}else StringReader(raw)
  XtreamArrayStream.read(reader,"get_vod_streams",batchSize=2){chunk,_->output.addAll(parser.parseCatalogBatch("get_vod_streams",chunk).movies)}
  return output
 }
 test("nested strings, escaped delimiters, Unicode and single-char input boundaries match legacy") {
  val raw="""[{"stream_id":1,"name":"Vídeo , ] } \" test","backdrop_path":["a,b","x"],"rating":"8,2"},{"stream_id":"2","name":"\\u00e7"}]"""
  check(parse(raw,true)==parser.parseMovies(raw))
 }
 test("ignored primitives and mixed arrays preserve recognized data") {
  val raw="""[null,2,false,"ignore",[],{"stream_id":"a"},{"other":1}]"""
  check(parse(raw)==parser.parseMovies(raw))
 }
 test("Android JSON leniency: comments, omitted entries, single quotes and unquoted keys") {
  for(raw in listOf("""/*header*/ [{stream_id:'a',name:'x,y'},{stream_id:'b'}]""", """[/* braces } [ quote" */ {"stream_id":"a"},,{"stream_id":"b"},]""", "[{stream_id:'a'} // tail comment\n]", "[/*only comment*/]")) {
   check(parse(raw)==parser.parseMovies(raw)) { "Lenient equivalence failed" }
  }
 }
 test("BOM and whitespace are accepted") {check(parse("\uFEFF  [{\"stream_id\":1}]").single().id=="1")}
 test("missing closing bracket recovery and upper character limit") {
  val raw="""[{"stream_id":"a"},{"stream_id":"b"}""";check(parse(raw)==parser.parseMovies(raw))
  var recovered=false
  XtreamArrayStream.read(StringReader(raw),"get_vod_streams"){chunk,_->parser.parseCatalogBatch("get_vod_streams",chunk)}.also{recovered=it.recoveredClosingBracket}
  check(recovered)
  val commented="[/*prefix*/{\"stream_id\":\"a\"}";check(parse(commented)==parser.parseMovies(commented))
  val huge="[{\"stream_id\":\"a\",\"name\":\""+"x".repeat(8_000_000)+"\"}"
  check(runCatching{parse(huge)}.isFailure)
 }
 test("unfinished object, string, nesting and trailing comma cannot activate partial response") {
  for(raw in listOf("[{\"stream_id\":1", "[{\"stream_id\":\"x", "[{\"stream_id\":1},", "[{} {]", "<html>bad</html>","[/{]")) {
   check(runCatching{parse(raw)}.isFailure)
  }
 }
 test("batch count and text budget are bounded independently of catalog length") {
  val raw=(0 until 1000).joinToString(",","[","]"){"{\"stream_id\":$it,\"name\":\""+"x".repeat(100)+"\"}"}
  var count=0;var max=0
  XtreamArrayStream.read(StringReader(raw),"get_vod_streams",batchSize=31,batchCharacters=1000){chunk,n->count+=n;max=maxOf(max,n);check(chunk.length<1200);parser.parseCatalogBatch("get_vod_streams",chunk)}
  check(count==1000&&max<=31)
 }
 println("$passed framing/legacy-parser scenarios passed using Android JSON")
}
