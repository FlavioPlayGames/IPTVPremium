package android.util;
public class Log {
 public static final java.util.List<String> messages = java.util.Collections.synchronizedList(new java.util.ArrayList<>());
 public static int i(String t,String m){ messages.add(t+":"+m);return 0; }
 public static int d(String t,String m){ return 0; }
 public static int w(String t,String m){ messages.add(t+":"+m);return 0; }
 public static int e(String t,String m){ messages.add(t+":"+m);return 0; }
 public static int e(String t,String m,Throwable e){ return e(t,m); }
 public static int w(String t,String m,Throwable e){ return w(t,m); }
}
