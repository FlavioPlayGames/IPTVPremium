package br.com.flaviotorres.iptvpremium.data.remote

interface PlaylistHttpClient {

    /** Implementations may stream; legacy test clients retain their existing behavior. */
    suspend fun <T> withReader(url: String, consume: suspend (java.io.Reader) -> T): T =
        java.io.StringReader(get(url)).use { consume(it) }

    /*
     * Mantido para respostas menores, como os endpoints JSON
     * do Xtream Codes.
     */
    suspend fun get(
        url: String
    ): String

    /*
     * Lê o conteúdo linha por linha sem transformar toda a resposta
     * em uma String gigante na memória.
     *
     * Será usado principalmente pelas listas M3U muito grandes.
     */
    suspend fun readLines(
        url: String,
        onLine: suspend (String) -> Unit
    )
}
