param([string]$Serial = '', [string]$AdbPath = '')
$ErrorActionPreference = 'Stop'
if (-not $AdbPath) {
    $AdbPath = Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe'
    if (-not (Test-Path -LiteralPath $AdbPath)) {
        $found = Get-Command adb -ErrorAction SilentlyContinue
        if ($found) { $AdbPath = $found.Source }
    }
}
if (-not (Test-Path -LiteralPath $AdbPath)) { throw 'ADB nao encontrado. Informe -AdbPath com o caminho do adb.exe.' }
$devices = @(& $AdbPath devices | ForEach-Object { if ($_ -match '^(\S+)\s+device$') { $Matches[1] } })
if (-not $Serial) {
    if ($devices.Count -ne 1) { throw ('Conecte um aparelho com depuracao USB autorizada ou informe -Serial. Aparelhos: ' + ($devices -join ', ')) }
    $Serial = $devices[0]
}
if ($Serial -notin $devices) { throw 'Aparelho nao conectado ou depuracao USB nao autorizada.' }
$target = @('-s', $Serial)
$package = 'br.com.flaviotorres.iptvpremium'
$report = [System.Collections.Generic.List[string]]::new()
$report.Add('IPTV Premium - metricas de importacao sem URLs ou credenciais')
$logs = @(& $AdbPath @target logcat -d -s 'XtreamEndpointPerf:I' 'M3uSourceSync:I' '*:S')
foreach ($line in $logs) {
    if ($line -match 'XtreamEndpointPerf.*endpoint=(authenticate|get_live_categories|get_live_streams|get_vod_categories|get_vod_streams|get_series_categories|get_series)\s' -or $line -match 'M3uSourceSync.*(SYNC_RESUMO|PERF etapa=XTREAM_TOTAL)') {
        $report.Add($line.ToString())
    }
}
if ($report.Count -eq 1) { $report.Add('Sem metricas disponiveis. Atualize uma lista no app e execute novamente.') }
$out = Join-Path $PSScriptRoot ('importacao-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt')
$report | Set-Content -LiteralPath $out -Encoding UTF8
$report | ForEach-Object { Write-Host $_ }
Write-Host ('Relatorio salvo: ' + $out)
Write-Host 'O script nao atualiza listas nem limpa registros ou dados.'
