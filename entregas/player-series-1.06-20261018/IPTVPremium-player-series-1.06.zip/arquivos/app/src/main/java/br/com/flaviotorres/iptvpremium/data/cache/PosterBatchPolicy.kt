package br.com.flaviotorres.iptvpremium.data.cache

internal const val CATEGORY_POSTER_BATCH_SIZE = 15
/** Antecipacao de uma linha antes de chegar ao proximo bloco. */
internal fun categoryPosterBatch(firstVisibleIndex: Int): Int {
    val index = firstVisibleIndex.coerceAtLeast(0)
    return (index + if (index == 0) 0 else 5) / CATEGORY_POSTER_BATCH_SIZE
}
