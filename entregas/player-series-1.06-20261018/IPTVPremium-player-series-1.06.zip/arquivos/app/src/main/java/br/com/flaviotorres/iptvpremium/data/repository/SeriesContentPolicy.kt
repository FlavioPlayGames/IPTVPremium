package br.com.flaviotorres.iptvpremium.data.repository

/** A quantidade de episodios reais prevalece sobre temporadas apenas informativas. */
internal fun playableSeriesSeasons(seasons: List<SeriesSeasonInfo>, episodes: List<SeriesEpisodeInfo>): List<SeriesSeasonInfo> {
    val metadata = seasons.associateBy { it.number }
    return episodes.filter { it.id.isNotBlank() && it.seasonNumber >= 0 }.groupBy { it.seasonNumber }
        .toSortedMap().map { (number, entries) ->
            metadata[number]?.copy(episodeCount = entries.size)
                ?: SeriesSeasonInfo(number, if (number == 0) "Especiais" else "Temporada $number", null, entries.size)
        }
}
