package br.com.flaviotorres.iptvpremium.data.repository

import android.net.Uri
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import br.com.flaviotorres.iptvpremium.data.resolver.M3uXtreamResolver
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import java.util.Locale

internal suspend fun episodePreviewSource(dao: PlaylistCacheDao, source: PlaylistSource,
    seriesId: String, episode: SeriesEpisodeInfo): String? {
    val generation = dao.getActiveGeneration(source.id)?.generationId ?: return null
    dao.episodePreviewUrl(source.id, generation, seriesId, episode.id)?.takeIf { it.isNotBlank() }?.let { return it }
    val xtream = when (source) {
        is PlaylistSource.XtreamCodes -> source
        is PlaylistSource.M3u -> M3uXtreamResolver.resolve(source)
    } ?: return null
    if (!episode.id.all(Char::isDigit) || episode.id.isBlank()) return null
    val base = xtream.serverUrl.trim().trimEnd('/').let { if (it.startsWith("http://",true) || it.startsWith("https://",true)) it else "http://$it" }
    val extension = episode.containerExtension?.trim()?.lowercase(Locale.ROOT)?.takeIf { it.matches(Regex("[a-z0-9]{2,5}")) } ?: "mp4"
    return "$base/series/${Uri.encode(xtream.username)}/${Uri.encode(xtream.password)}/${Uri.encode(episode.id)}.$extension"
}
