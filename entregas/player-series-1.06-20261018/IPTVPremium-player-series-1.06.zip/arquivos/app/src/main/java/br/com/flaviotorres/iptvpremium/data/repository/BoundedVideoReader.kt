package br.com.flaviotorres.iptvpremium.data.repository

import java.io.Closeable
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Leitura aleatoria limitada: nunca baixa um video inteiro para obter uma miniatura. */
internal class BoundedVideoReader(
    private val url: String,
    private val active: () -> Boolean = { true },
    private val maxBytes: Long = 6L * 1024 * 1024,
    private val blockSize: Int = 256 * 1024,
    private val maxRequests: Int = 24,
    timeoutMs: Long = 10_000
) : Closeable {
    private val deadline = System.nanoTime() + timeoutMs * 1_000_000
    private var closed = false
    private var total = -1L
    private var received = 0L
    private var requests = 0
    private val blocks = LinkedHashMap<Long, ByteArray>(4, .75f, true)
    private fun checkActive() { if (closed || !active() || System.nanoTime() >= deadline) throw IOException("Preview encerrado") }
    @Synchronized fun size(): Long { checkActive(); if (total < 0) block(0); return total }
    @Synchronized fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
        checkActive()
        if (position < 0 || offset < 0 || size < 0 || offset > buffer.size - size) throw IOException("Posicao invalida")
        if (size == 0) return 0
        if (total >= 0 && position >= total) return -1
        val start = position / blockSize * blockSize
        val data = block(start)
        val index = (position - start).toInt()
        if (index >= data.size) return -1
        val count = minOf(size, data.size - index)
        data.copyInto(buffer, offset, index, index + count)
        return count
    }
    private fun block(start: Long): ByteArray {
        blocks[start]?.let { return it }
        checkActive()
        if (requests++ >= maxRequests || received >= maxBytes) throw IOException("Limite de leitura do preview")
        val end = start + minOf(blockSize.toLong(), maxBytes - received) - 1
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            val remaining = ((deadline - System.nanoTime()) / 1_000_000).coerceIn(1, 4_000).toInt()
            connection.connectTimeout = remaining; connection.readTimeout = remaining
            connection.setRequestProperty("Range", "bytes=$start-$end")
            connection.setRequestProperty("Accept-Encoding", "identity")
            connection.setRequestProperty("User-Agent", "IPTVPremium/1.0")
            val status = connection.responseCode
            if (status == 206) {
                val range = Regex("bytes (\\d+)-(\\d+)/(\\d+)").matchEntire(connection.getHeaderField("Content-Range").orEmpty())
                    ?: throw IOException("Faixa ausente")
                if (range.groupValues[1].toLong() != start || range.groupValues[2].toLong() > end) throw IOException("Faixa invalida")
                total = range.groupValues[3].toLong()
            } else if (status == 200 && start == 0L && connection.contentLengthLong in 1..minOf(blockSize.toLong(), maxBytes)) {
                total = connection.contentLengthLong
            } else throw IOException("Origem sem leitura parcial")
            val limit = minOf(end - start + 1, total - start).coerceAtLeast(0).toInt()
            val bytes = ByteArray(limit)
            var count = 0
            connection.inputStream.use { input ->
                while (count < limit) {
                    checkActive()
                    val n = input.read(bytes, count, limit - count)
                    if (n < 0) break
                    count += n; received += n
                    if (received > maxBytes) throw IOException("Limite de dados")
                }
            }
            if (count == 0) throw IOException("Faixa vazia")
            val result = if (count == bytes.size) bytes else bytes.copyOf(count)
            blocks[start] = result
            while (blocks.size > 4) blocks.remove(blocks.keys.first())
            return result
        } finally { connection.disconnect() }
    }
    @Synchronized override fun close() { closed = true; blocks.clear() }
}
