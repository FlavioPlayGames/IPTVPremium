package br.com.flaviotorres.iptvpremium.data.cache.importer

import android.os.SystemClock
import android.util.Log
import androidx.room.withTransaction
import br.com.flaviotorres.iptvpremium.data.cache.PlaylistCacheDatabase
import br.com.flaviotorres.iptvpremium.data.cache.PlaylistCacheGenerationManager
import br.com.flaviotorres.iptvpremium.data.m3u.M3uCatalogParser
import br.com.flaviotorres.iptvpremium.data.m3u.M3uCatalogWriter
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.DeferredM3uEpisodes
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import java.io.*
import kotlinx.coroutines.*

class M3uCacheImporter internal constructor(
    private val httpClient:PlaylistHttpClient,
    private val dao:br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao,
    private val generationManager:PlaylistCacheGenerationManager,
    private val deferredEpisodes:DeferredM3uEpisodes,
    private val workRoot:File,
    private val onXmltvSources:(String,String,List<String>)->Unit,
    private val publish:suspend (File,String,String,M3uCatalogParser.Counts,()->Unit)->Unit
) {
    constructor(httpClient:PlaylistHttpClient,database:PlaylistCacheDatabase,
                generationManager:PlaylistCacheGenerationManager,deferredEpisodes:DeferredM3uEpisodes,
                workRoot:File,onXmltvSources:(String,String,List<String>)->Unit={_,_,_->}) :
        this(httpClient,database.playlistCacheDao(),generationManager,deferredEpisodes,workRoot,onXmltvSources,
            {spool,playlist,generation,counts,ensure->
                database.withTransaction {
                    M3uCatalogWriter.write(database.openHelper.writableDatabase,spool,playlist,generation,counts,ensure)
                }
            })

    suspend fun import(playlistId:String,playlistUrl:String,apiCovers:Boolean=true):String=withContext(Dispatchers.IO){
        require(playlistUrl.isNotBlank()){"A URL da lista M3U está vazia."}
        val started=SystemClock.elapsedRealtime()
        val generation=generationManager.beginImport(playlistId)
        val job=currentCoroutineContext().job;val ensure={job.ensureActive()}
        val session=File(workRoot,generation)
        var episodes:br.com.flaviotorres.iptvpremium.data.m3uepisodes.M3uEpisodeSource.Builder?=null
        var stage="start"
        suspend fun <T> phase(name:String,body:suspend()->T):T {
            stage=name;val start=SystemClock.elapsedRealtime()
            return try{ensure();body()}finally{Log.i(TAG,"stage=$name durationMs=${SystemClock.elapsedRealtime()-start}")}
        }
        Log.i(TAG,"stage=start revision=M3U_OFFICIAL_R1 status=RUNNING")
        try {
            check(session.mkdirs()){"WORK_DIRECTORY"}
            deferredEpisodes.prune(dao,playlistId)
            val source=File(session,"source.m3u");val spool=File(session,"catalog.bin")
            phase("download"){
                FileOutputStream(source).use{raw->
                    val writer=BufferedWriter(OutputStreamWriter(raw,Charsets.UTF_8),128*1024)
                    httpClient.readLines(playlistUrl){line->ensure();writer.write(line);writer.newLine()}
                    writer.flush();raw.fd.sync()
                }
            }
            check(workRoot.usableSpace>=maxOf(32L*1024*1024,source.length()*3)){"SPACE"}
            episodes=deferredEpisodes.begin(playlistId,generation)
            var xmltv=emptyList<String>()
            val counts=phase("prepare"){
                FileOutputStream(spool).use{raw->
                    val output=DataOutputStream(BufferedOutputStream(raw,256*1024))
                    val result=source.bufferedReader(Charsets.UTF_8,256*1024).use{reader->
                        M3uCatalogParser.prepare(reader,output,playlistId,generation,playlistUrl,{xmltv=it},ensure,checkNotNull(episodes))
                    }
                    output.flush();raw.fd.sync();result
                }
            }
            phase("episodes_source"){
                checkNotNull(episodes).finish()
                check(deferredEpisodes.sourceCounts(playlistId,generation)==(counts.series to counts.episodes)){"EPISODE_SOURCE_COUNTS"}
            }
            if(apiCovers) phase("series_covers") {
                val matched=br.com.flaviotorres.iptvpremium.data.m3u.M3uProviderSeriesCovers.prepare(httpClient,spool,playlistId,generation,playlistUrl)
                Log.i(TAG,"stage=series_covers status=OK matched=$matched")
            }
            phase("write"){
                publish(spool,playlistId,generation,counts,ensure)
            }
            phase("ready"){generationManager.markImportReady(playlistId,generation)}
            try{onXmltvSources(playlistId,playlistUrl,xmltv)}catch(cancelled:CancellationException){throw cancelled}
            catch(error:Exception){Log.w("XmltvEpg","discovery=metadata_unavailable error=${error.javaClass.simpleName}")}
            Log.i(TAG,"stage=summary revision=M3U_OFFICIAL_R1 status=OK wallMs=${SystemClock.elapsedRealtime()-started} entries=${counts.entries} channels=${counts.channels} movies=${counts.movies} series=${counts.series} categories=${counts.categories} deferredEpisodes=${counts.episodes} episodesRoom=0")
            generation
        }catch(error:Throwable){
            Log.w(TAG,"stage=$stage status=ERROR error=${error.javaClass.simpleName}")
            withContext(NonCancellable+Dispatchers.IO){
                try{
                    episodes?.close()
                    val status=runCatching{dao.generationStatus(playlistId,generation)}.getOrNull()
                    if(status!=null&&status !in setOf("READY","ACTIVE"))deferredEpisodes.discard(playlistId,generation)
                }catch(cleanup:Throwable){if(cleanup!==error)error.addSuppressed(cleanup)}
                try{generationManager.discardImport(playlistId,generation)}catch(cleanup:Throwable){if(cleanup!==error)error.addSuppressed(cleanup)}
            }
            throw error
        }finally{withContext(NonCancellable+Dispatchers.IO){session.deleteRecursively()}}
    }
    companion object{const val TAG="M3uOfficialPerf"}
}
