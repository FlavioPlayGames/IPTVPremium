package br.com.flaviotorres.iptvpremium.ui.movies

import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import br.com.flaviotorres.iptvpremium.data.cache.PosterKind

/** Stable catalogue rule for both formats: load only the image URL attached to this item.
 * Metadata lookup remains available in detail screens; it does not replace a catalogue cover.
 */
@Suppress("UNUSED_PARAMETER")
internal suspend fun loadCatalogPoster(context: Context, url: String?, kind: PosterKind,
    name: String, year: Int?, tmdbId: String?, imdbId: String?): ImageBitmap? =
    MoviePosterLoader.loadWithRetry(context, url, kind)
