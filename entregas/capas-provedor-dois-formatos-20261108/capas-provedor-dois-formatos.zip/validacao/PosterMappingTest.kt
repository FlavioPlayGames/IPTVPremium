package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.cache.importer.*
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.*
import br.com.flaviotorres.iptvpremium.data.m3u.*
import br.com.flaviotorres.iptvpremium.data.parser.DefaultXtreamParser
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.*
import java.nio.file.Files
private class Source:PlaylistHttpClient {
 override suspend fun get(url:String):String=error("No HTTP get")
 val lines=listOf("#EXTM3U",
 """#EXTINF:-1 group-title="Séries A" tvg-logo="http://example.invalid/cover1.jpg",Série A S01E01""","http://example.invalid/series/1",
 """#EXTINF:-1 group-title="Séries B" tvg-logo="http://example.invalid/cover-b.jpg",Série B S01E01""","http://example.invalid/series/2",
 """#EXTINF:-1 group-title="Filmes" tvg-logo="http://example.invalid/movie.jpg",Filme A (2020)""","http://example.invalid/movie/1.mp4",
 """#EXTINF:-1 group-title="Séries A" tvg-logo="http://example.invalid/cover-last.jpg",Série A S01E02""","http://example.invalid/series/3",
 """#EXTINF:-1 group-title="Séries B" tvg-logo="",Série B S01E02""","http://example.invalid/series/4")
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit){for(s in lines)onLine(s)}
}
private fun posters(d:RealSqlDb,table:String,id:String)=d.c.createStatement().use{it.executeQuery("SELECT $id,name,posterUrl FROM $table ORDER BY $id").use{r->buildList{while(r.next())add(listOf(r.getString(1),r.getString(2),r.getString(3)))}}}
fun main()=runBlocking {
 val root=Files.createTempDirectory("old-poster-rule").toFile()
 try{
  RealSqlDb(File(root,"old.db").toPath()).use{old->RealSqlDb(File(root,"new.db").toPath()).use{now->
   OldM3uCacheImporter(Source(),old.dao,PlaylistCacheGenerationManager(old.dao),batchSize=2).import("p","http://example.invalid/list")
   val store=DeferredM3uEpisodes(File(root,"episodes"));val bridge=NativeBridge(now.c)
   val g=M3uCacheImporter(Source(),now.dao,PlaylistCacheGenerationManager(now.dao),store,File(root,"work"),{_,_,_->}){spool,p,g,c,ensure->
    now.c.autoCommit=false
    try{M3uCatalogWriter.write(bridge.database,spool,p,g,c,ensure);now.c.commit()}catch(e:Throwable){now.c.rollback();throw e}finally{now.c.autoCommit=true}
   }.import("p","http://example.invalid/list")
   check(posters(old,"cached_movies","movieId")==posters(now,"cached_movies","movieId"));println("PASS M3U film IDs, titles and tvg-logo associations equal the supplied old native importer")
   check(posters(now,"cached_series","seriesId").associate{it[1] to it[2]}==mapOf("Série A" to null,"Série B" to "http://example.invalid/cover-b.jpg"));println("PASS pure M3U keeps stable provider series art and refuses varying episode art")
   check(now.count("cached_episodes")==0&&store.sourceCounts("p",g)==(2 to 4L));println("PASS restoring old artwork rule keeps official M3U episodes deferred and fully indexed")
  }}
  val parser=DefaultXtreamParser()
  repeat(30){i->
   val movie=parser.movieFromCatalogItem(JSONObject("""{"stream_id":$i,"name":"Movie $i","stream_icon":"http://example.invalid/movie-$i.jpg","cover":"http://example.invalid/wrong.jpg"}"""))!!
   check(movie.id==i.toString()&&movie.posterUrl=="http://example.invalid/movie-$i.jpg")
   val series=parser.seriesFromCatalogItem(JSONObject("""{"series_id":$i,"name":"Series $i","cover":"http://example.invalid/series-$i.jpg","stream_icon":"http://example.invalid/wrong.jpg"}"""))!!
   check(series.id==i.toString()&&series.posterUrl=="http://example.invalid/series-$i.jpg")
  };println("PASS Xtream film stream_icon and series cover stay attached to their own IDs across 60 records")
  check(parser.seriesFromCatalogItem(JSONObject("""{"series_id":99,"name":"Missing","stream_icon":"http://example.invalid/other.jpg"}"""))!!.posterUrl==null)
  println("PASS missing Xtream cover is not replaced by an unrelated metadata field")
 }finally{root.deleteRecursively()}
 Unit
}
