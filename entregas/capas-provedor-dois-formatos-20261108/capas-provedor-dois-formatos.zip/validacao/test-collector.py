from pathlib import Path
import os,subprocess,uuid
w=Path('/workspace/capas-regra-antiga');root=w/'collector-tests'/uuid.uuid4().hex;root.mkdir(parents=True)
adb=root/'fake-adb';adb.write_text('''#!/usr/bin/env python3
import sys,time
a=sys.argv[1:]
if a==['devices']:print('List of devices attached\\nfake-device device');sys.exit(0)
if 'logcat'in a:
 old='11-08 00:00:00.000 1 1 I M3uOfficialPerf: stage=start status=RUNNING'
 print(old,flush=True)
 if '-d'in a:sys.exit(0)
 time.sleep(.5)
 print('XtreamWritePerf: type=movies rows=2000 transactionLimit=2000 durationMs=10',flush=True)
 print('M3uSourceSync: XTREAM_NOVA_TENTATIVA tentativa=2/4 pausaMs=500 motivo=IOException',flush=True)
 print('M3uOfficialPerf: stage=prepare durationMs=42 url=https://secret password=secret',flush=True)
 print('M3uOfficialPerf: stage=series_covers status=OK matched=20',flush=True)
 print('M3uOfficialPerf: stage=summary revision=M3U_OFFICIAL_R1 status=OK wallMs=100 deferredEpisodes=100 episodesRoom=0',flush=True)
 print('M3uSourceSync: SYNC_RESUMO tipo=M3U resultado=SUCESSO duracaoMs=101',flush=True)
 print('M3uEpisodesPerf: stage=load status=OK episodes=17 durationMs=24',flush=True)
 print('M3uEpisodesPerf: stage=cache status=OK',flush=True)
 time.sleep(5)
''');adb.chmod(0o755)
env=dict(os.environ,XDG_CACHE_HOME='/workspace/storage-toolchain/xdg-cache',XDG_DATA_HOME='/workspace/storage-toolchain/xdg-data',XDG_CONFIG_HOME='/workspace/storage-toolchain/xdg-config')
pw='/workspace/storage-toolchain/powershell/pwsh';s='/workspace/outputs/capas-provedor-dois-formatos/Medir-Importacao.ps1'
r=subprocess.run([pw,'-NoProfile','-File',s,'-AdbPath',str(adb),'-PastaSaida',str(root),'-SomenteImportacao'],env=env,capture_output=True,text=True,timeout=20)
assert r.returncode==0,(r.stdout,r.stderr)
f=list(root.glob('diagnostico*.txt'));assert len(f)==1;t=f[0].read_text(encoding='utf-8-sig')
assert 'secret'not in t and 'https://'not in t and 'password'not in t
for field in ['IMPORTACAO_TERMINADA','stage=prepare durationMs=42','revision=M3U_OFFICIAL_R1','episodesRoom=0','episodes=17 durationMs=24','stage=cache','stage=series_covers','matched=20','type=movies rows=2000 transactionLimit=2000 durationMs=10','tentativa=2/4 pausaMs=500']:assert field in t,(field,t)
print('PASS fake ADB captures official import completion and episode load/cache metrics without leaking private data')
