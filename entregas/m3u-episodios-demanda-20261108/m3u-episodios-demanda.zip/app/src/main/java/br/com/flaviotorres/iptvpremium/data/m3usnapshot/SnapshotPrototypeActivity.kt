package br.com.flaviotorres.iptvpremium.data.m3usnapshot

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import android.view.Gravity
import br.com.flaviotorres.iptvpremium.data.storage.PlaylistStorage
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import br.com.flaviotorres.iptvpremium.data.remote.DefaultPlaylistHttpClient
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

/** ADB-only performance experiment; no launcher entry and no connection to the active catalogue UI. */
class SnapshotPrototypeActivity:Activity(){
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val text=TextView(this).apply{setTextColor(0xffffffff.toInt());setBackgroundColor(0xff122033.toInt());textSize=23f;gravity=Gravity.CENTER;setPadding(40,30,40,30)}
        setContentView(text)
        text.text="Protótipo independente de M3U\nPreparando teste…\nVoltar cancela o teste."
        // A recreated activity does not automatically repeat a download after rotation/process recovery.
        if(savedInstanceState!=null){text.text="Teste interrompido. Execute novamente pelo PowerShell.";return}
        scope.launch{
            val started=System.nanoTime()
            try{
                if(intent.getBooleanExtra("clear_prototype",false)){
                    SnapshotRunner.clear(applicationContext)
                    text.text="Arquivos do protótipo removidos.\nO catálogo do aplicativo foi preservado.\nPressione Voltar para retornar."
                    return@launch
                }
                val selection=PlaylistStorage(applicationContext).selection.first()
                val source=selection.playlists.singleOrNull{it.id==selection.activeId&&it.isEnabled} as? PlaylistSource.M3u
                if(source==null){text.text="Selecione uma lista M3U no aplicativo antes de executar este teste.";android.util.Log.i(SnapshotRunner.TAG,"stage=summary status=NO_M3U");return@launch}
                val labels=mapOf("cleanup" to "Limpando arquivos de testes interrompidos", "download" to "Baixando a lista", "prepare" to "Preparando os registros em disco", "bootstrap" to "Preparando o catálogo separado", "defer_indexes" to "Preparando a carga", "load" to "Gravando o catálogo", "indexes" to "Criando os índices", "validate" to "Conferindo os dados", "ready" to "Finalizando o banco", "room_validate" to "Validando a leitura pelo aplicativo", "checkpoint" to "Confirmando a gravação final", "finalize" to "Finalizando os arquivos", "publish" to "Publicando o protótipo", "complete" to "Concluído")
                val result=br.com.flaviotorres.iptvpremium.core.storage.StorageMaintenance.foregroundImport {
                    SnapshotRunner(applicationContext,DefaultPlaylistHttpClient()).run(source.id,source.playlistUrl){stage->runOnUiThread{text.text="Protótipo independente de M3U\n${labels[stage]?:stage}\nVoltar cancela o teste."}}
                }
                val total=(System.nanoTime()-started)/1_000_000
                android.util.Log.i(SnapshotRunner.TAG,"stage=complete status=OK totalMs=$total")
                showResult(result,total)

            }catch(cancelled:CancellationException){android.util.Log.i(SnapshotRunner.TAG,"stage=activity status=CANCELLED");throw cancelled}
            catch(error:Exception){android.util.Log.i(SnapshotRunner.TAG,"stage=activity status=ERROR code=FAILED");text.text="Não foi possível concluir o protótipo.\nO catálogo do aplicativo foi preservado.\nEnvie o diagnóstico do PowerShell."}
        }
    }
    private fun showResult(result:SnapshotRunner.Result,total:Long){
        val layout=android.widget.LinearLayout(this).apply{orientation=android.widget.LinearLayout.VERTICAL;setPadding(35,25,35,25);setBackgroundColor(0xff122033.toInt())}
        val title=TextView(this).apply{setTextColor(0xffffffff.toInt());textSize=22f;text="Catálogo M3U pronto em ${total/1000.0} s\nFilmes: ${result.counts[2]} · Séries: ${result.counts[3]}\n${result.pendingEpisodes} registros de episódios disponíveis sob demanda.\nEpisódios no banco inicial: ${result.counts[4]}"}
        layout.addView(title)
        val button=android.widget.Button(this).apply{text="Escolher uma série e testar episódios";setOnClickListener{showSeries(result,total)}}
        layout.addView(button);setContentView(layout);button.requestFocus()
    }
    private fun showSeries(result:SnapshotRunner.Result,total:Long){
        val runner=SnapshotRunner(applicationContext,DefaultPlaylistHttpClient())
        scope.launch{
            try{
                val series=runner.listSeries(result)
                val list=android.widget.ListView(this@SnapshotPrototypeActivity).apply{setBackgroundColor(0xff122033.toInt())}
                list.adapter=object:android.widget.ArrayAdapter<String>(this@SnapshotPrototypeActivity,android.R.layout.simple_list_item_1,series.map{it.second}){
                    override fun getView(position:Int,convertView:android.view.View?,parent:android.view.ViewGroup):android.view.View=super.getView(position,convertView,parent).also{(it as TextView).setTextColor(0xffffffff.toInt());it.textSize=20f}
                }
                list.setOnItemClickListener{_,_,position,_->
                    scope.launch{
                        val loading=TextView(this@SnapshotPrototypeActivity).apply{setTextColor(0xffffffff.toInt());setBackgroundColor(0xff122033.toInt());textSize=23f;gravity=Gravity.CENTER;text="Carregando somente os episódios desta série…"};setContentView(loading)
                        try{
                            val preview=runner.openSeries(result,series[position].first)
                            val layout=android.widget.LinearLayout(this@SnapshotPrototypeActivity).apply{orientation=android.widget.LinearLayout.VERTICAL;setPadding(30,20,30,20);setBackgroundColor(0xff122033.toInt())}
                            layout.addView(TextView(this@SnapshotPrototypeActivity).apply{setTextColor(0xffffffff.toInt());textSize=20f;text="${preview.title}\nEpisódios em cache: ${preview.count}\n"+preview.examples.joinToString("\n")})
                            val back=android.widget.Button(this@SnapshotPrototypeActivity).apply{text="Escolher outra série";setOnClickListener{showSeries(result,total)}}
                            layout.addView(back);setContentView(layout);back.requestFocus()
                        }catch(cancelled:CancellationException){throw cancelled}
                        catch(error:Exception){android.util.Log.i(SnapshotRunner.TAG,"stage=episodes_open status=ERROR");loading.text="Não foi possível carregar os episódios. Pressione Voltar e envie o diagnóstico."}
                    }
                }
                setContentView(list);list.requestFocus()
            }catch(cancelled:CancellationException){throw cancelled}
            catch(error:Exception){android.util.Log.i(SnapshotRunner.TAG,"stage=episodes_open status=ERROR");showResult(result,total)}
        }
    }
    override fun onDestroy(){scope.cancel();super.onDestroy()}
}
