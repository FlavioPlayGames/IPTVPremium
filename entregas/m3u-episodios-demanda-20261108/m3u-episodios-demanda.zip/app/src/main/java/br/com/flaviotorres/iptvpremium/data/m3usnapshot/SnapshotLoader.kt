package br.com.flaviotorres.iptvpremium.data.m3usnapshot

import androidx.sqlite.db.SupportSQLiteDatabase
import java.io.*

/** The caller supplies an isolated, unpublished database, never the application's active database. */
internal object SnapshotLoader {
    data class Result(val rows:LongArray,val commitNs:Long)
    fun load(db:SupportSQLiteDatabase,spool:File,playlist:String,generation:String,ensure:()->Unit={},progress:(Long)->Unit={}):Result {
        val statements=SnapshotSchema.inserts.map{db.compileStatement(it)}
        val attempted=LongArray(5);var commit=0L
        try {
            db.beginTransactionNonExclusive()
            try {
                db.execSQL("INSERT INTO playlist_cache_generations VALUES(?,?,'IMPORTING',?,NULL,NULL)",arrayOf(playlist,generation,System.currentTimeMillis()))
                DataInputStream(BufferedInputStream(FileInputStream(spool),256*1024)).use{input->
                    check(input.readInt()==0x4D335331){"INVALID_SPOOL"}
                    var total=0L
                    while(true){
                        ensure()
                        val record=SnapshotParser.read(input)?:break
                        val (kind,row)=record;val statement=statements[kind]
                        for(i in row.indices)when(val value=row[i]){null->statement.bindNull(i+1);is String->statement.bindString(i+1,value);is Long->statement.bindLong(i+1,value);else->error("INVALID_FIELD")}
                        statement.executeInsert();attempted[kind]++;total++
                        if(total%5000==0L)progress(total)
                    }
                }
                ensure();db.setTransactionSuccessful()
            } finally {val started=System.nanoTime();db.endTransaction();commit=System.nanoTime()-started}
        } finally {statements.forEach{it.close()}}
        return Result(attempted,commit)
    }
    fun indexes(db:SupportSQLiteDatabase,ensure:()->Unit={}){
        db.beginTransactionNonExclusive()
        try{SnapshotSchema.indexes.forEach{ensure();db.execSQL(it)};ensure();db.setTransactionSuccessful()}
        finally{db.endTransaction()}
    }
    fun validate(db:SupportSQLiteDatabase,expected:SnapshotParser.Counts,deferredEpisodes:Boolean=false):LongArray {
        db.query("PRAGMA quick_check").use{check(it.moveToFirst()&&it.getString(0)=="ok"&&!it.moveToNext()){"INTEGRITY"}}
        val counts=SnapshotSchema.names.map{table->db.query("SELECT COUNT(*) FROM $table").use{check(it.moveToFirst());it.getLong(0)}}.toLongArray()
        check(counts[0]==expected.categories.toLong()&&counts[3]==expected.series.toLong()){"COUNTS"}
        for((actual,input)in listOf(counts[1]to expected.channels,counts[2]to expected.movies,counts[4]to if(deferredEpisodes)0L else expected.episodes))check(actual<=input&&(input==0L||actual>0L)){"COUNTS"}
        db.query("SELECT 1 FROM cached_episodes e LEFT JOIN cached_series s ON s.playlistId=e.playlistId AND s.generationId=e.generationId AND s.seriesId=e.seriesId WHERE s.seriesId IS NULL LIMIT 1").use{check(!it.moveToFirst()){"EPISODE_RELATION"}}
        for((table,type)in listOf("cached_channels" to "LIVE_TV","cached_movies" to "MOVIES","cached_series" to "SERIES")){
            db.query("SELECT 1 FROM $table e LEFT JOIN cached_categories c ON c.playlistId=e.playlistId AND c.generationId=e.generationId AND c.categoryId=e.categoryId AND c.type=? WHERE e.categoryId IS NOT NULL AND c.categoryId IS NULL LIMIT 1",arrayOf(type)).use{check(!it.moveToFirst()){"CATEGORY_RELATION"}}
        }
        return counts
    }
    fun checkpoint(db:SupportSQLiteDatabase){
        db.query("PRAGMA wal_checkpoint(TRUNCATE)").use{check(it.moveToFirst()&&it.getInt(0)==0){"CHECKPOINT_BUSY"}}
    }
}
