package br.com.flaviotorres.iptvpremium.data.m3uepisodes

import android.content.Context
import android.util.AtomicFile
import android.util.Log
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import java.io.*
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class DeferredM3uEpisodes(private val root:File){
    private val locks=Array(16){Mutex()}
    private fun directory(playlist:String,generation:String)=File(File(root,M3uEpisodeSource.hash(playlist)),M3uEpisodeSource.hash(generation))
    fun begin(playlist:String,generation:String):M3uEpisodeSource.Builder {
        val dir=directory(playlist,generation);check(!dir.exists()&&(dir.mkdirs()||dir.isDirectory)){"EPISODE_SOURCE_EXISTS"}
        try{
            FileOutputStream(File(dir,"generation")).use{it.write(generation.toByteArray(Charsets.UTF_8));it.fd.sync()}
            return M3uEpisodeSource.Builder(dir,playlist,generation)
        }catch(error:Throwable){dir.deleteRecursively();throw error}
    }
    fun discard(playlist:String,generation:String){directory(playlist,generation).deleteRecursively()}
    fun sourceCounts(playlist:String,generation:String):Pair<Int,Long>? {
        val i=M3uEpisodeSource.index(directory(playlist,generation),playlist,generation)?:return null
        return i.series.size to i.series.values.sumOf{it.count.toLong()}
    }
    suspend fun ensure(cacheDao:PlaylistCacheDao,playlist:String,generation:String,series:String):Boolean=withContext(Dispatchers.IO){
        val key="$playlist\u0000$generation\u0000$series"
        locks[(key.hashCode()and Int.MAX_VALUE)%locks.size].withLock {
            val dir=directory(playlist,generation)
            if(!File(dir,"series.index").isFile)return@withLock false
            val done=AtomicFile(File(dir,"done-${M3uEpisodeSource.hash(series)}"))
            if(runCatching{done.openRead().use{it.read()==1&&it.read()==-1}}.getOrDefault(false)){
                Log.i("M3uEpisodesPerf","stage=cache status=OK")
                return@withLock true
            }
            val start=System.nanoTime();val job=currentCoroutineContext().job
            val index=M3uEpisodeSource.index(dir,playlist,generation)?:return@withLock false
            val prepared=M3uEpisodeSource.prepare(dir,index,series){job.ensureActive()}?:return@withLock false
            val published=prepared.use{cacheDao.insertDeferredM3uSeries(playlist,generation,it)}
            if(published){
                var output:FileOutputStream?=null
                try{output=done.startWrite();output.write(1);done.finishWrite(output)}
                catch(error:IOException){
                    output?.let{runCatching{done.failWrite(it)}}
                    // Rows already committed successfully. A cache marker failure must not hide them.
                    Log.i("M3uEpisodesPerf","stage=cache_marker status=ERROR")
                }
                Log.i("M3uEpisodesPerf","stage=load status=OK episodes=${index.series.getValue(series).count} durationMs=${(System.nanoTime()-start)/1_000_000}")
            }
            published
        }
    }
    /** Remove only sources whose generation has already been removed from the normal catalog. */
    suspend fun prune(cacheDao:PlaylistCacheDao,playlist:String){
        val parent=File(root,M3uEpisodeSource.hash(playlist))
        for(dir in parent.listFiles().orEmpty().take(32)){
            currentCoroutineContext().ensureActive()
            if(!dir.isDirectory||!Regex("[0-9a-f]{64}").matches(dir.name))continue
            val generation=runCatching{File(dir,"generation").readText(Charsets.UTF_8)}.getOrNull()?:continue
            if(generation.length<=200&&M3uEpisodeSource.hash(generation)==dir.name&&cacheDao.generationStatus(playlist,generation)==null)dir.deleteRecursively()
        }
    }
}

internal object DeferredM3uEpisodeAccess {
    @Volatile private var store:DeferredM3uEpisodes?=null
    fun initialize(context:Context):DeferredM3uEpisodes=store?:synchronized(this){store?:DeferredM3uEpisodes(File(context.applicationContext.filesDir,"m3u_episode_sources")).also{store=it}}
    suspend fun ensure(dao:PlaylistCacheDao,playlist:String,generation:String,series:String){store?.ensure(dao,playlist,generation,series)}
}
