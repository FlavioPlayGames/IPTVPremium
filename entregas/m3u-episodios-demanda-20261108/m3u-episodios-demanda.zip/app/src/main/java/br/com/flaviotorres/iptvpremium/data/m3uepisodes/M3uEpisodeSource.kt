package br.com.flaviotorres.iptvpremium.data.m3uepisodes

import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedEpisodeEntity
import java.io.*
import java.util.UUID
import java.security.MessageDigest

/** Compact, immutable episode source. Only a tail/count per series is kept during import. */
object M3uEpisodeSource {
    internal const val MAGIC=0x4D334531
    internal fun hash(value:String)=MessageDigest.getInstance("SHA-256").digest(value.toByteArray()).joinToString(""){"%02x".format(it)}
    internal fun writeString(out:DataOutput,value:String?){
        if(value==null){out.writeInt(-1);return}
        val bytes=value.toByteArray(Charsets.UTF_8);out.writeInt(bytes.size);out.write(bytes)
    }
    internal fun readString(input:DataInput):String? {
        val size=input.readInt();if(size == -1)return null
        require(size in 0..64*1024*1024){"EPISODE_FIELD_LENGTH"}
        return ByteArray(size).also{input.readFully(it)}.toString(Charsets.UTF_8)
    }
    internal data class Tail(var offset:Long,var count:Int)
    internal data class Index(val playlist:String,val generation:String,val bytes:Long,val series:Map<String,Tail>)
    internal fun index(directory:File,playlist:String,generation:String):Index? {
        val file=File(directory,"series.index");if(!file.isFile)return null
        return DataInputStream(BufferedInputStream(FileInputStream(file))).use{input->
            check(input.readInt()==MAGIC){"EPISODE_INDEX_VERSION"}
            val p=readString(input);val g=readString(input)
            check(p==playlist&&g==generation){"EPISODE_INDEX_IDENTITY"}
            val bytes=input.readLong();val count=input.readInt();require(count in 0..1_000_000)
            val map=HashMap<String,Tail>()
            repeat(count){
                val sid=checkNotNull(readString(input));val offset=input.readLong();val rows=input.readInt()
                check(rows>0&&rows.toLong()<=bytes/28&&offset in 0 until bytes&&map.put(sid,Tail(offset,rows))==null){"EPISODE_INDEX_RANGE"}
            }
            check(input.read()==-1&&File(directory,"episodes.records").length()==bytes){"EPISODE_INDEX_LENGTH"}
            Index(playlist,generation,bytes,map)
        }
    }
    class Builder internal constructor(private val directory:File,private val playlist:String,private val generation:String):Closeable {
        private val raw=FileOutputStream(File(directory,"episodes.records"))
        private val out=DataOutputStream(BufferedOutputStream(raw,256*1024))
        private val tails=LinkedHashMap<String,Tail>()
        private var position=0L;private var closed=false
        var total=0L;private set
        fun append(series:String,season:Int?,episode:Int?,name:String,poster:String?,url:String){
            check(!closed)
            // Encode only the payload needed on opening. IDs and Room entities are deferred.
            val n=name.toByteArray(Charsets.UTF_8);val p=poster?.toByteArray(Charsets.UTF_8);val u=url.toByteArray(Charsets.UTF_8)
            require(n.size<=64*1024*1024&&(p==null||p.size<=64*1024*1024)&&u.size<=64*1024*1024){"EPISODE_FIELD_LENGTH"}
            val previous=tails[series]
            out.writeLong(previous?.offset?:-1L);out.writeInt(season?:-1);out.writeInt(episode?:-1)
            for(bytes in arrayOf(n,p,u)){out.writeInt(bytes?.size?:-1);if(bytes!=null)out.write(bytes)}
            tails[series]=Tail(position,Math.addExact(previous?.count?:0,1))
            position+=28L+n.size+(p?.size?:0)+u.size
            total++
        }
        fun finish(){
            check(!closed);out.flush();raw.fd.sync();out.close();closed=true
            check(File(directory,"episodes.records").length()==position)
            val tmp=File(directory,"series.index.tmp")
            FileOutputStream(tmp).use{file->val data=DataOutputStream(BufferedOutputStream(file));data.writeInt(MAGIC);writeString(data,playlist);writeString(data,generation);data.writeLong(position);data.writeInt(tails.size)
                tails.forEach{(sid,tail)->writeString(data,sid);data.writeLong(tail.offset);data.writeInt(tail.count)}
                data.flush();file.fd.sync()
            }
            check(tmp.renameTo(File(directory,"series.index"))){"EPISODE_INDEX_PUBLISH"}
        }
        override fun close(){if(!closed){closed=true;out.close()}}
        fun abort(){close();directory.deleteRecursively()}
    }
    internal fun prepare(directory:File,index:Index,series:String,ensure:()->Unit):M3uEpisodeBatchSource? {
        val tail=index.series[series]?:return null
        val offsets=LongArray(tail.count)
        val prepared=File.createTempFile("selected-", ".episodes",directory)
        try {
            RandomAccessFile(File(directory,"episodes.records"),"r").use{records->
                var offset=tail.offset
                for(i in offsets.indices){ensure();check(offset in 0 until index.bytes){"EPISODE_CHAIN_RANGE"};offsets[offsets.lastIndex-i]=offset;records.seek(offset);val previous=records.readLong();check(previous == -1L||previous<offset){"EPISODE_CHAIN_ORDER"};offset=previous}
                check(offset == -1L){"EPISODE_CHAIN_COUNT"}
                FileOutputStream(prepared).use{file->
                    val data=DataOutputStream(BufferedOutputStream(file));data.writeInt(MAGIC)
                    for(at in offsets){
                        ensure();records.seek(at+8);val season=records.readInt();val episode=records.readInt()
                        val name=checkNotNull(readString(records));val poster=readString(records);val url=checkNotNull(readString(records))
                        val id=UUID.nameUUIDFromBytes("episode:$url:$name".toByteArray(Charsets.UTF_8)).toString()
                        data.writeByte(1);writeString(data,id);data.writeInt(season);data.writeInt(episode);writeString(data,name);writeString(data,poster);writeString(data,url)
                    }
                    data.writeByte(0);data.flush()
                }
            }
            return M3uEpisodeBatchSource(prepared,index.playlist,index.generation,series,tail.count)
        }catch(error:Throwable){prepared.delete();throw error}
    }
}

/** Prepared one-series rows; the Room transaction reads small collections, without HTTP or M3U parsing. */
class M3uEpisodeBatchSource internal constructor(private val file:File,private val playlist:String,private val generation:String,private val series:String,private val expected:Int):Closeable {
    private val input=DataInputStream(BufferedInputStream(FileInputStream(file)))
    private var read=0;private var finished=false
    init {try{check(input.readInt()==M3uEpisodeSource.MAGIC)}catch(error:Throwable){input.close();throw error}}
    fun next(limit:Int):List<CachedEpisodeEntity>{
        require(limit in 1..250);if(finished)return emptyList()
        val rows=ArrayList<CachedEpisodeEntity>(limit)
        while(rows.size<limit){
            when(input.readByte().toInt()){
                0->{check(input.read()==-1&&read==expected){"EPISODE_PREPARED_COUNT"};finished=true;break}
                1->{val id=checkNotNull(M3uEpisodeSource.readString(input));val season=input.readInt().takeUnless{it == -1};val episode=input.readInt().takeUnless{it == -1};val name=checkNotNull(M3uEpisodeSource.readString(input));val poster=M3uEpisodeSource.readString(input);val url=checkNotNull(M3uEpisodeSource.readString(input))
                    rows+=CachedEpisodeEntity(playlist,generation,id,series,season,episode,name,url,poster,null);read++;check(read<=expected)}
                else->error("EPISODE_PREPARED_FORMAT")
            }
        }
        return rows
    }
    override fun close(){try{input.close()}finally{file.delete()}}
}
