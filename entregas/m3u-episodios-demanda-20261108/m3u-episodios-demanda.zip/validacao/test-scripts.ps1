$ErrorActionPreference='Stop'
$folder='/workspace/outputs/m3u-episodios-demanda'
foreach($f in Get-ChildItem -LiteralPath $folder -Filter '*.ps1'){
 $errors=$null;$tokens=$null
 [System.Management.Automation.Language.Parser]::ParseFile($f.FullName,[ref]$tokens,[ref]$errors)>$null
 if($errors.Count){throw ($errors|Out-String)}
}
Write-Output 'PASS PowerShell syntax'
$text=[IO.File]::ReadAllText((Join-Path $folder 'Medir-Importacao-M3U.ps1'))
$start=$text.IndexOf('function Safe-Metrics');$end=$text.IndexOf('# Exclude the last historical line')
Invoke-Expression $text.Substring($start,$end-$start)
$safe=@(Safe-Metrics @('IPTV_PERF: stage=group status=OK startNs=123 endNs=456 beginUs=100 endUs=200 bodyMeasured=1 url=https://private password=secret','IPTV_PERF: stage=config revision=M3U_GROUP_R1 batchSize=250 transactionBatches=4','IPTV_PERF: stage=PRIVATE type=PRIVATE entries=private','IPTV_PERF: stage=category type=SERIES categoryIndex=2 entries=99','Other: stage=group entries=22'))
if($safe.Count -ne 3){throw 'Unexpected line count'}
if(($safe -join ' ') -match 'private|secret|https|password|PRIVATE'){throw 'Unexpected data leaked'}
foreach($field in @('stage=group','beginUs=100','endUs=200','revision=M3U_GROUP_R1','transactionBatches=4','stage=category','type=SERIES','categoryIndex=2')){if(-not(($safe -join ' ').Contains($field))){throw ('Missing '+$field)}}
Write-Output 'PASS strict metrics allowlist accepts new fields and rejects links, credentials and unknown enums'
