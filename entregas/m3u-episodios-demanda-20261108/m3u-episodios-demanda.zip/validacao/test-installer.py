from pathlib import Path
import json,subprocess,os,uuid,hashlib
w=Path('/workspace/m3u-episodios-demanda');o=Path('/workspace/outputs/m3u-episodios-demanda');m=json.loads((o/'manifest.json').read_text());root=w/'installer-tests'/uuid.uuid4().hex
pw='/workspace/storage-toolchain/powershell/pwsh';env=dict(os.environ,XDG_CACHE_HOME='/workspace/storage-toolchain/xdg-cache',XDG_DATA_HOME='/workspace/storage-toolchain/xdg-data',XDG_CONFIG_HOME='/workspace/storage-toolchain/xdg-config');logs=[]
def run(script,r):return subprocess.run([pw,'-NoProfile','-File',str(o/script),'-Projeto',str(r)],capture_output=True,text=True,env=env)
def sha(p):return hashlib.sha256(p.read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()).hexdigest()
for case in ['normal','unknown','corrupt','undo-conflict']:
 r=root/case;r.mkdir(parents=True);(r/'gradlew.bat').write_text('fixture');before={}
 for e in m:
  if e['allowMissing']:continue
  suffix=e['path'].split('br/com/flaviotorres/iptvpremium/')[-1]
  src=w/'before'/suffix if e['path'].endswith('.kt') else w/'before/tv-performance.gradle'
  if not src.exists():src=o/e['path']
  p=r/e['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(src.read_bytes());before[e['path']]=p.read_bytes()
 if case=='unknown':
  p=r/m[0]['path'];p.write_bytes(p.read_bytes()+b'// custom');before[m[0]['path']]=p.read_bytes()
 asset=o/m[0]['path'];original=asset.read_bytes()
 if case=='corrupt':asset.write_bytes(original+b'bad')
 try:result=run('Aplicar.ps1',r)
 finally:asset.write_bytes(original)
 assert (result.returncode==0)==(case in ['normal','undo-conflict']),(case,result.stdout,result.stderr)
 if case in ['normal','undo-conflict']:
  assert all(sha(r/e['path'])==e['sha']for e in m)
  saved=list((r/'.m3u-episodios-demanda-backups').iterdir());assert len(saved)==1
  for path,data in before.items():
   if hashlib.sha256(data.replace(b'\r\n',b'\n')).hexdigest()!=next(e['sha']for e in m if e['path']==path):assert(saved[0]/path).read_bytes()==data
  assert run('Aplicar.ps1',r).returncode==0;assert len(list((r/'.m3u-episodios-demanda-backups').iterdir()))==1
  if case=='undo-conflict':
   changed=r/m[0]['path'];changed.write_bytes(changed.read_bytes()+b'// later change');current={e['path']:(r/e['path']).read_bytes()for e in m}
   assert run('Desfazer.ps1',r).returncode!=0;assert all((r/path).read_bytes()==data for path,data in current.items())
  else:
   undo=run('Desfazer.ps1',r);assert undo.returncode==0,(undo.stdout,undo.stderr)
   assert all((r/path).read_bytes()==data for path,data in before.items());assert all(not(r/e['path']).exists()for e in m if e['allowMissing'])
 else:
  assert all((r/path).read_bytes()==data for path,data in before.items());assert not(r/'.m3u-episodios-demanda-backups').exists()
 logs.append('PASS installer '+case)
(w/'installer-results.txt').write_text('\n'.join(logs)+'\n');print('\n'.join(logs))
