package br.com.flaviotorres.iptvpremium.data.cache
import androidx.room.RoomOpenDelegate
import androidx.room.EntityInsertAdapter
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.SQLiteStatement
import br.com.flaviotorres.iptvpremium.data.cache.dao.*
import br.com.flaviotorres.iptvpremium.data.cache.importer.*
import br.com.flaviotorres.iptvpremium.data.cache.entity.*
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import java.sql.*
import java.lang.reflect.*
import java.nio.file.*
import kotlinx.coroutines.*
internal class SqlConnection(val raw:Connection):SQLiteConnection {
 override fun prepare(sql:String):SQLiteStatement=SqlStatement(raw.prepareStatement(sql))
 override fun close()=raw.close()
}
internal class SqlStatement(private val s:PreparedStatement):SQLiteStatement{
 private var rs:ResultSet?=null;private var executed=false
 override fun bindBlob(index:Int,value:ByteArray)=s.setBytes(index,value)
 override fun bindDouble(index:Int,value:Double)=s.setDouble(index,value)
 override fun bindLong(index:Int,value:Long)=s.setLong(index,value)
 override fun bindText(index:Int,value:String)=s.setString(index,value)
 override fun bindNull(index:Int)=s.setNull(index,Types.NULL)
 override fun getBlob(index:Int)=rs!!.getBytes(index+1)
 override fun getDouble(index:Int)=rs!!.getDouble(index+1)
 override fun getLong(index:Int)=rs!!.getLong(index+1)
 override fun getText(index:Int)=rs!!.getString(index+1)
 override fun isNull(index:Int)=rs!!.getObject(index+1)==null
 override fun getColumnCount():Int{ensureExecuted();return rs?.metaData?.columnCount?:0}
 override fun getColumnName(index:Int):String{ensureExecuted();return rs!!.metaData.getColumnName(index+1)}
 override fun getColumnType(index:Int)=when(rs!!.getObject(index+1)){null->5;is ByteArray->4;is String->3;is Double,is Float->2;else->1}
 private fun ensureExecuted(){if(!executed){executed=true;if(s.execute())rs=s.resultSet}}
 override fun step():Boolean{ensureExecuted();return rs?.next()?:false}
 override fun reset(){rs?.close();rs=null;executed=false}
 override fun clearBindings()=s.clearParameters()
 override fun close(){rs?.close();s.close()}
}

internal class RealSqlDb(val file:Path) : AutoCloseable {
 val c=DriverManager.getConnection("jdbc:sqlite:"+file)
 val connection=SqlConnection(c)
 val db=PlaylistCacheDatabase_Impl()
 val generated=br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao_Impl(db)
 var episodeCalls=0;var failEpisodeAt:Int?=null;var episodeError:Throwable=IllegalStateException("episode write failure");var beforeHydrate:(()->Unit)?=null
 var groups=0;var chunks=0;var peak=0;var failedAtChunk:Int?=null;var injectedFailure:Throwable=IllegalStateException("simulated transaction failure")
 var beforeUs=0L;var afterUs=0L;val stages=LongArray(5)
 val dao:PlaylistCacheDao
 init {
  c.createStatement().use{it.execute("PRAGMA journal_mode=WAL");it.execute("PRAGMA synchronous=NORMAL")}
  val method=db.javaClass.getDeclaredMethod("createOpenDelegate");method.isAccessible=true
  (method.invoke(db) as RoomOpenDelegate).createAllTables(connection)
  dao=Proxy.newProxyInstance(PlaylistCacheDao::class.java.classLoader,arrayOf(PlaylistCacheDao::class.java)){proxy,m,args0->
   val args=args0.orEmpty()
   fun body():Any?=try {InvocationHandler::class.java.getMethod("invokeDefault",Any::class.java,Method::class.java,Array<Any>::class.java).invoke(null,proxy,m,args)}catch(e:InvocationTargetException){throw e.cause!!}
   fun insert(fieldName:String,items:Any?) {
    val f=generated.javaClass.getDeclaredField(fieldName);f.isAccessible=true
    @Suppress("UNCHECKED_CAST") val adapter=f.get(generated) as EntityInsertAdapter<Any>
    @Suppress("UNCHECKED_CAST") adapter.insert(connection,items as List<Any>)
   }
   when(m.name){
    "getActiveGeneration" -> c.prepareStatement("SELECT * FROM playlist_cache_generations WHERE playlistId=? AND status='ACTIVE' ORDER BY activatedAtEpochMillis DESC LIMIT 1").use{s->s.setString(1,args[0]as String);s.executeQuery().use{r->if(r.next())PlaylistCacheGenerationEntity(r.getString(1),r.getString(2),r.getString(3),r.getLong(4),r.getObject(5)?.let{(it as Number).toLong()},r.getObject(6)?.let{(it as Number).toLong()})else null}}
    "generationStatus" -> c.prepareStatement("SELECT status FROM playlist_cache_generations WHERE playlistId=? AND generationId=?").use{s->s.setString(1,args[0]as String);s.setString(2,args[1]as String);s.executeQuery().use{r->if(r.next())r.getString(1)else null}}
    "insertDeferredM3uSeries" -> {
     beforeHydrate?.invoke();c.autoCommit=false
     try{val value=body();c.commit();groups++;value}catch(e:Throwable){c.rollback();throw e}finally{c.autoCommit=true}
    }
    "insertM3uGroup","insertImportBatch" -> {
     val g=if(m.name=="insertM3uGroup")args[0] as M3uWriteGroup else null
     peak=maxOf(peak,g?.batches?.sumOf{it.entries}?:((args[1]as List<*>).size+(args[2]as List<*>).size+(args[4]as List<*>).size))
     val trace=M3uTransactionMetrics.current();val begin=System.nanoTime();c.autoCommit=false;trace?.recordBegin(System.nanoTime()-begin)
     try {val result=body();c.commit();groups++;result} catch(e:Throwable){c.rollback();throw e}
     finally{c.autoCommit=true}
    }
    "insertImportBatchBody" -> {chunks++;if(chunks==failedAtChunk)throw injectedFailure;body()}
    "insertCategories" -> {insert("__insertAdapterOfCachedCategoryEntity",args[0]);Unit}
    "insertChannels" -> {insert("__insertAdapterOfCachedChannelEntity",args[0]);Unit}
    "insertMovies" -> {insert("__insertAdapterOfCachedMovieEntity_1",args[0]);Unit}
    "insertSeries" -> {insert("__insertAdapterOfCachedSeriesEntity_1",args[0]);Unit}
    "insertEpisodes" -> {episodeCalls++;if(episodeCalls==failEpisodeAt)throw episodeError;insert("__insertAdapterOfCachedEpisodeEntity",args[0]);Unit}
    "upsertGeneration" -> {insert("__insertAdapterOfPlaylistCacheGenerationEntity",listOf(args[0]!!));Unit}
    "updateGenerationStatus" -> {c.prepareStatement("UPDATE playlist_cache_generations SET status=?,completedAtEpochMillis=? WHERE playlistId=? AND generationId=?").use{s->s.setString(1,args[2]as String);s.setLong(2,args[3]as Long);s.setString(3,args[0]as String);s.setString(4,args[1]as String);s.executeUpdate()};Unit}
    "discardIncompleteImport" -> {c.prepareStatement("DELETE FROM playlist_cache_generations WHERE playlistId=? AND generationId=? AND status!='ACTIVE'").use{s->s.setString(1,args[0]as String);s.setString(2,args[1]as String);s.executeUpdate()};true}
    else -> if(m.isDefault)body() else error("Unexpected DAO method "+m.name)
   }
  } as PlaylistCacheDao
 }
 fun count(table:String,generation:String?=null):Int=c.createStatement().use{s->s.executeQuery("SELECT COUNT(*) FROM "+table+(generation?.let{" WHERE generationId='"+it+"'"}?:"")).use{it.next();it.getInt(1)}}
 fun canonical(generation:String)=listOf("cached_categories","cached_channels","cached_movies","cached_series","cached_episodes").map{table->
  c.createStatement().use{s->s.executeQuery("SELECT * FROM $table WHERE generationId='$generation' ORDER BY 1,3,4").use{r->buildList{while(r.next())add((1..r.metaData.columnCount).filter{r.metaData.getColumnName(it)!="generationId"}.map{r.getObject(it)})}}}
 }
 override fun close(){connection.close();Files.deleteIfExists(file);Files.deleteIfExists(Path.of(file.toString()+"-wal"));Files.deleteIfExists(Path.of(file.toString()+"-shm"))}
}
