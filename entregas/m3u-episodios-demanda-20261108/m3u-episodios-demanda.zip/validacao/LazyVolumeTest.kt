package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.DeferredM3uEpisodes
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import java.nio.file.*
import kotlinx.coroutines.*
private class Volume:PlaylistHttpClient {
 override suspend fun get(url:String):String=error("API not allowed")
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit){
  onLine("#EXTM3U")
  suspend fun row(name:String,group:String,url:String,poster:String){onLine("#EXTINF:-1 group-title=\"$group\" tvg-logo=\"$poster\",$name");onLine(url)}
  repeat(2355){row("Canal $it","Canais ${it%12}","http://x/live/$it.ts","c$it")}
  repeat(44099){row("Filme $it (2024)","Filmes ${it%32}","http://x/movie/$it.mkv","m$it")}
  repeat(283278){val series=(it.toLong()*9800/283278).toInt();row("Série $series S01E${it%40+1}","Séries ${series%60}","http://x/series/$it.mkv","ep-$it")}
 }
}
fun main()=runBlocking{
 Class.forName("org.sqlite.JDBC");val dir=Path.of("/workspace/m3u-episodios-demanda/volume");Files.createDirectories(dir)
 val source=dir.resolve("source").toFile();source.deleteRecursively()
 RealSqlDb(dir.resolve("catalog.db")).use{db->
  val store=DeferredM3uEpisodes(source)
  val gen=M3uCacheImporter(Volume(),db.dao,PlaylistCacheGenerationManager(db.dao),deferredEpisodes=store).import("p","http://x/list")
  check(listOf("cached_categories","cached_channels","cached_movies","cached_series","cached_episodes").map{db.count(it,gen)}==listOf(104,2355,44099,9800,0))
  check(store.sourceCounts("p",gen)==(9800 to 283278L))
  check(db.episodeCalls==0)
  println("PASS 329732-source-row native import persists 104 categories, 2355 channels, 44099 movies and 9800 series, with zero Room episode insert calls")
  println("PASS all 283278 episode records remain available in the compact per-series indexed source")
  println("Functional volume test under -Xmx128m; no Android/TV speed claim")
 }
 source.deleteRecursively()
 Unit
}
