from pathlib import Path
import os,subprocess,json,uuid
w=Path('/workspace/m3u-episodios-demanda');out=w/'collector-tests'/uuid.uuid4().hex;out.mkdir(parents=True)
adb=out/'fake-adb';adb.write_text('''#!/usr/bin/env python3
import sys,os,json,time
from pathlib import Path
a=sys.argv[1:];root=Path(os.environ['SNAPSHOT_FAKE_ROOT']);marker=root/'started';mode=os.environ.get('SNAPSHOT_FAKE_MODE','success')
if a==['devices']:print('List of devices attached\\nfake-device device');sys.exit(0)
if 'shell'in a:
 with(root/'commands.jsonl').open('a')as f:f.write(json.dumps(a)+'\\n')
 if 'start'in a:
  marker.write_text('start')
  print('Starting: Intent { cmp=prototype }')
 sys.exit(0)
if 'logcat'in a:
 old='11-08 00:00:00.000 1 1 I IPTV_SNAPSHOT: stage=summary status=ERROR'
 if '-d'in a:print(old);sys.exit(0)
 print(old,flush=True)
 while not marker.exists():time.sleep(.01)
 if mode=='cleanup':print('IPTV_SNAPSHOT: stage=summary status=CLEANED',flush=True)
 else:
  print('IPTV_SNAPSHOT: stage=source sourceHash='+('a'*64)+' sourceBytes=100 url=https://secret password=secret',flush=True)
  print('IPTV_SNAPSHOT: stage=summary status=OK totalMs=10',flush=True)
  time.sleep(1.3)
  print('IPTV_SNAPSHOT: stage=complete status=OK totalMs=25',flush=True)
 time.sleep(5)
''');adb.chmod(0o755)
pw='/workspace/storage-toolchain/powershell/pwsh';script=Path('/workspace/outputs/m3u-episodios-demanda/Testar-Prototipo-M3U.ps1')
env=dict(os.environ,XDG_CACHE_HOME='/workspace/storage-toolchain/xdg-cache',XDG_DATA_HOME='/workspace/storage-toolchain/xdg-data',XDG_CONFIG_HOME='/workspace/storage-toolchain/xdg-config')
logs=[]
for mode in ['success','cleanup']:
 case=out/mode;case.mkdir();env.update(SNAPSHOT_FAKE_ROOT=str(case),SNAPSHOT_FAKE_MODE=mode)
 args=[pw,'-NoProfile','-File',str(script),'-AdbPath',str(adb),'-PastaSaida',str(case)]
 if mode=='cleanup':args+=['-Limpar']
 else:args+=['-SomenteImportacao']
 r=subprocess.run(args,env=env,capture_output=True,text=True,timeout=20);assert r.returncode==0,(mode,r.stdout,r.stderr)
 report=list(case.glob('diagnostico-*.txt'));assert len(report)==1
 text=report[0].read_text(encoding='utf-8-sig');assert 'secret'not in text and 'https://'not in text and 'password'not in text
 assert ('stage=complete status=OK totalMs=25'in text)if mode=='success'else('status=CLEANED'in text)
 commands=[json.loads(l)for l in(case/'commands.jsonl').read_text().splitlines()]
 assert len(commands)==2 and 'force-stop'in commands[0]and 'start'in commands[1]
 assert not any('clear'in cmd or 'uninstall'in cmd for cmd in commands)
 if mode=='cleanup':assert 'clear_prototype'in commands[1]and 'true'in commands[1]
 logs.append('PASS fake ADB '+mode+': selected device, correct activity, private-data filter, terminal status')
logs.append('PASS summary OK alone does not end capture; complete is required')
(w/'collector-results.txt').write_text('\n'.join(logs)+'\n');print('\n'.join(logs))
