package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.*
import br.com.flaviotorres.iptvpremium.data.m3usnapshot.*
import java.io.*
import java.nio.file.*
import kotlinx.coroutines.*
fun main()=runBlocking {
 Class.forName("org.sqlite.JDBC");val root=Path.of("/workspace/m3u-episodios-demanda/snapshot-test");Files.createDirectories(root)
 val source=root.resolve("sources").toFile();source.deleteRecursively();val store=DeferredM3uEpisodes(source)
 val text=buildString{
  append("#EXTM3U\n")
  repeat(400){i->for(s in listOf("A","B"))append("#EXTINF:-1 group-title=\"Séries\" tvg-logo=\"p$i\",Show $s S01E${i+1}\nhttp://x/series/$s$i\n")}
 }
 val spool=root.resolve("metadata.bin").toFile()
 val counts=store.begin("p","new").use{builder->
  FileOutputStream(spool).use{raw->val out=DataOutputStream(BufferedOutputStream(raw));val c=SnapshotParser.prepare(text.reader().buffered(),out,"p","new",episodeSource=builder);out.flush();builder.finish();c}
 }
 RealSqlDb(root.resolve("catalog.db")).use{db->
  for(sql in SnapshotSchema.indexes){val name=Regex("`([^`]+)`").find(sql)!!.groupValues[1];db.c.createStatement().use{it.execute("DROP INDEX `$name`")}}
  val bridge=NativeBridge(db.c);val loaded=SnapshotLoader.load(bridge.database,spool,"p","new")
  check(loaded.rows[4]==0L&&counts.episodes==800L&&store.sourceCounts("p","new")==(2 to 800L))
  SnapshotLoader.indexes(bridge.database);val stored=SnapshotLoader.validate(bridge.database,counts,deferredEpisodes=true)
  check(stored[3]==2L&&stored[4]==0L)
  println("PASS snapshot initial metadata load contains series and no Room episode rows; all episode sources are finalized")
  db.c.createStatement().use{it.execute("UPDATE playlist_cache_generations SET status='ACTIVE'")}
  val ids=db.canonical("new")[3].map{it[1]as String}
  check(store.ensure(db.dao,"p","new",ids[0])&&db.count("cached_episodes")==400)
  check(db.canonical("new")[4].all{it[2]==ids[0]})
  println("PASS snapshot selected-series opening caches only that series and leaves the other series deferred")
  val writes=db.episodeCalls;check(store.ensure(db.dao,"p","new",ids[0])&&db.episodeCalls==writes)
  println("PASS snapshot repeated opening reuses the persistent episode cache")
 }
 spool.delete();source.deleteRecursively()
 Unit
}
