package br.com.flaviotorres.iptvpremium.data.cache

import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.cache.importer.OriginalM3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.*
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import java.nio.file.*
import java.io.*
import kotlinx.coroutines.*

private class Http(val lines:List<String>):PlaylistHttpClient{
 var reads=0
 override suspend fun get(url:String):String=error("unexpected API call")
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit){reads++;for(line in lines)onLine(line)}
}
private fun row(name:String,group:String,url:String,poster:String="poster")=listOf("#EXTINF:-1 group-title=\"$group\" tvg-logo=\"$poster\",$name",url)
private fun activate(db:RealSqlDb,p:String,g:String){db.c.prepareStatement("UPDATE playlist_cache_generations SET status=CASE WHEN generationId=? THEN 'ACTIVE' ELSE 'STALE' END WHERE playlistId=?").use{it.setString(1,g);it.setString(2,p);it.executeUpdate()}}
fun main(args:Array<String>)=runBlocking {
 Class.forName("org.sqlite.JDBC");val root=Path.of("/workspace/m3u-episodios-demanda/tests");Files.createDirectories(root)
 var n=0;fun ok(value:Boolean,label:String){check(value){label};n++;println("PASS $label")}
 val lines=listOf("#EXTM3U")+row("Live","Canais","http://x/live/a.ts")+row("Movie (2024)","Filmes","http://x/movie/a.mkv")+(1..600).flatMap{i->
  row("Ação 中文 S01E$i","Séries","http://x/series/a$i.mkv",if(i%3==0)""else "á-poster-$i")+row("Outra Série S02E$i","Séries B","http://x/series/b$i.mkv","b$i")
 }+row("Ação 中文 S01E1","Séries","http://x/series/a1.mkv","last")
 RealSqlDb(root.resolve("oracle.db")).use{oracle->RealSqlDb(root.resolve("candidate.db")).use{candidate->
  val ref=OriginalM3uCacheImporter(Http(lines),oracle.dao,PlaylistCacheGenerationManager(oracle.dao)).import("p","http://x/list")
  val storeRoot=root.resolve("sources").toFile();storeRoot.deleteRecursively();val sources=DeferredM3uEpisodes(storeRoot);val http=Http(lines)
  val g=M3uCacheImporter(http,candidate.dao,PlaylistCacheGenerationManager(candidate.dao),deferredEpisodes=sources).import("p","http://x/list")
  ok(candidate.count("cached_episodes")==0,"native M3U initial import does not insert any episode into Room")
  ok(candidate.canonical(g).take(4)==oracle.canonical(ref).take(4),"channels, movies, categories and final series metadata/order equal the full-import reference")
  ok(sources.sourceCounts("p",g)==(2 to 1201L),"compact source indexes interleaved series and retains every input episode")
  activate(candidate,"p",g)
  val ids=candidate.canonical(g)[3].map{it[1]as String}
  val first=ids.first();val second=ids.last()
  val calls=candidate.episodeCalls
  ok(sources.ensure(candidate.dao,"p",g,first),"opening one series hydrates its source into the active generation")
  val firstRows=candidate.canonical(g)[4]
  ok(firstRows.isNotEmpty()&&firstRows.all{it[2]==first},"unopened series remain absent from Room")
  ok(firstRows==oracle.canonical(ref)[4].filter{it[2]==first},"requested episodes preserve IDs, links, nullable fields, Unicode and last-occurrence metadata")
  val written=candidate.episodeCalls
  ok(written>calls&&sources.ensure(candidate.dao,"p",g,first)&&candidate.episodeCalls==written,"second request reuses persisted cache without another write")
  val reopened=DeferredM3uEpisodes(storeRoot)
  ok(reopened.ensure(candidate.dao,"p",g,first)&&candidate.episodeCalls==written,"cache completion survives constructing a new store instance")
  candidate.episodeCalls=0;candidate.failEpisodeAt=2;val cancelled=CancellationException("cancel selected series");candidate.episodeError=cancelled
  val attempt=runCatching{sources.ensure(candidate.dao,"p",g,second)}
  ok(attempt.exceptionOrNull()===cancelled&&candidate.canonical(g)[4]==firstRows,"cancellation in the second write batch rolls back all episodes of that request")
  candidate.failEpisodeAt=null
  ok(sources.ensure(candidate.dao,"p",g,second)&&candidate.canonical(g)==oracle.canonical(ref),"retry after cancelled hydration restores the complete reference result")
  ok(http.reads==1,"opening and reopening episodes does not download the playlist or call Xtream")
  val refreshed=M3uCacheImporter(Http(lines.dropLast(2)),candidate.dao,PlaylistCacheGenerationManager(candidate.dao),deferredEpisodes=sources).import("p","http://x/list")
  ok(candidate.count("cached_episodes",refreshed)==0&&candidate.canonical(g)==oracle.canonical(ref),"manual refresh creates an empty-episode generation while preserving the prior active cache")
  activate(candidate,"p",refreshed)
  ok(!sources.ensure(candidate.dao,"p",g,"unknown-series"),"unknown series never hydrates unrelated records")
  // Request an uncached old-generation series: the transaction guard must reject publication.
  val staleRoot=root.resolve("stale").toFile();staleRoot.deleteRecursively();val stale=DeferredM3uEpisodes(staleRoot)
  stale.begin("p",g).use{b->b.append("stale-series",1,1,"Stale S01E01",null,"http://x/series/stale");b.finish()}
  ok(!stale.ensure(candidate.dao,"p",g,"stale-series")&&candidate.count("cached_episodes",refreshed)==0,"active-generation guard rejects old-source writes after a list refresh")
  System.setProperty("atomicfile.fail","true")
  try{ok(sources.ensure(candidate.dao,"p",refreshed,first)&&candidate.count("cached_episodes",refreshed)>0,"marker IO failure does not hide successfully committed episodes")}finally{System.clearProperty("atomicfile.fail")}
  val beforeConcurrent=candidate.episodeCalls
  val concurrent=coroutineScope{listOf(async{sources.ensure(candidate.dao,"p",refreshed,first)},async{sources.ensure(candidate.dao,"p",refreshed,first)}).awaitAll()}
  ok(concurrent.all{it}&&candidate.episodeCalls==beforeConcurrent+3,"simultaneous requests for the same series perform only one cache write")
  stale.begin("p","absent-generation").use{b->b.append("s",1,1,"One",null,"http://x/one");b.finish()}
  stale.prune(candidate.dao,"p")
  ok(stale.sourceCounts("p","absent-generation")==null&&stale.sourceCounts("p",g)!=null,"pruning removes only unreferenced generations and retains generations still present in Room")
 }}
 // Truncated source must fail before the transaction can publish partial episodes.
 RealSqlDb(root.resolve("corrupt.db")).use{db->
  val dir=root.resolve("corrupt-source").toFile();dir.deleteRecursively();val store=DeferredM3uEpisodes(dir)
  val gen=M3uCacheImporter(Http(listOf("#EXTM3U")+row("Show S01E01","Séries","http://x/series/c")),db.dao,PlaylistCacheGenerationManager(db.dao),deferredEpisodes=store).import("p","http://x/list")
  activate(db,"p",gen);val records=dir.walkTopDown().first{it.name=="episodes.records"}
  RandomAccessFile(records,"rw").use{it.setLength(it.length()-1)}
  ok(runCatching{store.ensure(db.dao,"p",gen,db.canonical(gen)[3].single()[1]as String)}.isFailure&&db.count("cached_episodes")==0,"truncated durable source is rejected without caching partial episodes")
 }
 println("$n on-demand tests; actual DAO default transactions, generated adapters and real SQLite, Android AtomicFile mocked")
}
