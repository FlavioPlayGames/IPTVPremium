﻿param(
 [string]$Dispositivo='',
 [string]$PastaSaida=(Join-Path $env:USERPROFILE 'Downloads'),
 [ValidateRange(1,99)][int]$Rodada=1,
 [ValidateRange(60,1800)][int]$TempoMaximoSegundos=900,
 [string]$AdbPath='',
 [switch]$Limpar,
 [switch]$SomenteImportacao
)
$ErrorActionPreference='Stop'
if(!$AdbPath){$AdbPath=Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe'}
if(!(Test-Path -LiteralPath $AdbPath)){throw 'ADB nao encontrado. Informe -AdbPath.'}
$devices=@(& $AdbPath devices | ForEach-Object{if($_ -match '^(\S+)\s+device$'){$Matches[1]}})
if($LASTEXITCODE -ne 0){throw 'Nao foi possivel consultar os aparelhos.'}
if(!$Dispositivo){if($devices.Count -ne 1){throw 'Informe -Dispositivo com o serial de adb devices.'};$Dispositivo=$devices[0]}
if($Dispositivo -notin $devices -or $Dispositivo -notmatch '^[A-Za-z0-9_.:-]+$'){throw 'Aparelho desconectado ou serial invalido.'}
New-Item -ItemType Directory -Force -Path $PastaSaida | Out-Null
$report=Join-Path $PastaSaida ('diagnostico-prototipo-m3u-r'+$Rodada+'-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'.txt')
$temporary=Join-Path ([IO.Path]::GetTempPath())('iptv-snapshot-'+[guid]::NewGuid().ToString('N'))
$stdout=$temporary+'.out';$stderr=$temporary+'.err';$process=$null;$state='INCOMPLETE'
function Safe-Snapshot([string[]]$Lines){
 foreach($line in $Lines){
  if($line -notmatch '\b(IPTV_SNAPSHOT|M3uEpisodesPerf)\s*:\s*(.*)$'){continue};$tag=$Matches[1];$body=$Matches[2]
  $fields=[Collections.Generic.List[string]]::new()
  foreach($m in [regex]::Matches($body,'\b([A-Za-z][A-Za-z0-9]*)=([^\s]+)')){
   $k=$m.Groups[1].Value;$v=$m.Groups[2].Value
   if($k -cin @('startNs','endNs','durationMs','totalMs','entries','rows','processed','categories','channels','movies','series','episodes','databaseBytes','synchronous','sourceBytes','deferredEpisodes') -and $v -match '^\d+$'){$fields.Add($k+'='+$v)}
   elseif($k -cin @('stage','failedStage') -and $v -cmatch '^(episodes_open|cache|cache_marker|source_unavailable|complete|activity|start|cleanup|download|source|prepare|prepare_progress|bootstrap|defer_indexes|settings|load|load_progress|commit|indexes|validate|ready|room_validate|checkpoint|finalize|publish|summary)$'){$fields.Add($k+'='+$v)}
   elseif($k -ceq 'status' -and $v -cmatch '^(RUNNING|OK|ERROR|CANCELLED|NO_M3U|CLEANED)$'){$fields.Add($k+'='+$v)}
   elseif($k -ceq 'sourceHash' -and $v -cmatch '^[a-f0-9]{64}$'){$fields.Add($k+'='+$v)}
   elseif($k -ceq 'revision' -and $v -cmatch '^(SNAPSHOT_R1|SNAPSHOT_LAZY_R1)$'){$fields.Add($k+'='+$v)}
   elseif($k -ceq 'journal' -and $v -cmatch '^(wal|delete|truncate|persist|memory|off)$'){$fields.Add($k+'='+$v)}
   elseif($k -ceq 'code' -and $v -cmatch '^(SPACE|IO|INVALID_INPUT|VALIDATION|FAILED)$'){$fields.Add($k+'='+$v)}
  }
  if($fields.Count){$tag+': '+($fields -join ' ')}
 }
}
Write-Host 'O teste fecha o aplicativo para medir o prototipo isoladamente. Nao apaga dados.'
Write-Host 'A lista ativa deve ser M3U. A URL sera lida do cadastro do aparelho, sem digitacao no PowerShell.'
& $AdbPath -s $Dispositivo shell am force-stop br.com.flaviotorres.iptvpremium
if($LASTEXITCODE -ne 0){throw 'Nao foi possivel preparar o aplicativo.'}
$baseline=@(& $AdbPath -s $Dispositivo logcat -d -t 1 -v threadtime -s 'IPTV_SNAPSHOT:I' 'M3uEpisodesPerf:I' '*:S')
try{
 $arguments=@('-s',$Dispositivo,'logcat','-v','threadtime','-T','1','-s','IPTV_SNAPSHOT:I','M3uEpisodesPerf:I','*:S')
 $process=Start-Process -FilePath $AdbPath -ArgumentList $arguments -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru -NoNewWindow
 Start-Sleep -Milliseconds 500
 $launchArgs=@('-s',$Dispositivo,'shell','am','start','-W','-n','br.com.flaviotorres.iptvpremium/br.com.flaviotorres.iptvpremium.data.m3usnapshot.SnapshotPrototypeActivity')
 if($Limpar){$launchArgs+=@('--ez','clear_prototype','true')}
 $launch=@(& $AdbPath @launchArgs)
 if($LASTEXITCODE -ne 0 -or ($launch -join ' ') -match 'Error|Permission Denial|does not exist'){
  throw 'Nao foi possivel abrir o prototipo. Confirme a instalacao da variante desempenho deste pacote.'
 }
 Write-Host 'Teste iniciado automaticamente. Mantenha a TV nessa tela. Voltar cancela o prototipo.'
 $deadline=[DateTime]::UtcNow.AddSeconds($TempoMaximoSegundos)
 while([DateTime]::UtcNow -lt $deadline){
  Start-Sleep -Milliseconds 500
  $lines=if(Test-Path -LiteralPath $stdout){@(Get-Content -LiteralPath $stdout -ErrorAction SilentlyContinue|Where-Object{$_ -notin $baseline})}else{@()}
  if(($lines -match '\bstage=complete\b.*\bstatus=OK\b') -or ($lines -match '\bstage=(summary|activity)\b.*\bstatus=(ERROR|CANCELLED|NO_M3U|CLEANED)\b')){$state='FINISHED';break}
  if($process.HasExited){$state='LOGCAT_EXITED';break}
 }
 if($state -eq 'INCOMPLETE'){$state='TIMEOUT'}
 if(!$Limpar -and !$SomenteImportacao -and ($lines -match '\bstage=complete\b.*\bstatus=OK\b')){
  Write-Host 'Importacao inicial concluida. Agora, NA TV, escolha uma serie e abra os episodios.'
  Write-Host 'Abra a mesma serie novamente para conferir o cache. Voce tambem pode testar outra serie.'
  Read-Host 'Depois desses testes na TV, pressione Enter aqui para salvar o diagnostico' | Out-Null
 }
}finally{
 if($process -and !$process.HasExited){Stop-Process -Id $process.Id -ErrorAction SilentlyContinue;$process.WaitForExit()}
 $lines=if(Test-Path -LiteralPath $stdout){@(Get-Content -LiteralPath $stdout -ErrorAction SilentlyContinue|Where-Object{$_ -notin $baseline})}else{@()}
 @('IPTV Premium - prototipo independente M3U',('Estado: '+$state),('Rodada: '+$Rodada),'Tempo inclui download, preparacao, carga, indices, validacao e publicacao do prototipo.','No prototipo, episodios sao carregados quando uma serie e solicitada; o catalogo normal nao e substituido por este teste.','---')+@(Safe-Snapshot $lines)|Set-Content -LiteralPath $report -Encoding UTF8
 Remove-Item -LiteralPath $stdout,$stderr -Force -ErrorAction SilentlyContinue
 Write-Host ('Diagnostico salvo: '+$report)
 if($state -eq 'TIMEOUT'){Write-Host 'A coleta terminou por prazo. O teste pode continuar na TV; pressione Voltar se desejar cancelar.'}
}
