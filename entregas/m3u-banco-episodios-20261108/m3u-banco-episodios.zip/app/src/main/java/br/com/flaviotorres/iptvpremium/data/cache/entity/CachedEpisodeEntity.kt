package br.com.flaviotorres.iptvpremium.data.cache.entity

import androidx.room.Entity
import androidx.room.Index

@Entity(
    tableName = "cached_episodes",
    primaryKeys = [
        "playlistId",
        "generationId",
        "episodeId"
    ],
    indices = [
        Index(
            value = [
                "playlistId",
                "generationId",
                "seriesId",
                "seasonNumber"
            ]
        )
    ]
)
data class CachedEpisodeEntity(
    val playlistId: String,
    val generationId: String,
    val episodeId: String,
    val seriesId: String,
    val seasonNumber: Int?,
    val episodeNumber: Int?,
    val name: String,
    val streamUrl: String,
    val posterUrl: String?,
    val durationSeconds: Long?
)