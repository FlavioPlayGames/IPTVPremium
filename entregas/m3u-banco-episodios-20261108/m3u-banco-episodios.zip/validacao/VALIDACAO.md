# Validação

- Compilação Kotlin e Lint aprovadas.
- Doze verificações com SQLite real e a migração do aplicativo: 10 mil episódios, gerações ACTIVE/IMPORTING, campos/IDs/valores nulos/Unicode preservados, páginas de episódios idênticas, rollback transacional, idempotência e integrity_check. Bancos migrado e novo validados pelo RoomOpenDelegate gerado pelo compilador Room, usando adaptador JDBC no host.
- Benchmark com arquivo local, WAL/NORMAL, três rodadas, 100 mil episódios existentes mais 100 mil novos, IDs de tamanho real e 50 transações de dois mil registros. Mediana 2539 ms com dois índices secundários e 2040 ms com um; aproximadamente 19,7% de redução local no tempo de escrita. O plano da consulta de página usa o mesmo índice completo. Não é medição Android Room/TV.
- Foram avaliadas inserções múltiplas com 16/32/64/96 linhas; não deram ganho local e não foram integradas ao aplicativo. Somente a redundância de índice foi removida.
- Dezesseis cenários de paridade/falha/cancelamento do importador e quinze do sincronizador, além de armazenamento/codec: conteúdo/ordem, M3U direta, reavaliação, catálogo ativo e falhas locais preservados. DAO/HTTP simulados nesses testes.
- Instalador aplicado/reaplicado em fixture com backup byte a byte; corrupção e versão desconhecida recusadas. Sintaxe PowerShell verificada; filtro do relatório mantém versão de banco/tempos e descarta URL/senha fictícias.

Não houve acesso ao banco/provedor da TV, instalação/publicação automática ou medição do ganho real no aparelho. A alteração exige migração do banco interno de 4 para 5; cópias dos fontes não são backup/reversão dos dados já migrados.
