package br.com.flaviotorres.iptvpremium.ui.movies

import br.com.flaviotorres.iptvpremium.data.repository.CatalogMetadataCache
import java.security.MessageDigest
import org.json.JSONObject

/** Exact list/item association. Only a verified public TMDB image enters the existing metadata budget. */
internal object MoviePosterBindingCache {
    fun key(scope:String,id:String,url:String?,title:String,year:Int?,tmdb:String?,imdb:String?):String? {
        if(scope.isBlank()||id.isBlank())return null
        val input=listOf(scope,id,url,title,year?.toString(),tmdb,imdb)
            .joinToString(""){value->if(value==null)"-1:" else "${value.length}:$value"}
        val digest=MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
            .joinToString(""){"%02x".format(it.toInt()and 255)}
        return "movie_poster_binding_v1:$digest"
    }
    private fun image(root:JSONObject?):String? {
        if(root==null||root.optInt("id",0)<=0)return null
        val path=root.optString("poster_path")
        if(!Regex("^/[A-Za-z0-9_-]+\\.(?:jpg|png|webp)$").matches(path))return null
        return "https://image.tmdb.org/t/p/w342$path"
    }
    fun peek(key:String?)=image(CatalogMetadataCache.peek(key))
    suspend fun cached(key:String?):String? = image(CatalogMetadataCache.cached(key)).also {
        if(it!=null&&key!=null)android.util.Log.i("PosterBindingPerf","kind=MOVIES stage=binding event=HIT bindingHash=${key.takeLast(12)}")
    }
    suspend fun remember(key:String?,url:String,id:Int) {
        if(key==null||id<=0)return
        val prefix="https://image.tmdb.org/t/p/w342"
        if(!url.startsWith(prefix))return
        val root=JSONObject().put("id",id).put("poster_path",url.removePrefix(prefix))
        if(image(root)!=url)return
        CatalogMetadataCache.load(key){root}
        android.util.Log.i("PosterBindingPerf","kind=MOVIES stage=binding event=SAVED bindingHash=${key.takeLast(12)}")
    }
}
