package br.com.flaviotorres.iptvpremium.ui.movies

import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.remote.TmdbClientProvider
import br.com.flaviotorres.iptvpremium.data.repository.SeriesCatalogPosterResolver
import br.com.flaviotorres.iptvpremium.data.repository.MovieCatalogPosterResolver
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update

// One lookup slot remains available for visible work even during off-screen anticipation.
private val verifiedPosterBudget=PosterNetworkBudget(capacity=2,backgroundCapacity=1)
internal val SeasonPosterRevision=MutableStateFlow(0L)

private suspend fun awaitPosterPriority() {
    MediaOpeningPriority.awaitIdle()
    CatalogImportPriority.busy.first{!it}
    CatalogMemoryPolicy.pressured.first{!it}
}
private suspend fun cachedPoster(kind:PosterKind,name:String,year:Int?,tmdb:String?,imdb:String?,season:Int?):String? =
    if(kind==PosterKind.MOVIES)MovieCatalogPosterResolver.cached(name,year,tmdb,imdb)?.url
    else SeriesCatalogPosterResolver.cached(name,year,tmdb,imdb,season)?.url

private suspend fun verifiedPoster(kind:PosterKind,name:String,year:Int?,tmdb:String?,imdb:String?,season:Int?,background:Boolean=false):String? {
    cachedPoster(kind,name,year,tmdb,imdb,season)?.let{return it}
    awaitPosterPriority()
    val queuedAt=System.nanoTime()
    return verifiedPosterBudget.run(background) {
        android.util.Log.i("SeriesPosterPerf","stage=lookup_queue elapsedMs=${(System.nanoTime()-queuedAt)/1_000_000}")
        withTimeoutOrNull(15_000L) {
            if(kind==PosterKind.MOVIES)MovieCatalogPosterResolver.resolve(name,year,tmdb,imdb,TmdbClientProvider.client::get)?.url
            else SeriesCatalogPosterResolver.resolve(name,year,tmdb,imdb,TmdbClientProvider.client::get,season)?.url
        }
    }
}
internal fun cachedCatalogPosterUrl(kind:PosterKind,item:PosterCandidate):String? =
    if(kind==PosterKind.MOVIES)MoviePosterBindingCache.peek(MoviePosterBindingCache.key(item.scope,item.id,item.url,item.name,item.year,item.tmdbId,item.imdbId))
        ?: MovieCatalogPosterResolver.peek(item.name,item.year,item.tmdbId,item.imdbId)?.url
    else SeriesCatalogPosterResolver.peek(item.name,item.year,item.tmdbId,item.imdbId,item.season)?.url

internal fun peekCatalogPoster(url:String?,kind:PosterKind,name:String,year:Int?,tmdbId:String?,imdbId:String?,season:Int?=null,bindingKey:String?=null):ImageBitmap? {
    if(kind==PosterKind.MOVIES)return MoviePosterLoader.peekBitmap(url)?:MoviePosterLoader.peekBitmap(MoviePosterBindingCache.peek(bindingKey))?:
        MovieCatalogPosterResolver.peek(name,year,tmdbId,imdbId)?.let{MoviePosterLoader.peekBitmap(it.url)}
    val missing= !GenericPosterPolicy.hasSource(url)
    val prepared=SeriesCatalogPosterResolver.peek(name,year,tmdbId,imdbId,season)
        ?.takeIf{missing||MoviePosterLoader.knownMissing(url)||season!=null&&it.isSeason}
    return prepared?.let{MoviePosterLoader.peekBitmap(it.url)}?:MoviePosterLoader.peekBitmap(url)
}

/** Provider first; absent/broken provider covers use only a verified TMDB work, for either import format. */
internal suspend fun loadCatalogPoster(context:Context,url:String?,kind:PosterKind,name:String,year:Int?,tmdbId:String?,imdbId:String?,season:Int?=null,onProviderReady:(ImageBitmap)->Unit={},resolveProvider:(suspend()->MovieProviderPoster?)?=null,bindingKey:String?=null):ImageBitmap? {
    val started=System.nanoTime()
    fun ready(bitmap:ImageBitmap?,source:String):ImageBitmap? {
        val digest=java.security.MessageDigest.getInstance("SHA-256").digest("$kind|$name|$year|$season".toByteArray())
        val hash=digest.take(6).joinToString(""){"%02x".format(it.toInt()and 255)}
        android.util.Log.i("PosterFallbackPerf","kind=${kind.name} stage=fallback source=$source workHash=$hash elapsedMs=${(System.nanoTime()-started)/1_000_000}")
        return bitmap
    }
    if(kind==PosterKind.MOVIES) {
        MoviePosterLoader.loadCached(context,url,kind)?.let{return ready(it,"PROVIDER")}
        val bound=MoviePosterBindingCache.cached(bindingKey)
        if(bound!=null) {
            MoviePosterLoader.loadCached(context,bound,kind)?.let{return ready(it,"TMDB")}
            awaitPosterPriority()
            MoviePosterLoader.loadWithRetry(context,bound,kind)?.let{return ready(it,"TMDB")}
        }
        cachedPoster(kind,name,year,tmdbId,imdbId,season)
            ?.let{MoviePosterLoader.loadCached(context,it,kind)}?.let{return ready(it,"TMDB")}
    }
    val seasonal=if(kind==PosterKind.SERIES&&season!=null)
        SeriesCatalogPosterResolver.cached(name,year,tmdbId,imdbId,season)?.takeIf{it.isSeason} else null
    seasonal?.let{MoviePosterLoader.loadCached(context,it.url,kind)}?.let{return ready(it,"TMDB")}
    if(GenericPosterPolicy.hasSource(url)) {
        for(attempt in 0..1) {
            awaitPosterPriority()
            val started=System.nanoTime()
            val provider=MoviePosterLoader.loadWithRetry(context,url,kind)
            if(provider!=null) {
                onProviderReady(provider)
                val prepared=seasonal?.let{MoviePosterLoader.loadWithRetry(context,it.url,kind)}
                return ready(prepared?:provider,if(prepared!=null)"TMDB"else"PROVIDER")
            }
            // Do not repeat a stalled connection before trying a verified alternative.
            if(MoviePosterLoader.knownMissing(url)||(System.nanoTime()-started)/1_000_000>=2_000L)break
            if(attempt==0)delay(600L)
        }
    }
    var lookupName=name;var lookupYear=year;var lookupTmdb=tmdbId;var lookupImdb=imdbId
    val hasExternal=(tmdbId?.toLongOrNull()?:0)>0 || imdbId?.matches(Regex("tt[0-9]{5,12}"))==true
    if(kind==PosterKind.MOVIES&&!hasExternal&&resolveProvider!=null) {
        awaitPosterPriority()
        val details=try{resolveProvider()}catch(cancelled:CancellationException){throw cancelled}catch(_:Exception){null}
        if(details!=null) {
            lookupName=details.title?.takeIf{it.isNotBlank()}?:name
            lookupYear=details.year?:year;lookupTmdb=details.tmdbId;lookupImdb=details.imdbId
            if(details.url!=url&&GenericPosterPolicy.hasSource(details.url)) {
                MoviePosterLoader.loadWithRetry(context,details.url,kind)?.let{return ready(it,"PROVIDER")}
            }
        }
    }
    val fallback=try { verifiedPoster(kind,lookupName,lookupYear,lookupTmdb,lookupImdb,season) }
        catch(cancelled:CancellationException){throw cancelled}
        catch(_:Exception){null}
    val image=fallback?.let{awaitPosterPriority();MoviePosterLoader.loadWithRetry(context,it,kind)}
    if(image!=null&&fallback!=null&&kind==PosterKind.MOVIES) {
        MovieCatalogPosterResolver.cached(lookupName,lookupYear,lookupTmdb,lookupImdb)
            ?.takeIf{it.url==fallback}?.let{MoviePosterBindingCache.remember(bindingKey,it.url,it.tmdbId)}
    }
    return ready(image,if(image!=null)"TMDB"else"NONE")
}

/** A real playing episode can prepare a verified season poster without changing episode/provider IDs. */
internal suspend fun warmPlayingSeasonPoster(context:Context,name:String,year:Int?,tmdbId:String?,imdbId:String?,season:Int) {
    if(season<0)return
    try {
        awaitPosterPriority()
        val poster=verifiedPosterBudget.run(false) {
            withTimeoutOrNull(15_000L){SeriesCatalogPosterResolver.resolve(name,year,tmdbId,imdbId,TmdbClientProvider.client::get,season)?.takeIf{it.isSeason}}
        }?:return
        if(MoviePosterLoader.loadWithRetry(context,poster.url,PosterKind.SERIES)!=null)SeasonPosterRevision.update{it+1}
    }catch(cancelled:CancellationException){throw cancelled}
    catch(_:Exception){ }
}

/** Same five-item/two-worker reserve; keep compressed files only beyond the nearest row. */
internal suspend fun prefetchCatalogPoster(context:Context,kind:PosterKind,item:PosterCandidate):String? =
    MediaOpeningPriority.whileIdle { prefetchIdleCatalogPoster(context,kind,item) }

private suspend fun prefetchIdleCatalogPoster(context:Context,kind:PosterKind,item:PosterCandidate):String? {
    awaitPosterPriority()
    if(kind==PosterKind.MOVIES) {
        val bound=MoviePosterBindingCache.cached(MoviePosterBindingCache.key(item.scope,item.id,item.url,item.name,item.year,item.tmdbId,item.imdbId))
        if(bound!=null&&MoviePosterLoader.prefetch(context,bound,kind=kind,duringNavigation=true))return bound
    }
    if(kind==PosterKind.SERIES&&item.season!=null) {
        val prepared=SeriesCatalogPosterResolver.cached(item.name,item.year,item.tmdbId,item.imdbId,item.season)?.takeIf{it.isSeason}
        if(prepared!=null&&MoviePosterLoader.prefetch(context,prepared.url,kind=kind,duringNavigation=true))return prepared.url
    }
    if(GenericPosterPolicy.hasSource(item.url)) {
        if(MoviePosterLoader.prefetch(context,item.url,kind=kind,duringNavigation=true))return item.url
        // Do not turn a temporary background interruption into a metadata search.
        if(!MoviePosterLoader.knownMissing(item.url))return null
    }
    val url=verifiedPoster(kind,item.name,item.year,item.tmdbId,item.imdbId,item.season,background=true)?:return null
    return if(MoviePosterLoader.prefetch(context,url,kind=kind,duringNavigation=true))url else null
}
