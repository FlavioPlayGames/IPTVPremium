package br.com.flaviotorres.iptvpremium.ui.movies
import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import br.com.flaviotorres.iptvpremium.data.cache.PosterKind
object MoviePosterLoader {
 var beforeLoad: (suspend (String)->Unit)? = null
 private val bitmaps=java.util.concurrent.ConcurrentHashMap<String,ImageBitmap>()
 fun peekBitmap(url:String?):ImageBitmap?=url?.let{bitmaps[it]}
 suspend fun loadCached(context:Context,url:String?):ImageBitmap?=peekBitmap(url)
 suspend fun loadWithRetry(context:Context,url:String?,kind:PosterKind):ImageBitmap? = url?.takeIf{it.startsWith("https://")||it.startsWith("http://")}?.let{beforeLoad?.invoke(it);bitmaps.getOrPut(it){ImageBitmap(it)}}
}
