# Validação da r4

## Evidência recebida da TV, antes da r4

Arquivo IPTV-tempos-capas.txt: 918 linhas filtradas, 214 downloads concluídos e 2 cancelamentos. Nenhuma outra falha de download registrada. Esses números são eventos, não necessariamente obras distintas ou uma sessão isolada: a coleta também pode conter o buffer anterior do logcat.

| Métrica | Eventos | Mediana | Percentil 95 | Máximo |
|---|---:|---:|---:|---:|
| Fila do download | 214 | 0 ms | 0 ms | 803 ms |
| Download e preparação | 214 | 227,5 ms | 823 ms | 950 ms |
| Arquivo pronto (inclui fila/obtenção) | 218 | 233 ms | 872 ms | 1158 ms |
| Decodificação | 218 | 7 ms | 16 ms | 40 ms |
| Carregamento após obter a URL | 218 | 250,5 ms | 881 ms | 1176 ms |

52 eventos de identificação: 35 OK e 17 UNRESOLVED. A correlação local entre hashes públicos de identidade e a lista enviada confirmou os três títulos Lei e Ordem, Unidade de Vítimas Especiais e Toronto: Intenção Criminal como não resolvidos. A série original reapareceu como falha em cache, cujo prazo de falha em memória é curto. A lista não contém ano/IDs nesses três registros. URLs de episódios e a lista não acompanham esta entrega.

O código da r3 comparava `Lei e Ordem` e `Lei & Ordem` como nomes diferentes. A r4 corrige essa diferença na identificação de capas alternativas, preservando o restante do título. A causa específica de cada resposta real do TMDB não pode ser reconstruída somente pelos status do log.

## Testes executados

- Fontes reais de busca, validação, cache e seleção de capas com adaptadores Android, respostas TMDB sintéticas e bitmaps simulados: passaram preferência do provedor, rejeição de outra obra, cache de temporadas, identidade com campos nulos e prioridades de vídeo/importação.
- Grafias `e`/`&`, acentos, subtítulos e três obras distintas: passaram busca alternativa limitada, reaproveitamento do cache, nomes alternativos oficiais e rejeição de ano conflitante, ambiguidade e obra diferente. IDs dos testes são sintéticos; não foram incluídos como mapeamento no aplicativo.
- Concorrência: com quatro downloads bloqueados por um sinal de teste, todas as quatro identidades avançaram, sem ultrapassar duas consultas simultâneas. Confirma a separação das filas; não mede ganho em segundos na TV.
- Regressões reais de histórico/Continuar normal e Kids, reconciliação, metadados de favoritos, compactação de 2200 fatos e mais de 400 registros: passaram.
- Cache de metadados em disco entre processos JVM e seleção M3U de imagens estáveis/episódios/paisagem: passaram. Parser não alterado; não foi necessário reprocessar a lista completa nesta revisão.
- Aplicador e reversão: passaram aplicação, reaplicação, recusa de base diferente e proteção contra desfazer edições posteriores. Executados em PowerShell 7 e com simulação do comportamento de arrays JSON do Windows PowerShell 5.1; não em Windows real.
- Coletor ADB: passaram modos buffer e ao vivo, seleção automática da TV e retenção das 918 linhas da amostra mais os dois novos formatos de tempo. Rejeitou URLs e campos extras de teste. ADB simulado, sem acesso remoto à TV.

Para repetir os testes JVM com ferramentas locais:

```powershell
python .\testes\Testar-Host.py --projeto "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium" --tools "PASTA_DOS_JARS"
```

`--tools` é opcional; sem cache, o teste baixa suas dependências Maven. Os testes portáveis não substituem compilação Android, API real, imagem real ou validação na TV.

## Verificação Android

`:app:compileDesempenhoKotlin :app:lintDesempenho` concluídos com BUILD SUCCESSFUL. Lint: 0 erros, 178 avisos e 6 sugestões; mesma contagem da r3. A compilação usou a configuração desempenho do projeto, sem alterar versão/assinatura.

Não foi gerado/publicado APK, nem feita instalação remota na TV. Não foi medido ganho da r4 no aparelho. O instalador usa a compilação e assinatura locais do projeto do usuário.
