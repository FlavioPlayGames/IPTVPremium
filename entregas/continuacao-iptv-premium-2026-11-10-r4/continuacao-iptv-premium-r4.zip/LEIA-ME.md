# IPTV Premium — r4: identificação e carregamento de capas

Atualização incremental sobre a r3. Altera quatro arquivos Kotlin, com backup e conferência dos hashes antes da cópia. Use no projeto que recebeu a r3; não aplique por cima de alterações diferentes nos mesmos arquivos.

## Melhorias

- A identificação das capas alternativas de séries reconhece `e` e `&` como grafias equivalentes, com acentos e pontuação tratados pelas regras já existentes. Mantém subtítulos, anos e IDs para distinguir a série original de suas derivadas. Não muda as regras globais de identidade de histórico/favoritos.
- Se a consulta principal não identificar a série, há uma consulta alternativa com `&`, limitada ao primeiro idioma. Não escolhe uma obra pelo primeiro resultado ou por popularidade. Títulos ambíguos continuam sem capa verificada.
- A fila de duas consultas de metadados libera sua vaga antes do download e da preparação da imagem. A mesma separação vale para a capa da temporada assistida. Os downloads usam os limites já existentes, sem aumentar a concorrência de rede ou de decodificação.
- Novos registros medem o tempo de espera pela consulta e o tempo da identificação. O coletor exporta esses tempos junto dos registros existentes de download/decodificação, mediante uma lista estrita de campos permitidos.
- Conserva as chaves de cache da r3, os mapas de capas de temporadas e a preferência pelas capas válidas do provedor. Histórico, favoritos, perfis, importação e transporte de reprodução não foram modificados nesta revisão.

Os testes reproduzem metadados públicos sintéticos de três séries distintas de Lei e Ordem, com grafias `e`/`&`. A resposta atual do serviço e a capa final precisam ser conferidas na TV; não há garantia de correspondência para todo título. Não foi atribuído um ID fixo a nenhuma série da sua lista.

## Aplicar e instalar na TV

Salve `continuacao-iptv-premium-r4.zip` em Downloads. Execute no PowerShell:

```powershell
$projeto = "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium"
$pasta = "$env:USERPROFILE\Downloads\continuacao-iptv-premium-r4"
Unblock-File -LiteralPath "$pasta.zip"
Expand-Archive -LiteralPath "$pasta.zip" -DestinationPath $pasta -Force
Set-Location $pasta
powershell -ExecutionPolicy Bypass -File .\Aplicar.ps1 -Projeto "$projeto"
if ($LASTEXITCODE -eq 0) {
    powershell -ExecutionPolicy Bypass -File .\Instalar-TV.ps1 -Projeto "$projeto"
} else {
    throw "A aplicacao falhou. Confira a mensagem antes de compilar/instalar."
}
```

O instalador está na pasta extraída de Downloads. Compila `assembleDesempenho` com os arquivos e a assinatura locais, escolhe a ABI da TV e instala com `adb install -r`. Não contém APK ou arquivos privados. Se houver divergência de hash, não force: confira a mensagem e o arquivo indicado. A aplicação mostra o caminho do backup e o comando para desfazer.

Como o M3U já foi atualizado na r3 e as imagens de episódio já foram rejeitadas, esta revisão não exige nova importação nem limpeza de cache. Abra as séries sem capa para permitir a nova identificação.

## Conferência na TV e medição

1. Abra Lei e Ordem, Unidade de Vítimas Especiais e Toronto: Intenção Criminal no catálogo. Confira se cada uma recebe sua própria capa.
2. Visite algumas linhas com capas novas, aguarde, saia e reabra o mesmo catálogo. Não use Atualizar entre as duas aberturas.
3. Para registrar esses testes, abra outro PowerShell na pasta extraída e execute ANTES de navegar:

```powershell
powershell -ExecutionPolicy Bypass -File .\Coletar-Diagnostico.ps1 -AoVivo
```

Ctrl+C encerra. O arquivo fica em `Downloads\IPTV-tempos-capas-r4.txt`. O coletor também aceita `-Serial` quando houver mais de um dispositivo. Sem `-AoVivo`, exporta os registros ainda disponíveis no buffer da TV. Não apaga o buffer. Não exporta URLs, nomes dos conteúdos, senhas ou tokens.

A métrica `lookup_queue` mede a espera pela vaga de metadados. `lookup` mede a resolução/cache da identidade; não inclui o download da imagem. `PosterLoadPerf` registra fila/download/preparação/decodificação depois da obtenção da URL. O coletor não mede o instante exato em que o quadro aparece no painel da TV, e consultas canceladas ou encerradas pelo limite de tempo podem não gerar o registro final `lookup`.

Os tempos incluídos em VALIDACAO.md são da r3 recebida da TV; não representam um ganho já medido da r4.
