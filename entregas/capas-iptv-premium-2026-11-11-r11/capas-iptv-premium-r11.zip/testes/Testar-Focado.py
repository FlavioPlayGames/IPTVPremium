"""Testes JVM de r11: fontes reais, com adaptadores Android/DAO/rede/bitmap indicados no relatorio."""
from pathlib import Path
import argparse, os, subprocess, tempfile, shutil, urllib.request
cli=argparse.ArgumentParser(description=__doc__)
cli.add_argument('--projeto',type=Path,required=True)
cli.add_argument('--lista',type=Path,help='ZIP M3U completo, opcional')
cli.add_argument('--tools',type=Path,help='Cache local dos JARs Maven')
cli.add_argument('--java',default='java')
cli.add_argument('--suite',choices=['all','poster','xtream'],default='all')
a=cli.parse_args();fixtures=Path(__file__).resolve().parent
root=a.projeto.resolve()/'app/src/main/java/br/com/flaviotorres/iptvpremium'
tools=a.tools or fixtures/'.tools';tools.mkdir(parents=True,exist_ok=True)
artifacts=[('org.jetbrains.kotlin','kotlin-compiler-embeddable','2.2.10'),('org.jetbrains.kotlin','kotlin-stdlib','2.2.10'),('org.jetbrains.kotlin','kotlin-script-runtime','2.2.10'),('org.jetbrains.kotlin','kotlin-reflect','1.6.10'),('org.jetbrains.kotlin','kotlin-daemon-embeddable','2.2.10'),('org.jetbrains.kotlinx','kotlinx-coroutines-core-jvm','1.8.0'),('org.jetbrains','annotations','13.0'),('org.json','json','20250517'),('com.google.code.gson','gson','2.11.0')]
jars=[]
for group,name,version in artifacts:
 dest=tools/f'{name}-{version}.jar'
 if not dest.exists():
  temporary=dest.with_suffix('.download');url=f'https://repo.maven.apache.org/maven2/{group.replace(".","/")}/{name}/{version}/{dest.name}'
  with urllib.request.urlopen(url,timeout=120) as response,temporary.open('wb') as output:shutil.copyfileobj(response,output)
  temporary.replace(dest)
 jars.append(str(dest.resolve()))
cp=os.pathsep.join(jars)
def run(*args):subprocess.run(list(map(str,args)),check=True)
with tempfile.TemporaryDirectory(prefix='iptv-r11-host-') as tmp:
 work=Path(tmp)
 for group in ['shared','poster','parser','common','search','xtream']:
  (work/group).mkdir()
  for p in (fixtures/group).glob('*.kt'):shutil.copyfile(p,work/group/p.name)
 for source,model,fn in [('ui/components/UnifiedMediaCatalog.kt','CatalogPoster','catalogContinuePosters'),('ui/kids/KidsMediaCatalog.kt','KidsPoster','kidsContinuePosters')]:
  text=(root/source).read_text(encoding='utf-8-sig');start=text.index('internal data class '+model+'(');end=text.index('\n\n',start);fstart=text.index('internal fun '+fn+'(');fend=text.index('\n}',fstart)+2
  (work/'shared'/(model+'.kt')).write_text('package host\nimport br.com.flaviotorres.iptvpremium.data.history.WatchHistoryEntry\nimport br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType\n'+text[start:end]+'\n'+text[fstart:fend],encoding='utf-8')
 def compile(name,production,adapters):
  jar=work/(name+'.jar')
  run(a.java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',jar,*[root/f for f in production],*[work/f for f in adapters])
  return str(jar)+os.pathsep+cp
 if a.suite in ['all','poster']:
  metadata=['data/cache/PosterRequestLocks.kt','data/repository/CatalogMetadataCache.kt','data/repository/CatalogMetadataDiskCache.kt','data/repository/CatalogMetadataIdentity.kt','data/repository/SeriesCatalogPosterResolver.kt','data/repository/MovieCatalogPosterResolver.kt','data/repository/SeriesArtworkIdentityResolver.kt']
  poster=compile('poster',['ui/movies/CatalogPosterFallback.kt','ui/movies/MovieProviderPoster.kt','data/cache/GenericPosterPolicy.kt','data/cache/PosterCategoryPolicy.kt','data/cache/PosterReserve.kt','data/cache/PosterNetworkBudget.kt','data/cache/PosterVisibilityPriority.kt','data/cache/PosterSourceUrl.kt','data/cache/PosterFailurePolicy.kt']+metadata,['poster/'+p.name for p in (work/'poster').glob('*.kt') if p.name!='StorageMain.kt']+['shared/Context.kt','common/Budget.kt','common/Log.kt','common/CacheMain.kt'])
  run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.ui.movies.VisibleMainKt')
  run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.ui.movies.MovieFallbackMainKt')
  run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.ui.movies.ImportOrderMainKt')
  run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.data.cache.ReserveMainKt')
  for mode in ['write','read']:run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.data.repository.CacheMainKt',mode,work/'metadata-cache')
 if a.suite in ['all','xtream']:
  xtream=compile('xtream',['data/parser/DefaultXtreamParser.kt','data/parser/XtreamParser.kt','data/parser/XtreamDirectCatalogReader.kt','data/cache/ImportTuningPolicy.kt','data/cache/PosterSourceUrl.kt']+[str(p.relative_to(root)) for p in (root/'domain/model').glob('*.kt')],['xtream/JsonReader.kt','xtream/XtreamMain.kt','xtream/Log.kt'])
  run(a.java,'-cp',xtream,'host.xtream.XtreamMainKt')
