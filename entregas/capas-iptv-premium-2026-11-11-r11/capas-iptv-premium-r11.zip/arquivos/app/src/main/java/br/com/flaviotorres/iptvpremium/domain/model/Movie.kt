package br.com.flaviotorres.iptvpremium.domain.model

data class Movie(
    val id: String,
    val name: String,
    val categoryId: String?,
    val posterUrl: String?,
    val backdropUrl: String?,
    val streamUrl: String,
    val year: Int?,
    val rating: Double?,
    val durationSeconds: Long?,
    val addedAtEpochSeconds: Long? = null,
    val tmdbId: String? = null,
    val imdbId: String? = null
)
