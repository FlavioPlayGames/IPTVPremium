package br.com.flaviotorres.iptvpremium.data.cache.importer

/** One scan for known metadata; first occurrence and empty tvg-id presence stay unchanged. */
internal object M3uEntryMetadata {
    data class Fields(val group: String?, val logo: String?, val tvgId: String?, val hasXuiId: Boolean, val tmdbId:String?=null, val imdbId:String?=null)
    private val attributes = java.util.regex.Pattern.compile(
        "(?:^|\\s)(?:(group-title|tvg-logo|tvg-id|tmdb-id|tmdb_id|tmdb|tvg-tmdb|imdb-id|imdb_id|imdb|tvg-imdb)\\s*=\\s*\"([^\"]*)\"|(xui-id)\\s*=)",
        java.util.regex.Pattern.CASE_INSENSITIVE or java.util.regex.Pattern.UNICODE_CASE
    )
    // Keep the legacy type hint when an xui-id token occurs inside a quoted value.
    private val embeddedXui = java.util.regex.Pattern.compile(
        "\\sxui-id\\s*=", java.util.regex.Pattern.CASE_INSENSITIVE or java.util.regex.Pattern.UNICODE_CASE
    )
    private fun embedded(value: String?): Boolean =
        value != null && value.indexOf('=') >= 0 && embeddedXui.matcher(value).find()

    fun parse(line: String): Fields {
        var group: String? = null
        var logo: String? = null
        var tvgId: String? = null
        var hasXuiId = false
        var tmdb:String?=null;var imdb:String?=null
        val matcher = attributes.matcher(line)
        while (matcher.find()) {
            val key = matcher.group(1)
            if (!hasXuiId && key != null && embedded(matcher.group(2))) hasXuiId = true
            when {
                key == null -> hasXuiId = true
                key.equals("group-title", true) && group == null -> group = matcher.group(2)
                key.equals("tvg-logo", true) && logo == null -> logo = matcher.group(2)
                key.equals("tvg-id", true) && tvgId == null -> tvgId = matcher.group(2)
                key.lowercase(java.util.Locale.ROOT).replace('_','-') in listOf("tmdb-id","tmdb","tvg-tmdb") && tmdb==null -> tmdb=matcher.group(2)?.trim()?.toLongOrNull()?.takeIf{it>0}?.toString()
                key.lowercase(java.util.Locale.ROOT).replace('_','-') in listOf("imdb-id","imdb","tvg-imdb") && imdb==null -> imdb=matcher.group(2)?.trim()?.lowercase(java.util.Locale.ROOT)?.takeIf{it.matches(Regex("tt[0-9]{5,12}"))}
            }
        }
        return Fields(group, logo, tvgId, hasXuiId, tmdb, imdb)
    }
}
