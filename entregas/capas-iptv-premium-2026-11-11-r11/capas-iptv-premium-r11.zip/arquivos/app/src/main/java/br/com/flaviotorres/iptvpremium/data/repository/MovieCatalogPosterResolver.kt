package br.com.flaviotorres.iptvpremium.data.repository

import org.json.JSONObject

internal data class MovieCatalogPoster(val url:String,val tmdbId:Int)

/** Small public artwork record, shared across imports. Never guess by popularity or a fuzzy title. */
internal object MovieCatalogPosterResolver {
    private val pathPattern=Regex("^/[A-Za-z0-9_-]+\\.(?:jpg|png|webp)$")
    private fun key(title:String,year:Int?,tmdb:String?,imdb:String?) =
        "movie_catalog_poster_v1:"+listOf(artworkTitle(title),catalogTitleYear(title,year),tmdb?.trim(),imdb?.trim()).joinToString("|")
    private fun poster(root:JSONObject):MovieCatalogPoster? {
        val id=root.optInt("id",0).takeIf{it>0}?:return null
        val path=root.optString("poster_path").takeIf{pathPattern.matches(it)}?:return null
        return MovieCatalogPoster("https://image.tmdb.org/t/p/w342$path",id)
    }
    fun peek(title:String,year:Int?,tmdb:String?,imdb:String?) = CatalogMetadataCache.peek(key(title,year,tmdb,imdb))?.let(::poster)
    suspend fun cached(title:String,year:Int?,tmdb:String?,imdb:String?) = CatalogMetadataCache.cached(key(title,year,tmdb,imdb))?.let(::poster)
    suspend fun resolve(title:String,year:Int?,tmdb:String?,imdb:String?,get:suspend(String,Map<String,String>)->String):MovieCatalogPoster? {
        val wanted=artworkTitle(title)
        val release=catalogTitleYear(title,year)?.takeUnless{wanted==it.toString()}
        val imdbKey=imdb?.trim()?.lowercase(java.util.Locale.ROOT)?.takeIf{it.matches(Regex("tt[0-9]{5,12}"))}
        val tmdbKey=tmdb?.trim()?.toIntOrNull()?.takeIf{it>0}?.toString()
        if(wanted.isBlank()&&tmdbKey==null&&imdbKey==null)return null
        val root=CatalogMetadataCache.load(key(title,year,tmdb,imdb)) {
            val details=resolveUncachedArtworkIdentity(title,release,tmdbKey,imdbKey,get,"movie",emptyList(),
                searchLanguages=listOf("pt-BR","en-US","es-ES"),includeMovieCredits=false)?:return@load null
            val id=details.optInt("id",0).takeIf{it>0}?:return@load null
            val requestedId=tmdbKey?.toInt()
            if(requestedId!=null&&requestedId!=id)return@load null
            val external=details.optJSONObject("external_ids")?.optString("imdb_id").orEmpty().ifBlank{details.optString("imdb_id")}
            if(imdbKey!=null&&external.isNotBlank()&&external!=imdbKey)return@load null
            if(wanted.isNotBlank()&&officialSeriesNames(details,"movie").none{artworkTitle(it)==wanted})return@load null
            if(requestedId==null&&imdbKey==null&&release!=null&&details.optString("release_date").take(4).toIntOrNull()!=release)return@load null
            val path=details.optString("poster_path").takeIf{pathPattern.matches(it)}?:run {
                val rows=details.optJSONObject("images")?.optJSONArray("posters")
                (0 until (rows?.length()?:0)).mapNotNull{rows?.optJSONObject(it)}.filter {
                    pathPattern.matches(it.optString("file_path"))&&it.optDouble("aspect_ratio",0.0) in 0.01..0.99
                }.maxByOrNull { when(it.optString("iso_639_1")){"pt"->3;"null",""->2;"en"->1;else->0} }?.optString("file_path")
            }?:return@load null
            JSONObject().put("id",id).put("poster_path",path)
        }
        return root?.let(::poster)
    }
}
