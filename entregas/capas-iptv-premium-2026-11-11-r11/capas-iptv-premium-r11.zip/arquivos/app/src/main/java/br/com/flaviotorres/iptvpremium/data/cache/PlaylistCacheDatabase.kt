package br.com.flaviotorres.iptvpremium.data.cache

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedCategoryEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedChannelEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedEpisodeEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedMovieEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedSeriesEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.PlaylistCacheGenerationEntity

@Database(
    entities = [
        PlaylistCacheGenerationEntity::class,
        CachedCategoryEntity::class,
        CachedChannelEntity::class,
        CachedMovieEntity::class,
        CachedSeriesEntity::class,
        CachedEpisodeEntity::class
    ],
    version = PlaylistCacheDatabase.SCHEMA_VERSION,
    exportSchema = false
)
abstract class PlaylistCacheDatabase : RoomDatabase() {

    abstract fun playlistCacheDao(): PlaylistCacheDao

    companion object {
        const val SCHEMA_VERSION = 7

        @Volatile
        private var INSTANCE: PlaylistCacheDatabase? = null

        private val MIGRATION_1_2 =
            object : Migration(
                startVersion = 1,
                endVersion = 2
            ) {
                override fun migrate(
                    db: SupportSQLiteDatabase
                ) {
                    db.execSQL(
                        """
                        ALTER TABLE cached_movies
                        ADD COLUMN addedAtEpochSeconds INTEGER
                        """.trimIndent()
                    )

                    db.execSQL(
                        """
                        CREATE INDEX IF NOT EXISTS
                        index_cached_movies_playlistId_generationId_addedAtEpochSeconds
                        ON cached_movies(
                            playlistId,
                            generationId,
                            addedAtEpochSeconds
                        )
                        """.trimIndent()
                    )
                }
            }

        private val MIGRATION_2_3 =
            object : Migration(
                startVersion = 2,
                endVersion = 3
            ) {
                override fun migrate(
                    db: SupportSQLiteDatabase
                ) {
                    db.execSQL(
                        """
                        ALTER TABLE cached_movies
                        ADD COLUMN providerOrder INTEGER
                        """.trimIndent()
                    )

                    db.execSQL(
                        """
                        CREATE INDEX IF NOT EXISTS
                        index_cached_movies_playlistId_generationId_providerOrder
                        ON cached_movies(
                            playlistId,
                            generationId,
                            providerOrder
                        )
                        """.trimIndent()
                    )
                }
            }

        private val MIGRATION_3_4 =
            object : Migration(
                startVersion = 3,
                endVersion = 4
            ) {
                override fun migrate(db: SupportSQLiteDatabase) {
                    // Nao apaga historico, cache, favoritos ou episodios.
                    db.execSQL(
                        "ALTER TABLE cached_series ADD COLUMN providerOrder INTEGER"
                    )
                    // Aproveita a sequencia existente de insercao para
                    // preservar uma ordem estavel sem exigir novo download.
                    db.execSQL(
                        "UPDATE cached_series SET providerOrder = rowid"
                    )
                    db.execSQL(
                        """
                        CREATE INDEX IF NOT EXISTS
                        index_cached_series_playlistId_generationId_providerOrder
                        ON cached_series(playlistId, generationId, providerOrder)
                        """.trimIndent()
                    )
                }
            }

        // The season index already covers (playlistId, generationId, seriesId).
        // Keep the primary key and the complete index; no rows or IDs are changed.
        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("DROP INDEX IF EXISTS index_cached_episodes_playlistId_generationId_seriesId")
            }
        }

        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE cached_categories ADD COLUMN providerOrder INTEGER")
            }
        }

        // Nullable public identity metadata only; existing catalogues and user data stay intact.
        private val MIGRATION_6_7 = object : Migration(6, 7) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("ALTER TABLE cached_movies ADD COLUMN tmdbId TEXT")
                db.execSQL("ALTER TABLE cached_movies ADD COLUMN imdbId TEXT")
            }
        }

        fun getInstance(
            context: Context
        ): PlaylistCacheDatabase {
            return INSTANCE
                ?: synchronized(this) {
                    INSTANCE
                        ?: ImportTuning.configure(Room.databaseBuilder(
                            context.applicationContext,
                            PlaylistCacheDatabase::class.java,
                            "playlist_cache.db"
                        )
                            .addMigrations(
                                MIGRATION_1_2,
                                MIGRATION_2_3,
                                MIGRATION_3_4,
                                MIGRATION_4_5,
                                MIGRATION_5_6,
                                MIGRATION_6_7
                            ), ImportTuning.load(context))
                            .build()
                            .also { database ->
                                INSTANCE = database
                            }
                }
        }
    }
}
