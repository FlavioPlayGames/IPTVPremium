package br.com.flaviotorres.iptvpremium.data.m3u

import androidx.sqlite.db.SupportSQLiteDatabase
import java.io.*

internal object M3uCatalogWriter {
    /** The caller owns the Room transaction. Only its unpublished IMPORTING generation is writable. */
    fun write(db:SupportSQLiteDatabase,spool:File,playlist:String,generation:String,expected:M3uCatalogParser.Counts,ensure:()->Unit):LongArray {
        db.query("SELECT status FROM playlist_cache_generations WHERE playlistId=? AND generationId=?",arrayOf(playlist,generation)).use {
            check(it.moveToFirst()&&it.getString(0)=="IMPORTING"){"GENERATION_NOT_IMPORTING"}
        }
        val statements=M3uCatalogFormat.inserts.map{db.compileStatement(it)}
        val attempted=LongArray(4)
        try {
            DataInputStream(BufferedInputStream(FileInputStream(spool),256*1024)).use{input->
                check(input.readInt()==M3uCatalogFormat.MAGIC){"INVALID_SPOOL"}
                while(true){
                    ensure()
                    val (kind,row)=M3uCatalogParser.read(input)?:break
                    check(row[0]==playlist&&row[1]==generation){"GENERATION_MISMATCH"}
                    val statement=statements[kind]
                    for(i in row.indices)when(val value=row[i]){
                        null->statement.bindNull(i+1)
                        is String->statement.bindString(i+1,value)
                        is Long->statement.bindLong(i+1,value)
                        else->error("INVALID_FIELD")
                    }
                    statement.executeInsert();attempted[kind]++
                }
            }
            check(attempted.contentEquals(longArrayOf(expected.categories.toLong(),expected.channels,expected.movies,expected.series.toLong()))){"ATTEMPT_COUNTS"}
            for((index,table) in listOf("cached_categories","cached_channels","cached_movies","cached_series").withIndex()){
                ensure()
                db.query("SELECT COUNT(*) FROM $table WHERE playlistId=? AND generationId=?",arrayOf(playlist,generation)).use {
                    check(it.moveToFirst());val n=it.getLong(0);val total=attempted[index]
                    check(n<=total&&(total==0L||n>0)){"CATALOG_COUNTS"}
                    if(index==0||index==3)check(n==total){"CATALOG_COUNTS"}
                }
            }
            ensure()
            return attempted
        }finally{statements.forEach{it.close()}}
    }
}
