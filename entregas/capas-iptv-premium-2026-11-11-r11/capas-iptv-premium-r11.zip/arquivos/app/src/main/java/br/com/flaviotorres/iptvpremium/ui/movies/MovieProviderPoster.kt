package br.com.flaviotorres.iptvpremium.ui.movies

import br.com.flaviotorres.iptvpremium.data.cache.PosterRequestLocks
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.CancellationException

/** Provider metadata only; no video address, account or catalogue copies in this bounded RAM cache. */
data class MovieProviderPoster(val url:String?,val title:String?,val year:Int?,val tmdbId:String?,val imdbId:String?)
internal object MovieProviderPosterCache {
    private data class Entry(val value:MovieProviderPoster?,val time:Long)
    private val entries=LinkedHashMap<String,Entry>(16,.75f,true)
    private val locks=PosterRequestLocks()
    private val slots=Semaphore(2)
    private fun cached(key:String):Entry?=synchronized(entries){entries[key]?.takeIf {
        System.nanoTime()-it.time in 0..(if(it.value==null)60L else 600L)*1_000_000_000
    }}
    suspend fun load(key:String,loader:suspend()->MovieProviderPoster?):MovieProviderPoster? {
        cached(key)?.let{return it.value}
        return locks.withLock(key) {
            cached(key)?.let{return@withLock it.value}
            val result=slots.withPermit{withTimeoutOrNull(4_500L){
                try{loader()?.takeIf{it.url!=null||it.title!=null||it.year!=null||it.tmdbId!=null||it.imdbId!=null}}catch(cancelled:CancellationException){throw cancelled}catch(_:Exception){null}
            }}
            synchronized(entries){
                entries[key]=Entry(result,System.nanoTime())
                while(entries.size>128)entries.remove(entries.keys.first())
            }
            result
        }
    }
}
