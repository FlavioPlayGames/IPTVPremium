package br.com.flaviotorres.iptvpremium.data.repository

import android.util.Log
import java.security.MessageDigest
import org.json.JSONObject

internal const val SERIES_CATALOG_POSTER_PREFIX="series_catalog_poster_v2:"
internal data class SeriesCatalogPoster(val url:String,val tmdbId:Int,val workHash:String,val fallbackUrl:String?=null,val isSeason:Boolean=false)

/** Verified work identity, independent of playlist IDs and untrusted provider episode images. */
internal object SeriesCatalogPosterResolver {
    private val imagePath=Regex("^/[A-Za-z0-9_-]+\\.(?:jpg|png|webp)$")
    private val imdbPattern=Regex("tt[0-9]+")
    private data class Identity(val key:String,val title:String,val wanted:String,val year:Int?,val tmdb:Int?,val imdb:String?) {
        val hash:String get()=MessageDigest.getInstance("SHA-256").digest(key.toByteArray(Charsets.UTF_8)).take(6).joinToString(""){"%02x".format(it.toInt()and 255)}
    }
    private fun identity(title:String,year:Int?,tmdb:String?,imdb:String?):Identity? {
        val lookup=seriesArtworkLookupTitle(title.trim());val wanted=seriesPosterTitle(lookup)
        val tmdbId=tmdb?.trim()?.toIntOrNull()?.takeIf{it>0}
        val imdbId=imdb?.trim()?.takeIf{imdbPattern.matches(it)}
        if(wanted.isBlank()&&tmdbId==null&&imdbId==null)return null
        // In a title such as 1923/1983 the number is the name, not its release year.
        val suppliedYear=year?.takeUnless{wanted==it.toString()}
        val effectiveYear=catalogTitleYear(lookup,suppliedYear)
        val key=SERIES_CATALOG_POSTER_PREFIX+listOf(artworkTitle(lookup),effectiveYear?.toString().orEmpty(),tmdbId?.toString().orEmpty(),imdbId.orEmpty()).joinToString("|")
        return Identity(key,lookup,wanted,effectiveYear,tmdbId,imdbId)
    }
    private fun poster(root:JSONObject,work:Identity,season:Int?):SeriesCatalogPoster? {
        val seasonal=season?.takeIf{it>=0}?.let{root.optJSONObject("season_posters")?.optString(it.toString())}
        val path=seasonal?.takeIf{imagePath.matches(it)}?:root.optString("poster_path").takeIf{imagePath.matches(it)}?:return null
        val id=root.optInt("id",0).takeIf{it>0}?:return null
        val general=root.optString("poster_path").takeIf{imagePath.matches(it)&&it!=path}
        return SeriesCatalogPoster("https://image.tmdb.org/t/p/w500$path",id,work.hash,general?.let{"https://image.tmdb.org/t/p/w500$it"},seasonal?.let{imagePath.matches(it)}==true)
    }
    fun peek(title:String,year:Int?,tmdb:String?,imdb:String?,season:Int?=null):SeriesCatalogPoster? {
        val work=identity(title,year,tmdb,imdb)?:return null
        return CatalogMetadataCache.peek(work.key)?.let{poster(it,work,season)}
    }
    suspend fun cached(title:String,year:Int?,tmdb:String?,imdb:String?,season:Int?=null):SeriesCatalogPoster? {
        val work=identity(title,year,tmdb,imdb)?:return null
        return CatalogMetadataCache.cached(work.key)?.let{poster(it,work,season)}
    }
    suspend fun resolve(title:String,year:Int?,tmdb:String?,imdb:String?,get:suspend(String,Map<String,String>)->String,season:Int?=null):SeriesCatalogPoster? {
        val work=identity(title,year,tmdb,imdb)?:return null
        val started=System.nanoTime()
        var remote=false
        val root=CatalogMetadataCache.load(work.key){
            remote=true
            // Do not reuse an earlier provider-image-biased identity cache.
            val details=resolveUncachedArtworkIdentity(work.title,work.year,work.tmdb?.toString(),work.imdb,get,"tv",emptyList(),searchLanguages=listOf("pt-BR","en-US","es-ES"),allowAliasWithoutYear=true,titleNormalizer=::seriesPosterTitle,alternateQuery=seriesPosterAlternateQuery(work.title))?:return@load null
            val id=details.optInt("id",0);if(id<=0)return@load null
            if(work.tmdb!=null&&id!=work.tmdb)return@load null
            val externalImdb=details.optJSONObject("external_ids")?.optString("imdb_id").orEmpty()
            if(work.imdb!=null&&externalImdb.isNotBlank()&&externalImdb!=work.imdb)return@load null
            if(work.wanted.isNotBlank()&&officialSeriesNames(details).none{seriesPosterTitle(it)==work.wanted})return@load null
            if(work.tmdb==null&&work.imdb==null&&work.year!=null&&details.optString("first_air_date").take(4).toIntOrNull()!=work.year)return@load null
            val path=details.optString("poster_path").takeIf{imagePath.matches(it)}?:run {
                val list=details.optJSONObject("images")?.optJSONArray("posters")
                (0 until (list?.length()?:0)).mapNotNull{list?.optJSONObject(it)}.filter{
                    imagePath.matches(it.optString("file_path"))&&it.optDouble("aspect_ratio",0.0)<1.0
                }.maxByOrNull{when(it.optString("iso_639_1")){"pt"->3;"null",""->2;"en"->1;else->0}}?.optString("file_path")
            }
            val seasons=JSONObject()
            val rows=details.optJSONArray("seasons")
            for(index in 0 until (rows?.length()?:0)) {
                val row=rows?.optJSONObject(index)?:continue
                val number=row.optInt("season_number",-1)
                val cover=row.optString("poster_path")
                if(number>=0&&imagePath.matches(cover))seasons.put(number.toString(),cover)
            }
            if(path==null&&seasons.length()==0)return@load null
            // Store public artwork only, never the user's watch progress in the shared cache.
            JSONObject().put("id",id).put("poster_path",path).put("season_posters",seasons)
        }
        val result=root?.let{poster(it,work,season)}
        Log.i("SeriesPosterPerf","stage=identity status=${if(result!=null)"OK"else"UNRESOLVED"} source=${if(remote)"REMOTE"else"CACHE"} workHash=${work.hash}${result?.let{" tmdbId=${it.tmdbId}"}.orEmpty()}")
        Log.i("SeriesPosterPerf","stage=lookup status=${if(result!=null)"OK"else"UNRESOLVED"} source=${if(remote)"REMOTE"else"CACHE"} workHash=${work.hash} elapsedMs=${(System.nanoTime()-started)/1_000_000}")
        return result
    }
}
