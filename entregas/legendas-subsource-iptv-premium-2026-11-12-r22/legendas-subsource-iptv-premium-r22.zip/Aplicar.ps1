﻿[CmdletBinding()]
param([string]$Projeto="$env:USERPROFILE\AndroidStudioProjects\IPTVPremium",[string]$Downloads="$env:USERPROFILE\Downloads")
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Seguranca.ps1"
$Projeto=Projeto-Valido $Projeto
$itens=ConvertFrom-Json -InputObject (Get-Content -Raw -LiteralPath "$PSScriptRoot\manifesto.json")
$itens=@($itens)
$prontos=0
foreach($item in $itens) {
    if($item.path -notmatch '^app/src/main/(?:java/[A-Za-z0-9_/]+\.kt|res/drawable-nodpi/[a-z0-9_]+\.(?:png|webp))$'){throw 'Manifesto invalido.'}
    $p=Caminho-Seguro $Projeto $item.path
    if((Test-Path -LiteralPath $p) -and !(Test-Path -LiteralPath $p -PathType Leaf)){throw 'Destino inesperado.'}
    if($null -ne $item.afterHash -and (Hash-Arquivo (Join-Path "$PSScriptRoot\arquivos" $item.path)) -ne $item.afterHash){throw 'Conteudo do pacote alterado.'}
    $hash=Hash-Arquivo $p
    if($hash -eq $item.afterHash){$prontos++;continue}
    if($hash -ne $item.beforeHash){throw "Base diferente: $($item.path). Nenhum fonte ou recurso foi alterado."}
}
if($prontos -eq $itens.Count){Write-Host 'Atualizacao r22 ja aplicada.';return}
if($prontos -gt 0){throw 'Aplicacao parcial encontrada. Confira a base antes de continuar.'}
$backup=Destino-Externo $Projeto $Downloads 'IPTV-restauracao-r22-'
foreach($item in $itens) {
    $destino=Join-Path "$backup\arquivos" $item.path
    New-Item -ItemType Directory -Path (Split-Path $destino) -Force | Out-Null
    if($null -ne $item.beforeHash){Copy-Item -LiteralPath (Join-Path $Projeto $item.path) -Destination $destino}
    if((Hash-Arquivo $destino) -ne $item.beforeHash){throw 'Backup nao confere; nada foi alterado.'}
}
@{projeto=$Projeto;arquivos=$itens;desfeito=$false}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath "$backup\estado.json" -Encoding UTF8
try {
    foreach($item in $itens) {
        $p=Join-Path $Projeto $item.path
        if($null -eq $item.afterHash){Remove-Item -LiteralPath $p -Force}
        else {
            New-Item -ItemType Directory -Path (Split-Path $p) -Force | Out-Null
            Copy-Item -LiteralPath (Join-Path "$PSScriptRoot\arquivos" $item.path) -Destination $p -Force}
        if((Hash-Arquivo $p) -ne $item.afterHash){throw 'Resultado da copia/exclusao nao confere.'}
    }
} catch {
    foreach($item in $itens){
        $p=Join-Path $Projeto $item.path
        if($null -eq $item.beforeHash){if(Test-Path -LiteralPath $p -PathType Leaf){Remove-Item -LiteralPath $p -Force}}
        else {Copy-Item -LiteralPath (Join-Path "$backup\arquivos" $item.path) -Destination $p -Force}
    }
    throw
}
Write-Host "Atualizacao r22 aplicada. Recuperacao externa: $backup"
Write-Host "Para desfazer: powershell -ExecutionPolicy Bypass -File '$PSScriptRoot\Desfazer.ps1' -Backup '$backup'"
