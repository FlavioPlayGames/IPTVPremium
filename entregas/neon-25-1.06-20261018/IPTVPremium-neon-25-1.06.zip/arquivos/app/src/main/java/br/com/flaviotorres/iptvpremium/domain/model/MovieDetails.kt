package br.com.flaviotorres.iptvpremium.domain.model

data class MovieCastMemberDetails(
    val id: String,
    val name: String,
    val profileUrl: String? = null,
    val characterName: String? = null,
    val tmdbId: String? = null
)

data class MovieDetails(
    val movieId: String,
    val plot: String? = null,
    val genres: List<String> = emptyList(),

    /*
     * Mantido por compatibilidade com o fluxo atual do provedor,
     * que ainda entrega o elenco apenas como nomes em muitos casos.
     */
    val cast: List<String> = emptyList(),

    /*
     * Estrutura enriquecida para a próxima etapa:
     * foto, personagem e identificador da pessoa.
     *
     * Enquanto ainda não houver dados enriquecidos, permanece vazia
     * e a interface pode continuar usando "cast" como fallback.
     */
    val castMembers: List<MovieCastMemberDetails> = emptyList(),

    val director: String? = null,
    val trailerUrl: String? = null,
    val posterUrl: String? = null,
    val backdropUrl: String? = null,

    /*
     * Logo/arte oficial do título.
     * A MovieDetailsScreen já está preparada para exibir essa imagem
     * e usar o nome em texto quando ela não existir.
     */
    val titleLogoUrl: String? = null,

    val year: Int? = null,
    val rating: Double? = null,
    val ratingSource: RatingSource? = null,
    val durationSeconds: Int? = null,
    val imdbId: String? = null,
    val tmdbId: String? = null,
    val providerTitle: String? = null,
    val localizedTitle: String? = null
)
