package br.com.flaviotorres.iptvpremium.data.repository

import br.com.flaviotorres.iptvpremium.data.history.ContentIdentity

/** The same confirmed IDs and official translations used by movie/series artwork. */
internal class TitleAliasResolver(private val get: suspend (String, Map<String, String>) -> String) {
    suspend fun resolve(source: ContentIdentity): ContentIdentity? {
        val kind = when (source.kind) { "series" -> "tv"; "movies" -> "movie"; else -> return null }
        val root = resolveSeriesArtworkIdentity(source.title, source.normalizedYear,
            source.tmdbKey, source.imdbKey, get, kind) ?: return null
        val id = root.optInt("id", -1).takeIf { it > 0 }?.toString() ?: return null
        val imdb = root.optJSONObject("external_ids")?.optString("imdb_id")?.takeIf { it.matches(Regex("tt[0-9]+")) }
            ?: root.optString("imdb_id").takeIf { it.matches(Regex("tt[0-9]+")) }
        if (source.tmdbKey != null && source.tmdbKey != id) return null
        if (source.imdbKey != null && imdb != null && source.imdbKey != imdb) return null
        val names = (preferredSeriesSearchNames(root, kind) + officialSeriesNames(root, kind))
            .filter { it.isNotBlank() && it.length <= 160 && it != "null" }.distinct().take(32)
        val year = root.optString(if (kind == "tv") "first_air_date" else "release_date").take(4).toIntOrNull()
        return source.copy(year = source.normalizedYear ?: year, imdb = source.imdbKey ?: imdb,
            tmdb = id, alternateTitles = names)
    }
}
