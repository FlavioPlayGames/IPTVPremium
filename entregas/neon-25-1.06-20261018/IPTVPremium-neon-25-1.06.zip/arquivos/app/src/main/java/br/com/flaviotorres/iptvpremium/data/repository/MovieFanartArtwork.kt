package br.com.flaviotorres.iptvpremium.data.repository
import kotlinx.coroutines.CancellationException
import org.json.JSONObject
internal data class MovieFanartArtwork(val logos: List<String> = emptyList(), val backdrops: List<String> = emptyList())
/** Fanart movies accepts confirmed TMDB/IMDb identifiers; TVmaze is never called for films. */
internal suspend fun loadMovieFanartArtwork(tmdb: String?, imdb: String?,
    get: suspend(String, String, Map<String,String>)->String?): MovieFanartArtwork {
    val numeric = tmdb?.trim()?.toIntOrNull()?.takeIf { it > 0 }?.toString()
    val imdbKey = imdb?.trim()?.takeIf { it.matches(Regex("tt[0-9]+")) }
    for (id in listOfNotNull(numeric, imdbKey).distinct()) {
        val root = try { get("fanart", "/movies/$id", emptyMap())?.let(::JSONObject) }
            catch (cancelled: CancellationException) { throw cancelled }
            catch (_: Exception) { null } ?: continue
        if (numeric != null && root.has("tmdb_id") && root.optString("tmdb_id") != numeric) continue
        if (imdbKey != null && root.has("imdb_id") && root.optString("imdb_id") != imdbKey) continue
        val result = MovieFanartArtwork(prioritizedFanartImages(root, listOf("hdmovielogo", "movielogo")),
            prioritizedFanartImages(root, listOf("moviebackground")))
        if (result.logos.isNotEmpty() || result.backdrops.isNotEmpty()) return result
    }
    return MovieFanartArtwork()
}
