package br.com.flaviotorres.iptvpremium.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.flaviotorres.iptvpremium.data.cache.CatalogVerticalIntent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first

/** One pending destination for repeated DPAD commands, including not-yet-composed rows. */
internal class CatalogGridNavigator(private val grid: LazyGridState, private val scope: CoroutineScope,
    private val columns: Int, private val count: () -> Int, private val load: (Int) -> Unit,
    private val manual: () -> Unit) {
    private val requesters = mutableMapOf<Int, FocusRequester>()
    private val revision = MutableStateFlow(0L)
    private val intent = CatalogVerticalIntent(columns)
    private var job: Job? = null
    fun attach(index: Int, requester: FocusRequester) { requesters[index] = requester; revision.value++ }
    fun detach(index: Int, requester: FocusRequester) { if (requesters[index] === requester) requesters.remove(index) }
    fun focused(index: Int) { intent.focused(index) }
    fun cancel() { job?.cancel(); job = null; intent.clear() }
    fun key(index: Int, event: KeyEvent): Boolean {
        val vertical = event.key == Key.DirectionDown || event.key == Key.DirectionUp
        if (!vertical) {
            if (event.type == KeyEventType.KeyDown && (event.key == Key.DirectionLeft || event.key == Key.DirectionRight)) {
                cancel(); manual()
            }
            return false
        }
        if (event.type != KeyEventType.KeyDown) return true
        manual()
        val down = event.key == Key.DirectionDown
        val anchor = intent.desired ?: index
        val wasPending = intent.desired != null
        val target = intent.request(index, count(), down)
            ?: return if (!down && anchor < columns && !wasPending) false else true
        job?.cancel()
        job = scope.launch {
            if (target !in 0 until count()) { if (intent.desired == target) intent.clear(); return@launch }
            load(target) // Paging hint only; SQLite continues outside the UI thread.
            val visible = grid.layoutInfo.visibleItemsInfo
            if (visible.none { it.index == target }) {
                val firstRow = (visible.firstOrNull()?.index ?: target) / columns
                val lastRow = (visible.lastOrNull()?.index ?: target) / columns
                val rows = (lastRow - firstRow + 1).coerceAtLeast(1)
                val row = target / columns
                val anchor = if (row > lastRow) (row - rows + 1).coerceAtLeast(0) else row
                grid.scrollToItem(anchor * columns)
            }
            val ready = withTimeoutOrNull(2_500L) { revision.first { requesters[target] != null } }
            if (ready == null) { if (intent.desired == target) intent.clear(); return@launch }
            repeat(3) {
                withFrameNanos { }
                ensureActive()
                if (intent.desired != target) return@launch
                val focused = runCatching { requesters[target]?.requestFocus() == true }.getOrDefault(false)
                if (focused) return@launch
            }
            if (intent.desired == target) intent.clear()
        }
        return true
    }
}

internal fun Modifier.catalogGridNavigation(navigator: CatalogGridNavigator?, index: Int, requester: FocusRequester): Modifier =
    this.then(if (navigator == null) Modifier else Modifier.onPreviewKeyEvent { navigator.key(index, it) })

@Composable
internal fun BindCatalogFocus(navigator: CatalogGridNavigator?, index: Int, requester: FocusRequester) {
    DisposableEffect(navigator, index, requester) {
        navigator?.attach(index, requester)
        onDispose { navigator?.detach(index, requester) }
    }
}

@Composable
internal fun CatalogPosterPlaceholder(aspect: Float) {
    Column(Modifier.fillMaxWidth()) {
        Box(Modifier.fillMaxWidth().aspectRatio(aspect).background(Color(0xFF0B1020)))
        Spacer(Modifier.height(34.dp))
    }
}
