package br.com.flaviotorres.iptvpremium.data.cache

import kotlinx.coroutines.FlowPreview
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.debounce
import kotlinx.coroutines.flow.distinctUntilChanged

internal const val CATALOG_SEARCH_SETTLE_MS = 350L
@OptIn(FlowPreview::class)
internal fun Flow<String>.settledCatalogSearch(): Flow<String> =
    debounce { if (it.isBlank()) 0L else CATALOG_SEARCH_SETTLE_MS }.distinctUntilChanged()

/** Never wraps to column zero; an incomplete last row does not change the column. */
internal fun verticalCatalogTarget(index: Int, columns: Int, count: Int, down: Boolean): Int? {
    if (columns <= 0 || index !in 0 until count) return null
    val next = index.toLong() + if (down) columns else -columns
    return next.takeIf { it in 0L until count.toLong() }?.toInt()
}

internal object CatalogMemoryPolicy {
    val pressured = kotlinx.coroutines.flow.MutableStateFlow(false)
    const val totalTargetMb = 350
    const val pressureMb = 280
    const val postersKb = 20 * 1024
    const val detailsMb = 24
    const val carouselMb = 12
    const val playerBufferBytes = 24 * 1024 * 1024
    const val pagingWindow = 180
}

/** Desired positions survive repeated keys while a row is still being laid out. */
internal class CatalogVerticalIntent(private val columns: Int) {
    var desired: Int? = null
        private set
    fun request(current: Int, count: Int, down: Boolean): Int? =
        verticalCatalogTarget(desired ?: current, columns, count, down)?.also { desired = it }
    fun focused(index: Int) { if (desired == index) desired = null }
    fun clear() { desired = null }
}
