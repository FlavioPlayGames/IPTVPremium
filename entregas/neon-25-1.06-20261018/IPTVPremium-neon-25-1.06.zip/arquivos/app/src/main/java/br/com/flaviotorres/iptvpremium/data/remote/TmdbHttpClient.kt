package br.com.flaviotorres.iptvpremium.data.remote

import android.util.Log
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.FutureTask
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class TmdbHttpClient(
    private val readAccessToken: String,
    private val baseUrl: String = "https://api.themoviedb.org/3"
) {
    private data class Cached(val body: String, val created: Long)
    private val responseCache = LinkedHashMap<String, Cached>(16, 0.75f, true)
    private val requestLocks = Array(32) { Mutex() }
    /** Cancellation releases the UI immediately even on platforms whose disconnect blocks. */
    suspend fun get(path: String, queryParameters: Map<String, String> = emptyMap()): String {
        check(readAccessToken.isNotBlank()) { "TMDB_READ_TOKEN nao foi configurado." }
        val normalizedPath = if (path.startsWith("/")) path else "/$path"
        val query = queryParameters.filterValues { it.isNotBlank() }.entries.joinToString("&") {
            encode(it.key) + "=" + encode(it.value)
        }
        val address = baseUrl + normalizedPath + if (query.isEmpty()) "" else "?$query"
        return requestLocks[(address.hashCode() and Int.MAX_VALUE) % requestLocks.size].withLock {
            val now = System.nanoTime()
            synchronized(responseCache) { responseCache[address] }
                ?.takeIf { now - it.created in 0..600_000_000_000L }
                ?.let { return@withLock it.body }
            val body = suspendCancellableCoroutine<String> { continuation ->
            val current = AtomicReference<HttpURLConnection?>()
            val task = FutureTask<Unit> {
                var connection: HttpURLConnection? = null
                try {
                    if (!continuation.isActive) return@FutureTask Unit
                    connection = URL(address).openConnection() as HttpURLConnection
                    current.set(connection)
                    if (!continuation.isActive) return@FutureTask Unit
                    connection.connectTimeout = 5_000; connection.readTimeout = 5_000
                    connection.requestMethod = "GET"; connection.instanceFollowRedirects = true
                    connection.useCaches = false
                    connection.setRequestProperty("Accept", "application/json")
                    connection.setRequestProperty("Authorization", "Bearer $readAccessToken")
                    connection.setRequestProperty("User-Agent", "IPTVPremium/1.0")
                    val status = connection.responseCode
                    Log.d("SeriesArtwork", "fonte=tmdb http=$status")
                    check(status in 200..299) { "Erro HTTP $status ao acessar o TMDB." }
                    val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                        val out = StringBuilder(); val buffer = CharArray(8192)
                        while (true) {
                            if (!continuation.isActive) return@FutureTask Unit
                            val count = reader.read(buffer); if (count < 0) break
                            check(out.length + count <= 8 * 1024 * 1024) { "Resposta TMDB excede limite" }
                            out.append(buffer, 0, count)
                        }
                        out.toString()
                    }
                    if (continuation.isActive) continuation.resume(body)
                } catch (error: Exception) {
                    if (continuation.isActive) continuation.resumeWithException(error)
                } finally { connection?.disconnect() }
            }
            continuation.invokeOnCancellation {
                task.cancel(true)
                requests.remove(task)
                current.get()?.let { connection ->
                    // Some HttpURLConnection implementations block in disconnect while reading.
                    // Never execute this cleanup on the UI/cancellation thread.
                    runCatching { cleanup.execute { connection.disconnect() } }
                }
            }
            try { requests.execute(task) }
            catch (error: java.util.concurrent.RejectedExecutionException) {
                if (continuation.isActive) continuation.resumeWithException(error)
            }
            }
            synchronized(responseCache) {
                responseCache[address] = Cached(body, System.nanoTime())
                var bytes = responseCache.values.sumOf { it.body.length.toLong() * 2 }
                while (responseCache.size > 64 || bytes > 8L * 1024 * 1024) {
                    val entry = responseCache.entries.iterator()
                    if (!entry.hasNext()) break
                    bytes -= entry.next().value.body.length.toLong() * 2
                    entry.remove()
                }
            }
            body
        }
    }
    private fun encode(value: String): String = URLEncoder.encode(value, "UTF-8")
    companion object {
        private fun pool(size: Int, name: String) = ThreadPoolExecutor(size, size, 30L, TimeUnit.SECONDS,
            ArrayBlockingQueue<Runnable>(16), java.util.concurrent.ThreadFactory { action ->
                Thread(action, name).apply { isDaemon = true }
            }).apply { allowCoreThreadTimeOut(true) }
        private val requests = pool(2, "tmdb-request")
        private val cleanup = pool(1, "tmdb-cleanup")
    }
}
