package br.com.flaviotorres.iptvpremium.ui.movies

/** One budget for metadata and decoded principal images, reserving the final animation. */
internal object MovieOpeningPolicy {
    const val preparationMs = 3_500L
    const val remoteMs = 2_500L
    const val alignNanos = 450_000_000L
    const val pressNanos = 220_000_000L
    const val expandNanos = 550_000_000L
    fun remainingMs(elapsedMs: Long): Long = (preparationMs - elapsedMs.coerceAtLeast(0L)).coerceAtLeast(0L)
    fun minimumWaitMs(elapsedMs: Long, artworkReady: Boolean): Long =
        if (artworkReady) 0L else (2_000L - elapsedMs.coerceAtLeast(0L)).coerceAtLeast(0L)
}
