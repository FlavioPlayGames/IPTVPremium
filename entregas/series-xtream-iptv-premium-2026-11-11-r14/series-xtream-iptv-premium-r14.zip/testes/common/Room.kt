package androidx.room
annotation class Index(val value:Array<String>)
annotation class Entity(val tableName:String,val primaryKeys:Array<String>,val indices:Array<Index>)
