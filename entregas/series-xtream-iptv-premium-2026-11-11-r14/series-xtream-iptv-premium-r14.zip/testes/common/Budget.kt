package br.com.flaviotorres.iptvpremium.core.storage
import java.io.File
import java.io.Closeable
import android.content.Context
class CacheStorageBudget {
 fun retain(file:File):Closeable=Closeable{}
 fun reserve(file:File,size:Long):Lease {file.parentFile.mkdirs();return Lease(File(file.path+".tmp"))}
 class Lease(val temporary:File):Closeable {override fun close(){temporary.delete()}}
}
object AppCacheStorage {fun get(context:Context)=CacheStorageBudget()}
