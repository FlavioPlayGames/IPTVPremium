package br.com.flaviotorres.iptvpremium.data.repository
import android.content.Context
import kotlinx.coroutines.runBlocking
import org.json.JSONObject
import java.io.File
fun main(args:Array<String>)=runBlocking {
 CatalogMetadataDiskCache.initialize(Context(File(args[1])))
 if(args[0]=="write") {
  var requests=0
  val poster=SeriesCatalogPosterResolver.resolve("Series",2024,"123","tt456",{path,query->
   requests++;check(path=="/tv/123")
   JSONObject().put("id",123).put("name","Series").put("original_name","Series")
    .put("first_air_date","2024-01-01").put("poster_path","/general.jpg")
    .put("external_ids",JSONObject().put("imdb_id","tt456"))
    .put("seasons",org.json.JSONArray().put(JSONObject().put("season_number",2).put("poster_path","/season2.jpg"))).toString()
  },2)
  check(requests==1 && poster?.isSeason==true && poster.url.endsWith("/season2.jpg"))
  println("PASS: season metadata prepared and persisted using simulated TMDB response")
 } else {
  check(SeriesCatalogPosterResolver.peek("Series",2024,"123","tt456",2)==null)
  val poster=SeriesCatalogPosterResolver.cached("Series",2024,"123","tt456",2)
  check(poster?.isSeason==true && poster.url.endsWith("/season2.jpg"))
  check(SeriesCatalogPosterResolver.cached("Series",2024,"999","tt456",2)==null)
  check(SeriesCatalogPosterResolver.cached("Series",2024,"123","tt456",3)?.isSeason==false)
  println("PASS: fresh process reads correct season from real disk cache; identity and missing-season isolation")
 }
}
