package br.com.flaviotorres.iptvpremium.data.m3u
import java.io.*
import java.util.zip.ZipFile
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.M3uEpisodeSource
fun main(args:Array<String>) {
 val out=File(args[1]);out.mkdirs()
 val source=M3uEpisodeSource.Builder(File(out,"episodes").also{it.mkdirs()},"test","generation")
 val started=System.nanoTime()
 val counts=ZipFile(args[0]).use{zip->
  zip.getInputStream(zip.entries().asSequence().first{it.name.endsWith(".m3u")}).bufferedReader().use{reader->
   DataOutputStream(File(out,"catalog.bin").outputStream().buffered()).use{output->
    M3uCatalogParser.prepare(reader,output,"test","generation",episodeSource=source)
   }
  }
 }
 source.finish()
 println("counts=$counts elapsedMs=${(System.nanoTime()-started)/1000000}")
 val selected=setOf("The Dark (2026) [L]","Knot (2026) [L]","Krypto Salva o Dia")
 DataInputStream(File(out,"catalog.bin").inputStream().buffered()).use{input->
  check(input.readInt()==M3uCatalogFormat.MAGIC)
  while(true){val row=M3uCatalogParser.read(input)?:break
   if(row.first==3 && row.second[3] in selected)println("poster ${row.second[3]} => ${(row.second[5] as String?)?.substringAfterLast('/')}")
  }
 }
}
