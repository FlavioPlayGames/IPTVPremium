package host.xtream
import br.com.flaviotorres.iptvpremium.data.parser.*
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import org.json.JSONObject
import java.io.StringReader
fun main()=runBlocking {
 val parser=DefaultXtreamParser()
 val rows=JSONArray().put(JSONObject().put("stream_id",1).put("tmdb_id","1201").put("imdb_id","TT0001201").put("name","Insaciável 4K").put("stream_icon","null").put("movie_image","https://cdn.example/movie.jpg"))
  .put(JSONObject().put("stream_id",2).put("name","Outra Mamãe").put("stream_icon","not-an-image-url").put("cover_big","https://cdn.example/other.jpg"))
  .put(JSONObject().put("stream_id",3).put("name","Example").put("stream_icon","https://cdn.example/icon.jpg").put("cover","https://cdn.example/cover.jpg"))
 val regular=parser.parseMovies(rows.toString())
 val streamed=mutableListOf<br.com.flaviotorres.iptvpremium.domain.model.Movie>()
 XtreamDirectCatalogReader.read(StringReader(rows.toString()),"get_vod_streams",parser){streamed.addAll(it.movies)}
 check(streamed==regular)
 check(streamed.first().id=="1" && streamed.first().tmdbId=="1201" && streamed.first().imdbId=="tt0001201")
 check(streamed.map{it.posterUrl}==listOf("https://cdn.example/movie.jpg","https://cdn.example/other.jpg","https://cdn.example/cover.jpg"))
 check(streamed.map{it.name}==listOf("Insaciável 4K","Outra Mamãe","Example"))
 val details=parser.parseMovieDetails(JSONObject().put("info",JSONObject().put("movie_image","bad").put("cover_big","https://cdn.example/detail.jpg")).toString(),"1")
 check(details?.posterUrl=="https://cdn.example/detail.jpg")
 val big=JSONArray();repeat(1100){big.put(JSONObject().put("stream_id",it+1).put("name","Movie $it").put("cover","https://cdn.example/$it.jpg"))}
 var count=0;var batches=0
 XtreamDirectCatalogReader.read(StringReader(big.toString()),"get_vod_streams",parser){batch->count+=batch.movies.size;batches++;check(batch.movies.all{it.posterUrl!=null})}
 check(count==1100 && batches>1)
 println("PASS: actual Xtream normal/streaming parsers retain alternate covers, reject invalid addresses, preserve IDs/titles and batch 1100 movies")
}
