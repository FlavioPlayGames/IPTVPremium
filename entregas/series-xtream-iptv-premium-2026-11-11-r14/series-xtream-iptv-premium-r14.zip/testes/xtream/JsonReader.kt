package android.util
// Valid-JSON streaming adapter; malformed Android-reader behaviour is not claimed by these tests.
typealias JsonReader = com.google.gson.stream.JsonReader
typealias JsonToken = com.google.gson.stream.JsonToken
typealias MalformedJsonException = com.google.gson.stream.MalformedJsonException
