package host.search
import br.com.flaviotorres.iptvpremium.data.cache.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
private data class Result(val category:String?,val query:String,val favorites:Boolean,val ids:Set<String>,val sort:String)
private suspend fun scenario(series:Boolean)=coroutineScope {
 val query=MutableStateFlow("");val category=MutableStateFlow<String?>("action")
 val only=MutableStateFlow(false);val ids=MutableStateFlow(setOf("one"));val sort=MutableStateFlow("A_Z")
 val results=mutableListOf<Result>()
 val flow=if(series) seriesOptions(query,combine(category,only){c,f->SeriesCategoryFilter(c,f)},ids,sort)
  .map{Result(it.categoryId,it.searchQuery,it.favoritesOnly,it.favoriteSeriesIds,it.sortMode)}
 else moviesOptions(query,combine(category,only){c,f->MovieCategoryFilter(c,f)},ids,sort)
  .map{Result(it.categoryId,it.searchQuery,it.favoritesOnly,it.favoriteMovieIds,it.sortMode)}
 val job=launch {flow.distinctUntilChanged().collect{results+=it}}
 suspend fun waitFor(test:(Result)->Boolean):Result = withTimeout(3000){
  while(results.lastOrNull()?.let(test)!=true)delay(5)
  results.last()
 }
 check(waitFor{it.category=="action"}.query.isEmpty())
 query.value="vento"
 val global=waitFor{it.query=="vento"}
 check(global.category==null && !global.favorites && global.ids.isEmpty() && global.sort=="A_Z")
 // Search bypasses Favorites without destroying the remembered filter or saved IDs.
 only.value=true;yield();ids.value=setOf("one","two");delay(30)
 check(results.last()==global)
 query.value=""
 val restored=waitFor{it.query.isEmpty() && it.favorites}
 check(restored.category=="action" && restored.ids==setOf("one","two"))
 only.value=false;category.value="drama";waitFor{!it.favorites && it.category=="drama"}
 query.value="série nova";waitFor{it.query=="série nova"}
 check(results.last().category==null)
 query.value="   ";waitFor{it.query.isBlank() && it.category=="drama"}
 query.value="cancelled before debounce";delay(20);query.value=""
 waitFor{it.query.isEmpty() && it.category=="drama"}
 delay(CATALOG_SEARCH_SETTLE_MS+20)
 check(results.none{it.query=="cancelled before debounce"})
 check(category.value=="drama" && ids.value==setOf("one","two"))
 job.cancelAndJoin()
 println("PASS: actual ${if(series)"Series"else"Movies"} query flow searches all categories/Favorites, preserves selection/IDs/sort, restores on clear and cancels pending text")
}
fun main()=runBlocking {
 scenario(false);scenario(true)
 check(catalogHistoryMode("continue", ""))
 check(!catalogHistoryMode("continue", "vento"))
 check(!catalogHistoryMode("favorites", ""))
 check(catalogPagingKey("source:action","action","vento","DEFAULT")==catalogPagingKey("favorites",null,"vento","DEFAULT"))
 check(catalogPagingKey("source:action","action","","DEFAULT")=="source:action||DEFAULT")
 val normal=NormalClearHarness(this);normal.clearSearch();yield()
 check(normal.query=="" && normal.cursor==0 && normal.changes==listOf("") && normal.focus==1 && !normal.firstPosterPending)
 normal.clearSearch();yield();check(normal.changes.size==1)
 val kids=KidsClearHarness(this);kids.keyboard=true;kids.clearSearch();yield()
 check(kids.query=="" && kids.cursor==0 && kids.changes==listOf("") && kids.focus==0 && kids.keyboard)
 kids.changeSearch("nova pesquisa");check(kids.query=="nova pesquisa" && kids.cursor==13)
 println("PASS: Continue switches to global search; effective paging keys agree; real normal/Kids clear handlers reset text/cursor and preserve the keyboard")
 Unit
}
