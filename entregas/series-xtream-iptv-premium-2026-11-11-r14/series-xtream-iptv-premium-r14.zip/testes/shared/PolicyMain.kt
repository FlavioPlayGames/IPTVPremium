package host
import br.com.flaviotorres.iptvpremium.data.history.*
import br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType
import kotlin.random.Random
fun main() {
 fun movie(title:String,year:Int?,tmdb:String?=null)=WatchHistoryEntry("A",PlaybackContentType.MOVIE,"id",title=title,positionMs=25000,durationMs=100000,updatedAtMs=1,year=year,tmdbId=tmdb)
 check(historyMatchesCatalog(movie("Example 4K",2024),ContentIdentity("movies","Example HD",2024)))
 check(!historyMatchesCatalog(movie("Example",2024),ContentIdentity("movies","Example",2010)))
 check(!historyMatchesCatalog(movie("Example",2024,"123"),ContentIdentity("movies","Example",2024,tmdb="456")))
 check(!historyMatchesCatalog(movie("Old work",2024),ContentIdentity("movies","Other work",2024)))
 check(historyMatchesCatalog(movie("Translated name",2024,"123"),ContentIdentity("movies","Original name",2024,tmdb="123")))
 println("PASS: catalogue verification preserves variants and confirmed IDs, rejects remakes/recycled IDs")
 val random=Random(8595);val identity=HashMap<String,ContentIdentity>()
 val raw=(0 until 2200).map { index->
  val work=random.nextInt(150);val series=random.nextBoolean();val kind=if(series)"series"else"movies"
  val year=listOf(2020,2024,null)[random.nextInt(3)]
  val base="Work ${work%70}"
  val id=index.toString()
  identity[id]=ContentIdentity(kind,base,year,imdb=if(random.nextInt(5)==0)"tt${10000+work}"else null,
   tmdb=if(random.nextBoolean())"${work+1}"else null,
   alternateTitles=if(random.nextInt(4)==0)listOf("Alias ${work%70}")else emptyList(),
   providerAssetKey=if(!series && random.nextInt(6)==0)"asset:${work%40}"else null)
  WatchHistoryEntry("A",if(series)PlaybackContentType.EPISODE else PlaybackContentType.MOVIE,id,
   seriesId=if(series)"s$work"else null,title=base,seriesTitle=if(series)base else null,
   seasonNumber=if(series && random.nextInt(10)!=0)random.nextInt(1,3)else null,
   episodeNumber=if(series && random.nextInt(10)!=0)random.nextInt(1,4)else null,
   positionMs=25000,durationMs=100000,updatedAtMs=index.toLong(),year=year)
 }
 // Original r2 compaction semantics, used as reference for the indexed implementation.
 val reference=mutableListOf<WatchHistoryEntry>()
 for(h in raw.sortedByDescending{it.updatedAtMs}) {
  val value=identity.getValue(h.contentId)
  if(reference.none {other->other.contentType==h.contentType &&
   (h.contentType==PlaybackContentType.MOVIE || h.seasonNumber!=null && h.episodeNumber!=null && h.seasonNumber==other.seasonNumber && h.episodeNumber==other.episodeNumber) &&
   sameHistoryWork(value,identity.getValue(other.contentId))})reference.add(h)
 }
 val indexed=compactHistoryFacts(raw){identity.getValue(it.contentId)}
 check(indexed==reference)
 println("PASS: indexed history compaction matches original identity rules across 2200 mixed facts")
}
