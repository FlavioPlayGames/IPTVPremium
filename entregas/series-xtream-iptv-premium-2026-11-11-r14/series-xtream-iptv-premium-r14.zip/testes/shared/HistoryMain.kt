package host
import android.content.Context
import br.com.flaviotorres.iptvpremium.core.player.*
import br.com.flaviotorres.iptvpremium.data.history.*
import br.com.flaviotorres.iptvpremium.data.repository.SeriesEpisodeInfo
fun main() {
 val context=Context();val normal=WatchHistoryStore(context);val kids=WatchHistoryStore(context,true)
 val media=PlaybackMedia("ep1",PlaybackContentType.EPISODE,"Episode 1",durationMs=100000,seriesId="series",seasonNumber=2,episodeNumber=1,year=2024,tmdbId="123")
 val next=SeriesEpisodeInfo("ep2",2,2,"Episode 2",null,null,100,null)
 fun latest()=latestHistorySeries(normal.allLocal()).single()
 normal.save("list",media,20000,100000,"Series","https://images/series.jpg")
 check(latest().inProgress)
 // Reproduce the previous scheduling: queue once, then save another completed checkpoint.
 normal.save("list",media,95000,100000,"Series",null)
 normal.queueNext("list",media,next,"Series",null)
 check(latest().contentId=="ep2" && latest().pendingNext)
 normal.save("list",media,97000,100000,"Series",null)
 check(latest().contentId=="ep1" && !latest().inProgress)
 // The corrected route calls queueNext after every completed checkpoint.
 normal.queueNext("list",media,next,"Series",null)
 check(latest().contentId=="ep2" && latest().pendingNext)
 val stamp=latest().updatedAtMs
 normal.queueNext("list",media,next,"Series",null)
 check(latest().updatedAtMs==stamp) // duplicate callbacks do not rewrite.
 for(position in listOf(98000L,99000L,100000L)) {
  normal.save("list",media,position,100000,"Series",null)
  normal.queueNext("list",media,next,"Series",null)
  check(latest().contentId=="ep2" && latest().inProgress)
 }
 check(kids.allLocal().isEmpty())
 kids.save("list",media,25000,100000,"Series",null)
 check(kids.allLocal().single().positionMs==25000L)
 check(normal.allLocal().size==2)
 val decorated=latest().copy(tmdbId="123",catalogImdbId="tt456",seriesTitle="Series",year=2024)
 val card=catalogContinuePosters(listOf(decorated),true).single()
 val kidCard=kidsContinuePosters(listOf(decorated),true).single()
 check(card.tmdbId=="123" && card.imdbId=="tt456" && card.artworkSeason==2)
 check(kidCard.tmdbId==card.tmdbId && kidCard.imdbId==card.imdbId && kidCard.artworkSeason==2)
 val movie=decorated.copy(contentType=PlaybackContentType.MOVIE,contentId="movie",seriesId=null,positionMs=20000,pendingNext=false,finished=false)
 check(catalogContinuePosters(listOf(movie),false).single().id=="movie")
 check(catalogContinuePosters(listOf(movie.copy(positionMs=100000)),false).isEmpty())
 val resumed=media.copy(id="ep2",title="Episode 2",episodeNumber=2)
 normal.save("list",resumed,33000,100000,"Series",null)
 normal.save("list",media,100000,100000,"Series",null,true)
 normal.queueNext("list",media,next,"Series",null)
 check(latest().contentId=="ep2" && latest().positionMs==33000L && !latest().pendingNext)
 normal.save("list",resumed,100000,100000,"Series",null,true)
 normal.save("list",media,100000,100000,"Series",null,true)
 normal.queueNext("list",media,next,"Series",null)
 check(!latest().inProgress) // Do not resurrect a successor already completed.
 println("PASS: disappearance reproduced; repeated checkpoints, idempotence, profile isolation, poster identity, movie rules, preserved successor progress and completed successor")
}
