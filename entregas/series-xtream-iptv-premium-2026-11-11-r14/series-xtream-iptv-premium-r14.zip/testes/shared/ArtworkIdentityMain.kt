package host
import br.com.flaviotorres.iptvpremium.data.history.*
import br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType
fun main(){
 val canonical=SeriesPosterIdentity("Show700",null,null,null)
 val h=WatchHistoryEntry("A",PlaybackContentType.EPISODE,"e",seriesId="s",title="Ep",seriesTitle="Show700",seasonNumber=2,episodeNumber=1,
  positionMs=25000,durationMs=100000,updatedAtMs=1,year=2024,tmdbId="700",catalogArtwork=canonical)
 val normal=catalogContinuePosters(listOf(h),true).single();val kids=kidsContinuePosters(listOf(h),true).single()
 check(normal.artworkIdentity==canonical && kids.artworkIdentity==canonical)
 check(normal.year==2024 && normal.tmdbId=="700" && normal.artworkIdentity!!.year==null && normal.artworkIdentity!!.tmdbId==null)
 println("PASS: normal/Kids Continue cards retain display metadata and the exact nullable artwork lookup identity separately")
}