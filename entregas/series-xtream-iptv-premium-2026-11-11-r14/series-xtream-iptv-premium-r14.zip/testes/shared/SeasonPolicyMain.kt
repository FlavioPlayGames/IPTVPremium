package host
import br.com.flaviotorres.iptvpremium.data.history.*
import br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType
fun main() {
 val watched=WatchHistoryEntry("target",PlaybackContentType.EPISODE,"old-id","series","Episode",seasonNumber=2,episodeNumber=3,positionMs=50000,durationMs=100000,updatedAtMs=100)
 val unresolved=watched.copy(contentId="series",seriesOnly=true,seasonNumber=3,positionMs=0,durationMs=null,updatedAtMs=200,sharedFromPlaylist="origin")
 val queued=watched.copy(contentId="next",seasonNumber=4,pendingNext=true,positionMs=0,updatedAtMs=300)
 check(watchedSeriesSeasons(listOf(watched,unresolved,queued))["series"]==3)
 check(watchedSeriesSeasons(listOf(watched.copy(finished=true,positionMs=100000)))["series"]==2)
 check(watchedSeriesSeasons(listOf(watched.copy(seasonNumber=0)))["series"]==0)
 check(watchedSeriesSeasons(listOf(watched.copy(seasonNumber=null))).isEmpty())
 check(watchedSeriesSeasons(listOf(queued)).isEmpty())
 check(unresolved.positionMs==0L&&unresolved.seriesOnly&&watched.positionMs==50000L)
 println("PASS: known season survives unresolved cross-list episode IDs; completed episodes count; queued unplayed successors never select a season; resume data untouched")
}
