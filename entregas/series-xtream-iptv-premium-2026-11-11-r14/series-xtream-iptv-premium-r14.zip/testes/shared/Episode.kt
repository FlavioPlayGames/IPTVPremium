package br.com.flaviotorres.iptvpremium.data.repository
data class SeriesEpisodeInfo(
    val id: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val title: String,
    val thumbnailUrl: String?,
    val synopsis: String?,
    val durationSeconds: Int?,
    val containerExtension: String?
)