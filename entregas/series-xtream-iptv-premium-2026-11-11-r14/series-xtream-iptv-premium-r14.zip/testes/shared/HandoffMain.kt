package host
import android.content.Context
import br.com.flaviotorres.iptvpremium.core.player.*
import br.com.flaviotorres.iptvpremium.data.history.*
import br.com.flaviotorres.iptvpremium.data.cache.dao.*
import br.com.flaviotorres.iptvpremium.data.repository.SeriesEpisodeInfo
import kotlinx.coroutines.runBlocking

fun main()=runBlocking {
    var checks=0
    fun verify(name:String,value:Boolean) { check(value){name};checks++;println("PASS: $name") }
    fun resetInstances() { for(name in listOf("instance","kidsInstance"))SharedLibraryStore::class.java.getDeclaredField(name).apply{isAccessible=true}.set(null,null) }
    fun fresh():Context {resetInstances();return Context().also{it.getSharedPreferences("iptvpremium_history_profiles_v1",0).edit().putBoolean("continue_reset_v1",true).commit()}}
    fun movie(id:String,title:String="Example",year:Int?=2024)=SharedCatalogIdentity(id,title,year,null,null,null)
    fun media(id:String,title:String="Example",year:Int?=2024)=PlaybackMedia(id,PlaybackContentType.MOVIE,title,year=year)
    suspend fun transfer(l:SharedLibraryStore,d:PlaylistCacheDao,h:WatchHistoryStore,target:String) {
        l.selectTarget(target)
        for(phase in listOf(SharedLibraryStore.HandoffPhase.CONTINUE,SharedLibraryStore.HandoffPhase.FAVORITES))
            for(kind in listOf("movies","series"))l.reconcile(d,target,h.allLocal(),kind=kind,phase=phase,reuseUnchanged=true)
        l.checkpointCompletedHistory(target,h)
    }
    run {
        val c=fresh();val d=PlaylistCacheDao();val l=SharedLibraryStore.get(c);val h=WatchHistoryStore(c)
        d.movies["A"]=listOf(movie("a"),movie("missing","Only later"),movie("f","Favourite"))
        h.save("A",media("a"),25_000,100_000)
        h.save("A",media("missing","Only later"),32_000,100_000)
        l.setFavorite(d,"A","movies","f",true)
        d.movies["B"]=listOf(movie("b"),movie("fb","Favourite"))
        transfer(l,d,h,"B")
        verify("A -> B remaps real IDs and preserves resume position",h.all("B").single().let{it.contentId=="b" && it.positionMs==25_000L})
        verify("unavailable work stays stored and absent from active list",h.allLocal().any{it.title=="Only later"} && h.all("B").none{it.title=="Only later"})
        verify("favourites are transferred after Continue",l.favorites("B","movies",emptySet())==setOf("fb"))
        for(target in listOf("C","D","E")) {
            d.movies[target]=listOf(movie(target.lowercase()),movie("f$target","Favourite"))
            transfer(l,d,h,target)
            verify("handoff to $target uses current target IDs",h.all(target).single().contentId==target.lowercase())
            verify("last completed list is $target",l.historySource()==target)
        }
        verify("found movies do not accumulate one progress copy per list",h.allLocal().count{it.title=="Example"}==1)
        // Delete the entire list registry/catalogues; portable state is independent of both.
        d.movies.clear();d.series.clear();l.selectTarget(null)
        resetInstances();val reopened=SharedLibraryStore.get(c);val reopenedHistory=WatchHistoryStore(c)
        d.movies["NEW"]=listOf(movie("new"),movie("returned","Only later"),movie("new-f","Favourite"))
        transfer(reopened,d,reopenedHistory,"NEW")
        verify("deleting all lists and restarting retains last history",reopenedHistory.all("NEW").size==2)
        verify("unavailable work returns when a later catalogue contains it",reopenedHistory.all("NEW").first{it.contentId=="returned"}.positionMs==32_000L)
        verify("deleting all lists retains favourites",reopened.favorites("NEW","movies",emptySet())==setOf("new-f"))
        reopened.setFavorite(d,"NEW","movies","new-f",false)
        d.movies["LAST"]=listOf(movie("last"),movie("last-f","Favourite"))
        transfer(reopened,d,reopenedHistory,"LAST")
        verify("explicit unfavourite is not resurrected from old lists",reopened.favorites("LAST","movies",emptySet()).isEmpty())
        reopenedHistory.remove("LAST",PlaybackContentType.MOVIE,"last")
        d.movies["AFTER"]=listOf(movie("after"))
        transfer(reopened,d,reopenedHistory,"AFTER")
        verify("removed Continue does not return on the next list",reopenedHistory.all("AFTER").isEmpty())
    }
    run {
        val c=fresh();val d=PlaylistCacheDao();val l=SharedLibraryStore.get(c);val h=WatchHistoryStore(c)
        d.movies["A"]=listOf(movie("a",year=null));h.save("A",media("a",year=null),20_000,100_000)
        d.movies["B"]=listOf(movie("b",year=null))
        transfer(l,d,h,"B")
        verify("M3U / Xtream missing year uses unique exact normalized title",h.all("B").single().contentId=="b")
        d.movies["C"]=listOf(movie("old",year=1980),movie("new",year=2024))
        transfer(l,d,h,"C")
        verify("ambiguous remakes stay saved and are not displayed",h.all("C").isEmpty() && h.allLocal().isNotEmpty())
    }
    run {
        val c=fresh();val d=PlaylistCacheDao();val l=SharedLibraryStore.get(c);val h=WatchHistoryStore(c)
        val s=PlaybackMedia("a-e",PlaybackContentType.EPISODE,"Episode 2",seriesId="a-s",seasonNumber=1,episodeNumber=2,year=2024)
        d.series["A"]=listOf(SharedCatalogIdentity("a-s","Series",2024,null,"123",null))
        d.series["B"]=listOf(SharedCatalogIdentity("b-s","Series",2024,null,"123",null))
        h.save("A",s,40_000,100_000,"Series")
        transfer(l,d,h,"B")
        verify("matched series may open details without inventing episode IDs",h.all("B").single().let{it.seriesOnly && it.contentId=="b-s" && it.positionMs==0L})
        l.importEpisodeLinks("B") { listOf(SeriesEpisodeInfo("b-e",1,2,"Episode 2",null,null,100,null)) }
        l.checkpointCompletedHistory("B",h)
        verify("series resume uses real destination episode and exact coordinates",h.all("B").single().let{!it.seriesOnly && it.contentId=="b-e" && it.positionMs==40_000L})
        h.removeSeries("B","b-s")
        verify("batch removal hides the whole series",h.all("B").isEmpty())
        d.series["C"]=listOf(SharedCatalogIdentity("c-s","Series",2024,null,"123",null))
        transfer(l,d,h,"C")
        verify("removed series stays hidden on another import format",h.all("C").isEmpty())
    }
    run {
        val c=fresh();val d=PlaylistCacheDao();val normal=SharedLibraryStore.get(c);val kids=SharedLibraryStore.get(c,true)
        val h=WatchHistoryStore(c);val kh=WatchHistoryStore(c,true)
        d.movies["A"]=listOf(movie("a"));d.movies["B"]=listOf(movie("b"))
        h.save("A",media("a"),20_000,100_000);normal.setFavorite(d,"A","movies","a",true)
        transfer(kids,d,kh,"B")
        verify("Kids never inherits normal history or favourites",kh.all("B").isEmpty() && kids.favorites("B","movies",emptySet()).isEmpty())
        transfer(normal,d,h,"B");h.clearType(PlaybackContentType.MOVIE)
        transfer(normal,d,h,"A")
        verify("explicit clear never reimports prior playback",h.all("A").isEmpty())
    }
    run {
        val c=fresh();val d=PlaylistCacheDao();val l=SharedLibraryStore.get(c);val h=WatchHistoryStore(c)
        d.movies["A"]=listOf(movie("a"));d.movies["B"]=(0 until 900).map{movie("b%04d".format(it),if(it==700)"Example"else"Other $it")}
        h.save("A",media("a"),20_000,100_000)
        transfer(l,d,h,"B");val before=d.pageReads
        transfer(l,d,h,"B");val warm=d.pageReads-before
        val beforeStable=d.pageReads;transfer(l,d,h,"B")
        verify("stable active catalogue reuses matches without SQL scans",d.pageReads==beforeStable)
        println("Measured fixture catalogue pages: cold=$before transitional=$warm stable=${d.pageReads-beforeStable}")
        resetInstances();val again=SharedLibraryStore.get(c);val bh=WatchHistoryStore(c);val beforeRestart=d.pageReads
        transfer(again,d,bh,"B")
        verify("same generation reuses persisted matches after process restart",d.pageReads==beforeRestart)
    }
    run {
        val c=fresh();val d=PlaylistCacheDao();val l=SharedLibraryStore.get(c);val h=WatchHistoryStore(c)
        d.movies["A"]=listOf(movie("a"),movie("fav","Favourite"),movie("later","Missing favourite"))
        d.movies["B"]=listOf(movie("b"),movie("fav-b","Favourite"))
        h.save("A",media("a"),20_000,100_000)
        l.setFavorite(d,"A","movies","fav",true);l.setFavorite(d,"A","movies","later",true)
        l.selectTarget("B")
        l.reconcile(d,"B",h.allLocal(),kind="movies",phase=SharedLibraryStore.HandoffPhase.CONTINUE)
        verify("Continue publishes without waiting for favourite matching",h.all("B").size==1 && l.favorites("B","movies",emptySet()).isEmpty())
        l.reconcile(d,"B",h.allLocal(),kind="movies",phase=SharedLibraryStore.HandoffPhase.FAVORITES)
        l.checkpointCompletedHistory("B",h)
        verify("unmatched favourite is not visible in active list",l.favorites("B","movies",emptySet())==setOf("fav-b"))
        d.movies["C"]=listOf(movie("back","Missing favourite"))
        transfer(l,d,h,"C")
        verify("unmatched favourite survives and returns later",l.favorites("C","movies",emptySet())==setOf("back"))
    }
    run {
        val c=fresh()
        c.getSharedPreferences("iptvpremium_history_profiles_v1",0).edit().clear().commit()
        val raw="""[{"playlistId":"A","type":"MOVIE","contentId":"a","title":"Example","positionMs":20000,"durationMs":100000,"updatedAtMs":123,"year":2024}]"""
        c.getSharedPreferences("iptvpremium_watch_history_v1",0).edit().putString("items",raw).commit()
        c.getSharedPreferences("iptvpremium_shared_library_v1",0).edit()
            .putString("identities","""[{"playlist":"A","id":"a","kind":"movies","title":"Example","year":2024,"tracked":true,"favorite":true,"changed":100}]""")
            .putString("completed_history_source","A").commit()
        val h=WatchHistoryStore(c);val l=SharedLibraryStore.get(c);val d=PlaylistCacheDao()
        verify("older installation migration preserves existing progress",h.allLocal().single().positionMs==20_000L)
        d.movies["B"]=listOf(movie("b"));transfer(l,d,h,"B")
        verify("v1 identity/favourite migrates into the new local handoff",l.favorites("B","movies",emptySet())==setOf("b") && h.all("B").size==1)
        verify("legacy registry remains available as a recovery source",c.getSharedPreferences("iptvpremium_shared_library_v1",0).getString("identities",null)!=null)
    }
    run {
        val c=fresh();val l=SharedLibraryStore.get(c);val h=WatchHistoryStore(c);val d=PlaylistCacheDao()
        d.movies["A"]=listOf(movie("a"));d.movies["B"]=listOf(movie("b"))
        h.save("A",media("a"),20_000,100_000);transfer(l,d,h,"B")
        h.save("B",media("b"),48_000,100_000)
        d.movies["C"]=listOf(movie("c"));transfer(l,d,h,"C")
        verify("latest active-list progress supersedes its inherited position",h.all("C").single().positionMs==48_000L)
        l.selectTarget("C");l.reconcile(d,"B",h.allLocal())
        verify("stale prior-list worker cannot replace active links",h.all("C").single().contentId=="c")
        d.generation="updated";d.movies["C"]=emptyList();transfer(l,d,h,"C")
        verify("new generation invalidates old matches",l.projectHistory("C",l.effectiveHistory(h.allLocal())).all{it.localProjectionFallback})
    }
    run {
        val c=fresh();val d=PlaylistCacheDao();val l=SharedLibraryStore.get(c);val h=WatchHistoryStore(c)
        d.movies["A"]=listOf(movie("legacy","Legacy favourite"))
        c.getSharedPreferences("iptvpremium_favorites_v1",0).edit().putStringSet("movies_A",setOf("legacy")).commit()
        l.captureBeforeRemoval(d,"A",h.allLocal());d.movies.clear()
        d.movies["B"]=listOf(movie("new","Legacy favourite"));transfer(l,d,h,"B")
        verify("ID-only legacy favourite is captured before deleting its source catalogue",l.favorites("B","movies",emptySet())==setOf("new"))
    }
    run {
        val c=fresh();val d=PlaylistCacheDao();val l=SharedLibraryStore.get(c);val h=WatchHistoryStore(c)
        d.series["A"]=listOf(SharedCatalogIdentity("a-s","Series",2024,null,"123",null))
        d.series["B"]=listOf(SharedCatalogIdentity("b-s","Series",2024,null,"123",null))
        h.save("A",PlaybackMedia("a-e",PlaybackContentType.EPISODE,"Episode",seriesId="a-s",seasonNumber=1,episodeNumber=2,year=2024),20_000,100_000,"Series")
        transfer(l,d,h,"B")
        l.importEpisodeLinks("B") { listOf(SeriesEpisodeInfo("different",1,3,"Other episode",null,null,100,null)) }
        verify("absent destination episode stays saved without applying position to another episode",h.all("B").isEmpty() && h.allLocal().any{it.episodeNumber==2 && it.positionMs==20_000L})
    }
    run {
        val c=fresh();val d=PlaylistCacheDao();val l=SharedLibraryStore.get(c);val h=WatchHistoryStore(c)
        d.movies["A"]=listOf(movie("a","Original",year=null))
        d.movies["B"]=listOf(movie("b","Translated",year=null))
        l.rememberExternal("A","a",ContentIdentity("movies","Original",alternateTitles=listOf("Translated")))
        h.save("A",media("a","Original",year=null),20_000,100_000)
        transfer(l,d,h,"B")
        verify("previously confirmed aliases can match without provider year",h.all("B").single().contentId=="b")
        d.movies["C"]=listOf(movie("c","Original",year=null));transfer(l,d,h,"C")
        verify("handoff retains the original title for subsequent list matching",h.all("C").single().contentId=="c")
    }
    run {
        val c=fresh();val l=SharedLibraryStore.get(c);val h=WatchHistoryStore(c);val d=PlaylistCacheDao()
        d.movies["A"]=listOf(movie("a",year=null));d.movies["B"]=listOf(movie("b"))
        h.save("A",media("a",year=null),20_000,100_000)
        l.reconcile(d,"A",h.allLocal(),kind="movies")
        h.save("B",media("b"),30_000,100_000)
        h.remove("B",PlaybackContentType.MOVIE,"b")
        transfer(l,d,h,"B")
        verify("removal before destination reconciliation cannot resurrect inherited progress",h.all("B").isEmpty())
    }
    println("$checks handoff assertions passed")
}
