"""Compile real opening policies/cache and extracted preparation methods against explicit Android/image adapters."""
from pathlib import Path
import argparse,os,subprocess,tempfile
cli=argparse.ArgumentParser();cli.add_argument('--projeto',type=Path,required=True);cli.add_argument('--tools',type=Path,required=True);cli.add_argument('--java',default='java');a=cli.parse_args()
r=a.projeto/'app/src/main/java/br/com/flaviotorres/iptvpremium';fixtures=Path(__file__).parent/'opening'
names=['kotlin-compiler-embeddable-2.2.10.jar','kotlin-stdlib-2.2.10.jar','kotlin-script-runtime-2.2.10.jar','kotlin-reflect-1.6.10.jar','kotlin-daemon-embeddable-2.2.10.jar','kotlinx-coroutines-core-jvm-1.8.0.jar','annotations-13.0.jar'];cp=os.pathsep.join(str(a.tools/n)for n in names)
with tempfile.TemporaryDirectory()as td:
 w=Path(td)
 text=(r/'data/repository/SeriesEpisodesRepository.kt').read_text();start=text.index('data class SeriesSeasonInfo');end=text.index('/**\n * Consulta apenas',start);(w/'Series.kt').write_text('package br.com.flaviotorres.iptvpremium.data.repository\n'+text[start:end])
 text=(r/'ui/movies/MoviesViewModel.kt').read_text();start=text.index('    suspend fun prepareMovieDetails(');end=text.index('    /*\n     * PLAYLIST ESPECIFICA',start)
 model=text[text.index('data class PreparedMovieDetails('):text.index('\nclass MoviesViewModel(')]
 prefix='''package br.com.flaviotorres.iptvpremium.ui.movies
import android.content.Context
import android.os.SystemClock
import android.util.Log
import br.com.flaviotorres.iptvpremium.domain.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
private const val MOVIE_DETAILS_PERF_TAG="test"
var imageMode="slow"
data class MovieDetailsPreloadResult(val backdropReady:Boolean,val titleLogoReady:Boolean)
suspend fun preloadMovieDetailsImages(context:Context,backdropUrl:String?,titleLogoUrl:String?,viewportWidthPx:Int,viewportHeightPx:Int,castProfileUrls:List<String?>):MovieDetailsPreloadResult {
 if(imageMode=="error")error("fixture image failure")
 delay(1500);return MovieDetailsPreloadResult(true,true)
}
class FakeRepository(val movie:Movie){suspend fun getMovieById(playlistId:String,movieId:String)=movie}
'''
 (w/'Preparation.kt').write_text(prefix+model+'\nclass PreparationHarness(movie:Movie){val playlistId=MutableStateFlow<String?>("p");val repository=FakeRepository(movie)\n'+text[start:end]+'\n}')
 nav=(r/'core/navigation/AppNavigation.kt').read_text();start=nav.index('internal data class CinematicCarouselPoster(');end=nav.index('// Mesmo conjunto',start)
 (w/'Carousel.kt').write_text('package br.com.flaviotorres.iptvpremium.ui.movies\nprivate const val MAX_CAROUSEL_POSTERS=20\n'+nav[start:end].replace('private fun uniqueCarouselPosters','internal fun uniqueCarouselPosters')+'\nobject MoviePosterLoader {val cached=hashSetOf<String>();val missing=hashSetOf<String>();fun peekBitmap(url:String?)=url?.takeIf{it in cached};fun knownMissing(url:String?)=url in missing}\n')
 (w/'PosterResolver.kt').write_text('package br.com.flaviotorres.iptvpremium.data.repository\ndata class Poster(val url:String)\nobject MovieCatalogPosterResolver {val posters=hashMapOf<String,Poster>();fun peek(name:String,year:Int?,tmdb:String?,imdb:String?)=posters[name]}\n')
 sources=['ui/movies/MovieOpeningPolicy.kt','core/network/MovieOpeningAttempt.kt','data/cache/MediaOpeningPriority.kt','data/cache/PosterVisibilityPriority.kt','data/cache/PosterRequestLocks.kt','data/cache/CatalogDetailsWarmupCache.kt','ui/movies/CachedCarouselPolicy.kt']
 files=[r/s for s in sources]+list((r/'domain/model').glob('*.kt'))+list(fixtures.glob('*.kt'))+list(w.glob('*.kt'));jar=w/'opening.jar'
 subprocess.run([a.java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',str(jar),*map(str,files)],check=True)
 subprocess.run([a.java,'-cp',str(jar)+os.pathsep+cp,'br.com.flaviotorres.iptvpremium.ui.movies.OpeningMainKt'],check=True)
