"""Read-only source comparison: outputs hashes and equality, never source bodies or credentials."""
import argparse,zipfile,hashlib
from pathlib import Path
cli=argparse.ArgumentParser();cli.add_argument('--referencia',type=Path,required=True);cli.add_argument('--projeto',type=Path,required=True);a=cli.parse_args()
r=a.projeto/'app/src/main/java/br/com/flaviotorres/iptvpremium'
files=['data/cache/ImportTuning.kt','data/cache/ImportTuningPolicy.kt','data/remote/DefaultPlaylistHttpClient.kt','data/remote/PlaylistHttpClient.kt','data/parser/XtreamArrayStream.kt','data/sync/ProgressiveXtream.kt','data/sync/ImportAlternatives.kt','data/sync/SharedSync.kt','data/cache/PlaylistCacheGenerationManager.kt','data/repository/XtreamAuthenticationRecovery.kt']
def norm(value):return value.decode('utf-8-sig').replace('\r\n','\n').replace('\r','\n')
with zipfile.ZipFile(a.referencia)as z:
 def old(rel):
  suffix='br/com/flaviotorres/iptvpremium/'+rel
  matches=[i for i in z.infolist()if not i.is_dir()and i.filename.replace('\\','/').endswith(suffix)]
  if len(matches)!=1 or matches[0].file_size>8*1024*1024:raise ValueError('Ambiguous or oversized reference: '+rel)
  return norm(z.read(matches[0]))
 for rel in files:
  before=old(rel);after=norm((r/rel).read_bytes())
  print(('IGUAL'if before==after else'DIFERENTE'),rel,'sha256_atual='+hashlib.sha256(after.encode()).hexdigest())
 rel='data/repository/DefaultPlaylistRepository.kt';start='    override suspend fun importXtream(';end='    private suspend fun loadXtreamContent('
 before=old(rel);after=norm((r/rel).read_bytes());before=before[before.index(start):before.index(end)];after=after[after.index(start):after.index(end)]
 print(('IGUAL'if before==after else'DIFERENTE'),'fluxo_progressivo_e_recuperacao_Xtream','sha256_atual='+hashlib.sha256(after.encode()).hexdigest())
