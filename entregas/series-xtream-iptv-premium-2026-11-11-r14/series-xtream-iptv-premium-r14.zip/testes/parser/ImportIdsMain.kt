package br.com.flaviotorres.iptvpremium.data.m3u
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.M3uEpisodeSource
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uEntryMetadata
import java.io.*
import java.nio.file.Files
fun main() {
 val dir=Files.createTempDirectory("m3u-id-import-").toFile()
 val text="""#EXTM3U
#EXTINF:-1 group-title="Filmes" tvg-id="7777" tmdb-id="1201" imdb-id="tt0001201",Insaciável 4K
https://provider.example/movie/user/pass/1.mp4
#EXTINF:-1 group-title="Séries" tmdb_id="700" imdb_id="TT0000700",Series S01E01
https://provider.example/series/user/pass/2.mp4
"""
 val bytes=ByteArrayOutputStream();val builder=M3uEpisodeSource.Builder(File(dir,"episodes").also{it.mkdirs()},"list","gen")
 M3uCatalogParser.prepare(text.reader().buffered(),DataOutputStream(bytes),"list","gen",episodeSource=builder)
 builder.finish()
 val rows=mutableListOf<Pair<Int,Array<Any?>>>()
 DataInputStream(ByteArrayInputStream(bytes.toByteArray())).use{input->
  check(input.readInt()==M3uCatalogFormat.MAGIC)
  while(true){val row=M3uCatalogParser.read(input)?:break;rows.add(row)}
 }
 val movie=rows.single{it.first==2}.second;check(movie.size==15&&movie[13]=="1201"&&movie[14]=="tt0001201")
 val series=rows.single{it.first==3}.second;check(series[11]=="tt0000700"&&series[12]=="700")
 check(M3uEntryMetadata.parse("#EXTINF:-1 tvg-id=\"1234\",Example").tmdbId==null)
 println("PASS: M3U explicit external IDs survive movie/series serialization; tvg/provider IDs never become TMDB IDs")
 dir.deleteRecursively()
}
