package br.com.flaviotorres.iptvpremium.data.m3u
fun main() {
 fun candidates(p:M3uSeriesPosterSelection,name:String,vararg urls:String)=M3uSeriesPosterSelection.Candidates().also{c->urls.forEach{p.series(c,name,it)}}
 val p=M3uSeriesPosterSelection()
 val provider="https://provider.example/cover.jpg"
 check(p.select(candidates(p,"Valid",provider,provider))==provider)
 val same="https://image.tmdb.org/t/p/w500/poster.jpg"
 check(p.select(candidates(p,"Same image",same,"https://image.tmdb.org/t/p/w342/poster.jpg"))==same)
 check(p.select(candidates(p,"Episodes","https://image.tmdb.org/t/p/w500/ep1.jpg","https://image.tmdb.org/t/p/w500/ep2.jpg"))==null)
 val shared="https://image.tmdb.org/t/p/w500/film.jpg"
 val a=candidates(p,"A",shared);val b=candidates(p,"B",shared);p.movie(shared)
 check(p.select(a)==null && p.select(b)==null)
 check(p.select(candidates(p,"Landscape","https://image.tmdb.org/t/p/w1280/frame.jpg"))==null)
 check(p.select(candidates(p,"Landscape crop","https://image.tmdb.org/t/p/w600_and_h400_bestv2/frame.jpg"))==null)
 val portrait="https://image.tmdb.org/t/p/w600_and_h900_bestv2/poster2.jpg"
 check(p.select(candidates(p,"Portrait",portrait))==portrait)
 val late=candidates(p,"Late variation",*(1..8).map{"https://image.tmdb.org/t/p/w${it*100}/same.jpg"}.toTypedArray())
 p.series(late,"Late variation","https://image.tmdb.org/t/p/w500/different.jpg");check(p.select(late)==null)
 check(p.select(candidates(p,"Bad URL","http:///missing-host.jpg"))==null)
 println("PASS: uniform provider preserved; varying episode logos, movie placeholders and landscape frames rejected; TMDB sizes normalized")
}
