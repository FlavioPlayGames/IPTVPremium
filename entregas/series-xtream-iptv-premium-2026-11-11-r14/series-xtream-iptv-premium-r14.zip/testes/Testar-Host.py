"""Testes JVM de r14: fontes reais, com adaptadores Android/DAO/rede/bitmap indicados no relatorio."""
from pathlib import Path
import argparse, os, subprocess, tempfile, shutil, urllib.request
cli=argparse.ArgumentParser(description=__doc__)
cli.add_argument('--projeto',type=Path,required=True)
cli.add_argument('--lista',type=Path,help='ZIP M3U completo, opcional')
cli.add_argument('--tools',type=Path,help='Cache local dos JARs Maven')
cli.add_argument('--java',default='java')
a=cli.parse_args();fixtures=Path(__file__).resolve().parent
root=a.projeto.resolve()/'app/src/main/java/br/com/flaviotorres/iptvpremium'
tools=a.tools or fixtures/'.tools';tools.mkdir(parents=True,exist_ok=True)
artifacts=[('org.jetbrains.kotlin','kotlin-compiler-embeddable','2.2.10'),('org.jetbrains.kotlin','kotlin-stdlib','2.2.10'),('org.jetbrains.kotlin','kotlin-script-runtime','2.2.10'),('org.jetbrains.kotlin','kotlin-reflect','1.6.10'),('org.jetbrains.kotlin','kotlin-daemon-embeddable','2.2.10'),('org.jetbrains.kotlinx','kotlinx-coroutines-core-jvm','1.8.0'),('org.jetbrains','annotations','13.0'),('org.json','json','20250517'),('com.google.code.gson','gson','2.11.0')]
jars=[]
for group,name,version in artifacts:
 dest=tools/f'{name}-{version}.jar'
 if not dest.exists():
  temporary=dest.with_suffix('.download');url=f'https://repo.maven.apache.org/maven2/{group.replace(".","/")}/{name}/{version}/{dest.name}'
  with urllib.request.urlopen(url,timeout=120) as response,temporary.open('wb') as output:shutil.copyfileobj(response,output)
  temporary.replace(dest)
 jars.append(str(dest.resolve()))
cp=os.pathsep.join(jars)
def run(*args):subprocess.run(list(map(str,args)),check=True)
with tempfile.TemporaryDirectory(prefix='iptv-r14-host-') as tmp:
 work=Path(tmp)
 for group in ['shared','poster','parser','common','search','xtream']:
  (work/group).mkdir()
  for p in (fixtures/group).glob('*.kt'):shutil.copyfile(p,work/group/p.name)
 for source,model,fn in [('ui/components/UnifiedMediaCatalog.kt','CatalogPoster','catalogContinuePosters'),('ui/kids/KidsMediaCatalog.kt','KidsPoster','kidsContinuePosters')]:
  text=(root/source).read_text(encoding='utf-8-sig');start=text.index('internal data class '+model+'(');end=text.index('\n\n',start);fstart=text.index('internal fun '+fn+'(');fend=text.index('\n}',fstart)+2
  (work/'shared'/(model+'.kt')).write_text('package host\nimport br.com.flaviotorres.iptvpremium.data.history.WatchHistoryEntry\nimport br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType\n'+text[start:end]+'\n'+text[fstart:fend],encoding='utf-8')
 import re
 state=(root/'ui/components/GenericPosterArtwork.kt').read_text()
 state=re.search(r'internal data class PosterArtworkState\([^\n]+',state).group()
 code='package br.com.flaviotorres.iptvpremium.ui.movies\nimport androidx.compose.ui.graphics.ImageBitmap\n'+state+'\n'
 for name,path in [('normal','ui/components/UnifiedMediaCatalog.kt'),('kids','ui/kids/KidsMediaCatalog.kt')]:
  text=(root/path).read_text();body=re.search(r'onResult=\{([^\n]+)\},',text).group(1)
  code+=f'internal fun {name}Result(previous:PosterArtworkState,result:ImageBitmap?):PosterArtworkState {{var value=previous;val it=result;{body};return value}}\n'
 (work/'poster/RetainHandlers.kt').write_text(code)
 def compile(name,production,adapters):
  jar=work/(name+'.jar')
  run(a.java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',jar,*[root/f for f in production],*[work/f for f in adapters])
  return str(jar)+os.pathsep+cp
 # Compile the actual query-option expressions and DTOs extracted from both ViewModels.
 import re
 code='package host.search\nimport kotlinx.coroutines.*\nimport kotlinx.coroutines.flow.*\nimport br.com.flaviotorres.iptvpremium.data.cache.*\n'
 for media,option,cat,favs,variable,stop in [
  ('movies','MovieQueryOptions','MovieCategoryFilter','favoriteMovieIds','movieQueryOptions','\n    val movies:'),
  ('series','SeriesQueryOptions','SeriesCategoryFilter','favoriteSeriesIds','queryOptions','\n    @OptIn')]:
  text=(root/f'ui/{media}/{media.capitalize()}ViewModel.kt').read_text()
  for name in [option,cat]:
   match=re.search(r'private data class '+name+r'\([\s\S]*?\n\s*\)',text)
   assert match,name
   code+=match.group().replace('private data class','internal data class')+'\n'
  begin=text.index('private val '+variable)
  expression=text[text.index('=',begin)+1:text.index(stop,begin)]
  code+=f'internal fun {media}Options(searchQuery:Flow<String>,categoryFilter:Flow<{cat}>,{favs}:Flow<Set<String>>,sortMode:Flow<String>) ='+expression+'\n'
 ui=(root/'ui/components/UnifiedMediaCatalog.kt').read_text()
 begin=ui.index('internal fun catalogPagingKey(');end=ui.index('\n\n',begin)
 code+=ui[begin:end]+'\n'
 def method(text,name):
  begin=text.index('    fun '+name+'(');brace=text.index('{',begin);depth=1;end=brace+1
  while depth:
   if text[end]=='{':depth+=1
   if text[end]=='}':depth-=1
   end+=1
  return text[begin:end]
 for name,path in [('Normal','ui/components/UnifiedMediaCatalog.kt'),('Kids','ui/kids/KidsMediaCatalog.kt')]:
  text=(root/path).read_text()
  code+=f'internal class {name}ClearHarness(val scope:CoroutineScope) {{\n'
  code+='var query="initial";var cursor=3;var keyboard=false;var firstPosterPending=true;val changes=mutableListOf<String>();var focus=0;val searchFocus=this\nfun requestFocus(){focus++}\nfun beginFilterChange(){firstPosterPending=true}\nfun onSearch(value:String){changes+=value}\nsuspend fun withFrameNanos(block:(Long)->Unit){block(0)}\n'
  code+=method(text,'changeSearch')+'\n'+method(text,'clearSearch')+'\n}\n'
 (work/'search/Extracted.kt').write_text(code)
 search=compile('search',['data/cache/CatalogSearchScope.kt','data/cache/CatalogInteractionPolicy.kt'],['search/'+p.name for p in (work/'search').glob('*.kt')])
 run(a.java,'-cp',search,'host.search.SearchMainKt')
 shared=compile('shared',['data/history/SharedLibraryStore.kt','data/history/WatchHistoryStore.kt','data/history/ContentIdentity.kt','data/history/HistoryWorkPolicy.kt','data/history/SeriesSeasonCoverPolicy.kt','data/history/HistoryProfile.kt','data/history/HistoryProfileMigration.kt','data/history/PlayerFavoriteMigration.kt','data/history/ProviderMovieIdentity.kt','domain/model/FavoriteScope.kt','data/history/LibraryHandoffMatcher.kt'],['shared/'+p.name for p in (work/'shared').glob('*.kt')])
 for main in ['HandoffMainKt','SharedMainKt','PolicyMainKt','ArtworkIdentityMainKt','HistoryMainKt','SeasonPolicyMainKt']:run(a.java,'-cp',shared,'host.'+main)
 metadata=['data/cache/PosterRequestLocks.kt','data/repository/CatalogMetadataCache.kt','data/repository/CatalogMetadataDiskCache.kt','data/repository/CatalogMetadataIdentity.kt','data/repository/SeriesCatalogPosterResolver.kt','data/repository/MovieCatalogPosterResolver.kt','data/repository/SeriesArtworkIdentityResolver.kt']
 poster=compile('poster',['ui/movies/MoviePosterBindingCache.kt','ui/movies/CatalogPosterFallback.kt','ui/movies/MovieProviderPoster.kt','data/cache/GenericPosterPolicy.kt','data/cache/PosterCategoryPolicy.kt','data/cache/PosterReserve.kt','data/cache/PosterNetworkBudget.kt','data/cache/PosterVisibilityPriority.kt','data/cache/MediaOpeningPriority.kt','data/cache/PosterSourceUrl.kt','data/cache/PosterFailurePolicy.kt']+metadata,['poster/'+p.name for p in (work/'poster').glob('*.kt') if p.name!='StorageMain.kt']+['shared/Context.kt','common/Budget.kt','common/Log.kt','common/CacheMain.kt'])
 run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.ui.movies.VisibleMainKt')
 run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.ui.movies.SeriesReadyMainKt')
 run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.ui.movies.MovieFallbackMainKt')
 run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.ui.movies.ImportOrderMainKt')
 for mode in ['write','read']:run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.ui.movies.BindingMainKt',mode,work/'binding-cache')
 run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.data.cache.ReserveMainKt')
 for mode in ['write','read']:run(a.java,'-cp',poster,'br.com.flaviotorres.iptvpremium.data.repository.CacheMainKt',mode,work/'metadata-cache')
 parser=compile('parser',['data/m3u/M3uCatalogParser.kt','data/m3u/M3uCatalogFormat.kt','data/m3u/M3uSeriesPosterSelection.kt','data/m3u/M3uSeriesImagePolicy.kt','data/cache/importer/M3uEntryClassifier.kt','data/cache/importer/M3uEntryMetadata.kt','data/m3uepisodes/M3uEpisodeSource.kt','data/cache/entity/CachedEpisodeEntity.kt'],['parser/SelectionMain.kt','parser/ImportIdsMain.kt','common/ParserMain.kt','common/Epg.kt','common/Log.kt','common/Room.kt'])
 run(a.java,'-cp',parser,'br.com.flaviotorres.iptvpremium.data.m3u.SelectionMainKt')
 run(a.java,'-cp',parser,'br.com.flaviotorres.iptvpremium.data.m3u.ImportIdsMainKt')
 if a.lista:run(a.java,'-Xmx768m','-cp',parser,'br.com.flaviotorres.iptvpremium.data.m3u.ParserMainKt',a.lista.resolve(),work/'m3u')
 storage=compile('storage',['core/storage/CacheStorageBudget.kt','data/cache/PosterFileLru.kt','data/cache/PosterCategoryPolicy.kt'],['poster/StorageMain.kt'])
 run(a.java,'-cp',storage,'br.com.flaviotorres.iptvpremium.core.storage.StorageMainKt')
 xtream=compile('xtream',['data/parser/DefaultXtreamParser.kt','data/parser/XtreamParser.kt','data/parser/XtreamDirectCatalogReader.kt','data/cache/ImportTuningPolicy.kt','data/cache/PosterSourceUrl.kt']+[str(p.relative_to(root)) for p in (root/'domain/model').glob('*.kt')],['xtream/JsonReader.kt','xtream/XtreamMain.kt','xtream/Log.kt'])
 run(a.java,'-cp',xtream,'host.xtream.XtreamMainKt')
print('Testes JVM r14 concluidos. API, imagens reais e TV exigem validacao separada.')
