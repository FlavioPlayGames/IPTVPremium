package br.com.flaviotorres.iptvpremium.ui.movies
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.domain.model.*
import br.com.flaviotorres.iptvpremium.data.repository.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

fun main()=runBlocking {
 var calls=0
 val slow=MovieOpeningPolicy.prepare { calls++;delay(5_300);"metadata" }
 check(slow=="metadata" && calls==1)
 println("PASS: a valid response slower than five seconds completes without a redundant request")
 calls=0
 check(MovieOpeningPolicy.prepare { calls++;if(calls==1)null else "recovered" }=="recovered" && calls==2)
 val started=CompletableDeferred<Unit>();val stopped=CompletableDeferred<Unit>()
 val cancel=launch{MovieOpeningPolicy.prepare { try{started.complete(Unit);awaitCancellation()}finally{stopped.complete(Unit)} }}
 started.await();cancel.cancelAndJoin();withTimeout(500){stopped.await()}
 println("PASS: bounded fast recovery and caller cancellation")
 val flow=MutableStateFlow(true);val updates=MutableSharedFlow<Unit>();var starts=0;var cancels=0;val results=mutableListOf<String?>()
 val observing=launch{observeWhilePosterVisible(flow,updates,{
  starts++;try{delay(200);"poster"}finally{cancels++}
 },{results.add(it)})}
 withTimeout(1000){while(starts==0)delay(5)}
 MediaOpeningPriority.setBusy(true)
 withTimeout(1000){while(cancels==0)delay(5)}
 delay(250);check(results.isEmpty()&&starts==1)
 MediaOpeningPriority.setBusy(false)
 withTimeout(1000){while(results.isEmpty())delay(5)}
 check(results==listOf("poster")&&starts==2);observing.cancelAndJoin()
 val bgStart=CompletableDeferred<Unit>();var bgCalls=0;var bgStopped=false
 val background=async{MediaOpeningPriority.whileIdle {
  bgCalls++;try{bgStart.complete(Unit);delay(200);"background"}finally{bgStopped=true}
 }}
 bgStart.await();MediaOpeningPriority.setBusy(true)
 withTimeout(500){while(!bgStopped)delay(5)}
 delay(250);check(!background.isCompleted&&bgCalls==1)
 MediaOpeningPriority.setBusy(false);check(background.await()=="background"&&bgCalls==2)
 println("PASS: selected content cancels visible and background artwork work; release resumes both")
 val oldStarted=CompletableDeferred<Unit>();val oldRelease=CompletableDeferred<Unit>()
 val old=launch{CatalogDetailsWarmupCache.prefetchSeries("p","g","s") { oldStarted.complete(Unit);oldRelease.await();null }}
 oldStarted.await()
 val expected=SeriesEpisodesResult("s","Series",null,null,null,null,emptyList(),listOf(SeriesEpisodeInfo("ep",1,1,"One",null,null,null,null)))
 val selected=withTimeout(300){CatalogDetailsWarmupCache.seriesOrLoad("p","g","s"){expected}}
 check(selected===expected);oldRelease.complete(Unit);old.join()
 check(CatalogDetailsWarmupCache.getSeries("p","g","s")===expected)
 CatalogDetailsWarmupCache.trimMemory();check(CatalogDetailsWarmupCache.getSeries("p","g","s")==null)
 println("PASS: selected series bypasses stale background owner; pressure releases only disposable metadata")
 val local=Movie("movie","Title",null,null,null,"https://example.invalid/video",2024,null,null)
 val harness=PreparationHarness(local);val source=PlaylistSource.XtreamCodes(id="p",name="List",serverUrl="https://example.invalid",username="fixture",password="fixture")
 for(mode in listOf("slow","error")) {
  imageMode=mode;var requests=0
  val prepared=harness.prepareMovieDetails("movie",source,android.content.Context(),1920,1080){_,_->requests++;MovieDetails("movie",plot="Provider plot")}
  check(prepared?.details?.plot=="Provider plot"&&requests==1&&prepared.images==null)
 }
 println("PASS: actual preparation code retains selected data when artwork times out or fails")
 val cards=(1..20).toList()
 val stable=CachedCarouselPolicy.select("1",cards,{it.toString()},{"https://example.invalid/$it.jpg"},(1..4).map{"https://example.invalid/$it.jpg"}.toSet(),emptySet(),includeUncached=true)
 check(stable.size==20&&stable.first()==1)
 println("PASS: initial carousel keeps twenty stable positions with only four RAM hits; no network loader")
 val confirmed="https://example.invalid/tmdb.jpg"
 MovieCatalogPosterResolver.posters["Fallback title"]=Poster(confirmed)
 MoviePosterLoader.cached.add(confirmed)
 val fallbackMovie=local.copy(name="Fallback title",posterUrl=null)
 val carousel=uniqueCarouselPosters("movie",listOf(fallbackMovie))
 check(carousel.single().posterUrl==confirmed)
 println("PASS: real carousel candidate code reuses the selected movie's confirmed TMDB artwork without networking")
}
