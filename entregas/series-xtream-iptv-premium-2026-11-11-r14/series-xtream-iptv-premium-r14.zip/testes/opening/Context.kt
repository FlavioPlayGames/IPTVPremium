package android.content
class Context {val applicationContext get()=this}
