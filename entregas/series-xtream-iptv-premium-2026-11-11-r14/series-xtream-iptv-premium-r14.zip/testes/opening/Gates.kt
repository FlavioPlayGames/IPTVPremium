package br.com.flaviotorres.iptvpremium.data.cache
import kotlinx.coroutines.flow.MutableStateFlow
object CatalogImportPriority {val busy=MutableStateFlow(false)}
