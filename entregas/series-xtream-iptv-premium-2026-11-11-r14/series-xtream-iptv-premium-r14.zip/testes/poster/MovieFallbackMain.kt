package br.com.flaviotorres.iptvpremium.ui.movies
import android.content.Context
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.repository.*
import br.com.flaviotorres.iptvpremium.data.remote.TmdbClientProvider
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.nio.file.Files
fun main()=runBlocking {
 val context=Context(Files.createTempDirectory("movie-fallback").toFile());CatalogMetadataDiskCache.initialize(context)
 val api=TmdbClientProvider.client
 val provider="https://provider.example/cover.jpg"
 val before=api.requests.get()
 check(loadCatalogPoster(context,provider,PosterKind.MOVIES,"Insaciável 4K",2024,null,null)?.url==provider)
 check(api.requests.get()==before)
 val missing=loadCatalogPoster(context,null,PosterKind.MOVIES,"Insaciável 4K",2024,null,null)
 check(missing?.url=="https://image.tmdb.org/t/p/w342/movie1201.jpg")
 check(api.movieAppends.all{!it.split(',').contains("credits")})
 val requests=api.requests.get()
 check(loadCatalogPoster(context,null,PosterKind.MOVIES,"Insaciável HD",2024,null,null)?.url==missing.url)
 check(api.requests.get()==requests)
 val bad="https://provider.example/missing.jpg";MoviePosterLoader.broken.add(bad)
 check(loadCatalogPoster(context,bad,PosterKind.MOVIES,"Outra Mamãe",2024,null,null)?.url?.endsWith("/movie1202.jpg")==true)
 check(loadCatalogPoster(context,null,PosterKind.MOVIES,"Ambiguous",2024,null,null)==null)
 check(loadCatalogPoster(context,null,PosterKind.MOVIES,"Insaciável",2000,null,null)==null)
 check(loadCatalogPoster(context,null,PosterKind.MOVIES,"Wrong work",2024,"1201",null)==null)
 println("PASS: movie provider first; missing/broken cover verified on TMDB; quality tags normalized; cache reused; homonyms/wrong work rejected")
 check(!persistentPosterFailure("timeout",0));check(!persistentPosterFailure("io_error",0))
 check(!persistentPosterFailure("priority_busy",0));check(!persistentPosterFailure("priority_interrupted",0))
 check(!persistentPosterFailure("cache_budget",0));check(!persistentPosterFailure("http_status",429))
 check(!persistentPosterFailure("http_status",503));check(!persistentPosterFailure("image_prepare",200))
 check(persistentPosterFailure("http_status",404));check(persistentPosterFailure("http_status",410))
 println("PASS: transient/priority/storage failures never get a five-minute missing-image block")
 check(posterDownloadUrl("https://image.tmdb.org/t/p/original/example.jpg?q=keep")=="https://image.tmdb.org/t/p/w342/example.jpg?q=keep")
 check(posterDownloadUrl("https://image.tmdb.org/t/p/w185/example.jpg").contains("/w185/"))
 check(posterDownloadUrl("https://image.tmdb.org/t/p/w600_and_h900_bestv2/example.jpg")=="https://image.tmdb.org/t/p/w342/example.jpg")
 val foreign="https://provider.example/t/p/original/example.jpg";check(posterDownloadUrl(foreign)==foreign)
 check(posterSourceUrl("null")==null);check(posterSourceUrl("file:///tmp/image.jpg")==null)
 check(posterSourceUrl("//cdn.example/image.jpg")=="https://cdn.example/image.jpg")
 check(posterSourceUrl("https://cdn.example/my cover.jpg")=="https://cdn.example/my%20cover.jpg")
 println("PASS: reduced official CDN transport preserves query/cache identity; provider/invalid schemes are not rewritten")
 val release=CompletableDeferred<Unit>();val entered=CompletableDeferred<Unit>()
 val backgrounds=java.util.concurrent.atomic.AtomicInteger()
 api.beforeGet={path->if(path in listOf("/movie/1301","/movie/1303")){backgrounds.incrementAndGet();entered.complete(Unit);release.await()}}
 val bg=listOf("1301","1303").map{id->async{prefetchCatalogPoster(context,PosterKind.MOVIES,PosterCandidate(null,"Movie",2024,id))}}
 entered.await()
 val priority=withTimeout(2_000){loadCatalogPoster(context,null,PosterKind.MOVIES,"Movie",2024,"1302",null)}
 check(priority!=null && backgrounds.get()==1 && bg.none{it.isCompleted})
 release.complete(Unit);bg.awaitAll();api.beforeGet=null
 println("PASS: two pending anticipations cannot occupy both TMDB lookup slots; visible cover keeps priority")
 val visible=MutableStateFlow(false);val updates=MutableSharedFlow<Unit>(extraBufferCapacity=1)
 var loads=0;val values=mutableListOf<String?>()
 val job=launch {observeWhilePosterVisible(visible,updates,{loads++;if(loads==1)null else "ready"},{values.add(it)})}
 delay(30);check(loads==0);visible.value=true
 withTimeout(3000){while(values.lastOrNull()!="ready")delay(10)}
 check(loads==2)
 visible.value=false;delay(20);updates.emit(Unit);delay(30);check(loads==2)
 visible.value=true;withTimeout(500){while(loads<3)delay(10)}
 updates.emit(Unit);withTimeout(500){while(loads<4)delay(10)}
 job.cancelAndJoin()
 println("PASS: visible card retries once, resumes after re-entry and reacts to completed prefetch; invisible cards do not fetch")
 context.cacheDir.deleteRecursively()
 Unit
}
