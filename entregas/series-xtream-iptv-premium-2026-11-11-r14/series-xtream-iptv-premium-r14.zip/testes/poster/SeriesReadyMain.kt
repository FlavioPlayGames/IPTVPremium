package br.com.flaviotorres.iptvpremium.ui.movies
import android.content.Context
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.repository.*
import br.com.flaviotorres.iptvpremium.data.remote.TmdbClientProvider
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.nio.file.Files
fun main()=runBlocking {
 val context=Context(Files.createTempDirectory("series-ready-").toFile());CatalogMetadataDiskCache.initialize(context)
 val api=TmdbClientProvider.client;val provider="https://provider.example/ready-series.jpg"
 val visible=mutableListOf<String>()
 val cold=loadCatalogPoster(context,provider,PosterKind.SERIES,"Show960",2024,"960",null,1,onProviderReady={visible.add(it.url)})
 check(provider in visible&&cold?.url?.endsWith("/season960.jpg")==true)
 println("PASS: cold provider image appears immediately and still completes requested-season lookup")
 val known=SeriesCatalogPosterResolver.resolve("Show961",2024,"961",null,api::get)!!
 check(loadCatalogPoster(context,null,PosterKind.SERIES,"Show961",2024,"961",null)?.url==known.url)
 val broken="https://provider.example/timeout.jpg";MoviePosterLoader.broken.add(broken)
 val requests=MoviePosterLoader.requested.size;val network=api.requests.get()
 check(loadCatalogPoster(context,broken,PosterKind.SERIES,"Show961",2024,"961",null)?.url==known.url)
 check(MoviePosterLoader.requested.size==requests&&api.requests.get()==network)
 MoviePosterLoader.clearRam()
 val season=loadCatalogPoster(context,broken,PosterKind.SERIES,"Show961",2024,"961",null,1)
 check(season?.url?.endsWith("/season961.jpg")==true)
 check(MoviePosterLoader.requested.drop(requests).none{it==broken})
 check(api.requests.get()==network)
 println("PASS: general TMDB cache bypasses broken provider; known seasonal URL is fetched directly after bitmap eviction")
 val reserve=prefetchCatalogPoster(context,PosterKind.SERIES,PosterCandidate(provider,"Show962",2024,"962",season=1))
 check(reserve?.endsWith("/season962.jpg")==true)
 check(loadCatalogPoster(context,provider,PosterKind.SERIES,"Show962",2024,"962",null,9)?.url==provider)
 println("PASS: reserve completes season selection even with valid provider art; unavailable season never borrows another season")
 var starts=0;var stopped=false;val ready=CompletableDeferred<Unit>()
 val background=async{MediaOpeningPriority.whileIdle{starts++;try{ready.complete(Unit);delay(200);"result"}finally{stopped=true}}}
 ready.await();CatalogImportPriority.busy.value=true
 withTimeout(500){while(!stopped)delay(5)};delay(230);check(starts==1&&!background.isCompleted)
 CatalogImportPriority.busy.value=false;check(background.await()=="result"&&starts==2)
 val placed=MutableStateFlow(true);val updates=MutableSharedFlow<Unit>();var attempts=0;var finished=0
 val observer=launch{observeWhilePosterVisible(placed,updates,{attempts++;try{delay(200);"image"}finally{finished++}},{})}
 withTimeout(500){while(attempts==0)delay(5)};CatalogImportPriority.busy.value=true
 withTimeout(500){while(finished==0)delay(5)};delay(230);check(attempts==1)
 CatalogImportPriority.busy.value=false;withTimeout(500){while(attempts<2)delay(5)};observer.cancelAndJoin()
 println("PASS: import priority cancels both in-flight visible and background artwork metadata, then resumes safely")
}
