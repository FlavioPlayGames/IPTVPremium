package br.com.flaviotorres.iptvpremium.ui.movies
import android.content.Context
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.repository.*
import br.com.flaviotorres.iptvpremium.data.remote.TmdbClientProvider
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import org.json.JSONObject
import org.json.JSONArray
import java.nio.file.Files
fun main()=runBlocking {
 val dir=Files.createTempDirectory("import-order-").toFile();val context=Context(dir);CatalogMetadataDiskCache.initialize(context)
 val api=TmdbClientProvider.client
 val before=api.requests.get();var providerRequests=0
 val native=loadCatalogPoster(context,null,PosterKind.MOVIES,"Insaciável 4K",null,null,null,
  resolveProvider={providerRequests++;MovieProviderPoster("https://provider.example/native.jpg","Insaciável",2024,"1201",null)})
 check(native?.url=="https://provider.example/native.jpg"&&providerRequests==1&&api.requests.get()==before)
 val identified=loadCatalogPoster(context,null,PosterKind.MOVIES,"Insaciável 4K",null,null,null,
  resolveProvider={MovieProviderPoster(null,"Insaciável",2024,"1201",null)})
 check(identified?.url?.endsWith("/movie1201.jpg")==true)
 println("PASS: provider detail cover is used before TMDB; metadata-only provider response supplies actual TMDB ID/year")
 val calls=java.util.concurrent.atomic.AtomicInteger()
 coroutineScope{(1..12).map{async{MovieProviderPosterCache.load("deduplicated") {calls.incrementAndGet();delay(60);MovieProviderPoster(null,"Movie",2024,"1204",null)}}}.awaitAll()}
 check(calls.get()==1)
 repeat(2){check(MovieProviderPosterCache.load("missing"){calls.incrementAndGet();null}==null)}
 check(calls.get()==2)
 println("PASS: missing-provider metadata is deduplicated and cached without a catalogue sweep")
 val languages=mutableListOf<String>();val queries=mutableListOf<Map<String,String>>()
 val languageGet:suspend(String,Map<String,String>)->String={path,q->
  if(path=="/search/movie") {
   languages.add(q.getValue("language"));queries.add(q)
   JSONObject().put("results",if(q["language"]=="es-ES")JSONArray().put(JSONObject().put("id",2001).put("title","Language fixture").put("release_date","2024-01-01"))else JSONArray()).toString()
  }else JSONObject().put("id",2001).put("title","Language fixture").put("release_date","2024-01-01").put("poster_path","/languages.jpg").toString()
 }
 check(MovieCatalogPosterResolver.resolve("Language fixture",2024,null,null,languageGet)!=null)
 check(languages==listOf("pt-BR","en-US","es-ES")&&queries.all{it["year"]=="2024"})
 val idCalls=mutableListOf<String>()
 val idGet:suspend(String,Map<String,String>)->String={path,_->idCalls.add(path);JSONObject().put("id",2002).put("title","ID fixture").put("release_date","2024-01-01").put("poster_path","/id.jpg").toString()}
 check(MovieCatalogPosterResolver.resolve("ID fixture",2024,"2002",null,idGet)!=null)
 check(idCalls==listOf("/movie/2002"))
 println("PASS: actual external ID precedes search; name/year is sent in pt-BR, en-US, es-ES order")
 val visible=MutableStateFlow(true);val updates=MutableSharedFlow<Unit>();val results=mutableListOf<String?>();var attempts=0;var pending=false
 val job=launch{observeWhilePosterVisible(visible,updates,{attempts++;null as String?},{results.add(it)},{pending=true})}
 withTimeout(500){while(attempts==0)delay(5)}
 check(pending&&results.isEmpty())
 withTimeout(2500){while(results.isEmpty())delay(5)}
 check(attempts==2&&results==listOf<String?>(null))
 job.cancelAndJoin()
 println("PASS: no generic result while either attempt remains pending; final missing result is emitted once")
 dir.deleteRecursively();Unit
}
