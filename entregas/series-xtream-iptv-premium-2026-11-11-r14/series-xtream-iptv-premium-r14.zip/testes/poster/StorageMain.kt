package br.com.flaviotorres.iptvpremium.core.storage
import java.nio.file.Files
import java.io.File
import br.com.flaviotorres.iptvpremium.data.cache.*
fun main() {
 check(CacheStorageLimits.TOTAL==100_000_000L && CacheStorageLimits.IMAGES==75_000_000L)
 check(PosterCategoryPolicy.CAPACITY==125)
 val root=Files.createTempDirectory("iptv-rotation-").toFile()
 try {
  val cache=File(root,"cache").apply{mkdirs()};val images=File(cache,PosterKind.MOVIES.directory).apply{mkdirs()}
  var now=0L
  val caps=CacheStorageKind.entries.associateWith{if(it==CacheStorageKind.IMAGES)30L else 40L}
  val budget=CacheStorageBudget(cache,File(root,"subs"),40,caps,{++now})
  fun save(name:String):File {
   val file=File(images,name)
   val lease=checkNotNull(budget.reserve(file,6))
   lease.use{it.temporary.writeBytes(ByteArray(6));check(budget.accountedBytes()<=40);check(it.temporary.renameTo(file))}
   return file
  }
  val files=(0..4).map{save("$it.img")};val pin=budget.retain(files[0])
  val new=save("new.img")
  check(files[0].isFile && new.isFile && !files[1].exists() && !files[2].exists())
  check(budget.accountedBytes()<=30)
  check(budget.reserve(File(images,"oversize.img"),41)==null)
  pin.close()
  val dir=File(cache,PosterKind.SERIES.directory).apply{mkdirs()}
  val hashes=(1..4).map{it.toString(16).padStart(64,'0')}
  val lru=PosterFileLru(dir,{it.delete()},capacity=3,clock={++now})
  val pinFirst=checkNotNull(lru.acquire(hashes[0]));File(dir,"${hashes[0]}.img").writeText("1")
  for(i in 1..2)checkNotNull(lru.acquire(hashes[i])).use{File(dir,"${hashes[i]}.img").writeText("1")}
  lru.setVisible(setOf(hashes[2]))
  checkNotNull(lru.acquire(hashes[3])).use{File(dir,"${hashes[3]}.img").writeText("1")}
  check(File(dir,"${hashes[0]}.img").exists() && !File(dir,"${hashes[1]}.img").exists() && File(dir,"${hashes[2]}.img").exists())
  pinFirst.close()
  println("PASS: original 100MB cache/75MB images/125-per-kind limits unchanged; rotation frees oldest in chunks, pins readers/writers, accounts temporary reservations and rejects oversize")
 }finally{root.deleteRecursively()}
}
