package br.com.flaviotorres.iptvpremium.ui.movies
import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.repository.*
import br.com.flaviotorres.iptvpremium.data.remote.TmdbClientProvider
import kotlinx.coroutines.*
import java.io.File

fun main(args:Array<String>)=runBlocking {
 val dir=File(args[1]);dir.mkdirs();val context=Context(dir);CatalogMetadataDiskCache.initialize(context)
 val bad="https://provider.example/unavailable.jpg";val expected="https://image.tmdb.org/t/p/w342/movie1201.jpg"
 val key=MoviePosterBindingCache.key("list-A","movie-1",bad,"Insaciável 4K",null,null,null)!!
 MoviePosterLoader.broken.add(bad)
 if(args[0]=="write") {
  var details=0
  val result=loadCatalogPoster(context,bad,PosterKind.MOVIES,"Insaciável 4K",null,null,null,
   resolveProvider={details++;MovieProviderPoster(null,"Insaciável",2024,"1201",null)},bindingKey=key)
  check(result?.url==expected&&details==1)
  check(MovieCatalogPosterResolver.peek("Insaciável 4K",null,null,null)==null)
  check(peekCatalogPoster(bad,PosterKind.MOVIES,"Insaciável 4K",null,null,null,bindingKey=key)?.url==expected)
  val calls=MoviePosterLoader.requested.size;val tmdb=TmdbClientProvider.client.requests.get()
  repeat(3) {
   val returned=loadCatalogPoster(context,bad,PosterKind.MOVIES,"Insaciável 4K",null,null,null,
    resolveProvider={error("must not query native details again")},bindingKey=key)
   check(returned?.url==expected)
  }
  check(MoviePosterLoader.requested.size==calls&&TmdbClientProvider.client.requests.get()==tmdb)
  println("PASS: enriched ID/year is bound to original list item; three returns reuse the image without provider/TMDB work")
  val item=PosterCandidate(bad,"Insaciável 4K",id="movie-1",scope="list-A")
  check(cachedCatalogPosterUrl(PosterKind.MOVIES,item)==expected)
  check(prefetchCatalogPoster(context,PosterKind.MOVIES,item)==expected)
  check(MoviePosterLoader.requested.size==calls)
  println("PASS: reserve and visible-file protection see the same resolved URL as the card")
 } else {
  check(MoviePosterBindingCache.peek(key)==null)
  check(MoviePosterBindingCache.cached(key)==expected)
  val result=loadCatalogPoster(context,bad,PosterKind.MOVIES,"Insaciável 4K",null,null,null,
   resolveProvider={error("must not query native details after restart")},bindingKey=key)
  check(result?.url==expected&&MoviePosterLoader.requested.toList()==listOf(expected))
  check(TmdbClientProvider.client.requests.get()==0)
  println("PASS: fresh process restores exact binding from disk and refetches only the known good image")
 }
 val other=MoviePosterBindingCache.key("list-B","movie-1",bad,"Insaciável 4K",null,null,null)!!
 check(other!=key&&MoviePosterBindingCache.cached(other)==null)
 check(MoviePosterBindingCache.key("list-A","movie-2",bad,"Insaciável 4K",null,null,null)!=key)
 check(MoviePosterBindingCache.key("list-A","movie-1",bad,"Insaciável 4K",2024,null,null)!=key)
 check(MoviePosterBindingCache.key("","movie-1",bad,"Insaciável 4K",null,null,null)==null)
 MoviePosterBindingCache.remember(other,"https://private.example/SECRET",1201)
 check(MoviePosterBindingCache.cached(other)==null)
 val json=dir.walkTopDown().filter{it.extension=="json"}.joinToString(""){it.readText()}
 check("SECRET" !in json&&"provider.example" !in json&&"list-A" !in json)
 val previous=PosterArtworkState(ImageBitmap(expected),true)
 check(normalResult(previous,null).bitmap===previous.bitmap&&kidsResult(previous,null).bitmap===previous.bitmap)
 check(normalResult(PosterArtworkState(null,false),null).finished)
 check(kidsResult(PosterArtworkState(null,false),null).finished)
 println("PASS: bindings isolate lists/items/identity, reject private image URLs; real normal/Kids handlers retain loaded artwork on failure")
}
