package androidx.compose.ui.graphics
data class ImageBitmap(val url:String)
