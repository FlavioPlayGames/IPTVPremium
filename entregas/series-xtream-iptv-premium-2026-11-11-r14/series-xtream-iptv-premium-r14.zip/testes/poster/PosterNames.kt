package br.com.flaviotorres.iptvpremium.ui.movies
import br.com.flaviotorres.iptvpremium.data.repository.*
import org.json.JSONObject
import org.json.JSONArray

internal suspend fun testPosterNames() {
    // Synthetic public metadata: exercise production search/validation, without real API access.
    val titles=listOf("Lei & Ordem","Lei & Ordem: Unidade de Vítimas Especiais","Lei & Ordem Toronto: Intenção Criminal")
    val providers=listOf("Lei e Ordem","Lei e Ordem Unidade de Vitimas Especiais","Lei e Ordem Toronto Intencao Criminal")
    val ids=listOf(910001,910002,910003)
    fun row(index:Int)=JSONObject().put("id",ids[index]).put("name",titles[index]).put("original_name","Fixture $index")
        .put("first_air_date","1990-01-01").put("poster_path","/poster${ids[index]}.jpg")
    val requests=mutableListOf<Pair<String,Map<String,String>>>()
    val get:suspend(String,Map<String,String>)->String={path,query->
        requests.add(path to query)
        if(path=="/search/tv") {
            // The first query with 'e' finds nothing; the one bounded '&' variant succeeds.
            JSONObject().put("results",if(query.getValue("query").contains("&"))JSONArray(titles.indices.map(::row))else JSONArray()).toString()
        } else row(ids.indexOf(path.substringAfterLast('/').toInt())).toString()
    }
    for(index in titles.indices) {
        val before=requests.size
        val poster=SeriesCatalogPosterResolver.resolve(providers[index],null,null,null,get)
        check(poster?.tmdbId==ids[index]) {"Wrong franchise identity for ${providers[index]}"}
        check(requests.size-before==3) // primary search, alternate search, verified details
        val after=requests.size
        check(SeriesCatalogPosterResolver.cached(providers[index],null,null,null)?.url==poster.url)
        check(SeriesCatalogPosterResolver.resolve(providers[index],null,null,null,get)?.tmdbId==ids[index])
        check(requests.size==after)
    }
    check(artworkTitle("Lei & Ordem")!=artworkTitle("Lei e Ordem")) // unrelated shared identity rules stay unchanged
    check(seriesPosterTitle(titles[0])==seriesPosterTitle(providers[0]))
    check(seriesPosterTitle(providers[0])!=seriesPosterTitle(providers[1]))
    check(SeriesCatalogPosterResolver.resolve(providers[0],2024,null,null,get)==null) // wrong release year
    val ambiguous:suspend(String,Map<String,String>)->String={_,_->
        JSONObject().put("results",JSONArray().put(row(0)).put(row(0).put("id",910004))).toString()
    }
    check(SeriesCatalogPosterResolver.resolve(titles[0],null,null,null,ambiguous)==null)
    val conflicting:suspend(String,Map<String,String>)->String={_,_->row(1).toString()}
    check(SeriesCatalogPosterResolver.resolve(providers[0],null,ids[1].toString(),null,conflicting)==null)
    // Alias lookup remains available when only an original-language name is returned by search.
    val alias:suspend(String,Map<String,String>)->String={path,_->
        if(path=="/search/tv")JSONObject().put("results",JSONArray().put(JSONObject().put("id",910005).put("name","Alias fixture"))).toString()
        else JSONObject().put("id",910005).put("name","Alias fixture").put("poster_path","/alias.jpg")
            .put("alternative_titles",JSONObject().put("results",JSONArray().put(JSONObject().put("title","Outra & História")))).toString()
    }
    check(SeriesCatalogPosterResolver.resolve("Outra e Historia",null,null,null,alias)?.tmdbId==910005)
    println("PASS: e/& punctuation, three distinct Law & Order works, bounded alternate query, cache reuse, aliases, ambiguous/year/conflicting-title rejection")
}
