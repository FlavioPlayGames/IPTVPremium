package br.com.flaviotorres.iptvpremium.data.cache
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
object CatalogImportPriority { val busy=MutableStateFlow(false) }

object CatalogMemoryPolicy {val pressured=MutableStateFlow(false)}
