package br.com.flaviotorres.iptvpremium.data.cache
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicInteger
fun main()=runBlocking {
 val plan=PosterReservePlan()
 check(plan.size(10)==15)
 check(plan.size(15)==25)
 check(plan.size(20)==25)
 check(plan.size(15)==15)
 plan.reset();check(plan.size(900)==15)
 println("PASS: original reserve starts at 15, grows to 25, and resets on reverse/jump/rapid pause")
 val started=mutableListOf<Int>();val completed=mutableListOf<Int>();val gates=mutableMapOf<Int,CompletableDeferred<Unit>>()
 val preparing=mutableListOf<List<Int>>();val active=AtomicInteger();val peak=AtomicInteger()
 val reserve=PosterReserve<Int>(this,fetch={i->
  started+=i;val n=active.incrementAndGet();peak.updateAndGet{maxOf(it,n)}
  try{gates.getOrPut(i){CompletableDeferred()}.await();completed+=i;true}finally{active.decrementAndGet()}
 },prepare={preparing.add(it)})
 reserve.update((0..14).toList(),emptyList());yield()
 check(started==listOf(0,1) && preparing.first()==(0..4).toList())
 gates.getValue(0).complete(Unit);gates.getValue(1).complete(Unit);yield();yield()
 check(started==listOf(0,1,2,3))
 gates.getValue(2).complete(Unit);yield();yield();check(started.last()==4)
 gates.getValue(3).complete(Unit);yield();yield();check(started.none{it>=5})
 gates.getValue(4).complete(Unit);yield();yield();check(started.takeLast(2)==listOf(5,6))
 check(completed.take(5).toSet()==(0..4).toSet())
 // A normal row move retains useful work and advances the same ordered groups.
 reserve.update((5..29).toList(),(0..4).toList());yield()
 check(started.count{it==5}==1 && started.count{it==6}==1 && peak.get()<=2)
 check(preparing.all { it.size<=5 })
 reserve.pause();yield();yield();check(active.get()==0)
 reserve.update((500..514).toList(),emptyList());yield();check(started.takeLast(2)==listOf(500,501))
 reserve.pause();yield();yield()
 println("PASS: two workers, strict five-item groups, nearest-five preparation, useful downloads retained and latest stopped position resumed")
 val fast=mutableListOf<Int>()
 val pending=PosterReserve<Int>(this,fetch={i->fast+=i;awaitCancellation()},prepare={})
 pending.update((0..14).toList(),emptyList());pending.pause()
 pending.update((100..114).toList(),emptyList());yield();yield()
 check(fast==listOf(100,101))
 pending.pause();yield();yield()
 println("PASS: canceled-before-start workers release slots; rapid pause/resume cannot stall the restored reserve")
 // The same scheduler handles typed series identities, preserving five-card sequencing.
 val series=mutableListOf<String>()
 val typed=PosterReserve<PosterCandidate>(this,fetch={p->series+=p.name;true},prepare={})
 typed.update((1..15).map{PosterCandidate(null,"Series $it",id=it.toString())},emptyList())
 withTimeout(2000){while(series.size<15)yield()}
 check(series==(1..15).map{"Series $it"});typed.pause()
 println("PASS: typed missing-cover series use the identical ordered reserve, including null provider URLs")
 Unit
}
