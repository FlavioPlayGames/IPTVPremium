﻿function Hash-Arquivo([string]$Caminho) {
    if(Test-Path -LiteralPath $Caminho -PathType Leaf){return (Get-FileHash -Algorithm SHA256 -LiteralPath $Caminho).Hash.ToLowerInvariant()}
    return $null
}
function Projeto-Valido([string]$Caminho) {
    $p=(Resolve-Path -LiteralPath $Caminho).Path.TrimEnd([char[]]'\/')
    if(!(Test-Path -LiteralPath (Join-Path $p 'app/src/main/AndroidManifest.xml') -PathType Leaf) -or
       !(Test-Path -LiteralPath (Join-Path $p 'gradlew.bat') -PathType Leaf)){throw 'Pasta nao corresponde ao projeto Android esperado.'}
    if((Get-Item -LiteralPath $p -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw 'Projeto aponta para link/juncao.'}
    return $p
}
function Caminho-Seguro([string]$Raiz,[string]$Relativo) {
    if($Relativo -notmatch '^[A-Za-z0-9._/-]+$' -or $Relativo.Split('/') -contains '..' -or $Relativo.StartsWith('/')){throw 'Caminho relativo invalido.'}
    $p=$Raiz
    foreach($parte in $Relativo.Split('/')) {
        $p=Join-Path $p $parte
        if(Test-Path -LiteralPath $p){if((Get-Item -LiteralPath $p -Force).Attributes -band [IO.FileAttributes]::ReparsePoint){throw "Link/juncao encontrado: $Relativo"}}
    }
    return $p
}
function Destino-Externo([string]$Raiz,[string]$Downloads,[string]$Prefixo) {
    $d=(Resolve-Path -LiteralPath $Downloads).Path.TrimEnd([char[]]'\/')
    if($d -eq $Raiz -or $d.StartsWith($Raiz+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'A recuperacao precisa ficar fora do projeto.'}
    $p=Join-Path $d ($Prefixo+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
    New-Item -ItemType Directory -Path $p | Out-Null
    return $p
}
