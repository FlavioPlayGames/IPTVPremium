package br.com.flaviotorres.iptvpremium.data.history

/** Known watched season is visual metadata, independent of target episode-ID mapping. Never use an unplayed queued successor. */
internal fun watchedSeriesSeasons(history:List<WatchHistoryEntry>):Map<String,Int> =
    latestHistorySeries(history.filter{!it.pendingNext && it.seasonNumber!=null && it.seasonNumber>=0})
        .associate{it.seriesId!! to it.seasonNumber!!}
