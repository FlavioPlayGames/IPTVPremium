﻿[CmdletBinding()]
param(
    [string]$Projeto="$env:USERPROFILE\AndroidStudioProjects\IPTVPremium",
    [Alias('Tv')][string]$Serial='',
    [string]$Adb="$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe"
)
$ErrorActionPreference='Stop'
# External PowerShell does not inherit Android Studio's Java configuration.
if([string]::IsNullOrWhiteSpace($env:JAVA_HOME) -or !(Test-Path -LiteralPath "$env:JAVA_HOME\bin\java.exe" -PathType Leaf)) {
    $jbr=Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
    if(!(Test-Path -LiteralPath "$jbr\bin\java.exe" -PathType Leaf)){throw 'Java nao encontrado. Defina JAVA_HOME para o JDK usado no Android Studio antes de aplicar.'}
    $env:JAVA_HOME=$jbr
}
& "$PSScriptRoot\Aplicar.ps1" -Projeto $Projeto
& "$PSScriptRoot\Instalar-TV.ps1" -Projeto $Projeto -Serial $Serial -Adb $Adb
