﻿param([Parameter(Mandatory=$true)][string]$Backup,[switch]$Instalar)
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Seguranca.ps1"
$estado=Get-Content -Raw -LiteralPath (Join-Path $Backup 'estado.json')|ConvertFrom-Json
function Instalar-Restaurado([string]$Projeto) {
    if([string]::IsNullOrWhiteSpace($env:JAVA_HOME) -or !(Test-Path -LiteralPath "$env:JAVA_HOME\bin\java.exe" -PathType Leaf)) {
        $env:JAVA_HOME=Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
        if(!(Test-Path -LiteralPath "$env:JAVA_HOME\bin\java.exe" -PathType Leaf)){throw 'Defina JAVA_HOME antes de instalar.'}
    }
    & "$PSScriptRoot\Instalar-TV.ps1" -Projeto $Projeto
}
if($estado.desfeito){Write-Host 'Backup ja restaurado.';if($Instalar){Instalar-Restaurado (Projeto-Valido $estado.projeto)};return}
$raiz=Projeto-Valido $estado.projeto
foreach($item in $estado.arquivos) {
    $p=Caminho-Seguro $raiz $item.path
    if((Test-Path -LiteralPath $p) -and !(Test-Path -LiteralPath $p -PathType Leaf)){throw 'Destino inesperado na restauracao.'}
    if((Hash-Arquivo $p) -ne $item.afterHash){throw "Arquivo mudou depois da limpeza: $($item.path)"}
    if((Hash-Arquivo (Join-Path "$Backup\arquivos" $item.path)) -ne $item.beforeHash){throw 'Backup nao confere.'}
}
foreach($item in $estado.arquivos){
    if($item.keepOnUndo){continue}
    $p=Join-Path $raiz $item.path
    if($null -eq $item.beforeHash){Remove-Item -LiteralPath $p -Force}
    else {Copy-Item -LiteralPath (Join-Path "$Backup\arquivos" $item.path) -Destination $p -Force}
}
$estado.desfeito=$true
$estado|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $Backup 'estado.json') -Encoding UTF8
Write-Host 'Fontes anteriores restaurados. Use -Instalar para compilar e instalar a restauracao na TV.'
if($Instalar){Instalar-Restaurado $raiz}
