package br.com.flaviotorres.iptvpremium.data.sync

import br.com.flaviotorres.iptvpremium.data.resolver.M3uXtreamResolver
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.net.URI
import java.net.URLDecoder
import java.security.MessageDigest
import java.util.Locale

internal interface M3uTransportStore {
    suspend fun read(key: String): String?
    suspend fun write(key: String, value: String)
}

/** Remembers the successful transport for this exact configuration. */
class M3uTransportPolicy internal constructor(
    private val store: M3uTransportStore,
    private val verifyAccount: suspend (PlaylistSource.XtreamCodes) -> Boolean
) {
    suspend fun select(source: PlaylistSource.M3u, commit: Boolean = true): PlaylistSource.XtreamCodes? {
        if (source.forceM3u) return null
        val selected = store.read(key(source))
        val reevaluate = hasReevaluation(source)
        val wasApi = !reevaluate && selected?.endsWith(":API") == true
        val candidate = candidate(source) ?: run {
            check(!wasApi) { "A nova configuração não permite manter a API. Cadastre outra entrada para mudar o formato." }
            return null
        }
        if (!reevaluate && selected == fingerprint(source) + ":API") return candidate
        if (!reevaluate && selected == fingerprint(source) + ":M3U") return null
        val api = verifyAccount(candidate)
        currentCoroutineContext().ensureActive()
        check(api || !wasApi) { "A API escolhida anteriormente não foi confirmada. A lista atual foi preservada." }
        if (commit) { if (api) rememberApi(source) else rememberNative(source) }
        return candidate.takeIf { api }
    }

    /** Called only after a complete native import for a new source. */
    internal suspend fun rememberNative(source: PlaylistSource.M3u) {
        currentCoroutineContext().ensureActive()
        store.write(key(source), fingerprint(source) + ":M3U")
        store.write(key(source) + ":reevaluate", "")
    }

    /** Explicit portal edits renegotiate once, even when the exact link is unchanged. */
    internal suspend fun requestReevaluation(source: PlaylistSource.M3u) {
        store.write(key(source) + ":reevaluate", fingerprint(source))
    }
    internal suspend fun hasReevaluation(source: PlaylistSource.M3u): Boolean =
        store.read(key(source) + ":reevaluate") == fingerprint(source)
    internal suspend fun rememberApi(source: PlaylistSource.M3u) {
        currentCoroutineContext().ensureActive()
        store.write(key(source), fingerprint(source) + ":API")
        store.write(key(source) + ":reevaluate", "")
    }

    internal suspend fun actualTransport(source: PlaylistSource.M3u): String {
        if (hasReevaluation(source)) return "checking"
        return when (store.read(key(source))) {
            fingerprint(source) + ":API" -> "xtream"
            fingerprint(source) + ":M3U" -> "m3u"
            else -> "automatic"
        }
    }

    suspend fun hasApiSelection(source: PlaylistSource.M3u): Boolean = store.read(key(source))?.endsWith(":API") == true

    /** Used by deferred channels only; never starts a probe from navigation. */
    suspend fun selected(source: PlaylistSource.M3u): PlaylistSource.XtreamCodes? {
        val candidate = candidate(source) ?: return null
        return candidate.takeIf { store.read(key(source)) == fingerprint(source) + ":API" }
    }

    private fun candidate(source: PlaylistSource.M3u): PlaylistSource.XtreamCodes? {
        if (source.forceM3u) return null
        val clean = source.playlistUrl.trim().replace("&amp;", "&", true).replace("\\&", "&")
        val uri = runCatching { URI(clean) }.getOrNull() ?: return null
        // A filtered/signed/custom get.php must retain its exact M3U semantics.
        val allowed = setOf("username", "password", "type", "output")
        val parameters = linkedMapOf<String, String>()
        for (pair in uri.rawQuery.orEmpty().split('&')) {
            val name = runCatching { URLDecoder.decode(pair.substringBefore('='), "UTF-8").lowercase(Locale.ROOT) }.getOrNull() ?: return null
            if (name !in allowed) return null
            val value = runCatching { URLDecoder.decode(pair.substringAfter('=', ""), "UTF-8") }.getOrNull() ?: return null
            if (parameters[name]?.let { it != value } == true) return null
            parameters[name] = value
        }
        if (parameters["type"]?.lowercase(Locale.ROOT)?.let { it !in setOf("m3u", "m3u_plus") } == true) return null
        if (parameters["output"]?.lowercase(Locale.ROOT)?.let { it !in setOf("ts", "mpegts") } == true) return null
        if (uri.rawFragment != null) return null
        return M3uXtreamResolver.resolve(source)
    }

    private fun key(source: PlaylistSource.M3u) = "source_" + digest(source.id)
    private fun fingerprint(source: PlaylistSource.M3u) = digest(source.id + "\u0000" + source.playlistUrl.trim() + if (source.forceM3u) "\u0000DIRECT" else "")
    private fun digest(value: String) = MessageDigest.getInstance("SHA-256").digest(value.toByteArray(Charsets.UTF_8))
        .joinToString("") { "%02x".format(it.toInt() and 255) }
}
