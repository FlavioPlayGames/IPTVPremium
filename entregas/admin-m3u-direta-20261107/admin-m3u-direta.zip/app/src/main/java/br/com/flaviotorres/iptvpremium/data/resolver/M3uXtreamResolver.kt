package br.com.flaviotorres.iptvpremium.data.resolver

import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import java.net.URI
import java.net.URLDecoder
import java.util.Locale

object M3uXtreamResolver {
    /** Derives an API source only from explicit get.php credentials, preserving the list ID. */
    fun resolve(source: PlaylistSource.M3u): PlaylistSource.XtreamCodes? = runCatching {
        if (source.forceM3u) return null
        // Clipboard links may contain HTML entities or Markdown-escaped separators.
        val cleaned = source.playlistUrl.trim()
            .replace("&amp;", "&", ignoreCase = true)
            .replace("\\&", "&")
        val uri = URI(cleaned)
        val scheme = uri.scheme?.lowercase(Locale.ROOT) ?: return null
        if (scheme !in setOf("http", "https") || uri.host.isNullOrBlank() || uri.rawUserInfo != null) return null
        val path = uri.rawPath.orEmpty().trimEnd('/')
        if (!path.endsWith("/get.php", ignoreCase = true)) return null
        val parameters = linkedMapOf<String, String>()
        for (part in uri.rawQuery.orEmpty().split('&')) {
            val split = part.indexOf('=')
            if (split < 0) continue
            val key = URLDecoder.decode(part.substring(0, split), "UTF-8").lowercase(Locale.ROOT)
            if (key != "username" && key != "password") continue
            val value = URLDecoder.decode(part.substring(split + 1), "UTF-8")
            // Conflicting repeated credentials must not silently select a different account.
            if (parameters.containsKey(key) && parameters[key] != value) return null
            parameters[key] = value
        }
        val username = parameters["username"]?.trim()?.takeIf { it.isNotBlank() } ?: return null
        val password = parameters["password"]?.takeIf { it.isNotBlank() } ?: return null
        val prefix = path.dropLast("/get.php".length).trimEnd('/')
        PlaylistSource.XtreamCodes(
            id = source.id, name = source.name, isEnabled = source.isEnabled,
            serverUrl = "$scheme://${uri.rawAuthority}$prefix", username = username, password = password
        )
    }.getOrNull()
}
