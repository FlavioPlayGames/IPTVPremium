[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Projeto,[Parameter(Mandatory=$true)][string]$Site)
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath $Projeto).Path
$web=(Resolve-Path -LiteralPath $Site).Path
if(!(Test-Path (Join-Path $root 'gradlew.bat'))){throw 'Projeto Android nao encontrado.'}
if(!(Test-Path (Join-Path $web 'wrangler.jsonc'))){throw 'Projeto do site nao encontrado.'}
Write-Host 'Use a chave tecnica criada em API Consumers do OpenSubtitles.com para o IPTV Premium.'
Write-Host 'Nao use senha da conta nem chave de outro aplicativo.'
$secure=Read-Host 'Chave de API do aplicativo (entrada oculta)' -AsSecureString
$pointer=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($secure)
try{$apiKey=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($pointer)}finally{[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($pointer)}
try{
 if($apiKey -notmatch '^[^\s\x00-\x1f\x7f]{8,512}$'){throw 'Formato de chave invalido.'}
 $agent=Read-Host 'User-Agent registrado (Enter para IPTVPremium v1.13)'
 if(!$agent){$agent='IPTVPremium v1.13'}
 if($agent.Length -lt 3 -or $agent.Length -gt 200 -or $agent -match '[\x00-\x1f\x7f]'){throw 'User-Agent invalido.'}
 $ignore=Join-Path $root '.gitignore'
 $rules="`n/app/src/*/res/values/opensubtitles-private.xml`n/.opensubtitles-config-backups/`n"
 [IO.File]::AppendAllText($ignore,$rules,[Text.UTF8Encoding]::new($false))
 $file=Join-Path $root 'app/src/desempenho/res/values/opensubtitles-private.xml'
 if(Test-Path -LiteralPath $file){$backup=Join-Path $root ('.opensubtitles-config-backups/'+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Path $backup -Force|Out-Null;Copy-Item -LiteralPath $file -Destination (Join-Path $backup 'opensubtitles-private.xml')}
 New-Item -ItemType Directory -Force -Path (Split-Path $file)|Out-Null
 $escapedKey=[Security.SecurityElement]::Escape($apiKey);$escapedAgent=[Security.SecurityElement]::Escape($agent)
 $xml="<?xml version=`"1.0`" encoding=`"utf-8`"?>`n<resources>`n<string name=`"opensubtitles_api_key`" translatable=`"false`">$escapedKey</string>`n<string name=`"opensubtitles_user_agent`" translatable=`"false`">$escapedAgent</string>`n</resources>`n"
 [IO.File]::WriteAllText($file,$xml,[Text.UTF8Encoding]::new($false))
 Push-Location $web
 try{
  $apiKey | & npx.cmd wrangler secret put OPENSUBTITLES_API_KEY
  if($LASTEXITCODE -ne 0){throw 'A chave foi salva localmente, mas o envio do segredo a Cloudflare falhou. Corrija o acesso e execute novamente.'}
  $agent | & npx.cmd wrangler secret put OPENSUBTITLES_USER_AGENT
  if($LASTEXITCODE -ne 0){throw 'O User-Agent nao foi configurado no servidor. Execute novamente apos corrigir o acesso.'}
 }finally{Pop-Location}
 Write-Host 'Registro configurado no projeto e no servidor. Compile e instale o APK novamente; abra a etapa 2 de legendas na TV.' -ForegroundColor Green
}finally{$apiKey=$null;$agent=$null;$xml=$null;$escapedKey=$null;$secure.Dispose()}
