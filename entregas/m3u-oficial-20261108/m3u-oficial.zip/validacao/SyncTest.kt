package br.com.flaviotorres.iptvpremium.data.sync
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import br.com.flaviotorres.iptvpremium.data.cache.entity.*
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import br.com.flaviotorres.iptvpremium.domain.model.*
import br.com.flaviotorres.iptvpremium.domain.repository.PlaylistRepository
import java.lang.reflect.Proxy
import java.io.IOException
import kotlinx.coroutines.*
private class Db {
 val gen=mutableMapOf<String,String>();var active:String?=null
 val movieRecords=mutableListOf<CachedMovieEntity>();var channels=0;var movies=0;var series=0;var episodes=0;var pending=false;var deferred=0L
 val episodeNumbers=mutableListOf<Int?>()
 val dao=Proxy.newProxyInstance(PlaylistCacheDao::class.java.classLoader,arrayOf(PlaylistCacheDao::class.java)){proxy,m,a0 ->
  val a=a0.orEmpty()
  when(m.name){
   "generationStatus" -> gen[a[1]as String]
   "getActiveGeneration" -> active?.let{PlaylistCacheGenerationEntity("p",it,"ACTIVE",0L)}
   "upsertGeneration" -> {val g=a[0] as PlaylistCacheGenerationEntity;gen[g.generationId]=g.status;Unit}
   "updateGenerationStatus" -> {gen[a[1] as String]=a[2] as String;Unit}
   "discardIncompleteImport" -> {check(a[1]!=active);gen.remove(a[1]);true}
   "insertCategories" -> {pending=pending||(a[0] as List<*>).any{(it as CachedCategoryEntity).categoryId=="__live_pending__"};Unit}
   "insertChannels" -> {channels+=(a[0] as List<*>).size;Unit}
   "insertMovies" -> {movies+=(a[0] as List<*>).size;movieRecords+=(a[0] as List<*>).map{it as CachedMovieEntity};Unit}
   "insertSeries" -> {series+=(a[0] as List<*>).size;Unit}
   "insertEpisodes" -> {episodes+=(a[0] as List<*>).size;Unit}
   "insertImportBatch" -> {channels+=(a[1] as List<*>).size;movies+=(a[2] as List<*>).size;movieRecords+=(a[2] as List<*>).map{it as CachedMovieEntity};series+=(a[3] as List<*>).size;episodes+=(a[4] as List<*>).size;episodeNumbers+=(a[4] as List<*>).map{(it as CachedEpisodeEntity).episodeNumber};Unit}
   else -> error("Unexpected DAO ${m.name}")
  }
 } as PlaylistCacheDao
}
private class Http:PlaylistHttpClient {
 var nativeCalls=0
 var lines=listOf("#EXTM3U", "#EXTINF:-1,Live", "http://example.invalid/live/1")
 override suspend fun get(url:String)=error("No network here")
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit){nativeCalls++;for(line in lines)onLine(line)}
}
private class Store:M3uTransportStore {
 val values=mutableMapOf<String,String>()
 override suspend fun read(key:String)=values[key]
 override suspend fun write(key:String,value:String){values[key]=value}
}
private class Api:PlaylistRepository,ProgressiveXtreamRepository {
 var calls=0;var fail=false;var providerFail=false;var hold:CompletableDeferred<Unit>?=null
 override suspend fun loadContent(source:PlaylistSource):PlaylistContent=error("Must use progressive import")
 override suspend fun importXtream(source:PlaylistSource.XtreamCodes,sink:XtreamCatalogSink) {
  calls++;check(sink.includeLive&&sink.includeOnDemand)
  hold?.let{it.complete(Unit);awaitCancellation()}
  if(providerFail)throw IOException("provider unavailable")
  if(fail)throw XtreamCatalogWriteException(IOException("disk failure"))
  sink.append("get_live_streams",PlaylistContent(channels=listOf(Channel("1","Live",null,null,"http://example.invalid/live/1",null))))
  sink.append("get_vod_streams",PlaylistContent(movies=listOf(Movie("11","Film",null,null,null,"http://example.invalid/movie/11",2024,7.0,null))))
  sink.append("get_series",PlaylistContent(series=listOf(Series("21","Show",null,null,null,2024,7.0,null))))
 }
}
private fun native(h:Http,d:Db,manager:PlaylistCacheGenerationManager):M3uCacheImporter {
 val root=java.nio.file.Files.createTempDirectory("sync-official").toFile();root.deleteOnExit()
 return M3uCacheImporter(h,d.dao,manager,br.com.flaviotorres.iptvpremium.data.m3uepisodes.DeferredM3uEpisodes(java.io.File(root,"sources")),java.io.File(root,"work"),{_,_,_->}){spool,p,g,c,ensure->
  java.io.DataInputStream(spool.inputStream()).use{input->check(input.readInt()==0x4D335331);while(true){
   ensure();val (kind,r)=br.com.flaviotorres.iptvpremium.data.m3u.M3uCatalogParser.read(input)?:break
   when(kind){1->d.channels++;2->{d.movies++;d.movieRecords+=CachedMovieEntity(p,g,r[2]as String,r[3]as String,r[4]as String?,r[5]as String?,r[6]as String?,r[7]as String,(r[8]as Long?)?.toInt(),null,null,null,(r[12]as Long?)?.toInt())};3->d.series++}
  }};d.deferred+=c.episodes
 }
}
private fun source()=PlaylistSource.M3u("p","Test",playlistUrl="http://example.invalid/get.php?username=u&password=p&type=m3u_plus&output=mpegts")
fun main()=runBlocking {
 var count=0
 suspend fun test(name:String,block:suspend()->Unit){block();println("PASS $name");count++}
 test("fresh candidate imports all three API catalogues, zero M3U reads, zero episodes, no live-pending marker"){
  val d=Db();val h=Http();val a=Api();val store=Store();var probes=0
  val policy=M3uTransportPolicy(store){probes++;true};val manager=PlaylistCacheGenerationManager(d.dao)
  val sync=M3uSourceSynchronizer(a,native(h,d,manager),d.dao,manager,policy)
  val g=sync.sync(source());check(d.gen[g]=="READY"&&h.nativeCalls==0&&d.channels==1&&d.movies==1&&d.series==1&&d.episodes==0&&!d.pending)
  d.active=g;d.gen[g]="ACTIVE"
  val g2=sync.sync(source());check(g2!=g&&d.gen[g]=="ACTIVE"&&d.gen[g2]=="READY"&&probes==1&&a.calls==2&&h.nativeCalls==0)
  println("  selected transport survives refresh; previous generation stays ACTIVE until caller activates READY")
 }
 test("API write failure keeps ACTIVE generation and decision; never triggers M3U fallback"){
  val d=Db();val h=Http();val a=Api();val store=Store();val policy=M3uTransportPolicy(store){true};policy.select(source())
  d.active="old";d.gen["old"]="ACTIVE";a.fail=true;val manager=PlaylistCacheGenerationManager(d.dao)
  val sync=M3uSourceSynchronizer(a,native(h,d,manager),d.dao,manager,policy)
  check(runCatching{sync.sync(source())}.isFailure);check(h.nativeCalls==0&&a.calls==1&&d.gen==mapOf("old" to "ACTIVE")&&policy.selected(source())!=null)
 }
 test("legacy M3U catalogue keeps original IDs/path without probing or conversion"){
  val d=Db();d.active="old";d.gen["old"]="ACTIVE";val h=Http();val a=Api();val manager=PlaylistCacheGenerationManager(d.dao)
  val sync=M3uSourceSynchronizer(a,native(h,d,manager),d.dao,manager,M3uTransportPolicy(Store()){error("Must not probe existing M3U")})
  val g=sync.sync(source());check(a.calls==0&&h.nativeCalls==1&&d.gen["old"]=="ACTIVE"&&d.gen[g]=="READY")
 }
 test("cancelled API import discards incomplete generation and never starts M3U"){
  val d=Db();val h=Http();val a=Api();val manager=PlaylistCacheGenerationManager(d.dao);val entered=CompletableDeferred<Unit>();a.hold=entered
  val sync=M3uSourceSynchronizer(a,native(h,d,manager),d.dao,manager,M3uTransportPolicy(Store()){true})
  val job=launch{sync.sync(source())};entered.await();job.cancelAndJoin();withTimeout(5000){while(d.gen.values.contains("IMPORTING"))delay(10)};check(d.gen.isEmpty()&&h.nativeCalls==0)
 }
 test("native M3U recognises E1000/E1001 and preserves episode numbers instead of creating movies"){
  val d=Db();val h=Http();h.lines=listOf("#EXTM3U")+(1000..1001).flatMap{listOf("""#EXTINF:-1 xui-id="$it" group-title="Anime",Show S01E$it""","http://example.invalid/opaque$it")}
  val manager=PlaylistCacheGenerationManager(d.dao);val g=native(h,d,manager).import("p","http://example.invalid/file.m3u")
  check(d.gen[g]=="READY"&&d.movies==0&&d.episodes==0&&d.deferred==2L)
 }
 test("fresh API provider failure falls back to original M3U and remembers native choice"){
  val d=Db();val h=Http();val a=Api();a.providerFail=true;val store=Store();val policy=M3uTransportPolicy(store){true};val manager=PlaylistCacheGenerationManager(d.dao)
  val sync=M3uSourceSynchronizer(a,native(h,d,manager),d.dao,manager,policy)
  val g=sync.sync(source());check(d.gen[g]=="READY"&&h.nativeCalls==1&&a.calls==2&&policy.selected(source())==null)
  d.active=g;sync.sync(source());check(a.calls==2&&h.nativeCalls==2)
 }
 test("fresh API probe error still attempts M3U"){
  val d=Db();val h=Http();val a=Api();val policy=M3uTransportPolicy(Store()){throw IOException("provider blocked")};val m=PlaylistCacheGenerationManager(d.dao)
  val g=M3uSourceSynchronizer(a,native(h,d,m),d.dao,m,policy).sync(source());check(d.gen[g]=="READY"&&h.nativeCalls==1&&a.calls==0&&policy.selected(source())==null)
 }
 test("fresh API local storage failure does not attempt M3U"){
  val d=Db();val h=Http();val a=Api();a.fail=true;val m=PlaylistCacheGenerationManager(d.dao)
  check(runCatching{M3uSourceSynchronizer(a,native(h,d,m),d.dao,m,M3uTransportPolicy(Store()){true}).sync(source())}.isFailure);check(h.nativeCalls==0)
 }
 test("failed API refresh preserves existing active catalogue without changing IDs"){
  val d=Db();d.active="old";d.gen["old"]="ACTIVE";val h=Http();val a=Api();a.providerFail=true;val policy=M3uTransportPolicy(Store()){true};policy.select(source());val m=PlaylistCacheGenerationManager(d.dao)
  check(runCatching{M3uSourceSynchronizer(a,native(h,d,m),d.dao,m,policy).sync(source())}.isFailure);check(h.nativeCalls==0&&d.gen==mapOf("old" to "ACTIVE")&&policy.selected(source())!=null)
 }
 test("explicit edit of existing native list rechecks API and upgrades successfully"){
  val d=Db();d.active="old";d.gen["old"]="ACTIVE";val h=Http();val a=Api();var probes=0;val policy=M3uTransportPolicy(Store()){probes++;true};policy.rememberNative(source());policy.requestReevaluation(source());val m=PlaylistCacheGenerationManager(d.dao)
  val g=M3uSourceSynchronizer(a,native(h,d,m),d.dao,m,policy).sync(source())
  check(probes==1&&a.calls==1&&h.nativeCalls==0&&d.gen["old"]=="ACTIVE"&&d.gen[g]=="READY"&&policy.actualTransport(source())=="xtream"&&!policy.hasReevaluation(source()))
 }
 test("explicit native edit with failed API keeps old generation and imports original M3U"){
  val d=Db();d.active="old";d.gen["old"]="ACTIVE";val h=Http();val a=Api();a.providerFail=true;val policy=M3uTransportPolicy(Store()){true};policy.rememberNative(source());policy.requestReevaluation(source());val m=PlaylistCacheGenerationManager(d.dao)
  val g=M3uSourceSynchronizer(a,native(h,d,m),d.dao,m,policy).sync(source());check(a.calls==2&&h.nativeCalls==1&&d.gen["old"]=="ACTIVE"&&d.gen[g]=="READY"&&policy.actualTransport(source())=="m3u")
 }
 test("nonalphabetical M3U movie order is recorded exactly as provider supplies it"){
  val d=Db();val h=Http();h.lines=listOf("#EXTM3U", "#EXTINF:-1 group-title=\"Filmes\",Zeta (2024)","http://example.invalid/movie/u/p/101.mp4", "#EXTINF:-1 group-title=\"Filmes\",Alfa (2023)","http://example.invalid/movie/u/p/102.mp4")
  val m=PlaylistCacheGenerationManager(d.dao);native(h,d,m).import("p","http://example.invalid/list.m3u");check(d.movieRecords.map{it.name}==listOf("Zeta (2024)","Alfa (2023)"));check(d.movieRecords.map{it.providerOrder}==listOf(0,1))
 }
 test("cancelled explicit upgrade leaves old native catalogue and does not commit API"){
  val d=Db();d.active="old";d.gen["old"]="ACTIVE";val h=Http();val a=Api();val entered=CompletableDeferred<Unit>();a.hold=entered;val policy=M3uTransportPolicy(Store()){true};policy.rememberNative(source());policy.requestReevaluation(source());val m=PlaylistCacheGenerationManager(d.dao)
  val job=launch{M3uSourceSynchronizer(a,native(h,d,m),d.dao,m,policy).sync(source())};entered.await();job.cancelAndJoin();withTimeout(5000){while(d.gen.values.contains("IMPORTING"))delay(10)};check(h.nativeCalls==0&&d.gen==mapOf("old" to "ACTIVE")&&policy.selected(source())==null&&policy.hasReevaluation(source())) { "native=${h.nativeCalls} generations=${d.gen} selected=${policy.selected(source())!=null} pending=${policy.hasReevaluation(source())}" }
 }
 test("administrator direct M3U never probes or imports API even for an Xtream-compatible URL"){
  val d=Db();val h=Http();val a=Api();val store=Store();val policy=M3uTransportPolicy(store){error("Must not probe forced M3U")};val direct=source().copy(forceM3u=true);policy.requestReevaluation(direct);val m=PlaylistCacheGenerationManager(d.dao)
  val g=M3uSourceSynchronizer(a,native(h,d,m),d.dao,m,policy).sync(direct);check(a.calls==0&&h.nativeCalls==1&&d.gen[g]=="READY"&&policy.selected(direct)==null&&policy.actualTransport(direct)=="m3u")
  check(br.com.flaviotorres.iptvpremium.data.resolver.M3uXtreamResolver.resolve(direct)==null)
 }
 test("direct M3U overrides a previous API choice on the same list without deleting active generation"){
  val d=Db();d.active="old";d.gen["old"]="ACTIVE";val h=Http();val a=Api();val policy=M3uTransportPolicy(Store()){true};policy.select(source());val direct=source().copy(forceM3u=true);policy.requestReevaluation(direct);val m=PlaylistCacheGenerationManager(d.dao)
  val g=M3uSourceSynchronizer(a,native(h,d,m),d.dao,m,policy).sync(direct);check(a.calls==0&&h.nativeCalls==1&&d.gen["old"]=="ACTIVE"&&d.gen[g]=="READY"&&policy.selected(direct)==null)
 }
 println("$count synchronizer scenarios passed (real manager/writer/policy; simulated DAO and HTTP)")
}
