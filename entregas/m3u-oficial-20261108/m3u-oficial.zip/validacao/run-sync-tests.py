from pathlib import Path
import subprocess,sys
w=Path('/workspace/m3u-oficial');tc=Path('/workspace/storage-toolchain');classes='/workspace/backup-reviewed-build/app/build/intermediates/built_in_kotlinc/desempenho/compileDesempenhoKotlin/classes'
cp=(tc/'tests/xtream.classpath').read_text().strip().replace('/workspace/storage-work/app/build/intermediates/built_in_kotlinc/debug/compileDebugKotlin/classes',classes)
cp='/workspace/xtream-direct-fix/tests/android-classes:'+cp
java=str(tc/'jdk-25.0.4.1/bin/java')
for name in sys.argv[1:]:
 jar=w/(name+'.jar')
 subprocess.run([java,'-Xmx512m','-cp',str(tc/'gradle-9.6.0/lib/*'),'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-Xfriend-paths='+classes,'-classpath',cp,'-d',str(jar),str(w/(name+'.kt'))],check=True)
 subprocess.run([java,'-Xmx384m','-cp',str(jar)+':'+cp,'br.com.flaviotorres.iptvpremium.data.sync.'+name+'Kt'],check=True,timeout=120)
