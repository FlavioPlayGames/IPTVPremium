package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.*
import java.io.*
import java.nio.file.Files
import kotlinx.coroutines.*
fun main()=runBlocking {
 val root=Files.createTempDirectory("official-deferred").toFile()
 RealSqlDb(File(root,"catalog.db").toPath()).use{d->
  d.c.createStatement().execute("INSERT INTO playlist_cache_generations VALUES('p','g','ACTIVE',0,0,1)")
  val store=DeferredM3uEpisodes(File(root,"sources"));val source=store.begin("p","g")
  repeat(601){source.append("s",1,it+1,"Épisode $it",null,"http://example.invalid/series/$it")};source.append("other",2,1,"Other",null,"http://example.invalid/series/other");source.finish()
  d.failEpisodeAt=2;d.episodeError=CancellationException("injected")
  check(runCatching{store.ensure(d.dao,"p","g","s")}.isFailure&&d.count("cached_episodes")==0)
  println("PASS cancellation during second episode batch rolls back the whole requested series")
  d.failEpisodeAt=null
  coroutineScope{listOf(async{store.ensure(d.dao,"p","g","s")},async{store.ensure(d.dao,"p","g","s")}).awaitAll().forEach{check(it)}}
  check(d.count("cached_episodes")==601&&d.episodeCalls==5)
  println("PASS simultaneous selected-series requests publish one complete cache and leave other series deferred")
  System.setProperty("atomicfile.fail","true")
  try{check(store.ensure(d.dao,"p","g","other"))}finally{System.clearProperty("atomicfile.fail")}
  check(d.count("cached_episodes")==602);println("PASS marker failure cannot hide successfully committed episodes")
  val new=store.begin("p","new");new.append("new",1,1,"New",null,"http://example.invalid/new");new.finish()
  d.c.createStatement().execute("INSERT INTO playlist_cache_generations VALUES('p','new','READY',1,1,NULL)")
  check(!store.ensure(d.dao,"p","new","new")&&d.count("cached_episodes","new")==0)
  println("PASS only the active generation can receive deferred episodes")
 }
 root.deleteRecursively();Unit
}
