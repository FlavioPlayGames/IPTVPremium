from pathlib import Path
import sqlite3,re
s=Path('/workspace/backup-reviewed-build/app/src/main/java/br/com/flaviotorres/iptvpremium/data/cache/dao/PlaylistCacheDao.kt').read_text()
queries={m[2]:m[1] for m in re.finditer(r'@Query\(\s*"""(.*?)"""\s*\)\s*(?:suspend\s+)?fun\s+(\w+)',s,re.S)}
c=sqlite3.connect(':memory:')
c.executescript('''CREATE TABLE cached_categories(playlistId,generationId,categoryId,name,type,source,providerOrder);
CREATE TABLE cached_channels(playlistId,generationId,channelId,name,categoryId,channelNumber);
CREATE TABLE cached_series(playlistId,generationId,seriesId,name,categoryId,providerOrder);''')
c.executemany('INSERT INTO cached_categories VALUES(?,?,?,?,?,?,?)',[('p','g','z','Zulu','SERIES','M3U',0),('p','g','a','Alfa','SERIES','M3U',1),('x','g','z','Zulu','SERIES','XTREAM',None),('x','g','a','Alfa','SERIES','XTREAM',None)])
c.executemany('INSERT INTO cached_series VALUES(?,?,?,?,?,?)',[('p','g','z','Zulu','z',0),('p','g','a','Alfa','a',1)])
c.executemany('INSERT INTO cached_channels VALUES(?,?,?,?,?,?)',[('p','g','z','Zulu','z',1),('p','g','a','Alfa','a',2)])
p=dict(playlistId='p',generationId='g',type='SERIES',parentalExcludedIds='none',parentalRestrict=0,parentalAllowedIds='z',sortMode='DEFAULT',subtitledOnly=0,categoryId=None,searchQuery='',favoritesOnly=0,favoriteSeriesIds='none',pattern='',sort=0,restrictIds=0,ids='none',excluded='none',restrictParental=0,allowed='z')
def names(method,params):
 cur=c.execute(queries[method],params);idx=[x[0]for x in cur.description].index('name');return [r[idx]for r in cur]
assert names('getCategoriesByType',p)==['Zulu','Alfa']
assert names('getCategoriesByType',dict(p,playlistId='x'))==['Alfa','Zulu']
print('PASS actual category DAO query follows M3U positions while preserving unranked Xtream order')
for method in ['getSeriesPagingSource','getSeriesPagingSourceFiltered']:
 assert names(method,p)==['Zulu','Alfa']
 if method.endswith('Filtered'):
  assert names(method,dict(p,sortMode='A_Z'))==['Alfa','Zulu']
  assert names(method,dict(p,sortMode='Z_A'))==['Zulu','Alfa']
  assert names(method,dict(p,parentalRestrict=1))==['Zulu']
print('PASS actual series DAO queries preserve provider DEFAULT and explicit A-Z/Z-A with parental filtering')
assert names('filteredChannels',p)==['Zulu','Alfa']
assert names('filteredChannels',dict(p,sort=1))==['Alfa','Zulu']
assert names('filteredChannels',dict(p,sort=2))==['Zulu','Alfa']
assert names('filteredChannels',dict(p,categoryId='a'))==['Alfa']
print('PASS actual channels DAO query preserves source DEFAULT, selected sort and category filter')
