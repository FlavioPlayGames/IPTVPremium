from pathlib import Path
import json,subprocess,os,uuid,hashlib,re
w=Path('/workspace/m3u-oficial');o=Path('/workspace/outputs/m3u-oficial');m=json.loads((o/'manifest.json').read_text());root=w/'installer-tests'/uuid.uuid4().hex
pw='/workspace/storage-toolchain/powershell/pwsh';env=dict(os.environ,XDG_CACHE_HOME='/workspace/storage-toolchain/xdg-cache',XDG_DATA_HOME='/workspace/storage-toolchain/xdg-data',XDG_CONFIG_HOME='/workspace/storage-toolchain/xdg-config')
def run(script,r):return subprocess.run([pw,'-NoProfile','-File',str(o/script),'-Projeto',str(r)],capture_output=True,text=True,env=env)
def sha(p):return hashlib.sha256(p.read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()).hexdigest()
def keep(e):return re.search(r'data/cache/(PlaylistCacheDatabase|entity/CachedCategoryEntity)\.kt$|data/m3usnapshot/|app/src/desempenho/AndroidManifest\.xml$',e['path'])is not None
logs=[]
first=next(e for e in m if not e['remove'] and e['before'] and not keep(e))
for case in ['normal','unknown','corrupt','undo-conflict']:
 r=root/case;r.mkdir(parents=True);(r/'gradlew.bat').write_text('fixture');before={}
 for e in m:
  if not e['before']:continue
  suffix=e['path'].split('br/com/flaviotorres/iptvpremium/')[-1]
  src=w/'before'/suffix if e['path'].endswith('.kt') else w/'before-desempenho-manifest.xml'
  p=r/e['path'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(src.read_bytes());before[e['path']]=p.read_bytes()
 if case=='unknown':
  p=r/first['path'];p.write_bytes(p.read_bytes()+b'// custom');before[first['path']]=p.read_bytes()
 asset=o/first['path'];original=asset.read_bytes()
 if case=='corrupt':asset.write_bytes(original+b'bad')
 try:result=run('Aplicar.ps1',r)
 finally:asset.write_bytes(original)
 assert(result.returncode==0)==(case in ['normal','undo-conflict']),(case,result.stdout,result.stderr)
 if case in ['normal','undo-conflict']:
  assert all(not(r/e['path']).exists()if e['remove']else sha(r/e['path'])==e['sha']for e in m)
  saved=list((r/'.m3u-oficial-backups').iterdir());assert len(saved)==1
  for path,data in before.items():assert(saved[0]/path).read_bytes()==data
  assert run('Aplicar.ps1',r).returncode==0;assert len(list((r/'.m3u-oficial-backups').iterdir()))==1
  if case=='undo-conflict':
   p=r/first['path'];p.write_bytes(p.read_bytes()+b'// later');current={e['path']:(r/e['path']).read_bytes()if(r/e['path']).exists()else None for e in m}
   assert run('Desfazer.ps1',r).returncode!=0;assert all(((r/path).read_bytes()if(r/path).exists()else None)==data for path,data in current.items())
  else:
   undo=run('Desfazer.ps1',r);assert undo.returncode==0,(undo.stdout,undo.stderr)
   for e in m:
    p=r/e['path']
    if keep(e):assert not p.exists()if e['remove']else sha(p)==e['sha']
    elif e['path']in before:assert p.read_bytes()==before[e['path']]
    else:assert not p.exists()
 else:
  assert all((r/path).read_bytes()==data for path,data in before.items());assert not(r/'.m3u-oficial-backups').exists()
 logs.append('PASS installer '+case+' (including obsolete-file removal and schema-compatible undo)')
(w/'installer-results.txt').write_text('\n'.join(logs)+'\n');print('\n'.join(logs))
