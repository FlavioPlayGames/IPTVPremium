package br.com.flaviotorres.iptvpremium.data.cache.entity

import androidx.room.Entity
import androidx.room.Index

@Entity(
    tableName = "cached_categories",
    primaryKeys = [
        "playlistId",
        "generationId",
        "categoryId",
        "type"
    ],
    indices = [
        Index(
            value = [
                "playlistId",
                "generationId",
                "type"
            ]
        ),
        Index(
            value = [
                "playlistId",
                "generationId",
                "categoryId"
            ]
        )
    ]
)
data class CachedCategoryEntity(
    val playlistId: String,
    val generationId: String,
    val categoryId: String,
    val name: String,
    val type: String,
    val source: String,
    val providerOrder: Int? = null
)
