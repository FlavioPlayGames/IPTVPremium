package br.com.flaviotorres.iptvpremium.data.m3u

internal object M3uCatalogFormat {
    val columns = intArrayOf(7,9,13,18)
    val inserts = listOf(
        "INSERT OR REPLACE INTO cached_categories (playlistId,generationId,categoryId,name,type,source,providerOrder) VALUES (?,?,?,?,?,?,?)",
        "INSERT OR REPLACE INTO cached_channels (playlistId,generationId,channelId,name,categoryId,logoUrl,streamUrl,epgChannelId,channelNumber) VALUES (?,?,?,?,?,?,?,?,?)",
        "INSERT OR REPLACE INTO cached_movies (playlistId,generationId,movieId,name,categoryId,posterUrl,backdropUrl,streamUrl,year,rating,durationSeconds,addedAtEpochSeconds,providerOrder) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)",
        "INSERT OR REPLACE INTO cached_series (playlistId,generationId,seriesId,name,categoryId,posterUrl,backdropUrl,year,rating,plot,titleLogoUrl,imdbId,tmdbId,ratingSource,durationSeconds,genres,trailerUrl,providerOrder) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
    )
}
