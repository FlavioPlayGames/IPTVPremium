package br.com.flaviotorres.iptvpremium.data.cache
import androidx.sqlite.db.*
import android.database.sqlite.SQLiteTransactionListener
import java.lang.reflect.Proxy
import kotlinx.coroutines.*

private class Fake {
 var depth=0;var closed=0;var failure:RuntimeException?=null;var failBegin=false;var failEnd=false
 val calls=mutableListOf<String>();var listener:Any?=null;var statementSql="";var sql="";var values:Any?=null
 val statement=Proxy.newProxyInstance(SupportSQLiteStatement::class.java.classLoader,arrayOf(SupportSQLiteStatement::class.java)){_,m,a->calls+="statement."+m.name;when(m.name){"executeInsert"->42L;"executeUpdateDelete"->1;"simpleQueryForLong"->1L;"simpleQueryForString"->"ok";else->null}}as SupportSQLiteStatement
 val db=Proxy.newProxyInstance(SupportSQLiteDatabase::class.java.classLoader,arrayOf(SupportSQLiteDatabase::class.java)){_,m,a->
  calls+=m.name
  when {
   m.name=="inTransaction"->depth>0
   m.name.startsWith("beginTransaction")->{if(failBegin)throw checkNotNull(failure);depth++;listener=a?.firstOrNull();null}
   m.name=="endTransaction"->{depth--;if(failEnd)throw checkNotNull(failure);null}
   m.name=="compileStatement"->{statementSql=a!![0]as String;statement}
   m.name=="execSQL"->{sql=a!![0]as String;values=a.getOrNull(1);null}
   m.name=="enableWriteAheadLogging"->true
   m.name=="isWriteAheadLoggingEnabled"->true
   m.name=="isOpen"->true
   m.name=="getPath"->"fixture"
   else->null
  }
 } as SupportSQLiteDatabase
 var currentDb=db
 val helper=Proxy.newProxyInstance(SupportSQLiteOpenHelper::class.java.classLoader,arrayOf(SupportSQLiteOpenHelper::class.java)){_,m,_->
  calls+="helper."+m.name
  when(m.name){"getWritableDatabase","getReadableDatabase"->currentDb;"getDatabaseName"->"fixture";"close"->{closed++;null};else->null}
 }as SupportSQLiteOpenHelper
}
fun main()=runBlocking {
 var n=0;fun ok(value:Boolean,label:String){check(value){label};println("PASS $label");n++}
 val fake=Fake();val helper=M3uMeasuredOpenHelper(fake.helper);val db=helper.writableDatabase
 ok(db===helper.readableDatabase && db===helper.writableDatabase,"same native database reuses a single wrapper for reader/writer access")
 val t=M3uTransactionMetrics()
 withContext(Dispatchers.IO+t){
  db.beginTransactionNonExclusive();db.beginTransaction();db.setTransactionSuccessful();db.endTransaction();db.setTransactionSuccessful();db.endTransaction()
 }
 ok(t.begins==1&&t.ends==1&&t.nestedBegins==1&&t.nestedEnds==1&&fake.depth==0,"actual SQLite interface boundaries distinguish outer and nested transactions")
 ok(t.beginNs>0&&t.endNs>0&&t.nestedBeginNs>0&&t.nestedEndNs>0,"all four native-boundary clocks are observed")
 val listener=Proxy.newProxyInstance(SQLiteTransactionListener::class.java.classLoader,arrayOf(SQLiteTransactionListener::class.java)){_,_,_->null}as SQLiteTransactionListener
 val listenerTrace=M3uTransactionMetrics()
 withContext(listenerTrace){
  db.beginTransactionWithListener(listener);check(fake.listener===listener);db.endTransaction()
  db.beginTransactionWithListenerNonExclusive(listener);check(fake.listener===listener);db.endTransaction()
  db.beginTransactionReadOnly();db.endTransaction()
  db.beginTransactionWithListenerReadOnly(listener);check(fake.listener===listener);db.endTransaction()
 }
 ok(listenerTrace.begins==4&&listenerTrace.ends==4,"all listener/read-only variants delegate unchanged and remain measured")
 db.compileStatement("fixture SQL").use{it.bindString(1,"value");check(it.executeInsert()==42L)}
 val args=arrayOf<Any?>(null,123L,"bound value");db.execSQL("fixture SQL",args)
 helper.setWriteAheadLoggingEnabled(true)
 ok(fake.statementSql=="fixture SQL"&&fake.sql=="fixture SQL"&&fake.values===args&&"helper.setWriteAheadLoggingEnabled" in  fake.calls,"statements, bound arguments and WAL configuration are forwarded without rewriting")
 val failure=IllegalStateException("simulated begin");fake.failure=failure;fake.failBegin=true
 val bad=M3uTransactionMetrics()
 try{withContext(bad){db.beginTransactionNonExclusive()};error("expected failure")}catch(e:RuntimeException){check(e===failure)}
 fake.failBegin=false
 withContext(bad){db.beginTransaction();db.endTransaction()}
 ok(fake.depth==0&&bad.begins==2&&bad.ends==1,"failed begin preserves exception and leaves no stale nested marker")
 val endFailure=IllegalStateException("simulated end");fake.failure=endFailure;fake.failEnd=true
 val ending=M3uTransactionMetrics()
 try{withContext(ending){db.beginTransaction();db.endTransaction()};error("expected failure")}catch(e:RuntimeException){check(e===endFailure)}
 fake.failEnd=false;withContext(ending){db.beginTransaction();db.endTransaction()}
 ok(ending.begins==2&&ending.ends==2&&ending.nestedEnds==0,"end failure preserves exception and clears diagnostic state")
 // A transaction opened before entering a trace must not be labelled as an outer begin in that trace.
 db.beginTransaction()
 val nested=M3uTransactionMetrics();withContext(nested){db.beginTransaction();db.endTransaction()};db.endTransaction()
 ok(nested.begins==0&&nested.ends==0&&nested.nestedBegins==1&&nested.nestedEnds==1,"existing transactions are not mistaken for a new traced outer transaction")
 helper.close();val reopened=helper.writableDatabase
 ok(fake.closed==1&&reopened!==db,"closing clears helper identity cache for a subsequent reopen")
 val context=M3uTransactionMetrics();withContext(context){context.enterBody();context.exitBody()}
 ok(context.contextObserved&&M3uTransactionMetrics.current()==null,"body validates coroutine trace and restores original thread context")
 println("$n boundary/delegation checks; fake native interface, not measurements on TV")
}
