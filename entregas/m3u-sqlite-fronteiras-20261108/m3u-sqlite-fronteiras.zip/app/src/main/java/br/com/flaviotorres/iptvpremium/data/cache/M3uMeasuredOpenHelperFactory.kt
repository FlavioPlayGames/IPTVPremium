package br.com.flaviotorres.iptvpremium.data.cache

import android.database.sqlite.SQLiteTransactionListener
import androidx.sqlite.db.SupportSQLiteDatabase
import androidx.sqlite.db.SupportSQLiteOpenHelper
import androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory

/** Observe the existing Android SQLite helper. Driver, configuration, SQL and durability stay delegated. */
internal class M3uMeasuredOpenHelperFactory(
    private val delegate: SupportSQLiteOpenHelper.Factory = FrameworkSQLiteOpenHelperFactory()
) : SupportSQLiteOpenHelper.Factory {
    override fun create(configuration: SupportSQLiteOpenHelper.Configuration): SupportSQLiteOpenHelper =
        M3uMeasuredOpenHelper(delegate.create(configuration))
}

internal class M3uMeasuredOpenHelper(private val delegate: SupportSQLiteOpenHelper) : SupportSQLiteOpenHelper by delegate {
    private var original: SupportSQLiteDatabase? = null
    private var measured: M3uMeasuredDatabase? = null
    @Synchronized private fun wrap(db: SupportSQLiteDatabase): SupportSQLiteDatabase {
        if (original !== db) { original = db; measured = M3uMeasuredDatabase(db) }
        return checkNotNull(measured)
    }
    override val writableDatabase: SupportSQLiteDatabase get() = wrap(delegate.writableDatabase)
    override val readableDatabase: SupportSQLiteDatabase get() = wrap(delegate.readableDatabase)
    @Synchronized override fun close() {
        try { delegate.close() } finally { original = null; measured = null }
    }
}

internal class M3uMeasuredDatabase(private val delegate: SupportSQLiteDatabase) : SupportSQLiteDatabase by delegate {
    // Android transactions belong to threads. Keep outer/nested markers even outside a trace.
    private val stack = ThreadLocal<ArrayDeque<Boolean>>()
    private inline fun begin(operation: () -> Unit) {
        val outer = !delegate.inTransaction()
        val trace = M3uTransactionMetrics.current()
        val started = if (trace != null) System.nanoTime() else 0L
        try {
            operation()
            val transactions = stack.get() ?: ArrayDeque<Boolean>().also { stack.set(it) }
            transactions.addLast(outer)
        } finally {
            if (trace != null) {
                val elapsed = System.nanoTime() - started
                if (outer) trace.recordBegin(elapsed) else trace.recordNestedBegin(elapsed)
            }
        }
    }
    override fun beginTransaction() = begin { delegate.beginTransaction() }
    override fun beginTransactionNonExclusive() = begin { delegate.beginTransactionNonExclusive() }
    override fun beginTransactionReadOnly() = begin { delegate.beginTransactionReadOnly() }
    override fun beginTransactionWithListener(transactionListener: SQLiteTransactionListener) = begin { delegate.beginTransactionWithListener(transactionListener) }
    override fun beginTransactionWithListenerNonExclusive(transactionListener: SQLiteTransactionListener) = begin { delegate.beginTransactionWithListenerNonExclusive(transactionListener) }
    override fun beginTransactionWithListenerReadOnly(transactionListener: SQLiteTransactionListener) = begin { delegate.beginTransactionWithListenerReadOnly(transactionListener) }
    override fun endTransaction() {
        val transactions = stack.get()
        val outer = transactions?.lastOrNull()
        val trace = M3uTransactionMetrics.current()
        val started = if (trace != null) System.nanoTime() else 0L
        try { delegate.endTransaction() }
        finally {
            if (transactions?.isNotEmpty() == true) transactions.removeLast()
            if (transactions.isNullOrEmpty()) stack.remove()
            if (trace != null && outer != null) {
                val elapsed = System.nanoTime() - started
                if (outer) trace.recordEnd(elapsed) else trace.recordNestedEnd(elapsed)
            }
        }
    }
}
