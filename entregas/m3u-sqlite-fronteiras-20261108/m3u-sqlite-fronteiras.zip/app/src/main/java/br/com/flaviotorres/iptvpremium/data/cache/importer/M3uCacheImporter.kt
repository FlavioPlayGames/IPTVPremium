
package br.com.flaviotorres.iptvpremium.data.cache.importer

import android.os.SystemClock
import android.util.Log
import br.com.flaviotorres.iptvpremium.data.cache.PlaylistCacheGenerationManager
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedCategoryEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedChannelEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedEpisodeEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedMovieEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedSeriesEntity
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.UUID

class M3uCacheImporter(
    private val httpClient: PlaylistHttpClient,
    private val cacheDao: PlaylistCacheDao,
    private val generationManager: PlaylistCacheGenerationManager,
    private val batchSize: Int = M3uWritePolicy.configured().batchSize,
    private val batchCharacters: Int = br.com.flaviotorres.iptvpremium.data.cache.ImportTuningState.profile.m3uBatchCharacters,
    private val onXmltvSources:(String,String,List<String>)->Unit={_,_,_->},
    private val transactionBatches: Int = M3uWritePolicy.configured().transactionBatches,
    private val originalWriter: Boolean = M3uWritePolicy.configured().name == "ORIGINAL"
) {

    suspend fun import(
        playlistId: String,
        playlistUrl: String
    ): String {
        require(playlistUrl.isNotBlank()) {
            "A URL da lista M3U está vazia."
        }

        val startedAt = SystemClock.elapsedRealtime()
        val importStartedNs = System.nanoTime()

        Log.i(PERF_TAG,"fase=INICIO formato=M3U revisao=M3U_METADATA_R4 versaoBanco=${br.com.flaviotorres.iptvpremium.data.cache.PlaylistCacheDatabase.SCHEMA_VERSION} banco=M3U_EP_INDEX_R1 diagnostico=M3U_GROUP_R1")
        val generationId = generationManager.beginImport(
            playlistId = playlistId
        )

        Log.i(PERF_TAG,"fase=GERACAO_CRIADA decorridoMs=${SystemClock.elapsedRealtime()-startedAt}")
        try {
            val xmltvSources=importIntoGeneration(
                playlistId = playlistId,
                generationId = generationId,
                playlistUrl = playlistUrl
            )

            currentCoroutineContext().ensureActive()
            val readyStarted = System.nanoTime()
            generationManager.markImportReady(
                playlistId = playlistId,
                generationId = generationId
            )

            Log.i("IPTV_PERF", "stage=ready startNs=$readyStarted endNs=${System.nanoTime()}")

            try {onXmltvSources(playlistId,playlistUrl,xmltvSources)}
            catch(cancelled:kotlinx.coroutines.CancellationException){throw cancelled}
            catch(error:Exception){Log.w("XmltvEpg","discovery=metadata_unavailable error=${error.javaClass.simpleName}")}

            Log.i(
                PERF_TAG,
                "Importação M3U concluída. " +
                        "tempoTotalMs=${SystemClock.elapsedRealtime() - startedAt}"
            )

            Log.i("IPTV_PERF", "stage=import status=OK startNs=$importStartedNs endNs=${System.nanoTime()} wallMs=${SystemClock.elapsedRealtime()-startedAt}")
            return generationId
        } catch (error: Throwable) {
            Log.w(PERF_TAG,"fase=INTERROMPIDA erro=${error.javaClass.simpleName} decorridoMs=${SystemClock.elapsedRealtime()-startedAt}")
            try { generationManager.discardImport(playlistId, generationId) }
            catch (cleanup: Throwable) { if (cleanup !== error) error.addSuppressed(cleanup) }
            throw error
        }
    }

    private suspend fun importIntoGeneration(
        playlistId: String,
        generationId: String,
        playlistUrl: String
    ) = coroutineScope {
        val startedAt = SystemClock.elapsedRealtime()
        val xmltvSources=linkedSetOf<String>()

        val categoryBatch =
            LinkedHashMap<String, CachedCategoryEntity>()

        val channelBatch =
            ArrayList<CachedChannelEntity>(batchSize)

        val movieBatch =
            ArrayList<CachedMovieEntity>(batchSize)

        val seriesBatch =
            LinkedHashMap<String, CachedSeriesEntity>()

        val seriesFirstOrder = HashMap<String, Int>()

        val episodeBatch =
            ArrayList<CachedEpisodeEntity>(batchSize)

        // Categorias já incluídas nesta importação.
        // Evita regravá-las a cada lote de 500 itens.
        val insertedCategoryKeys = HashSet<String>()

        // Uma categoria conserva o mesmo ID por toda a importação.
        // Não precisamos recalcular seu UUID a cada item.
        val categoryIdCache = HashMap<String, String>()

        require(batchSize in 1..2000 && batchCharacters > 0 && transactionBatches in 1..8)
        var previousSeriesGroup: String? = null
        var previousSeriesName: String? = null
        var previousSeriesId: String? = null
        // Bounded metadata cache: skip identical upserts even when series are interleaved.
        // Eviction only loses the optimization; the next record is written normally.
        val recentSeriesRecords = object : LinkedHashMap<String, CachedSeriesEntity>(256, 0.75f, true) {
            override fun removeEldestEntry(eldest: MutableMap.MutableEntry<String, CachedSeriesEntity>?): Boolean = size > 256
        }
        var seriesIdReused = 0L
        var seriesUpserts = 0L
        var bufferedEntries = 0
        var peakBufferedEntries = 0
        var queueWaitMs = 0L
        var parsingNs = 0L
        var conversionNs = 0L
        val categoryEntries = LinkedHashMap<String, Long>()
        var pendingExtInf: String? = null
        var channelNumber = 0
        var foundExtInf = false
        var foundStream = false

        var processedEntries = 0L
        var movieCount = 0L
        var seriesEpisodeCount = 0L
        var databaseWriteMs = 0L
        var bufferedCharacters = 0L
        var flushCount = 0L
        var slowestWriteMs = 0L

        fun cachedCategoryId(
            type: String,
            groupName: String
        ): String {
            val key = "$type:$groupName"

            return categoryIdCache.getOrPut(key) {
                stableId("category:$type:$groupName")
            }
        }

        fun registerCategory(
            type: String,
            categoryId: String,
            groupName: String
        ) {
            val key = categoryKey(
                type = type,
                categoryId = categoryId
            )

            categoryEntries[key] = (categoryEntries[key] ?: 0L) + 1L
            if (!insertedCategoryKeys.add(key)) {
                return
            }

            categoryBatch[key] = CachedCategoryEntity(
                playlistId = playlistId,
                generationId = generationId,
                categoryId = categoryId,
                name = groupName,
                type = type,
                source = SOURCE_M3U
            )
        }

        val writes = Channel<M3uWriteGroup>(capacity = 1)
        var groupCount = 0L
        var beforeBodyNs = 0L; var afterBodyNs = 0L
        var beginNs = 0L; var endNs = 0L
        var beginCalls = 0; var endCalls = 0
        var nestedBeginNs = 0L; var nestedEndNs = 0L
        var nestedBeginCalls = 0; var nestedEndCalls = 0
        val stageNs = LongArray(5)
        var seriesWritten = 0L
        var contextGroups = 0L
        var groupPeakEntries = 0
        var heapPeakObservedKb = 0L
        val writer = launch(Dispatchers.IO) {
            for (group in writes) {
                currentCoroutineContext().ensureActive()
                val trace = br.com.flaviotorres.iptvpremium.data.cache.M3uTransactionMetrics()
                val started = System.nanoTime()
                try {
                    if (originalWriter) {
                        val batch = group.batches.single()
                        cacheDao.insertImportBatch(batch.categories, batch.channels, batch.movies, batch.series, batch.episodes, batch.metrics)
                    } else kotlinx.coroutines.withContext(trace) { cacheDao.insertM3uGroup(group, trace) }
                } catch (error: Throwable) {
                    Log.i("IPTV_PERF", "stage=group status=ERROR group=${groupCount+1} batches=${group.batches.size} startNs=$started endNs=${System.nanoTime()}")
                    throw error
                }
                val finished = System.nanoTime()
                val elapsed = (finished - started) / 1_000_000
                val entered = trace.enteredNs
                val exited = trace.exitedNs
                val before = if (entered > 0) entered - started else 0L
                val after = if (exited > 0) finished - exited else 0L
                beforeBodyNs += before; afterBodyNs += after
                beginNs += trace.beginNs; endNs += trace.endNs
                beginCalls += trace.begins; endCalls += trace.ends
                nestedBeginNs += trace.nestedBeginNs; nestedEndNs += trace.nestedEndNs
                nestedBeginCalls += trace.nestedBegins; nestedEndCalls += trace.nestedEnds
                groupCount++
                if (trace.contextObserved) contextGroups++
                seriesWritten += group.batches.sumOf { it.series.size }.toLong()
                databaseWriteMs += elapsed
                slowestWriteMs = maxOf(slowestWriteMs, elapsed)
                flushCount += group.batches.size
                for (batch in group.batches) for (stage in br.com.flaviotorres.iptvpremium.data.cache.dao.ImportBatchWriteMetrics.Stage.entries) {
                    stageNs[stage.ordinal] += batch.metrics.nanos(stage)
                }
                val entries = group.batches.sumOf { it.entries }
                groupPeakEntries = maxOf(groupPeakEntries, entries)
                val runtime = Runtime.getRuntime()
                heapPeakObservedKb = maxOf(heapPeakObservedKb, (runtime.totalMemory()-runtime.freeMemory())/1024)
                Log.i("IPTV_PERF", "stage=group status=OK group=$groupCount batches=${group.batches.size} entries=$entries " +
                    "startNs=$started endNs=$finished durationUs=${(finished-started)/1000} " +
                    "beforeBodyUs=${before/1000} afterBodyUs=${after/1000} beginUs=${trace.beginNs/1000} endUs=${trace.endNs/1000} " +
                    "beginCalls=${trace.begins} endCalls=${trace.ends} nestedBeginUs=${trace.nestedBeginNs/1000} nestedEndUs=${trace.nestedEndNs/1000} nestedBeginCalls=${trace.nestedBegins} nestedEndCalls=${trace.nestedEnds} boundary=SUPPORT_SQLITE_R1 contextMeasured=${if(trace.contextObserved)1 else 0} bodyMeasured=${if(entered>0)1 else 0}")
            }
        }
        Log.i("IPTV_PERF", "stage=config revision=M3U_GROUP_R1 boundary=SUPPORT_SQLITE_R1 batchSize=$batchSize transactionBatches=$transactionBatches charactersLimit=$batchCharacters queueGroups=1 original=${if(originalWriter)1 else 0}")
        val prepared = ArrayList<M3uWriteBatch>(transactionBatches)
        var preparedCharacters = 0L
        var preparedEntries = 0
        suspend fun sendPrepared() {
            if (prepared.isEmpty()) return
            val group = M3uWriteGroup(prepared.toList())
            val waitStarted = System.nanoTime()
            writes.send(group)
            queueWaitMs += (System.nanoTime() - waitStarted)/1_000_000
            prepared.clear(); preparedCharacters = 0; preparedEntries = 0
        }
        suspend fun flush() {
            if(categoryBatch.isEmpty() && channelBatch.isEmpty() && movieBatch.isEmpty() && seriesBatch.isEmpty() && episodeBatch.isEmpty())return
            // The character budget applies to the whole prepared group, not each of its batches.
            if (prepared.isNotEmpty() && (preparedCharacters + bufferedCharacters > batchCharacters || preparedEntries + bufferedEntries > 2000)) sendPrepared()
            prepared += M3uWriteBatch(categoryBatch.values.toList(),channelBatch.toList(),movieBatch.toList(),seriesBatch.values.toList(),episodeBatch.toList(),bufferedCharacters)
            preparedCharacters += bufferedCharacters
            preparedEntries += bufferedEntries
            categoryBatch.clear();channelBatch.clear();movieBatch.clear();seriesBatch.clear();episodeBatch.clear()
            bufferedCharacters=0L;bufferedEntries=0
            if (prepared.size >= transactionBatches || preparedCharacters >= batchCharacters || preparedEntries >= 2000) sendPrepared()
        }

        httpClient.readLines(
            url = playlistUrl
        ) { rawLine ->
            currentCoroutineContext().ensureActive()
            if (bufferedCharacters >= batchCharacters) flush()
            bufferedCharacters += rawLine.length
            val parseStarted=System.nanoTime()
            var conversionStarted = 0L
            try {
            val line = rawLine
                .removePrefix("\uFEFF")
                .trim()

            if (line.isBlank()) {
                return@readLines
            }

            if (
                line.startsWith(
                    "#EXTINF",
                    ignoreCase = true
                )
            ) {
                foundExtInf = true
                pendingExtInf = line
                return@readLines
            }

            if(line.startsWith("#EXTM3U",true)) {
                xmltvSources+=br.com.flaviotorres.iptvpremium.data.epg.xmltvHeaderSources(line,playlistUrl)
            }
            if (line.startsWith("#")) {
                return@readLines
            }

            val extInf = pendingExtInf
                ?: return@readLines

            pendingExtInf = null
            foundStream = true
            processedEntries++
            bufferedEntries++
            peakBufferedEntries=maxOf(peakBufferedEntries,bufferedEntries)

            val name = extractDisplayName(extInf)
                .ifBlank { "Conteúdo" }

            val metadata = M3uEntryMetadata.parse(extInf)
            val groupName = metadata.group?.trim()?.takeIf { it.isNotBlank() } ?: DEFAULT_CATEGORY_NAME
            val logoUrl = metadata.logo?.trim()?.takeIf { it.isNotBlank() }
            val rawTvgId = metadata.tvgId
            val tvgId = rawTvgId?.trim()?.takeIf { it.isNotBlank() }
            val hasXuiId = metadata.hasXuiId

            val entryType = classifyEntry(
                    streamUrl = line,
                    groupName = groupName,
                    name = name,
                    hasXuiId = hasXuiId,
                    hasTvgIdAttribute = rawTvgId != null
                )
            conversionStarted = System.nanoTime()
            when (entryType) {
                EntryType.LIVE_TV -> {
                    channelNumber++

                    val categoryId = cachedCategoryId(
                        TYPE_LIVE_TV,
                        groupName
                    )

                    val channelId = stableId(
                        "channel:$line:$name:${tvgId.orEmpty()}"
                    )

                    registerCategory(
                        type = TYPE_LIVE_TV,
                        categoryId = categoryId,
                        groupName = groupName
                    )

                    channelBatch += CachedChannelEntity(
                        playlistId = playlistId,
                        generationId = generationId,
                        channelId = channelId,
                        name = name,
                        categoryId = categoryId,
                        logoUrl = logoUrl,
                        streamUrl = line,
                        epgChannelId = tvgId,
                        channelNumber = channelNumber
                    )
                }

                EntryType.MOVIE -> {
                    movieCount++

                    val categoryId = cachedCategoryId(
                        TYPE_MOVIES,
                        groupName
                    )

                    val movieId = stableId(
                        "movie:$line:$name"
                    )

                    registerCategory(
                        type = TYPE_MOVIES,
                        categoryId = categoryId,
                        groupName = groupName
                    )

                    movieBatch += CachedMovieEntity(
                        playlistId = playlistId,
                        generationId = generationId,
                        movieId = movieId,
                        name = name,
                        categoryId = categoryId,
                        posterUrl = logoUrl,
                        backdropUrl = null,
                        streamUrl = line,
                        year = extractYear(name),
                        rating = null,
                        durationSeconds = null,
                        providerOrder = (movieCount - 1).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
                    )
                }

                EntryType.SERIES -> {
                    seriesEpisodeCount++

                    val categoryId = cachedCategoryId(
                        TYPE_SERIES,
                        groupName
                    )

                    val episodeInfo = extractEpisodeInfo(name)

                    val seriesName = episodeInfo.seriesName
                        .ifBlank { name }

                    val seriesId=if(previousSeriesGroup==groupName && previousSeriesName==seriesName) {
                        seriesIdReused++;checkNotNull(previousSeriesId)
                    } else stableId("series:$groupName:$seriesName").also {
                        previousSeriesGroup=groupName;previousSeriesName=seriesName;previousSeriesId=it
                    }

                    val episodeId = stableId(
                        "episode:$line:$name"
                    )

                    registerCategory(
                        type = TYPE_SERIES,
                        categoryId = categoryId,
                        groupName = groupName
                    )

                    val seriesProviderOrder =
                        seriesFirstOrder.getOrPut(seriesId) {
                            seriesFirstOrder.size
                        }

                    val previous=recentSeriesRecords[seriesId]
                    val unchanged=previous!=null && previous.seriesId==seriesId && previous.name==seriesName &&
                        previous.categoryId==categoryId && previous.posterUrl==logoUrl
                    if(!unchanged) {
                    val record=CachedSeriesEntity(
                        playlistId = playlistId,
                        generationId = generationId,
                        seriesId = seriesId,
                        name = seriesName,
                        categoryId = categoryId,
                        posterUrl = logoUrl,
                        backdropUrl = null,
                        year = extractYear(seriesName),
                        rating = null,
                        plot = null,
                        titleLogoUrl = null,
                        imdbId = null,
                        tmdbId = null,
                        ratingSource = null,
                        durationSeconds = null,
                        genres = null,
                        trailerUrl = null,
                        providerOrder = seriesProviderOrder
                    )
                    seriesBatch[seriesId]=record;recentSeriesRecords[seriesId]=record;seriesUpserts++
                    }

                    episodeBatch += CachedEpisodeEntity(
                        playlistId = playlistId,
                        generationId = generationId,
                        episodeId = episodeId,
                        seriesId = seriesId,
                        seasonNumber = episodeInfo.seasonNumber,
                        episodeNumber = episodeInfo.episodeNumber,
                        name = name,
                        streamUrl = line,
                        posterUrl = logoUrl,
                        durationSeconds = null
                    )
                }
            }

            } finally {
                val ended = System.nanoTime()
                parsingNs += ended - parseStarted
                if (conversionStarted != 0L) conversionNs += ended - conversionStarted
            }
            if (
                bufferedEntries >= batchSize ||
                channelBatch.size >= batchSize ||
                movieBatch.size >= batchSize ||
                seriesBatch.size >= batchSize ||
                episodeBatch.size >= batchSize ||
                categoryBatch.size >= batchSize
            ) {
                flush()
            }
        }

        flush()
        sendPrepared()
        writes.close()
        writer.join()

        if (!foundExtInf || !foundStream) {
            throw IllegalStateException(
                "O endereço informado não retornou uma lista M3U válida."
            )
        }

        val totalMs = SystemClock.elapsedRealtime() - startedAt

        Log.i(
            PERF_TAG,
            "M3U processada: " +
                    "tempoMs=$totalMs " +
                    "gravacaoRoomMs=$databaseWriteMs " +
                    "parsingMs=${parsingNs/1_000_000} esperaFilaMs=$queueWaitMs sobreposicao=true " +
                    "lotes=$flushCount gravacaoPicoMs=$slowestWriteMs " +
                    "entradas=$processedEntries " +
                    "canais=$channelNumber " +
                    "filmes=$movieCount " +
                    "episodios=$seriesEpisodeCount " +
                    "seriesDistintas=${seriesFirstOrder.size} " +
                    "categoriasDistintas=${insertedCategoryKeys.size} " +
                    "seriesPreparadas=$seriesUpserts idsSerieReutilizados=$seriesIdReused entradasPicoLote=$peakBufferedEntries limiteEntradas=$batchSize limiteCaracteres=$batchCharacters"
        )
        Log.i("IPTV_PERF", "stage=summary revision=M3U_GROUP_R1 status=OK wallMs=$totalMs groups=$groupCount batches=$flushCount " +
            "entries=$processedEntries channels=$channelNumber movies=$movieCount episodes=$seriesEpisodeCount series=${seriesFirstOrder.size} categories=${insertedCategoryKeys.size} " +
            "writeMs=$databaseWriteMs parsingMs=${parsingNs/1_000_000} syntaxUs=${(parsingNs-conversionNs)/1000} conversionUs=${conversionNs/1000} queueWaitMs=$queueWaitMs duplicateQueries=0 retries=0 " +
            "beforeBodyUs=${beforeBodyNs/1000} afterBodyUs=${afterBodyNs/1000} beginUs=${beginNs/1000} endUs=${endNs/1000} beginCalls=$beginCalls endCalls=$endCalls nestedBeginUs=${nestedBeginNs/1000} nestedEndUs=${nestedEndNs/1000} nestedBeginCalls=$nestedBeginCalls nestedEndCalls=$nestedEndCalls boundary=SUPPORT_SQLITE_R1 " +
            "categoriesUs=${stageNs[0]/1000} channelsUs=${stageNs[1]/1000} moviesUs=${stageNs[2]/1000} seriesUs=${stageNs[3]/1000} episodesUs=${stageNs[4]/1000} " +
            "peakGroupEntries=$groupPeakEntries peakGroupMs=$slowestWriteMs heapPeakObservedKb=$heapPeakObservedKb seriesPrepared=$seriesUpserts seriesWritten=$seriesWritten contextGroups=$contextGroups")
        categoryEntries.entries.forEachIndexed { index, entry ->
            val type = entry.key.substringBefore(':')
            Log.i("IPTV_PERF", "stage=category type=$type categoryIndex=$index entries=${entry.value}")
        }
        xmltvSources.take(4)
    }

    private fun classifyEntry(streamUrl:String,groupName:String,name:String,hasXuiId:Boolean,hasTvgIdAttribute:Boolean):EntryType =
        when(M3uEntryClassifier.classify(streamUrl,groupName,name,hasXuiId,hasTvgIdAttribute)) {
            M3uEntryClassifier.Kind.LIVE_TV->EntryType.LIVE_TV
            M3uEntryClassifier.Kind.MOVIE->EntryType.MOVIE
            M3uEntryClassifier.Kind.SERIES->EntryType.SERIES
        }

    private fun extractEpisodeInfo(
        name: String
    ): EpisodeInfo {
        val compactMatch = COMPACT_EPISODE_REGEX.find(name)

        if (compactMatch != null) {
            val season = compactMatch.groupValues
                .getOrNull(1)
                ?.toIntOrNull()

            val episode = compactMatch.groupValues
                .getOrNull(2)
                ?.toIntOrNull()

            val cleanSeriesName = name
                .removeRange(compactMatch.range)
                .replace(TRAILING_SERIES_SEPARATOR_REGEX, "")
                .trim()

            return EpisodeInfo(
                seriesName = cleanSeriesName,
                seasonNumber = season,
                episodeNumber = episode
            )
        }

        val verboseMatch = VERBOSE_EPISODE_REGEX.find(name)

        if (verboseMatch != null) {
            val season = verboseMatch.groupValues
                .getOrNull(1)
                ?.toIntOrNull()

            val episode = verboseMatch.groupValues
                .getOrNull(2)
                ?.toIntOrNull()

            val cleanSeriesName = name
                .substring(0, verboseMatch.range.first)
                .replace(TRAILING_SERIES_SEPARATOR_REGEX, "")
                .trim()

            return EpisodeInfo(
                seriesName = cleanSeriesName,
                seasonNumber = season,
                episodeNumber = episode
            )
        }

        return EpisodeInfo(
            seriesName = name.trim(),
            seasonNumber = null,
            episodeNumber = null
        )
    }

    private fun looksLikeEpisode(
        name: String
    ): Boolean {
        return COMPACT_EPISODE_REGEX.containsMatchIn(name) ||
                VERBOSE_EPISODE_REGEX.containsMatchIn(name)
    }

    private fun extractYear(
        value: String
    ): Int? {
        return YEAR_REGEX.find(value)
            ?.value
            ?.toIntOrNull()
    }

    private fun normalizeForClassification(
        value: String
    ): String {
        return value
            .lowercase(Locale.ROOT)
            .replace('á', 'a')
            .replace('à', 'a')
            .replace('ã', 'a')
            .replace('â', 'a')
            .replace('ä', 'a')
            .replace('é', 'e')
            .replace('è', 'e')
            .replace('ê', 'e')
            .replace('ë', 'e')
            .replace('í', 'i')
            .replace('ì', 'i')
            .replace('î', 'i')
            .replace('ï', 'i')
            .replace('ó', 'o')
            .replace('ò', 'o')
            .replace('õ', 'o')
            .replace('ô', 'o')
            .replace('ö', 'o')
            .replace('ú', 'u')
            .replace('ù', 'u')
            .replace('û', 'u')
            .replace('ü', 'u')
            .replace('ç', 'c')
    }

    private fun containsAny(
        value: String,
        keywords: Set<String>
    ): Boolean {
        return keywords.any { keyword ->
            keyword in value
        }
    }

    private fun extractDisplayName(
        extInf: String
    ): String {
        val commaIndex = extInf.lastIndexOf(',')

        if (
            commaIndex < 0 ||
            commaIndex >= extInf.lastIndex
        ) {
            return ""
        }

        return extInf
            .substring(commaIndex + 1)
            .trim()
    }

    private fun stableId(
        value: String
    ): String {
        return UUID.nameUUIDFromBytes(
            value.toByteArray(StandardCharsets.UTF_8)
        ).toString()
    }

    private fun categoryKey(
        type: String,
        categoryId: String
    ): String {
        return "$type:$categoryId"
    }

    private data class EpisodeInfo(
        val seriesName: String,
        val seasonNumber: Int?,
        val episodeNumber: Int?
    )

    private enum class EntryType {
        LIVE_TV,
        MOVIE,
        SERIES
    }

    private companion object {
        const val PERF_TAG = "M3uImportPerf"
        const val DEFAULT_CATEGORY_NAME = "Sem categoria"

        const val TYPE_LIVE_TV = "LIVE_TV"
        const val TYPE_MOVIES = "MOVIES"
        const val TYPE_SERIES = "SERIES"

        const val SOURCE_M3U = "M3U"

        // Compiladas uma única vez, em vez de uma vez por entrada.
        val COMPACT_EPISODE_REGEX = Regex(
            """(?i)\bS(\d{1,3})\s*E(\d{1,6})\b"""
        )

        val VERBOSE_EPISODE_REGEX = Regex(
            """(?i)\b(?:temporada|season)\s*(\d{1,3}).*?\b(?:epis[oó]dio|episode|ep)\s*(\d{1,6})\b"""
        )

        val TRAILING_SERIES_SEPARATOR_REGEX = Regex(
            """[\s._\-–—|]+$"""
        )

        val YEAR_REGEX = Regex(
            """\b(19|20)\d{2}\b"""
        )

        val MOVIE_KEYWORDS = setOf(
            "filme",
            "filmes",
            "movie",
            "movies",
            "cinema",
            "vod",
            "lancamentos",
            "lancamento"
        )

        val SERIES_KEYWORDS = setOf(
            "serie",
            "series",
            "seriado",
            "seriados",
            "temporada",
            "season"
        )

        val SERIES_TITLE_KEYWORDS = setOf(
            "temporada",
            "season",
            "episodio",
            "episode"
        )
    }
}
