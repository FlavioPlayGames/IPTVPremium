package br.com.flaviotorres.iptvpremium.data.cache

import kotlin.coroutines.CoroutineContext
import kotlinx.coroutines.ThreadContextElement

/** Carries only timings through Room's transaction dispatcher. Never stores SQL or user data. */
class M3uTransactionMetrics : ThreadContextElement<M3uTransactionMetrics?>,
    CoroutineContext.Element {
    companion object Key : CoroutineContext.Key<M3uTransactionMetrics> {
        private val local = ThreadLocal<M3uTransactionMetrics?>()
        fun current(): M3uTransactionMetrics? = local.get()
    }
    override val key: CoroutineContext.Key<*> get() = Key
    override fun updateThreadContext(context: CoroutineContext): M3uTransactionMetrics? =
        local.get().also { local.set(this) }
    override fun restoreThreadContext(context: CoroutineContext, oldState: M3uTransactionMetrics?) { local.set(oldState) }
    var enteredNs = 0L; private set
    var exitedNs = 0L; private set
    var beginNs = 0L; private set
    var endNs = 0L; private set
    var begins = 0; private set
    var ends = 0; private set
    var nestedBeginNs = 0L; private set
    var nestedEndNs = 0L; private set
    var nestedBegins = 0; private set
    var nestedEnds = 0; private set
    fun recordNestedBegin(nanos: Long) { nestedBeginNs += nanos; nestedBegins++ }
    fun recordNestedEnd(nanos: Long) { nestedEndNs += nanos; nestedEnds++ }
    var contextObserved = false; private set
    fun enterBody() { enteredNs = System.nanoTime(); contextObserved = current() === this }
    fun exitBody() { exitedNs = System.nanoTime() }
    fun recordBegin(nanos: Long) { beginNs += nanos; begins++ }
    fun recordEnd(nanos: Long) { endNs += nanos; ends++ }
}
