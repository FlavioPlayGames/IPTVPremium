package br.com.flaviotorres.iptvpremium.core.player

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.zip.ZipInputStream

/** Read a pack in memory without writing paths or retaining every episode. */
internal object SubsourceArchive {
    fun select(bytes: ByteArray, season: Int?, episode: Int?, requireEpisode: Boolean): ByteArray? {
        if (bytes.size < 6) return null
        if (bytes[0] != 'P'.code.toByte() || bytes[1] != 'K'.code.toByte())
            return if (requireEpisode || bytes.size > 1_000_000) null else bytes
        var sole: ByteArray? = null
        var count = 0
        var total = 0
        var selected: ByteArray? = null
        try {
            ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
                var inspected = 0
                val buffer = ByteArray(8192)
                while (true) {
                    val entry = zip.nextEntry ?: break
                    if (++inspected > 500) return null
                    val subtitle = !entry.isDirectory && (entry.name.endsWith(".srt",true) || entry.name.endsWith(".vtt",true))
                    val matches = season != null && episode != null &&
                        SubsourceEpisodePolicy.candidate(entry.name,season,episode,0) == 1
                    val collect = subtitle && (matches && selected == null || count == 0)
                    val out = if (collect) ByteArrayOutputStream() else null
                    var size = 0
                    while (true) {
                        val n = zip.read(buffer)
                        if (n < 0) break
                        total += n; size += n
                        if (total > 10_000_000) return null
                        if (size <= 1_000_000) out?.write(buffer,0,n)
                    }
                    if (subtitle) {
                        count++
                        val data = out?.takeIf { size in 1..1_000_000 }?.toByteArray()
                        if (matches && data != null && selected == null) selected = data
                        if (count == 1) {
                            val unrelated = season != null && episode != null &&
                                SubsourceEpisodePolicy.candidate(entry.name,season,episode,0) == 0 &&
                                (SubsourceEpisodePolicy.markers(entry.name).isNotEmpty() ||
                                 Regex("(?i)(?<![a-z0-9])(?:e|ep|episode)[ ._-]*[0-9]").containsMatchIn(entry.name))
                            sole = if (unrelated) null else data
                        } else sole = null
                    }
                }
            }
        } catch (_: IOException) { return null }
        return selected ?: if (!requireEpisode && count == 1) sole else null
    }
}
