package br.com.flaviotorres.iptvpremium.core.player

/** Metadata hints are not proof that a season archive contains the requested episode. */
internal object SubsourceEpisodePolicy {
    private val pairs = listOf(
        Regex("(?i)(?<![a-z0-9])s(\\d{1,2})[ ._-]*e(\\d{1,3})(?!\\d)"),
        Regex("(?i)(?<![a-z0-9])(\\d{1,2})x(\\d{1,3})(?!\\d)")
    )
    fun markers(text: String): List<Pair<Int, Int>> = pairs.flatMap { regex ->
        regex.findAll(text).map { it.groupValues[1].toInt() to it.groupValues[2].toInt() }.toList()
    }
    fun candidate(text: String, season: Int, episode: Int, files: Int): Int {
        val episodes = markers(text)
        if (episodes.isNotEmpty()) return if (season to episode in episodes) 1 else 0
        val seasons = Regex("(?i)(?<![a-z0-9])(?:s|season[ ._-]*|temporada[ ._-]*)(\\d{1,2})(?!\\d)")
            .findAll(text).map { it.groupValues[1].toInt() }.toList()
        if (seasons.any { it != season }) return 0
        // The work has already been resolved to this season. Episode-only release names are valid.
        val standalone = Regex("(?i)(?<![a-z0-9])(?:ep(?:isode)?[ ._-]*|e)(\\d{1,3})(?!\\d)")
            .findAll(text).map { it.groupValues[1].toInt() }.toList()
        if (standalone.isNotEmpty()) return if (episode in standalone) 1 else 0
        // Unknown single files are not guessed. Packs must be checked inside their ZIP after selection.
        return if (season in seasons || files > 1) 2 else 0
    }
}
