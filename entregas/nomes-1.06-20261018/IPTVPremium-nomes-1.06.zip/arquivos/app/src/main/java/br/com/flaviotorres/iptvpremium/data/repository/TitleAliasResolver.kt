package br.com.flaviotorres.iptvpremium.data.repository

import br.com.flaviotorres.iptvpremium.data.history.ContentIdentity
import org.json.JSONObject

/** Nomes oficiais, nao traducao automatica. Sem imagens, elenco ou dados do provedor. */
internal class TitleAliasResolver(
    private val get: suspend (String, Map<String, String>) -> String
) {
    suspend fun resolve(source: ContentIdentity): ContentIdentity? {
        val type = if (source.kind == "series") "tv" else if (source.kind == "movies") "movie" else return null
        val ids = if (source.tmdbKey != null) listOf(source.tmdbKey!!) else if (source.imdbKey != null) {
            val root = JSONObject(get("/find/${source.imdbKey}", mapOf("external_source" to "imdb_id")))
            root.optJSONArray(if (type == "tv") "tv_results" else "movie_results")?.let { array ->
                (0 until minOf(array.length(), 3)).mapNotNull { array.optJSONObject(it)?.optLong("id")?.takeIf { id -> id > 0 }?.toString() }
            }.orEmpty()
        } else {
            val query = linkedMapOf("query" to ContentIdentity.normalizeTitle(source.title, source.normalizedYear),
                "language" to "en-US", "include_adult" to "false")
            source.normalizedYear?.let { query[if (type == "tv") "first_air_date_year" else "year"] = it.toString() }
            val results = JSONObject(get("/search/$type", query)).optJSONArray("results") ?: return null
            (0 until minOf(results.length(), 3)).mapNotNull { results.optJSONObject(it)?.optLong("id")?.takeIf { id -> id > 0 }?.toString() }
        }
        val matches = ids.distinct().mapNotNull { id ->
            val details = JSONObject(get("/$type/$id", mapOf("language" to "en-US", "append_to_response" to "alternative_titles,external_ids")))
            if (details.optLong("id").toString() != id) return@mapNotNull null
            val year = details.optString(if (type == "tv") "first_air_date" else "release_date").take(4).toIntOrNull()
            val imdb = details.optJSONObject("external_ids")?.optString("imdb_id")
                ?.takeIf { ContentIdentity(source.kind, source.title, imdb = it).imdbKey != null }
                ?: details.optString("imdb_id").takeIf { ContentIdentity(source.kind, source.title, imdb = it).imdbKey != null }
            if (source.imdbKey != null && source.imdbKey != imdb) return@mapNotNull null
            val titles = mutableListOf(details.optString(if (type == "tv") "name" else "title"),
                details.optString(if (type == "tv") "original_name" else "original_title"))
            val alternatives = details.optJSONObject("alternative_titles")
            val array = alternatives?.optJSONArray(if (type == "tv") "results" else "titles")
            if (array != null) for (i in 0 until minOf(array.length(), 200)) {
                array.optJSONObject(i)?.optString("title")?.let { titles.add(it) }
            }
            val names = titles.filter { it.isNotBlank() && it.length <= 160 && it != "null" }.distinct()
            val knownId = source.tmdbKey == id || (source.imdbKey != null && source.imdbKey == imdb)
            if (!knownId) {
                if (source.normalizedYear != null && source.normalizedYear != year) return@mapNotNull null
                val keys = names.map { ContentIdentity.normalizeTitle(it, year) }.toSet()
                if (source.normalizedTitle !in keys) return@mapNotNull null
            }
            source.copy(year = source.year ?: year, imdb = source.imdbKey ?: imdb, tmdb = id,
                alternateTitles = names.take(32))
        }
        // Nunca escolhe por popularidade: remakes/resultados ambiguos ficam separados.
        return matches.singleOrNull()
    }
}
