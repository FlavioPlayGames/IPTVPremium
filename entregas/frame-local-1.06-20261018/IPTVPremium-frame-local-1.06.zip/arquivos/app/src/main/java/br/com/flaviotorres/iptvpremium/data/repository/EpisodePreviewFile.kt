package br.com.flaviotorres.iptvpremium.data.repository

import java.io.File

/** Prefixo temporario limitado. Nunca persiste um episodio no cache de imagens. */
internal fun <T> withEpisodePreviewFile(
    file: File,
    reader: BoundedVideoReader,
    checkActive: () -> Unit,
    decode: (File) -> T
): T {
    try {
        reader.use {
            file.outputStream().use { output ->
                val buffer = ByteArray(64 * 1024)
                var position = 0L
                while (position < EPISODE_PREVIEW_FILE_LIMIT) {
                    checkActive()
                    val size = minOf(buffer.size.toLong(), EPISODE_PREVIEW_FILE_LIMIT - position).toInt()
                    val read = reader.readAt(position, buffer, 0, size)
                    if (read <= 0) break
                    output.write(buffer, 0, read)
                    position += read
                }
            }
        }
        checkActive()
        return decode(file)
    } finally {
        file.delete()
    }
}
internal const val EPISODE_PREVIEW_FILE_LIMIT = 6L * 1024 * 1024
