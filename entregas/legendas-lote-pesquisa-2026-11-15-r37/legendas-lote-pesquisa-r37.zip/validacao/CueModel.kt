package br.com.flaviotorres.iptvpremium.core.player
data class ExternalSubtitleCue(val startMs: Long, val endMs: Long, val text: String)
