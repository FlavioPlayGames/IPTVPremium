package br.com.flaviotorres.iptvpremium.core.player

import java.io.ByteArrayOutputStream
import java.io.File
import java.nio.file.Files
import java.util.zip.ZipOutputStream
import java.util.zip.ZipEntry

fun main() {
 val one="1\n00:00:01,000 --> 00:00:03,000\nOlá\n".toByteArray()
 fun zip(vararg names:String):ByteArray {val out=ByteArrayOutputStream();ZipOutputStream(out).use{z->names.forEach{n->z.putNextEntry(ZipEntry(n));z.write(one);z.closeEntry()}};return out.toByteArray()}
 val files=ManualSubtitleArchive.read(zip("S05E06/Serie.S05E06.WEB-DL.srt","Temporada 5/Serie.S05E06.BluRay.srt","Serie.S05E07.srt","pasta/sem-numero.srt"),"temporada.zip")
 check(files.size==4 && files[0].season==5 && files[0].episode==6)
 val target=ManualSubtitleTarget("season","p","s","Serie",2017,"100",5,null,listOf(6,7),false)
 val choices=manualSubtitleChoices(target,files)
 check(choices.size==3 && choices[0]==6 && choices[1]==6 && choices[2]==7 && 3 !in choices)
 check(manualSubtitleNumber("S05E06/Serie.S05E06.srt")==5 to 6)
 check(manualSubtitleNumber("pasta/Serie.5x06.srt")==5 to 6)
 check(manualSubtitleNumber("Serie.S05E06E07.srt")==null)
 check(manualSubtitleNumber("Serie.S05E06.S05E07.srt")==null)
 check(ManualSubtitleArchive.read(zip("Serie.S05E06E07.srt"),"ambigua.zip").single().episode==null)
 check(manualSubtitleChoices(target,ManualSubtitleArchive.read(zip("S06E06.srt"),"outra.zip")).isEmpty())
 check(manualSubtitleWorkKey("movie","123",false,null,null)==manualSubtitleWorkKey("movie","00123",false,null,null))
 check(manualSubtitleWorkKey("movie",null,false,null,null)==null)
 check(manualSubtitleWorkKey("movie","123",false,null,null)!=manualSubtitleWorkKey("movie","456",false,null,null))
 check(manualSubtitleWorkKey("movie","123",true,null,null)!=manualSubtitleWorkKey("movie","123",false,null,null))
 check(manualSubtitleWorkKey("episode","123",false,5,6)!=manualSubtitleWorkKey("episode","123",false,5,7))
 val root=Files.createTempDirectory("subtitle-removal-test").toFile()
 try {
  val a=File(root,"primary").apply{mkdir()};val b=File(root,"legacy").apply{mkdir()}
  val first="a".repeat(64);val second="b".repeat(64)
  File(a,"$first.srt").writeBytes(one);File(b,"$first.srt").writeBytes(one);File(a,"$second.srt").writeBytes(one)
  val unrelated=File(root,"passwords.json").apply{writeText("untouched")}
  val temp=File(a,"download.part").apply{writeText("active")}
  check(savedSubtitleFiles(a,b).size==2)
  check(deleteSavedSubtitleFiles(a,b,setOf("../passwords.json")).isEmpty())
  check(deleteSavedSubtitleFiles(a,b,setOf(second)){false}.isEmpty() && File(a,"$second.srt").exists())
  check(deleteSavedSubtitleFiles(a,b,setOf(first))==setOf(first));check(savedSubtitleFiles(a,b).size==1)
  check(deleteSavedSubtitleFiles(a,b,setOf(second))==setOf(second));check(savedSubtitleFiles(a,b).isEmpty())
  check(unrelated.readText()=="untouched" && temp.readText()=="active")
  val cache=File(root,"cache").apply{mkdir()}
  val pinned=File(a,"$first.srt").apply{writeBytes(one)}
  val budget=br.com.flaviotorres.iptvpremium.core.storage.CacheStorageBudget(cache,a)
  val lease=budget.retain(pinned)
  check(deleteSavedSubtitleFiles(a,b,setOf(first)){budget.removeDisposable(it)}.isEmpty())
  lease.close()
  check(deleteSavedSubtitleFiles(a,b,setOf(first)){budget.removeDisposable(it)}==setOf(first))
  check(budget.accountedBytes()==temp.length())
 }finally{root.deleteRecursively()}
 println("PASS real ZIP subfolders, duplicate path IDs, multiple options per episode, pending/ambiguous names, verified work keys and isolated/busy/legacy subtitle deletion.")
}
