from pathlib import Path
import subprocess,os
r=Path('/workspace/iptv-visual-r32');f=r/'app/src/main/java/br/com/flaviotorres/iptvpremium/core/navigation/player';tools=Path('/workspace/iptv-tools');java=str(tools/'jdk25/bin/java')
jars=list(tools.glob('*.jar'))+list(Path('/workspace/.gradle-cache/caches/9.6.0/transforms').glob('*/transformed/*-runtime.jar'))+[Path('/workspace/android-sdk/platforms/android-37.0/android.jar')]
jars+=list(Path('/workspace/.gradle-cache/caches/modules-2/files-2.1/com.google.guava/guava/33.3.1-android').glob('*/*.jar'))
cp=os.pathsep.join(map(str,jars));jar=r/'validacao/r37/batch-tests.jar'
sources=[str(r/'app/src/main/java/br/com/flaviotorres/iptvpremium/core/storage/CacheStorageBudget.kt')]+[str(f/name) for name in ['ManualSubtitleArchive.kt','ManualSubtitleTarget.kt','ManualSubtitleBatch.kt','SavedSubtitleFiles.kt']]+[str(r/'validacao/r37/BatchVerify.kt'),str(r/'validacao/r37/CueModel.kt')]
result=subprocess.run([java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',str(jar)]+sources,capture_output=True,text=True)
print((result.stdout+result.stderr)[-2000:]);assert result.returncode==0
result=subprocess.run([java,'-cp',str(jar)+os.pathsep+cp,'br.com.flaviotorres.iptvpremium.core.player.BatchVerifyKt'],capture_output=True,text=True)
print((result.stdout+result.stderr)[-2000:]);assert result.returncode==0
