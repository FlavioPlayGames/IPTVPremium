package br.com.flaviotorres.iptvpremium.core.player;
import java.util.*;
import java.io.*;
import kotlin.Pair;
public class ManualStoreVerify {
 static void check(boolean ok){if(!ok)throw new AssertionError();}
 static byte[] srt(String text){return ("1\n00:00:01,000 --> 00:00:03,000\n"+text+"\n").getBytes(java.nio.charset.StandardCharsets.UTF_8);}
 static PlaybackMedia media(String id,String title,String tmdb,boolean episode){return new PlaybackMedia(id,episode?PlaybackContentType.EPISODE:PlaybackContentType.MOVIE,title,"https://example.invalid/video",null,null,null,null,episode?"series":null,episode?5:null,episode?6:null,null,tmdb,episode?"Serie":null,episode?2017:2002);}
 static void remove(File f){if(f.isDirectory())for(File c:Objects.requireNonNull(f.listFiles()))remove(c);f.delete();}
 public static void main(String[] args)throws Exception {
  android.content.Context context=new android.content.Context();
  try {
   ManualSubtitleStore store=new ManualSubtitleStore(context);
   ManualSubtitleTarget target=new ManualSubtitleTarget("season","p","series","Serie",2017,"100",5,null,List.of(6,7),false);
   ManualSubtitleFile a=new ManualSubtitleFile("S05E06.WEB.srt",srt("WEB"),5,6);
   ManualSubtitleFile b=new ManualSubtitleFile("S05E06.BluRay.srt",srt("BluRay"),5,6);
   check(store.save(target,List.of(new Pair<>(a,6),new Pair<>(b,6)))==2);
   check(store.options(media("e6","Episode","100",true),"p",false).size()==2);
   ManualSubtitleFile sameBytes=new ManualSubtitleFile("S05E06.AMZN.srt",srt("WEB"),5,6);
   check(store.save(target,List.of(new Pair<>(sameBytes,6)))==1);
   check(store.options(media("e6","Episode","100",true),"p",false).size()==3);
   ManualSubtitleTarget movie=new ManualSubtitleTarget("movie","p","hd","Homem-Aranha HD",2002,"123",null,null,Collections.emptyList(),false);
   check(store.save(movie,List.of(new Pair<>(new ManualSubtitleFile("filme.srt",srt("Filme"),null,null),0)))==1);
   check(store.options(media("4k","Homem-Aranha 4K","123",false),"p",false).size()==1);
   check(store.options(media("hdr","Homem-Aranha 4K HDR","123",false),"other-list",false).size()==1);
   check(store.options(media("hdr","Homem-Aranha 4K HDR","456",false),"p",false).isEmpty());
   check(store.options(media("hd","Homem-Aranha HD","456",false),"p",false).isEmpty());
   check(store.options(media("hdr","Homem-Aranha 4K HDR",null,false),"p",false).isEmpty());
   check(store.options(media("hdr","Homem-Aranha 4K HDR","123",false),"p",true).isEmpty());
   check(new ManualSubtitleStore(context).options(media("4k","Homem-Aranha 4K","123",false),"p",false).size()==1);
   List<ExternalSubtitleOption> options=store.options(media("4k","Homem-Aranha 4K","123",false),"p",false);
   String id=options.get(0).getProviderId();check(store.read(id)!=null);
   File file=new File(context.getFilesDir(),"iptv_subtitles_lru_5mb/"+id+".srt");check(file.delete());store.removeReferences(Set.of(id));
   check(store.options(media("4k","Homem-Aranha 4K","123",false),"p",false).isEmpty());
   check(store.options(media("e6","Episode","100",true),"p",false).size()==3);
   System.out.println("PASS real compiled manual store + real disk budget: multiple variants per episode, save/reopen, HD/4K/HDR verified sharing, conflicting IDs, no name-only/Kids cross-match and individual removal.");
  }finally{remove(context.getFilesDir().getParentFile());}
 }
}
