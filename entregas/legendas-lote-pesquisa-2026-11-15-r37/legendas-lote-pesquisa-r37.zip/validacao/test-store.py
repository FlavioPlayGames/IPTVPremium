from pathlib import Path
import subprocess,os
r=Path('/workspace/iptv-visual-r32');v=r/'validacao/r37';tools=Path('/workspace/iptv-tools');java=str(tools/'jdk25/bin/java');android=Path('/workspace/android-sdk/platforms/android-37.0/android.jar')
fake=v/'preferences-host';fake.mkdir(exist_ok=True)
def run(args):
 x=subprocess.run(args,capture_output=True,text=True);print((x.stdout+x.stderr)[-1800:]);assert x.returncode==0
run([str(tools/'jdk25/bin/javac'),'-cp',str(android),'-d',str(fake),str(v/'preferences-fake/android/content/Context.java')])
classes=r/'app/build/intermediates/built_in_kotlinc/desempenho/compileDesempenhoKotlin/classes'
jars=[fake,classes]+list(tools.glob('*.jar'))+list(Path('/workspace/.gradle-cache/caches/9.6.0/transforms').glob('*/transformed/*-runtime.jar'))+[android]
cp=os.pathsep.join(map(str,jars))
assert (classes/'br/com/flaviotorres/iptvpremium/core/player/ManualSubtitleStore.class').exists(), 'Wait for final Kotlin compilation before testing its output'
run([str(tools/'jdk25/bin/javac'),'-cp',cp,'-d',str(fake),str(v/'ManualStoreVerify.java')])
run([java,'-cp',cp,'br.com.flaviotorres.iptvpremium.core.player.ManualStoreVerify'])
