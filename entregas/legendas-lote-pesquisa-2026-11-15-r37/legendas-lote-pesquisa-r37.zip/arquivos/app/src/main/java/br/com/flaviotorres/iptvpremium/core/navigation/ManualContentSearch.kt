package br.com.flaviotorres.iptvpremium.ui.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.paging.LoadState
import androidx.paging.map
import androidx.paging.compose.collectAsLazyPagingItems
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.data.repository.*
import br.com.flaviotorres.iptvpremium.data.cache.PosterKind
import br.com.flaviotorres.iptvpremium.ui.components.*
import br.com.flaviotorres.iptvpremium.ui.movies.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.CancellationException

private data class ManualSearchItem(val id:String,val name:String,val year:Int?,val tmdb:String?,val imdb:String?,val poster:String?)

/** Only the selected cover is loaded. Result rows have no thumbnails and never start a poster fan-out. */
@Composable
internal fun ManualContentSearch(repository:PlaylistCatalogRepository,playlist:String,kind:String,access:Any,
    query:String,onQuery:(String)->Unit,keyboard:Boolean,onKeyboard:(Boolean)->Unit,first:FocusRequester,
    modifier:Modifier=Modifier,onChoose:(String,String,Int?,String?)->Unit) {
    val settled by produceState(query,query){delay(300);value=query}
    var selected by remember(playlist,kind,settled,access){mutableStateOf<ManualSearchItem?>(null)}
    val flow=remember(repository,playlist,kind,settled,access) {
        if(kind=="movie")repository.movies(playlistId=playlist,searchQuery=settled).map{page->page.map{ManualSearchItem(it.id,it.name,it.year,it.tmdbId,it.imdbId,it.posterUrl)}}
        else repository.series(playlistId=playlist,searchQuery=settled).map{page->page.map{ManualSearchItem(it.id,it.name,it.year,it.tmdbId,it.imdbId,it.posterUrl)}}
    }
    val paging=flow.collectAsLazyPagingItems()
    LaunchedEffect(keyboard){if(!keyboard){withFrameNanos{};first.requestFocus()}}
    LaunchedEffect(paging.itemCount,settled){if(selected==null&&paging.itemCount>0)selected=paging[0]}
    Column(modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            SubtitleActionButton(query.ifBlank{if(kind=="movie")"Buscar filme"else"Buscar série"},leadingIcon=SubtitleSettingsIcon.SEARCH,
                modifier=Modifier.weight(1f).focusRequester(first)){onKeyboard(!keyboard)}
            SubtitleActionButton("Limpar",compact=true,modifier=Modifier.width(90.dp)){onQuery("")}
        }
        Text("Pesquise no catálogo da lista ativa.",color=SubtitleVisual.muted,fontSize=12.sp)
        if(keyboard) {
            AppKeyboard(actionText="PESQUISAR",currentText=query,onCharacter={onQuery((query+it).take(100))},onBackspace={onQuery(query.dropLast(1))},
                onReplaceAll={onQuery(it.take(100))},onClearAll={onQuery("")},themeBorders=true,onAction={onKeyboard(false)},
                modifier=Modifier.weight(1f).verticalScroll(rememberScrollState()))
        } else Row(Modifier.weight(1f).fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(16.dp)) {
            SubtitleSurfacePanel(Modifier.weight(.60f).fillMaxHeight()) {
                Text("Resultados",color=SubtitleVisual.ink,fontSize=18.sp)
                LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                    items(paging.itemCount,key={paging.peek(it)?.id?:"loading-$it"}){index->paging[index]?.let {item->
                        SubtitleActionButton(item.name,description=listOfNotNull(item.year?.toString(),if(kind=="movie")"Filme"else"Série").joinToString(" · "),
                            onFocused={selected=item}){selected=item}
                    }}
                    item{when{
                        paging.loadState.refresh is LoadState.Loading->Text("Carregando…",color=SubtitleVisual.muted)
                        paging.loadState.refresh is LoadState.Error->SubtitleActionButton("Tentar novamente"){paging.retry()}
                        paging.itemCount==0->Text("Nenhum resultado encontrado.",color=SubtitleVisual.muted)
                    }}
                }
            }
            SubtitleSurfacePanel(Modifier.weight(.40f).fillMaxHeight()) {
                Text("Selecionado",color=SubtitleVisual.ink,fontSize=18.sp)
                val item=selected
                if(item==null)Text("Selecione um conteúdo.",color=SubtitleVisual.muted,fontSize=14.sp)
                else {
                    Row(horizontalArrangement=Arrangement.spacedBy(12.dp),verticalAlignment=Alignment.CenterVertically) {
                        key(item.id,item.poster,item.tmdb) {ManualSelectedCover(item,kind,Modifier.width(74.dp).aspectRatio(2f/3f))}
                        Column(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(7.dp)) {
                            Text(item.name,color=SubtitleVisual.ink,fontSize=17.sp,maxLines=3)
                            Text(listOfNotNull(if(kind=="movie")"Filme"else"Série",item.year?.toString()).joinToString(" · "),color=SubtitleVisual.muted,fontSize=12.sp)
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    Text(if(kind=="movie")"Continue para enviar a legenda."else"Escolha a temporada ou o episódio na próxima etapa.",color=SubtitleVisual.muted,fontSize=12.sp)
                    SubtitleActionButton("Continuar") {
                        val verified=item.tmdb?.takeIf{(it.toLongOrNull()?:0)>0}?:if(kind=="movie")MovieCatalogPosterResolver.peek(item.name,item.year,item.tmdb,item.imdb)?.tmdbId?.toString()else null
                        onChoose(item.id,item.name,item.year,verified)
                    }
                }
            }
        }
    }
}

@Composable
private fun ManualSelectedCover(item:ManualSearchItem,kind:String,modifier:Modifier) {
    val context=LocalContext.current.applicationContext
    val posterKind=if(kind=="movie")PosterKind.MOVIES else PosterKind.SERIES
    val binding=if(kind=="movie")MoviePosterBindingCache.key("manual-search",item.id,item.poster,item.name,item.year,item.tmdb,item.imdb)else null
    var image by remember{mutableStateOf(peekCatalogPoster(item.poster,posterKind,item.name,item.year,item.tmdb,item.imdb,bindingKey=binding))}
    var loading by remember{mutableStateOf(image==null)}
    LaunchedEffect(item.id,item.poster) {
        try {delay(180);image=loadCatalogPoster(context,item.poster,posterKind,item.name,item.year,item.tmdb,item.imdb,onProviderReady={image=it},bindingKey=binding)}
        catch(cancelled:CancellationException){throw cancelled}
        catch(_:Exception){image=null}
        finally{loading=false}
    }
    Box(modifier.clip(RoundedCornerShape(7.dp)).background(SettingsLook.control),contentAlignment=Alignment.Center) {
        image?.let{Image(it,null,Modifier.fillMaxSize(),contentScale=ContentScale.Crop)}?:Text(if(loading)"Carregando capa…"else"Capa indisponível",color=SubtitleVisual.muted,fontSize=11.sp,modifier=Modifier.padding(6.dp))
    }
}
