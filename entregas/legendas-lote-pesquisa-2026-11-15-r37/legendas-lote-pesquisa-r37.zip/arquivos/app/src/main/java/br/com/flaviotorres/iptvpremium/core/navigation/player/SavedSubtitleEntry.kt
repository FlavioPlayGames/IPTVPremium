package br.com.flaviotorres.iptvpremium.core.player

internal data class SavedSubtitleEntry(val id:String,val label:String,val manual:Boolean)
