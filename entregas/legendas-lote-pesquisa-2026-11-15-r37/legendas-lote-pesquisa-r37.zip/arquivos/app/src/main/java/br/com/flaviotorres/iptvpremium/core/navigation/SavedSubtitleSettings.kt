package br.com.flaviotorres.iptvpremium.ui.settings

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.core.player.*
import br.com.flaviotorres.iptvpremium.ui.components.SettingsLook
import kotlinx.coroutines.*

@Composable
internal fun SavedSubtitleSettings(onBack:()->Unit) {
    val context=LocalContext.current.applicationContext
    val repo=remember(context){ExternalSubtitleRepository(context)}
    val scope=rememberCoroutineScope()
    var entries by remember{mutableStateOf<List<SavedSubtitleEntry>>(emptyList())}
    var selected by remember{mutableStateOf<Set<String>>(emptySet())}
    var pending by remember{mutableStateOf<Set<String>?>(null)}
    var loading by remember{mutableStateOf(true)}
    var busy by remember{mutableStateOf(false)}
    var message by remember{mutableStateOf("")}
    val first=remember{FocusRequester()}
    BackHandler {if(!busy){if(pending!=null)pending=null else onBack()}}
    LaunchedEffect(repo){entries=withContext(Dispatchers.IO){repo.savedDownloads()};loading=false}
    LaunchedEffect(loading){if(!loading){withFrameNanos{};first.requestFocus()}}
    SubtitleSettingsFrame("ARQUIVOS DE LEGENDAS","",{if(!busy)onBack()}) {
        Text("Arquivos enviados manualmente e baixados pelos provedores, salvos neste aparelho.",color=SubtitleVisual.muted,fontSize=13.sp)
        Row(horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            SubtitleActionButton(if(selected.size==entries.size&&selected.isNotEmpty())"Limpar seleção"else"Selecionar todas",compact=true,
                modifier=Modifier.weight(1f).focusRequester(first),enabled=!busy&&!loading){selected=if(selected.size==entries.size)emptySet()else entries.map{it.id}.toSet()}
            SavedSubtitleDelete("Excluir selecionadas",!busy&&selected.isNotEmpty(),Modifier.weight(1f)){pending=selected}
            SavedSubtitleDelete("Excluir tudo",!busy&&entries.isNotEmpty(),Modifier.weight(1f)){pending=entries.map{it.id}.toSet()}
        }
        Text(if(loading)"Carregando…"else"${entries.size} arquivo(s) · ${selected.size} selecionado(s)",color=SubtitleVisual.muted,fontSize=12.sp)
        LazyColumn(Modifier.weight(1f),verticalArrangement=Arrangement.spacedBy(8.dp)) {
            items(entries,key={it.id}) {entry->Row(horizontalArrangement=Arrangement.spacedBy(8.dp),verticalAlignment=Alignment.CenterVertically) {
                SubtitleActionButton(entry.label,description=if(entry.manual)"Envio manual"else"Download",checked=entry.id in selected,enabled=!busy,modifier=Modifier.weight(1f)) {
                    selected=if(entry.id in selected)selected-entry.id else selected+entry.id
                }
                SavedSubtitleDelete("Excluir",!busy,Modifier.width(90.dp)){pending=setOf(entry.id)}
            }}
        }
        if(message.isNotBlank())Text(message,color=SubtitleVisual.muted,fontSize=13.sp)
        if(!loading&&entries.isEmpty())Text("Nenhuma legenda salva.",color=SubtitleVisual.muted,fontSize=15.sp)
    }
    pending?.let {ids->
        val cancel=remember{FocusRequester()}
        LaunchedEffect(ids){withFrameNanos{};cancel.requestFocus()}
        Dialog(onDismissRequest={if(!busy)pending=null},properties=DialogProperties(usePlatformDefaultWidth=false)) {
            SubtitleSurfacePanel(Modifier.widthIn(max=520.dp).fillMaxWidth(.90f)) {
                Text("Excluir ${ids.size} legenda(s)?",color=SubtitleVisual.ink,fontSize=21.sp)
                Text("Os arquivos serão removidos deste aparelho. Se compartilhados, deixarão de estar disponíveis nas versões vinculadas. Contas, chaves e histórico serão mantidos.",color=SubtitleVisual.muted,fontSize=14.sp)
                Row(horizontalArrangement=Arrangement.spacedBy(12.dp)) {
                    SubtitleActionButton("Cancelar",enabled=!busy,modifier=Modifier.weight(1f).focusRequester(cancel)){pending=null}
                    SavedSubtitleDelete(if(busy)"Excluindo…"else"Excluir",!busy,Modifier.weight(1f)) {
                        scope.launch {
                            busy=true
                            try{
                                val count=withContext(Dispatchers.IO){repo.deleteDownloads(ids)}
                                entries=withContext(Dispatchers.IO){repo.savedDownloads()};selected=emptySet();pending=null
                                message="$count arquivo(s) excluído(s)."+if(count<ids.size)" Os demais estão em uso ou já foram removidos; confira a lista."else""
                            }catch(cancelled:CancellationException){throw cancelled}
                            catch(_:Exception){message="Não foi possível concluir a exclusão. Tente novamente.";pending=null}
                            finally{busy=false;withFrameNanos{};first.requestFocus()}
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SavedSubtitleDelete(label:String,enabled:Boolean,modifier:Modifier=Modifier,onClick:()->Unit) {
    var focused by remember{mutableStateOf(false)}
    val shape=RoundedCornerShape(8.dp)
    Row(modifier.heightIn(min=36.dp).onFocusChanged{focused=it.isFocused}
        .background(if(focused)SettingsLook.selection else SettingsLook.control,shape)
        .border(if(focused)1.5.dp else .7.dp,SettingsLook.border(focused),shape)
        .clickable(enabled=enabled,onClick=onClick).padding(8.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp,Alignment.CenterHorizontally)) {
        SubtitleSettingsGlyph(SubtitleSettingsIcon.TRASH,Modifier.size(17.dp),Color(0xFFE53935))
        Text(label,color=if(enabled)SubtitleVisual.ink else SubtitleVisual.muted.copy(alpha=.5f),fontSize=12.sp,maxLines=1)
    }
}
