package br.com.flaviotorres.iptvpremium.core.player

/** Basename wins over folder hints; ambiguous names remain reviewable, never guessed. */
internal fun manualSubtitleNumber(name:String):Pair<Int,Int>? {
    val pattern=Regex("(?i)(?<![a-z0-9])s([0-9]{1,3})[ ._-]*e([0-9]{1,4})(?![0-9])|(?<![0-9])([0-9]{1,3})x([0-9]{1,4})(?![0-9])")
    fun pairs(text:String)=pattern.findAll(text).map {m->
        m.groupValues[1].ifEmpty{m.groupValues[3]}.toInt() to m.groupValues[2].ifEmpty{m.groupValues[4]}.toInt()
    }.distinct().toList()
    val basename=name.replace('\\','/').substringAfterLast('/')
    if(Regex("(?i)s[0-9]+[ ._-]*e[0-9]+[ ._-]*e[0-9]+").containsMatchIn(basename))return null
    val own=pairs(basename)
    return if(own.isNotEmpty())own.singleOrNull()else pairs(name).singleOrNull()
}

internal fun manualSubtitleChoices(target:ManualSubtitleTarget,files:List<ManualSubtitleFile>):Map<Int,Int> =
    files.mapIndexedNotNull {index,file->target.validEpisode(file)?.let{index to it}}.toMap()

/** A verified work identifier only; resolution words and similar titles never establish identity. */
internal fun manualSubtitleWorkKey(kind:String,tmdb:String?,kids:Boolean,season:Int?,episode:Int?):String? {
    val id=tmdb?.trim()?.toLongOrNull()?.takeIf{it>0}?:return null
    return listOf("work-v2",if(kids)"kids"else"normal",kind,"tmdb:$id",
        if(kind=="movie")""else season?.toString().orEmpty(),if(kind=="movie")""else episode?.toString().orEmpty()).joinToString("\u0000")
}
