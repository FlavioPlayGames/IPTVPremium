package br.com.flaviotorres.iptvpremium.core.player

import java.io.File
private val savedSubtitleId=Regex("[a-f0-9]{64}")
internal fun savedSubtitleFiles(primary:File,legacy:File):List<File> =
    (primary.listFiles().orEmpty().toList()+legacy.listFiles().orEmpty().toList())
        .filter{it.isFile&&it.extension=="srt"&&savedSubtitleId.matches(it.nameWithoutExtension)}.distinctBy{it.name}

/** Never recurse or accept a caller path; temporary files and non-subtitle data are outside this operation. */
internal fun deleteSavedSubtitleFiles(primary:File,legacy:File,ids:Set<String>,delete:(File)->Boolean={it.delete()}):Set<String> {
    val allowed=savedSubtitleFiles(primary,legacy).map{it.nameWithoutExtension}.toSet()
    return ids.intersect(allowed).filter {id->
        val files=listOf(File(primary,"$id.srt"),File(legacy,"$id.srt"))
        files.forEach{if(it.isFile)delete(it)}
        files.none{it.exists()}
    }.toSet()
}
