﻿param([Parameter(Mandatory=$true)][string]$Backup)
$ErrorActionPreference = 'Stop'
$estado = Get-Content -Raw -LiteralPath (Join-Path $Backup 'estado.json') | ConvertFrom-Json
if ($estado.desfeito) { Write-Host 'Este backup ja foi restaurado.'; return }
function Hash([string]$Caminho) {
    if (Test-Path -LiteralPath $Caminho -PathType Leaf) { return (Get-FileHash -Algorithm SHA256 -LiteralPath $Caminho).Hash.ToLowerInvariant() }
    return $null
}
foreach ($item in $estado.arquivos) {
    if ($item.path -isnot [string] -or $item.path -notmatch '^app/src/main/java/[A-Za-z0-9_/]+\.kt$') { throw 'Caminho inesperado no backup.' }
    if ((Hash (Join-Path $estado.projeto $item.path)) -ne $item.afterHash) { throw "Arquivo modificado depois da aplicacao: $($item.path). Nada foi desfeito." }
    if ($null -ne $item.beforeHash -and (Hash (Join-Path "$Backup\originais" $item.path)) -ne $item.beforeHash) { throw "Backup invalido: $($item.path)" }
}
foreach ($item in $estado.arquivos) {
    $destino = Join-Path $estado.projeto $item.path
    if ($null -ne $item.beforeHash) { Copy-Item -LiteralPath (Join-Path "$Backup\originais" $item.path) -Destination $destino -Force }
    else { Remove-Item -LiteralPath $destino }
}
$estado.desfeito = $true
$estado | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $Backup 'estado.json')
Write-Host 'Fontes restaurados. Dados da TV nao foram alterados.'
