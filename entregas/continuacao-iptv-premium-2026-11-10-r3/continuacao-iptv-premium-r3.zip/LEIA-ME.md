# IPTV Premium — revisão r3

Base: os fontes com a primeira entrega/r2 aplicada. O pacote modifica 12 arquivos Kotlin e mantém pacote, configuração de versão, assinatura local e formatos existentes de dados. Não contém APK, lista M3U, credenciais, recursos grandes ou arquivos de configuração privados.

## O que mudou

### Capas M3U

A r2 retirava a imagem de 13 Horas, mas ainda escolhia outra URL entre os logos dos episódios. Isso não comprovava que a alternativa era uma capa de série e explica por que fotos de episódios continuavam aparecendo.

A r3 mantém imagens estáveis do provedor. Logos que variam entre episódios, imagens compartilhadas com filmes em séries distintas e formatos TMDB de paisagem são rejeitados como capa principal. Uma capa ausente/rejeitada recebe uma consulta verificada ao TMDB somente quando o card está visível, em segundo plano. Não há busca de todo o catálogo durante a importação ou pré-busca TMDB de todas as séries.

A identificação continua exigindo compatibilidade de título, ano e IDs quando disponíveis. A imagem usada é o poster da série ou da temporada assistida; não um still de episódio. Reutiliza os caches existentes, limita consultas simultâneas a duas e aguarda as prioridades de abertura do vídeo/importação. As capas estáveis do provedor continuam no fluxo existente.

**Uma imagem verificada não é garantida para todo título.** Se o TMDB estiver indisponível ou não identificar a obra com segurança, permanece a capa genérica. A rede do ambiente remoto bloqueou o acesso real ao TMDB; a aparência final precisa ser conferida na TV.

### Filmes e séries no Continuar

- Um progresso da própria lista não desaparece porque a reconciliação entre listas ainda não terminou. Antes de exibi-lo, o repositório confere que o item realmente existe no catálogo e rejeita conflitos de identidade/ano/IDs.
- Uma identidade registrada antes da reprodução, por exemplo ao favoritar, passa a aproveitar o ano e os IDs confirmados posteriormente no checkpoint. Só completa campos ausentes sem sobrescrever identificadores contraditórios.
- Foi removido o corte global de 400 registros do arquivo de histórico. A compactação mantém as mesmas regras de identidade, com índice para evitar comparar cada fato salvo com todo o histórico.
- O reinício explícito pelo botão Atualizar aguarda as gravações pendentes de progresso/favoritos antes de encerrar o processo.
- Normal e Kids permanecem separados; remoções explícitas e conteúdos concluídos continuam respeitados. Os limiares de início/conclusão não foram alterados.

Se uma versão anterior já descartou um registro pelo limite de 400 e não restar uma cópia utilizável no histórico, este pacote não consegue inventar esse registro. Ele corrige a apresentação dos fatos ainda existentes e impede esse novo descarte. O diagnóstico incluído ajuda a distinguir falta no armazenamento de filtragem na apresentação.

### Temporada no Continuar e Home

O card do Continuar usa uma identidade de arte separada dos metadados exibidos: mantém exatamente os campos, inclusive valores nulos, usados pelo catálogo ao preparar a temporada. Isso evita misturar um ID/ano histórico com uma chave de cache diferente.

O botão Atualizar da Home continua limpando somente caches. Agora seu reinício solicita a Home explicitamente, em vez de restaurar a última aba. O estado de navegação anterior é descartado somente nesse reinício manual; histórico, listas, favoritos e configurações permanecem. A retomada normal do aplicativo e a atualização silenciosa mantêm seus caminhos existentes. O controle parental continua sendo aplicado.

Não houve alteração do transporte Xtream, dos codecs, bitrate/resolução ou do cache RAM de temporadas do player.

## Aplicar e instalar

Baixe `continuacao-iptv-premium-r3.zip` em Downloads. No PowerShell:

```powershell
$projeto = "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium"
$pasta = "$env:USERPROFILE\Downloads\continuacao-iptv-premium-r3"
Unblock-File -LiteralPath "$pasta.zip"
Expand-Archive -LiteralPath "$pasta.zip" -DestinationPath $pasta -Force
Set-Location $pasta
powershell -ExecutionPolicy Bypass -File .\Aplicar.ps1 -Projeto "$projeto"
if ($LASTEXITCODE -eq 0) {
    powershell -ExecutionPolicy Bypass -File .\Instalar-TV.ps1 -Projeto "$projeto"
} else {
    throw "A aplicacao falhou. Confira a mensagem antes de compilar/instalar."
}
```

O script de instalação está **na pasta extraída em Downloads**. O comando acima muda para essa pasta antes de executá-lo; não presume um arquivo inexistente na raiz do projeto.

Aplicar.ps1 confere os hashes da base e do pacote antes de copiar, cria backup e mostra o comando de reversão. Se a base divergir, não force a aplicação. O instalador aceita -Projeto, identifica a TV conectada, compila assembleDesempenho usando sua configuração/assinatura locais, escolhe o APK pela ABI e instala com `adb install -r`. Não desinstala nem limpa dados para contornar recusa de assinatura.

Para executar o Lint localmente também:

```powershell
Set-Location $projeto
.\gradlew.bat :app:compileDesempenhoKotlin :app:lintDesempenho
```

Para desfazer os fontes, use o backup indicado ao aplicar:

```powershell
powershell -ExecutionPolicy Bypass -File "$pasta\Desfazer.ps1" -Backup "CAMINHO_DO_BACKUP"
```

## Teste na TV

1. **M3U: abra Minhas Listas → selecione a lista → Atualizar lista.** Isso reimporta os campos de capa. O botão Atualizar da Home só limpa caches e não substitui essa etapa.
2. Abra o catálogo de séries e aguarde o carregamento das capas visíveis. Confira os exemplos anteriores e navegue para outros cards; a consulta é feita à medida que aparecem.
3. Assista a um filme por pelo menos 15 segundos, pare antes do fim e abra Continuar. Repita com uma série. Faça isso nos dois formatos e no mesmo perfil em que assistiu.
4. Troque de lista e confirme somente os títulos que essa lista realmente possui. Correspondências ambíguas continuam sendo omitidas para não misturar obras.
5. Confira a temporada no Continuar após sair/reabrir; teste também Kids separadamente.
6. Use Atualizar na Home e confirme o retorno à Home e a preservação dos progressos. Confira a navegação de temporadas no player.

A entrega tem compilação/Lint e testes JVM, mas não foi instalada fisicamente na sua TV pelo ambiente remoto.

## Se ainda faltar algum item ou capa

Depois de reproduzir o problema e abrir o catálogo/Continuar, execute na pasta extraída:

```powershell
powershell -ExecutionPolicy Bypass -File .\Coletar-Diagnostico.ps1
```

O arquivo será salvo em `C:\Users\flavi\Downloads\IPTV-diagnostico.txt` no seu usuário. O coletor exporta apenas contagens e estados públicos de arte/API com formato estrito. Não exporta logs completos, títulos assistidos, URLs de reprodução, senhas, chaves ou tokens. Ele não modifica dados na TV.

Leia `VALIDACAO.md` para os resultados e limites dos testes. Não houve promoção para a versão oficial nem publicação do site.
