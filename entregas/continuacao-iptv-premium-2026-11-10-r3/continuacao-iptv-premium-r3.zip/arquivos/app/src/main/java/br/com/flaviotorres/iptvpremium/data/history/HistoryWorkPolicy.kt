package br.com.flaviotorres.iptvpremium.data.history

internal fun historyIdentityConflict(a:ContentIdentity,b:ContentIdentity):Boolean {
    if(a.kind!=b.kind)return true
    if(a.imdbKey!=null && b.imdbKey!=null && a.imdbKey!=b.imdbKey)return true
    if(a.tmdbKey!=null && b.tmdbKey!=null && a.tmdbKey!=b.tmdbKey)return true
    val external=a.imdbKey!=null && a.imdbKey==b.imdbKey || a.tmdbKey!=null && a.tmdbKey==b.tmdbKey
    return !external && a.normalizedYear!=null && b.normalizedYear!=null && a.normalizedYear!=b.normalizedYear
}
internal fun sameHistoryWork(a:ContentIdentity,b:ContentIdentity):Boolean {
    if(a.kind!=b.kind)return false
    if(a.imdbKey!=null && b.imdbKey!=null && a.imdbKey!=b.imdbKey)return false
    if(a.tmdbKey!=null && b.tmdbKey!=null && a.tmdbKey!=b.tmdbKey)return false
    if(a.imdbKey!=null && a.imdbKey==b.imdbKey || a.tmdbKey!=null && a.tmdbKey==b.tmdbKey)return true
    if(a.normalizedYear!=null && b.normalizedYear!=null && a.normalizedYear!=b.normalizedYear)return false
    if(a.kind=="movies" && a.providerAssetKey!=null && a.providerAssetKey==b.providerAssetKey)return true
    return a.normalizedYear!=null && a.normalizedYear==b.normalizedYear && a.sharesTitle(b)
}
internal data class HistoryWorkLink(val key:String,val identity:ContentIdentity,val updated:Long)
/** All members must agree, so an incomplete title cannot bridge two remakes. */
internal fun canonicalHistoryRepresentatives(items:List<HistoryWorkLink>):Map<String,String> {
    val groups=mutableListOf<MutableList<HistoryWorkLink>>()
    for(item in items.sortedByDescending{it.updated}) {
        val group=groups.firstOrNull{members->members.all{sameHistoryWork(it.identity,item.identity)}}
        if(group==null)groups.add(mutableListOf(item))else group.add(item)
    }
    return groups.flatMap{group->group.map{it.key to group.first().key}}.toMap()
}
private fun historyQuality(title:String):Int? {
    val t=title.lowercase()
    return when {Regex("\\b(?:4k|uhd|2160p)\\b").containsMatchIn(t)->2160
        Regex("\\b(?:fhd|1080p)\\b").containsMatchIn(t)->1080
        Regex("\\b(?:hd|720p)\\b").containsMatchIn(t)->720
        Regex("\\bsd\\b").containsMatchIn(t)->480
        else->null}
}
internal fun preferredHistoryVariantIndex(source:String,candidates:List<Pair<String,Int?>>):Int? {
    val quality=historyQuality(source)
    val subtitled=ContentIdentity.isSubtitled(source)
    return candidates.indices.minWithOrNull(compareBy<Int>{ContentIdentity.isSubtitled(candidates[it].first)!=subtitled}
        .thenBy{quality!=null && historyQuality(candidates[it].first)!=quality}
        .thenBy{candidates[it].second?:Int.MAX_VALUE}.thenBy{it})
}
/** Select the newest event before filtering; finished events must supersede older unfinished episodes. */
fun latestHistorySeries(entries:List<WatchHistoryEntry>):List<WatchHistoryEntry> = entries
    .filter{it.contentType==br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType.EPISODE && !it.seriesId.isNullOrBlank()}
    .sortedByDescending{it.updatedAtMs}.distinctBy{it.seriesId}

/** Own-list fallback still rejects a recycled provider ID; it never invents catalogue rows. */
internal fun historyMatchesCatalog(entry:WatchHistoryEntry,current:ContentIdentity):Boolean {
    val title=if(entry.contentType==br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType.EPISODE)entry.seriesTitle.orEmpty()else entry.title
    val saved=ContentIdentity(current.kind,title,entry.year,tmdb=entry.tmdbId)
    if(historyIdentityConflict(saved,current))return false
    if(saved.tmdbKey!=null && saved.tmdbKey==current.tmdbKey)return true
    return title.isBlank() || saved.sharesTitle(current)
}

private data class HistoryFactBucket(val type:br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType,
    val season:Int?,val episode:Int?,val facet:String,val value:String)

/** Index only saved facts, not the catalogue. All candidates retain the full identity checks. */
internal fun compactHistoryFacts(raw:List<WatchHistoryEntry>,identityOf:(WatchHistoryEntry)->ContentIdentity):List<WatchHistoryEntry> {
    val kept=mutableListOf<WatchHistoryEntry>()
    val index=HashMap<HistoryFactBucket,MutableList<ContentIdentity>>()
    for(entry in raw.sortedByDescending{it.updatedAtMs}) {
        val movie=entry.contentType==br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType.MOVIE
        if(!movie && (entry.seasonNumber==null || entry.episodeNumber==null)){kept.add(entry);continue}
        val identity=identityOf(entry)
        val keys=mutableListOf<HistoryFactBucket>()
        fun key(facet:String,value:String)=HistoryFactBucket(entry.contentType,if(movie)null else entry.seasonNumber,
            if(movie)null else entry.episodeNumber,facet,value)
        identity.imdbKey?.let{keys+=key("imdb",it)}
        identity.tmdbKey?.let{keys+=key("tmdb",it)}
        if(movie)identity.providerAssetKey?.let{keys+=key("asset",it)}
        identity.normalizedYear?.let{year->identity.normalizedTitles.forEach{keys+=key("title:$year",it)}}
        if(keys.any{bucket->index[bucket].orEmpty().any{sameHistoryWork(identity,it)}})continue
        kept.add(entry)
        keys.forEach{index.getOrPut(it){mutableListOf()}.add(identity)}
    }
    return kept
}
