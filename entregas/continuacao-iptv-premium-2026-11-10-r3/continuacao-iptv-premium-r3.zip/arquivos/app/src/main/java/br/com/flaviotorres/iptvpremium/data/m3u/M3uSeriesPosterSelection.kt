package br.com.flaviotorres.iptvpremium.data.m3u

import java.net.URI

/** Import-scoped evidence only. No network, title guessing or persistent blacklist. */
internal class M3uSeriesPosterSelection {
    private val movieImages = HashSet<String>()
    private val firstSeries = HashMap<String, String>()
    private val sharedSeriesImages = HashSet<String>()
    private val tmdbPath = Regex("^/t/p/[^/]+/([A-Za-z0-9_-]+\\.(?:jpg|png|webp))$")

    class Candidates {
        internal val urls = LinkedHashSet<String>()
        internal var firstImage: String? = null
        internal var varied = false
    }

    fun movie(url: String?) { key(url)?.let(movieImages::add) }

    fun series(candidates: Candidates, name: String, url: String?) {
        val value = url?.trim() ?: return
        if (value in candidates.urls || (candidates.varied && candidates.urls.size >= 8)) return
        val image = key(value) ?: return
        if (candidates.firstImage == null) candidates.firstImage = image
        else if (candidates.firstImage != image) candidates.varied = true
        if (candidates.urls.size >= 8) return
        val previous = firstSeries.putIfAbsent(image, name)
        if (previous != null && previous != name) sharedSeriesImages.add(image)
        // Bound alternatives instead of retaining every episode image in memory.
        candidates.urls.add(value)
    }

    // Different episode logos cannot establish a series poster. Never pick a random episode image.
    fun select(candidates: Candidates): String? = if (candidates.varied) null else candidates.urls.firstOrNull { url ->
        val image = key(url)
        M3uSeriesImagePolicy.catalogueImage(url) && (image !in movieImages || image !in sharedSeriesImages)
    }

    private fun key(raw: String?): String? {
        val url = raw?.trim()?.takeIf { it.startsWith("https://", true) || it.startsWith("http://", true) }
            ?: return null
        val uri = runCatching { URI(url) }.getOrNull() ?: return null
        if (uri.host.isNullOrBlank()) return null
        // TMDB sizes refer to the same public image. Other providers keep the complete URL.
        return if (uri.host.equals("image.tmdb.org", true)) {
            tmdbPath.matchEntire(uri.path.orEmpty())?.groupValues?.get(1)?.let { "tmdb:$it" } ?: url
        } else url
    }
}
