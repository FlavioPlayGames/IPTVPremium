package br.com.flaviotorres.iptvpremium.ui.movies

import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.remote.TmdbClientProvider
import br.com.flaviotorres.iptvpremium.data.repository.SeriesCatalogPosterResolver
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

private val verifiedPosterSlots=Semaphore(2)
internal val SeasonPosterRevision=MutableStateFlow(0L)
internal fun peekCatalogPoster(url:String?,kind:PosterKind,name:String,year:Int?,tmdbId:String?,imdbId:String?,season:Int?=null):ImageBitmap? {
    val missingProvider= !GenericPosterPolicy.hasSource(url)
    val seasonal=if(kind==PosterKind.SERIES&&(season!=null||missingProvider))SeriesCatalogPosterResolver.peek(name,year,tmdbId,imdbId,season)?.takeIf{missingProvider||it.isSeason}else null
    return seasonal?.let{MoviePosterLoader.peekBitmap(it.url)}?:MoviePosterLoader.peekBitmap(url)
}

/** Valid provider covers stay first. Only visible missing/rejected covers get a verified fallback. */
internal suspend fun loadCatalogPoster(context:Context,url:String?,kind:PosterKind,name:String,year:Int?,tmdbId:String?,imdbId:String?,season:Int?=null,onProviderReady:(ImageBitmap)->Unit={}):ImageBitmap? {
    if(kind!=PosterKind.SERIES)return MoviePosterLoader.loadWithRetry(context,url,kind)
    if(!GenericPosterPolicy.hasSource(url)) {
        val prepared=SeriesCatalogPosterResolver.cached(name,year,tmdbId,imdbId,season)
        prepared?.let{MoviePosterLoader.loadWithRetry(context,it.url,kind)}?.let{return it}
        MediaOpeningPriority.awaitIdle();CatalogImportPriority.busy.first{!it}
        return verifiedPosterSlots.withPermit {
            try {
                withTimeoutOrNull(15_000L) {
                    val verified=SeriesCatalogPosterResolver.resolve(name,year,tmdbId,imdbId,TmdbClientProvider.client::get,season)
                        ?:return@withTimeoutOrNull null
                    MoviePosterLoader.loadWithRetry(context,verified.url,kind)
                }
            }catch(cancelled:CancellationException){throw cancelled}
            catch(_:Exception){null}
        }
    }
    if(season==null)return MoviePosterLoader.loadWithRetry(context,url,kind)
    val prepared=SeriesCatalogPosterResolver.cached(name,year,tmdbId,imdbId,season)?.takeIf{it.isSeason}
    prepared?.let{MoviePosterLoader.loadCached(context,it.url)}?.let{return it}
    val provider=MoviePosterLoader.loadWithRetry(context,url,kind)
    provider?.let(onProviderReady)
    // A stored public metadata lookup is local IO, not a search or a details request.
    return prepared?.let{MoviePosterLoader.loadWithRetry(context,it.url,kind)}?:provider
}

/** Called after an episode starts playing, never from an unvisited catalogue row. */
internal suspend fun warmPlayingSeasonPoster(context:Context,name:String,year:Int?,tmdbId:String?,imdbId:String?,season:Int) {
    if(season<0)return
    MediaOpeningPriority.awaitIdle();CatalogImportPriority.busy.first{!it}
    verifiedPosterSlots.withPermit {
        try {
            withTimeoutOrNull(15_000L){
                val poster=SeriesCatalogPosterResolver.resolve(name,year,tmdbId,imdbId,TmdbClientProvider.client::get,season)?.takeIf{it.isSeason}?:return@withTimeoutOrNull
                if(MoviePosterLoader.loadWithRetry(context,poster.url,PosterKind.SERIES)!=null)SeasonPosterRevision.update{it+1}
            }
        }catch(cancelled:CancellationException){throw cancelled}
        catch(_:Exception){ /* Optional artwork must never fail playback. */ }
    }
}
