﻿[CmdletBinding()]
param(
    [Alias('Tv')][string]$Serial = '',
    [string]$Adb = "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe",
    [string]$Saida = "$env:USERPROFILE\Downloads\IPTV-diagnostico.txt"
)
$ErrorActionPreference = 'Stop'
if (!(Test-Path -LiteralPath $Adb -PathType Leaf)) { throw "ADB nao encontrado: $Adb" }
function Ler-Adb([string[]]$Argumentos) {
    $anterior=$ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        $linhas=@(& $Adb @Argumentos 2>&1)
        $codigo=$LASTEXITCODE
    } finally { $ErrorActionPreference=$anterior }
    if($codigo -ne 0){throw 'Falha ao consultar o ADB.'}
    $linhas | ForEach-Object { "$_" }
}
$conectados=@(Ler-Adb -Argumentos @('devices','-l') | ForEach-Object {
    if($_ -match '^(\S+)\s+device(?:\s+(.*))?$') {[PSCustomObject]@{Serial=$Matches[1];Detalhes=[string]$Matches[2]}}
})
if([string]::IsNullOrWhiteSpace($Serial)) {
    $tv=@($conectados | Where-Object {$_.Detalhes -match '(?:^|\s)(?:model:Smart_TV_Pro|product:G08_4K_GB|device:G08)(?:\s|$)'})
    if($tv.Count -eq 1){$Serial=$tv[0].Serial}
    elseif($tv.Count -eq 0 -and $conectados.Count -eq 1){$Serial=$conectados[0].Serial}
    else{throw 'Nao foi possivel escolher uma unica TV autorizada. Confira adb devices -l ou informe -Serial.'}
}
if($Serial -notmatch '^[A-Za-z0-9._:-]+$' -or @($conectados | Where-Object {$_.Serial -eq $Serial}).Count -ne 1){throw 'TV nao conectada/autorizada.'}
# Read only the diagnostic tags, then retain strictly formatted public statuses/counts.
$linhas=@(Ler-Adb -Argumentos @('-s',$Serial,'logcat','-d','-v','raw','-s','ContinueTrace:I','SeriesPosterPerf:I','SeriesArtwork:D','*:S'))
$contagens=@($linhas | Where-Object {
    $_ -match '^profile=(?:normal|kids)(?: [a-z_]+=[0-9]+)+$' -or
    $_ -match '^fonte=tmdb http=[0-9]{3}$' -or
    $_ -match '^stage=identity status=(?:OK|UNRESOLVED) source=(?:REMOTE|CACHE) workHash=[0-9a-f]{12}(?: tmdbId=[0-9]+)?$'
})
if($contagens.Count -eq 0){throw 'Nenhum registro encontrado. Na versao desempenho r3, abra os catalogos/Continuar e deixe as capas carregarem depois de reproduzir o problema e tente novamente.'}
$contagens | Set-Content -LiteralPath $Saida -Encoding UTF8
Write-Host "Diagnostico filtrado salvo em: $Saida"
