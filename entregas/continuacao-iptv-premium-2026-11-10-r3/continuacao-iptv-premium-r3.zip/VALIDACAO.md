# Validação r3 — 10/11/2026

## Android

Executados com sucesso no projeto reconstruído com os arquivos fornecidos:

```text
:app:compileDesempenhoKotlin
:app:lintDesempenho
BUILD SUCCESSFUL
```

A compilação Kotlin/Java e o Lint passaram nos fontes finais. Relatório: **0 erros, 178 avisos e 6 sugestões**. Não foram suprimidos os avisos do projeto. Os dois avisos adicionais de UseKtx apontam os commits explícitos usados para aguardar as gravações antes do reinício.

Ferramentas: Gradle 9.6.0, AGP 9.4.1, JDK 25, Android SDK Platform 37.0. A versão/configuração de assinatura do projeto não foi alterada. Não houve geração de APK assinado no ambiente remoto, empacotamento/R8 final ou instalação física na TV. O instalador fará assembleDesempenho no computador que tem sua assinatura existente.

## Histórico: código real de vinculação

Diferente dos primeiros testes isolados da entrega anterior, esta etapa executou **SharedLibraryStore, WatchHistoryStore, HistoryProfileMigration e PlayerFavoriteMigration reais**, com Context/SharedPreferences e DAO de catálogo em memória. As consultas do adaptador reproduzem a seleção de candidatos/paginação usada pelo componente, mas não são execução de Room/SQLite no Android.

A base r2 falhou em cinco cenários reproduzidos:

1. Novo checkpoint local de filme ocultado enquanto os vínculos ainda não existem.
2. A mesma perda de apresentação para episódio/série.
3. Ano/ID do checkpoint ignorados quando a identidade do filme já tinha sido criada como favorito.
4. Série sem ano na identidade antiga não distinguida de um remake mesmo com metadados posteriores no checkpoint.
5. Gravação de 450 fatos reduzida a 400.

Os cinco passaram com a r3. Também passaram:

- remoção explícita permanece oculta;
- flush do reinício não altera os checkpoints armazenados;
- verificação contra remakes, IDs reciclados e obras diferentes;
- variante de qualidade e identificação por ID confirmado;
- compactação indexada produz exatamente o mesmo resultado da regra anterior em 2.200 fatos mistos, com anos, aliases, IDs e coordenadas de episódios;
- normal/Kids separados e próximo episódio pendente preservado após checkpoints repetidos;
- progresso anterior do sucessor mantido e sucessor concluído não recolocado na fila;
- filmes/séries concluídos mantêm a regra de apresentação existente.

A remoção do corte de 400 evita novas perdas por esse limite. Não comprova recuperação de fatos que uma versão anterior já removeu do aparelho. Também não prova que estes cinco cenários cobrem todas as causas possíveis no histórico específico da TV; por isso o diagnóstico por etapas foi incluído.

## Capas: fluxo real com serviços/bitmaps simulados

Foram executados o carregador CatalogPosterFallback e os componentes reais de identidade/cache de metadados. Rede e decodificação de bitmaps foram substituídas por adaptadores de teste.

Passaram:

- imagem válida do provedor tem prioridade e não inicia pesquisa TMDB;
- capa ausente/rejeitada recebe poster verificado da série;
- temporada preparada é reutilizada quando existe;
- mistura de ID/ano histórico com campos nulos do catálogo é reproduzida e evitada pela identidade canônica de arte;
- cards normal/Kids preservam os metadados exibidos e a identidade de arte separadamente;
- título incompatível com o ID não recebe imagem de outra obra;
- temporada inexistente preserva o provedor quando disponível;
- consultas opcionais aguardam abertura de vídeo/importação e não ultrapassam duas simultâneas;
- um novo processo JVM recupera a temporada do cache JSON em disco sem pesquisa remota.

Esses testes não verificam os bytes/imagens efetivamente entregues pelos provedores. O TMDB_READ_TOKEN existe na configuração fornecida, mas a tentativa de API real foi bloqueada no CONNECT do proxy (403), antes de validar o serviço/credencial. Nenhuma chave foi impressa ou incluída no pacote. A verificação visual real continua pendente na TV.

## Lista M3U completa

Executados os preparadores r2 e r3 sobre o ZIP enviado, com 85.921.420 bytes descompactados:

| Tipo | r2 | r3 |
|---|---:|---:|
| Canais | 2.355 | 2.355 |
| Filmes | 44.098 | 44.098 |
| Episódios | 283.538 | 283.538 |
| Séries | 9.804 | 9.804 |
| Categorias | 104 | 104 |

Os 329.991 itens foram preservados. Na comparação dos registros preparados, somente a coluna de capa de 6.865 séries mudou. A r3 preservou 2.679 imagens estáveis do provedor e deixou 7.125 séries para fallback verificado quando seus cards forem exibidos. Esse número não representa consultas antecipadas a 7.125 obras.

Os três exemplos anteriores passaram a rejeitar os logos variáveis, em vez de escolher outra foto de episódio. Não foi atribuído um poster TMDB real a esses exemplos neste ambiente, pois a API estava bloqueada.

Os arquivos de episódios e seus índices ficaram byte a byte idênticos. IDs, categorias, ordem, títulos, URLs de reprodução e demais campos não mudaram nessa comparação. O teste executou o parser, formato e armazenamento adiado reais; Log Android, anotações Room e descoberta XMLTV foram adaptados para JVM. O writer Room e a importação num dispositivo não foram executados.

Testes de seleção também cobriram imagem uniforme, tamanhos TMDB diferentes da mesma imagem, logos variáveis, placeholder compartilhado com filme, paisagem e variação após o oitavo candidato.

## Reinício, scripts e diagnóstico

O caminho real da Home foi inspecionado: CacheRestartActivity limpa caches e encerra o processo anterior. A r3 aguarda commits pendentes antes disso e envia uma intenção de abrir a Home. O fluxo normal de restauração permanece condicionado à ausência dessa intenção. Esse comportamento foi compilado e passou no Lint, mas sua navegação e a durabilidade do Android SharedPreferences não foram testadas fisicamente.

Aplicação/reversão verificadas em PowerShell 7 sobre cópias da base r2, também simulando a saída de arrays JSON do Windows PowerShell 5.1: hashes, reaplicação, reversão e recusas de base/edições divergentes. Windows PowerShell 5.1 nativo não foi executado.

O instalador -Projeto é o mesmo helper já testado com ADB/Gradle simulados: seleção automática, ABI, fallback universal, falha de build, recusa de assinatura, ambiguidade, aparelho não autorizado e avisos do daemon. O coletor foi executado com logs simulados contendo linhas indevidas; só reteve as contagens e os estados de API/arte permitidos pelo filtro.

ContinueTrace é emitido apenas em debug/desempenho e contém contagens do armazenamento, projeção e filtro do catálogo, com perfil normal/Kids. O coletor também admite o status HTTP do TMDB e o status público/hash de identidade de arte. URLs, títulos assistidos, contas e credenciais não fazem parte desses registros exportados.

## Reproduzir os testes JVM

Com Java, Python 3 e acesso ao Maven Central:

```powershell
python .\testes\Testar-Host.py --projeto "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium"
```

Para incluir a lista completa:

```powershell
python .\testes\Testar-Host.py --projeto "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium" --lista "CAMINHO_DO_Flavio8595-full.zip"
```

O runner extrai os modelos/funções reais dos cards dos fontes em teste, compila os componentes reais selecionados com os adaptadores indicados e remove os arquivos temporários ao sair. Não inclui a lista ou suas credenciais no pacote. A comparação r2 × r3 foi executada separadamente durante esta entrega; o runner testa os fontes atuais do projeto informado.

API real, download/decodificação real de imagens, instalação e comportamento visual na TV permanecem etapas distintas ainda não executadas aqui.
