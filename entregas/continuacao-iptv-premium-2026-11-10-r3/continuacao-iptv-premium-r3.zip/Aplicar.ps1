﻿param([string]$Projeto = "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium")
$ErrorActionPreference = 'Stop'
$Projeto = (Resolve-Path -LiteralPath $Projeto).Path
$itens = ConvertFrom-Json -InputObject (Get-Content -Raw -LiteralPath "$PSScriptRoot\manifesto.json")
$itens = @($itens)
function Hash([string]$Caminho) {
    if (Test-Path -LiteralPath $Caminho -PathType Leaf) { return (Get-FileHash -Algorithm SHA256 -LiteralPath $Caminho).Hash.ToLowerInvariant() }
    return $null
}
$aplicados = 0
foreach ($item in $itens) {
    if ($item.path -isnot [string] -or $item.path -notmatch '^app/src/main/java/[A-Za-z0-9_/]+\.kt$') { throw 'Caminho inesperado no manifesto.' }
    $destino = Join-Path $Projeto $item.path
    $origem = Join-Path "$PSScriptRoot\arquivos" $item.path
    if ((Hash $origem) -ne $item.afterHash) { throw "Arquivo do pacote alterado: $($item.path)" }
    $atual = Hash $destino
    if ($atual -eq $item.afterHash) { $aplicados++; continue }
    if ($atual -ne $item.beforeHash) { throw "Base diferente da recebida: $($item.path). Nenhum arquivo foi alterado." }
    if ((Test-Path -LiteralPath $destino) -and !(Test-Path -LiteralPath $destino -PathType Leaf)) { throw "Destino inesperado: $destino" }
}
if ($aplicados -eq $itens.Count) { Write-Host 'Este pacote ja esta aplicado.'; return }
if ($aplicados -gt 0) { throw 'Aplicacao parcial encontrada. Restaure a base antes de reaplicar.' }
$backup = Join-Path $Projeto ('.iptv-backups\continuacao-' + (Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $backup | Out-Null
foreach ($item in $itens) {
    if ($null -ne $item.beforeHash) {
        $copia = Join-Path "$backup\originais" $item.path
        New-Item -ItemType Directory -Path (Split-Path $copia) -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $Projeto $item.path) -Destination $copia
    }
}
@{ projeto = $Projeto; arquivos = $itens; desfeito = $false } | ConvertTo-Json -Depth 8 | Set-Content -Encoding UTF8 -LiteralPath "$backup\estado.json"
try {
    foreach ($item in $itens) {
        $destino = Join-Path $Projeto $item.path
        New-Item -ItemType Directory -Path (Split-Path $destino) -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path "$PSScriptRoot\arquivos" $item.path) -Destination $destino -Force
        if ((Hash $destino) -ne $item.afterHash) { throw "Falha na copia: $($item.path)" }
    }
} catch {
    foreach ($item in $itens) {
        $destino = Join-Path $Projeto $item.path
        if ($null -ne $item.beforeHash) { Copy-Item -LiteralPath (Join-Path "$backup\originais" $item.path) -Destination $destino -Force }
        elseif (Test-Path -LiteralPath $destino -PathType Leaf) { Remove-Item -LiteralPath $destino }
    }
    throw
}
Write-Host "Aplicado. Backup: $backup"
Write-Host "Para desfazer: & '$PSScriptRoot\Desfazer.ps1' -Backup '$backup'"
