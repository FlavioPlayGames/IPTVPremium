package host
import android.content.Context
import br.com.flaviotorres.iptvpremium.core.player.*
import br.com.flaviotorres.iptvpremium.data.history.*
import br.com.flaviotorres.iptvpremium.data.cache.dao.*
import br.com.flaviotorres.iptvpremium.data.repository.SeriesEpisodeInfo
import kotlinx.coroutines.runBlocking
fun main()=runBlocking {
 fun fresh():Context {
  for(name in listOf("instance","kidsInstance")){SharedLibraryStore::class.java.getDeclaredField(name).apply{isAccessible=true}.set(null,null)}
  return Context().also{it.getSharedPreferences("iptvpremium_history_profiles_v1",0).edit().putBoolean("continue_reset_v1",true).commit()}
 }
 fun fact(kind:PlaybackContentType,id:String,series:String?=null,year:Int?=2024,tmdb:String?=null)=WatchHistoryEntry("A",kind,id,series,"Example",seriesTitle=if(series!=null)"Example" else null,seasonNumber=if(series!=null)1 else null,episodeNumber=if(series!=null)1 else null,positionMs=25000,durationMs=100000,updatedAtMs=100,year=year,tmdbId=tmdb)
 var failures=0
 fun verify(name:String,value:Boolean){println("${if(value)"PASS"else"FAIL"}: $name");if(!value)failures++}
 // New local progress must not depend on a finished reconciliation pass.
 for(kind in listOf(PlaybackContentType.MOVIE,PlaybackContentType.EPISODE)) {
  val ctx=fresh();val library=SharedLibraryStore.get(ctx);val dao=PlaylistCacheDao()
  val h=fact(kind,if(kind==PlaybackContentType.MOVIE)"m"else"e",if(kind==PlaybackContentType.EPISODE)"s"else null)
  if(kind==PlaybackContentType.MOVIE)dao.movies["A"]=listOf(SharedCatalogIdentity("m","Example",2024,null,null,null))
  else dao.series["A"]=listOf(SharedCatalogIdentity("s","Example",2024,null,null,null))
  library.reconcile(dao,"A",emptyList(),kind=if(kind==PlaybackContentType.MOVIE)"movies"else"series")
  val store=WatchHistoryStore(ctx)
  store.save("A",PlaybackMedia(h.contentId,kind,h.title,seriesId=h.seriesId,seasonNumber=h.seasonNumber,episodeNumber=h.episodeNumber,year=h.year),25000,100000,h.seriesTitle)
  verify("local saved $kind survives reconciliation gap",store.all("A").any{it.contentId==h.contentId && it.positionMs==25000L})
 }
 // A favorite identity cached before playback has no year/ID; checkpoint now has verified metadata.
 run {
  val ctx=fresh();val l=SharedLibraryStore.get(ctx);val d=PlaylistCacheDao()
  d.movies["A"]=listOf(SharedCatalogIdentity("m","Example",null,null,null,null,streamUrl="https://provider.example/movie/a/b/1.mp4"))
  d.movies["B"]=listOf(SharedCatalogIdentity("other","Example",2024,null,null,null,streamUrl="https://other.example/movie/a/b/9.mp4"))
  l.setFavorite(d,"A","movies","m",true)
  val h=fact(PlaybackContentType.MOVIE,"m",year=2024,tmdb="123")
  l.reconcile(d,"B",listOf(h),kind="movies")
  verify("movie checkpoint metadata enriches previously cached favorite identity",l.projectHistory("B",listOf(h)).any{it.contentId=="other"})
 }
 run {
  val ctx=fresh();val l=SharedLibraryStore.get(ctx);val d=PlaylistCacheDao()
  d.series["A"]=listOf(SharedCatalogIdentity("s","Example",null,null,null,null))
  d.series["B"]=listOf(SharedCatalogIdentity("s2010","Example",2010,null,null,null),SharedCatalogIdentity("s2024","Example",2024,null,"123",null))
  l.setFavorite(d,"A","series","s",true)
  val h=fact(PlaybackContentType.EPISODE,"e","s",year=2024,tmdb="123")
  l.reconcile(d,"B",listOf(h),kind="series")
  l.importEpisodeLinks("B"){id->listOf(SeriesEpisodeInfo("$id-e1",1,1,"Episode",null,null,100,null))}
  val projected=l.projectHistory("B",listOf(h))
  verify("series checkpoint metadata distinguishes remake while sharing progress",projected.singleOrNull()?.seriesId=="s2024")
 }
 run {
  val ctx=fresh();val store=WatchHistoryStore(ctx)
  val entries=(0 until 450).map { n->fact(PlaybackContentType.MOVIE,"m$n").copy(title="Work $n",updatedAtMs=n.toLong()+1000) }
  store.checkpointPlaylist("A",entries)
  verify("history retains more than 400 saved facts",store.allLocal().size==450)
  val saved=ctx.getSharedPreferences("iptvpremium_watch_history_v1",0).getString("items",null)
  WatchHistoryStore.flushBeforeRestart(ctx)
  verify("restart flush preserves saved checkpoints",saved==ctx.getSharedPreferences("iptvpremium_watch_history_v1",0).getString("items",null))
 }
 run {
  val ctx=fresh();val l=SharedLibraryStore.get(ctx);val h=fact(PlaybackContentType.MOVIE,"m")
  val d=PlaylistCacheDao();d.movies["A"]=listOf(SharedCatalogIdentity("m","Example",2024,null,null,null))
  l.setFavorite(d,"A","movies","m",true);l.reconcile(d,"A",listOf(h),kind="movies")
  l.hide("A",PlaybackContentType.MOVIE,"m",listOf(h))
  verify("explicit removal remains hidden",l.projectHistory("A",listOf(h)).isEmpty())
 }
 println("Failures: $failures")
 if(failures>0)error("Real SharedLibraryStore regression failures: $failures")
}
