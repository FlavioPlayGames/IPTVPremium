package br.com.flaviotorres.iptvpremium.data.cache.dao
import br.com.flaviotorres.iptvpremium.data.history.*
data class Generation(val generationId:String)
data class MovieRow(val name:String,val year:Int?,val streamUrl:String)
data class SeriesRow(val name:String,val year:Int?,val imdbId:String?,val tmdbId:String?)
class PlaylistCacheDao {
 val movies=mutableMapOf<String,List<SharedCatalogIdentity>>()
 val series=mutableMapOf<String,List<SharedCatalogIdentity>>()
 var generation="g"
 suspend fun getActiveGeneration(playlist:String)=Generation(generation)
 suspend fun getActiveMovieById(playlist:String,id:String)=movies[playlist].orEmpty().firstOrNull{it.contentId==id}?.let{MovieRow(it.title,it.year,it.streamUrl.orEmpty())}
 suspend fun getParentalSeriesById(playlist:String,generation:String,id:String)=series[playlist].orEmpty().firstOrNull{it.contentId==id}?.let{SeriesRow(it.title,it.year,it.imdb,it.tmdb)}
 private fun glob(pattern:String,text:String):Boolean {
  val rx=StringBuilder("^");var inside=false
  for(c in pattern)when(c){'*'->rx.append(".*");'?'->rx.append('.');'['->{inside=true;rx.append(c)};']'->{inside=false;rx.append(c)};else->if(inside)rx.append(c)else rx.append(Regex.escape(c.toString()))}
  return Regex(rx.append('$').toString()).matches(text)
 }
 suspend fun sharedMovieCandidates(playlist:String,generation:String,after:String,pattern:String,ids:List<String>,streamPattern:String="")=movies[playlist].orEmpty().filter{it.contentId>after && (it.contentId in ids || pattern.isNotEmpty()&&glob(pattern,it.title) || streamPattern.isNotEmpty()&&glob(streamPattern,it.streamUrl.orEmpty()))}.sortedBy{it.contentId}.take(256)
 suspend fun sharedSeriesCandidates(playlist:String,generation:String,after:String,pattern:String,ids:List<String>,imdbs:List<String>,tmdbs:List<String>)=series[playlist].orEmpty().filter{it.contentId>after && (it.contentId in ids || pattern.isNotEmpty()&&glob(pattern,it.title) || it.imdb in imdbs || it.tmdb in tmdbs)}.sortedBy{it.contentId}.take(256)
 suspend fun sharedSeriesEpisodeCandidates(playlist:String,generation:String,season:Int,episode:Int,pattern:String):List<SharedSeriesEpisodeIdentity> = emptyList()
}
