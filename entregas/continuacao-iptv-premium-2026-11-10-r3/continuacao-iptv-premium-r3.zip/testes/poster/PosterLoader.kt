package br.com.flaviotorres.iptvpremium.ui.movies
import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import br.com.flaviotorres.iptvpremium.data.cache.PosterKind
object MoviePosterLoader {
 private val bitmaps=java.util.concurrent.ConcurrentHashMap<String,ImageBitmap>()
 fun peekBitmap(url:String?):ImageBitmap?=url?.let{bitmaps[it]}
 suspend fun loadCached(context:Context,url:String?):ImageBitmap?=peekBitmap(url)
 suspend fun loadWithRetry(context:Context,url:String?,kind:PosterKind):ImageBitmap? = url?.takeIf{it.startsWith("https://")||it.startsWith("http://")}?.let{bitmaps.getOrPut(it){ImageBitmap(it)}}
}
