package br.com.flaviotorres.iptvpremium.data.remote
import org.json.JSONObject
import org.json.JSONArray
import java.util.concurrent.atomic.AtomicInteger
import kotlinx.coroutines.delay
object TmdbClientProvider {val client=TestTmdbClient()}
class TestTmdbClient {
 val requests=AtomicInteger();val active=AtomicInteger();val peak=AtomicInteger()
 suspend fun get(path:String,query:Map<String,String>):String {
  requests.incrementAndGet();val parallel=active.incrementAndGet();peak.updateAndGet{maxOf(it,parallel)}
  try {
   delay(35)
   if(path=="/search/tv") {
    val id=Regex("show([0-9]+)").matchEntire(query.getValue("query"))?.groupValues?.get(1)?.toInt()?:error("Unexpected fixture title")
    return JSONObject().put("results",JSONArray().put(JSONObject().put("id",id).put("name","Show$id").put("original_name","Show$id").put("first_air_date","2024-01-01"))).toString()
   }
   val id=Regex("^/tv/([0-9]+)$").matchEntire(path)?.groupValues?.get(1)?.toInt()?:error("Unexpected fixture request")
   return JSONObject().put("id",id).put("name","Show$id").put("original_name","Show$id").put("first_air_date","2024-01-01")
    .put("poster_path","/general$id.jpg").put("seasons",JSONArray().put(JSONObject().put("season_number",1).put("poster_path","/season$id.jpg"))).toString()
  } finally {active.decrementAndGet()}
 }
}
