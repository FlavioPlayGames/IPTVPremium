package br.com.flaviotorres.iptvpremium.data.cache
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
enum class PosterKind { SERIES, MOVIES }
object MediaOpeningPriority { val busy=MutableStateFlow(false);suspend fun awaitIdle(){busy.first{!it}} }
object CatalogImportPriority { val busy=MutableStateFlow(false) }
