package br.com.flaviotorres.iptvpremium.core.player

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.*
import java.net.URI
import java.net.URLEncoder

internal data class SubsourceQuery(val title:String,val year:Int?,val imdb:String?,val season:Int?=null,val episode:Int?=null) {
    val episodic get()=season!=null&&episode!=null
}
internal data class SubsourceHit(val id:String,val language:String,val release:String,val seasonPack:Boolean=false)
internal class SubsourceException(val text:String):Exception(text)
internal class SubsourceClient(
    private val key:()->String?,
    private val transport:OpenSubtitleTransport=OpenSubtitleHttpTransport(),
    private val trace:(String)->Unit={},
    private val paceMs:Long=1_000L
) {
    companion object {
        private val gate=Mutex()
        private var lastRequest=0L
        private val limited=mutableMapOf<String,Long>()
    }
    fun scope():String?=key()?.takeIf{it.length in 8..512&&it.none{c->c.isWhitespace()||c.isISOControl()}}?.let(::openSubtitleDigest)
    fun checkScope(expected:String) {if(scope()!=expected)throw SubsourceException("Conecte sua conta SubSource em Configurações > Legendas.")}
    private suspend fun request(path:String,scope:String,limit:Int=2_000_000):OpenSubtitleResponse {
        require(path.startsWith('/')&&!path.startsWith("//"))
        checkScope(scope)
        val response=gate.withLock {
            if(System.currentTimeMillis()<(limited[scope]?:0))throw SubsourceException("SubSource: limite temporário. Aguarde para tentar novamente.")
            val elapsed=System.nanoTime()/1_000_000-lastRequest
            if(elapsed<paceMs)delay(paceMs-elapsed)
            checkScope(scope)
            val current=key()?:throw SubsourceException("SubSource não configurado.")
            val started=System.nanoTime()
            try {
                transport.request("https://api.subsource.net/api/v1$path","GET",
                    mapOf("X-API-Key" to current,"Accept" to "application/json","User-Agent" to "IPTVPremium v1.13"),null,limit)
                    .also {
                        val endpoint=if(path.startsWith("/movies/"))"search"else if(path.substringBefore('?').endsWith("/download"))"download"else"subtitles"
                        trace("stage=subsource endpoint=$endpoint httpStatus=${it.code} elapsedMs=${(System.nanoTime()-started)/1_000_000}")
                        if(it.code==429){limited[scope]=System.currentTimeMillis()+(it.retryAfterSeconds?:60).coerceIn(1,86400)*1000;while(limited.size>32)limited.remove(limited.keys.first())}
                    }
            }catch(cancelled:CancellationException){throw cancelled}
            catch(_:Exception){throw SubsourceException("SubSource: falha de conexão. Tente novamente.")}
            finally{lastRequest=System.nanoTime()/1_000_000}
        }
        checkScope(scope)
        when(response.code) {
            401,403->throw SubsourceException("SubSource: chave recusada ou acesso não autorizado.")
            429->throw SubsourceException("SubSource: limite temporário. Aguarde para tentar novamente.")
        }
        if(response.code !in 200..299)throw SubsourceException("SubSource indisponível (HTTP ${response.code}).")
        return response
    }
    private data class Page(val rows:JSONArray,val pages:Int?)
    private suspend fun page(path:String,scope:String):Page {
        val response=request(path,scope)
        return try {
            when(val root=JSONTokener(String(response.data,Charsets.UTF_8)).nextValue()) {
                is JSONArray->Page(root,null)
                is JSONObject->{if(root.has("success")&&!root.optBoolean("success"))throw SubsourceException("SubSource recusou a consulta.");Page(root.optJSONArray("data")?:throw SubsourceException("SubSource: resposta incompatível."),root.optJSONObject("pagination")?.optInt("pages",0)?.takeIf{it>0})}
                else->throw SubsourceException("SubSource: resposta incompatível.")
            }
        }catch(error:SubsourceException){throw error}catch(_:Exception){throw SubsourceException("SubSource: resposta incompatível.")}
    }
    suspend fun search(query:SubsourceQuery):Pair<String,List<SubsourceHit>> = withContext(Dispatchers.IO) {
        val scope=scope()?:throw SubsourceException("SubSource não configurado.")
        require(query.title.isNotBlank() && (query.season==null)==(query.episode==null))
        val imdb=query.imdb?.takeIf{it.matches(Regex("tt[0-9]{5,12}"))}
        val params=linkedMapOf("searchType" to if(imdb!=null)"imdb"else"text",
            (if(imdb!=null)"imdb"else"q") to (imdb?:query.title),"type" to if(query.episodic)"series"else"movie")
        if(imdb==null&&!query.episodic&&query.year!=null)params["year"]=query.year.toString()
        if(query.episodic)params["season"]=query.season.toString()
        val works=page("/movies/search?"+parameters(params),scope).rows
        val valid=(0 until minOf(works.length(),100)).mapNotNull{works.optJSONObject(it)}.filter { work ->
            val kind=work.optString("type").lowercase(java.util.Locale.ROOT)
            val correctKind=if(query.episodic)kind in setOf("series","tvseries","tv")else kind=="movie"
            val name=listOf(work.optString("title"),work.optString("alternateTitle")).any{openSubtitleTitleKey(it)==openSubtitleTitleKey(query.title)}
            val returnedImdb=work.optString("imdbId").ifBlank{work.optString("imdb")}
            val byId=imdb!=null&&(returnedImdb.isBlank()||returnedImdb==imdb)
            val year=query.episodic||query.year==null||work.optInt("releaseYear",0)==query.year
            val season=work.optInt("season",query.season?:-1)
            correctKind&&work.optLong("movieId",0)>0&&(if(imdb!=null)byId else name&&year)&&(!query.episodic||season==query.season)
        }.distinctBy{it.optLong("movieId")}
        trace("stage=subsource_works received=${works.length()} matched=${valid.size}")
        if(valid.size!=1)return@withContext scope to emptyList()
        val id=valid.single().getLong("movieId")
        val found=mutableListOf<SubsourceHit>()
        for((language,label)in listOf("brazilian_portuguese" to "pt-BR","english" to "en","spanish" to "es")) {
            var received=0;var rejected=0;var pagesRead=0;var truncated=false
            val languageHits=linkedMapOf<String,SubsourceHit>()
            val seenPages=mutableSetOf<String>()
            for(number in 1..5) {
                val result=page("/subtitles?"+parameters(linkedMapOf("movieId" to id.toString(),"language" to language,"sort" to "rating","limit" to "100","page" to number.toString())),scope)
                pagesRead++
                val subtitles=result.rows
                // A broken API that repeats the first page must not keep the query running.
                val signature=openSubtitleDigest(subtitles.toString())
                if(!seenPages.add(signature)){truncated=true;break}
                received+=subtitles.length()
                for(index in 0 until minOf(subtitles.length(),100)) {
                    val row=subtitles.optJSONObject(index)?:continue
                    val subtitleId=row.optString("subtitleId").takeIf{it.matches(Regex("[1-9][0-9]{0,17}"))}
                    val rowLanguage=row.optString("language").lowercase(java.util.Locale.ROOT)
                    val accepted=when(label){"pt-BR"->rowLanguage in setOf("brazillian-portuguese","brazilian-portuguese","brazilian_portuguese","pt-br");"en"->rowLanguage in setOf("english","en");else->rowLanguage in setOf("spanish","es","spanish_spain","spanish_latin-america")}
                    if(subtitleId==null||!accepted||row.has("movieId")&&row.optLong("movieId")!=id){rejected++;continue}
                    val releases=row.optJSONArray("releaseInfo")
                    val release=if(releases!=null)(0 until minOf(releases.length(),20)).map{releases.optString(it)}.joinToString(" · ")
                        else row.optString("releaseInfo").takeUnless{it=="null"}.orEmpty().ifBlank{row.optString("release_info")}
                    val classification=if(query.episodic)SubsourceEpisodePolicy.candidate(release+" "+row.optString("commentary"),query.season!!,query.episode!!,row.optInt("files",0))else 1
                    if(classification==0){rejected++;continue}
                    val pack=classification==2
                    val name=release.replace(Regex("[\\r\\n\\t]")," ").take(200)+(if(pack)" · Pacote da temporada (conferir episódio)"else "")
                    languageHits.putIfAbsent(subtitleId,SubsourceHit(subtitleId,label,name,pack))
                }
                val more=if(result.pages!=null)number<result.pages else subtitles.length()>=100
                if(!more)break
                if(number==5||languageHits.values.count{!it.seasonPack}>=30){truncated=true;break}
            }
            val selected=languageHits.values.sortedBy{it.seasonPack}.take(30)
            found.addAll(selected)
            trace("stage=subsource_results language=$label pages=$pagesRead received=$received accepted=${selected.size} rejected=$rejected packs=${selected.count{it.seasonPack}} truncated=$truncated")
        }
        checkScope(scope)
        scope to found.distinctBy{it.id}.groupBy{it.language}.let{g->listOf("pt-BR","en","es").flatMap{g[it].orEmpty().take(30)}}
    }
    /** One explicit GET to the download API; no redirect/retry with a personal key. */
    suspend fun download(id:String,scope:String):ByteArray=withContext(Dispatchers.IO) {
        require(id.matches(Regex("[1-9][0-9]{0,17}")))
        request("/subtitles/$id/download",scope,5_000_000).data
    }
    private fun parameters(values:Map<String,String>)=values.entries.joinToString("&"){(k,v)->"${URLEncoder.encode(k,"UTF-8")}=${URLEncoder.encode(v,"UTF-8")}"}
}
