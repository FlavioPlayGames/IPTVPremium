package br.com.flaviotorres.iptvpremium.core.player
import kotlinx.coroutines.*
import org.json.*
import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
private data class Call(val url:String,val headers:Map<String,String>)
private class Fake:OpenSubtitleTransport {
 val calls=mutableListOf<Call>();var handle:(Call)->OpenSubtitleResponse={OpenSubtitleResponse(200,"{\"success\":true,\"data\":[]}".toByteArray())}
 override suspend fun request(url:String,method:String,headers:Map<String,String>,body:String?,limit:Int):OpenSubtitleResponse {
  check(method=="GET"&&body==null);val call=Call(url,headers);calls+=call;return handle(call)
 }
}
private var checks=0
private fun verify(ok:Boolean,label:String){check(ok){label};checks++;println("PASS $label")}
private fun response(data:JSONArray)=OpenSubtitleResponse(200,JSONObject().put("success",true).put("data",data).toString().toByteArray())
private fun work(id:Int=1,title:String="The Handmaid's Tale",type:String="series",year:Int=2017)=JSONObject().put("movieId",id).put("title",title).put("type",type).put("releaseYear",year).put("season",5)
private fun sub(id:Int,lang:String,release:String)=JSONObject().put("subtitleId",id).put("language",lang).put("releaseInfo",JSONArray().put(release))
fun main()=runBlocking {
 var key:String?="fake-personal-subsource-key";val wire=Fake();val trace=mutableListOf<String>()
 val client=SubsourceClient({key},wire,{trace+=it},0)
 wire.handle={c->when {
  "/movies/search?" in c.url->response(JSONArray().put(work()))
  "language=brazilian_portuguese" in c.url->response(JSONArray().put(sub(10,"brazilian_portuguese","Show.S05E06.WEB"))
    .put(sub(11,"brazillian-portuguese","Show.S05E060")) .put(sub(12,"brazillian-portuguese","Show.S05E07"))
    .put(sub(13,"portuguese","Show.S05E06")))
  "language=english" in c.url->response(JSONArray().put(sub(20,"english","Show.S05E06")))
  else->response(JSONArray().put(sub(30,"spanish","Show.S05E06")))
 }}
 val query=SubsourceQuery("The Handmaid's Tale",2017,null,5,6)
 val(scope,hits)=client.search(query)
 verify(hits.map{it.id}==listOf("10","20","30"),"exact episode/languages only; E060, E07 and generic Portuguese rejected")
 verify(hits.map{it.language}==listOf("pt-BR","en","es"),"Brazilian Portuguese before English and Spanish")
 verify(wire.calls.size==4&&wire.calls.none{it.url.endsWith("/download")},"search resolves work and three languages without downloading files")
 verify(wire.calls.all{it.headers["X-API-Key"]==key&&"Authorization" !in it.headers&&it.url.startsWith("https://api.subsource.net/api/v1/")},"personal key stays in official API header, never URL or unrelated host")
 wire.calls.clear();wire.handle={response(JSONArray().put(work()).put(work(2)))}
 verify(client.search(query).second.isEmpty(),"ambiguous work is not selected by popularity")
 wire.handle={response(JSONArray().put(work(title="Other Show")))}
 verify(client.search(query).second.isEmpty(),"unrelated title rejected without IMDb")
 wire.handle={response(JSONArray().put(work(type="movie")))}
 verify(client.search(query).second.isEmpty(),"wrong content type rejected")
 wire.handle={response(JSONArray().put(work(title="Remake",type="movie",year=2020)))}
 verify(client.search(SubsourceQuery("Remake",2000,null)).second.isEmpty(),"name-only search rejects different release year")
 wire.calls.clear();wire.handle={c->if("/movies/search?" in c.url)response(JSONArray().put(work(title="Original Title").put("imdbId","tt1234567")))else response(JSONArray())}
 client.search(query.copy(title="Translated Title",imdb="tt1234567"))
 verify("searchType=imdb" in wire.calls.first().url&&"imdb=tt1234567" in wire.calls.first().url,"verified IMDb is used before text search")
 wire.handle={response(JSONArray().put(work().put("imdbId","tt9999999")))}
 verify(client.search(query.copy(imdb="tt1234567")).second.isEmpty(),"conflicting returned IMDb rejected")
 wire.handle={OpenSubtitleResponse(200,byteArrayOf(80,75,3,4))};wire.calls.clear()
 verify(client.download("10",scope).size==4&&wire.calls.size==1&&wire.calls.single().url.endsWith("/subtitles/10/download"),"one download API GET only after selection")
 wire.handle={OpenSubtitleResponse(302,"https://untrusted.invalid/file.zip".toByteArray())};wire.calls.clear()
 try{client.download("10",scope);error("redirect accepted")}catch(_:SubsourceException){verify(wire.calls.size==1,"authenticated download is not redirected/retried with a personal key")}
 wire.handle={OpenSubtitleResponse(403,byteArrayOf())}
 try{client.search(query);error("403 accepted")}catch(e:SubsourceException){verify("recusada" in e.text,"403 remains authentication error, not cached empty result")}
 wire.handle={OpenSubtitleResponse(200,"{}".toByteArray())}
 try{client.search(query);error("invalid accepted")}catch(e:SubsourceException){verify("incompatível" in e.text,"malformed API data is not an empty search")}
 wire.handle={key="replacement-personal-key";response(JSONArray())}
 try{client.search(query);error("scope accepted")}catch(_:SubsourceException){verify(client.scope()!=scope,"account change discards late search results")}

 key="fake-personal-subsource-key";wire.calls.clear()
 fun paged(rows:JSONArray,pages:Int)=OpenSubtitleResponse(200,JSONObject().put("success",true).put("data",rows).put("pagination",JSONObject().put("pages",pages)).toString().toByteArray())
 wire.handle={c->when {
  "/movies/search?" in c.url->response(JSONArray().put(work(type="tvseries")))
  "language=brazilian_portuguese" in c.url && "page=1" in c.url->paged(JSONArray().put(sub(40,"brazillian-portuguese","Show.S05E07")),2)
  "language=brazilian_portuguese" in c.url->paged(JSONArray().put(sub(41,"brazillian-portuguese","Show.5x06.WEB")),2)
  else->response(JSONArray())
 }}
 verify(client.search(query).second.map{it.id}==listOf("41"),"episode can be found on second page with 5x06 marker")
 verify(wire.calls.size==5,"pagination follows declared pages, not just row count")
 wire.handle={c->if("/movies/search?" in c.url)response(JSONArray().put(work()))else if("language=english" in c.url)response(JSONArray()
  .put(sub(50,"english","unused").put("releaseInfo","Show S05E06 WEB"))
  .put(sub(51,"english","Show Season 5 Complete").put("files",10))
  .put(sub(52,"english","Show Season 4 Complete").put("files",10))
  .put(sub(53,"english","Show Episode 6"))
  .put(sub(54,"english","Show Season 4 Episode 6"))
  .put(sub(55,"english","Unknown single file"))
  .put(sub(56,"english","Show S05E06").put("movieId",999))
 )else response(JSONArray())}
 val mixed=client.search(query).second
 verify(mixed.map{it.id}==listOf("50","53","51"),"string releaseInfo, episode-only label and season pack accepted; mismatched season/work and unknown file rejected")
 verify(mixed.last().seasonPack&&"Pacote" in mixed.last().release,"season packs are identified and require archive verification")
 wire.calls.clear();wire.handle={c->if("/movies/search?" in c.url)response(JSONArray().put(work()))else {
  val n=Regex("[?&]page=(\\d+)").find(c.url)!!.groupValues[1].toInt()
  paged(JSONArray().put(sub(100+n,"english","Show S05E07")),100)
 }}
 client.search(query)
 verify(wire.calls.size==16&&wire.calls.none{"page=6" in it.url},"request budget is at most five pages per language")
 verify(trace.any{"truncated=true" in it&&"stage=subsource_results" in it},"diagnostic reports bounded incomplete scan")
 wire.calls.clear();wire.handle={c->if("/movies/search?" in c.url)response(JSONArray().put(work()))else paged(JSONArray().put(sub(80,"english","Show S05E07")),100)}
 client.search(query)
 verify(wire.calls.size==7,"repeated API page stops instead of spending full request budget")
 verify(trace.any{"stage=subsource_works received=1 matched=1"==it}&&trace.any{"stage=subsource_results language=pt-BR" in it},"safe counters identify work and each provider language outcome")
 fun zip(vararg entries:Pair<String,String>):ByteArray {
  val out=ByteArrayOutputStream();ZipOutputStream(out).use{z->entries.forEach{(name,text)->z.putNextEntry(ZipEntry(name));z.write(text.toByteArray());z.closeEntry()}};return out.toByteArray()
 }
 val archive=zip("Show.S05E05.srt" to "five","Show.5x06.srt" to "six","Show.S05E07.srt" to "seven")
 verify(SubsourceArchive.select(archive,5,6,true)?.decodeToString()=="six","season pack selects requested episode, not first ZIP entry")
 verify(SubsourceArchive.select(archive,5,8,true)==null,"missing episode in pack is rejected")
 verify(SubsourceArchive.select(zip("Show.S05E07.srt" to "wrong"),5,6,false)==null,"even a single explicitly wrong episode is rejected")
 verify(SubsourceArchive.select(zip("subtitle.srt" to "unknown"),5,6,true)==null,"pack cannot silently use an unidentified single file")
 verify(SubsourceArchive.select(zip("subtitle.srt" to "six"),5,6,false)?.decodeToString()=="six","a previously verified individual release can use an unnamed sole file")
 verify(SubsourceArchive.select(zip("Episode 6.srt" to "six"),5,6,true)?.decodeToString()=="six","episode-only filenames are recognized within the resolved season")
 verify(SubsourceArchive.select(zip("Show.S05E06.srt" to "x".repeat(1_000_001)),5,6,true)==null,"oversized uncompressed subtitle rejected")
 verify(SubsourceArchive.select(zip("ignored.bin" to "x".repeat(10_000_001),"S05E06.srt" to "six"),5,6,true)==null,"total uncompressed archive budget includes non-subtitle entries")
 verify(SubsourceArchive.select(byteArrayOf(80,75,1,2,3,4,5),5,6,true)==null,"invalid archive rejected")

 val packOption=ExternalSubtitleOption("SubSource","51","en","Season 5",seasonNumber=5,episodeNumber=6,accountScope="account-A",verifyArchiveEpisode=true)
 verify(StorageAdapter.downloadedOptionKey(packOption)!=StorageAdapter.downloadedOptionKey(packOption.copy(episodeNumber=7)),"same pack uses separate extracted cache files for different episodes")
 verify(StorageAdapter.downloadedOptionKey(packOption)!=StorageAdapter.downloadedOptionKey(packOption.copy(seasonNumber=4)),"cache isolates seasons")
 verify(StorageAdapter.downloadedOptionKey(packOption)!=StorageAdapter.downloadedOptionKey(packOption.copy(accountScope="account-B")),"cache isolates personal accounts")
 val roundTrip=StorageAdapter.decodeOptions(JSONArray().put(StorageAdapter.encodeOption(packOption))).single()
 verify(roundTrip==packOption,"pack verification and episode survive option persistence")
 val legacy=StorageAdapter.encodeOption(packOption);legacy.remove("verifyArchiveEpisode")
 verify(!StorageAdapter.decodeOptions(JSONArray().put(legacy)).single().verifyArchiveEpisode,"legacy individual options remain readable")
 key=null;wire.calls.clear()
 try{client.search(query);error("anonymous accepted")}catch(_:SubsourceException){verify(wire.calls.isEmpty(),"unconfigured account performs no anonymous requests")}
 verify(trace.none{it.contains("fake-personal-subsource-key")||it.contains("https://")||it.contains("The Handmaid")},"trace excludes key, URL and title")
 println("$checks SubSource checks passed; simulated API contract, no real account/service access.")
}
