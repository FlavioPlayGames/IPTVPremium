package br.com.flaviotorres.iptvpremium.data.resolver
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
fun main() {
 fun source(url:String)=PlaylistSource.M3u("same-list","User list",false,url)
 val valid=listOf(
 "http://example.test/get.php?username=alice&password=secret" to "http://example.test",
 "https://example.test:8443/panel/get.php/?username=alice&password=secret&type=m3u_plus" to "https://example.test:8443/panel",
 "https://example.test/GET.PHP?USERNAME=alice&PASSWORD=secret" to "https://example.test",
 "https://example.test/get.php?username=alice&amp;password=secret&amp;type=m3u_plus" to "https://example.test",
 "https://example.test/get.php?username=alice\\&password=secret" to "https://example.test",
 "https://example.test/get.php?password=secret&username=alice" to "https://example.test"
 )
 for ((url,base) in valid) { val x=checkNotNull(M3uXtreamResolver.resolve(source(url)));check(x.serverUrl==base&&x.username=="alice"&&x.password=="secret"&&x.id=="same-list"&&x.name=="User list"&&!x.isEnabled);println("PASS recognized link variant preserving identity") }
 val encoded=checkNotNull(M3uXtreamResolver.resolve(source("https://example.test/p%20ath/get.php?username=a%2Bb&password=x%26y%3Dz%2B")))
 check(encoded.username=="a+b"&&encoded.password=="x&y=z+"&&encoded.serverUrl=="https://example.test/p%20ath");println("PASS encoded credentials decoded once")
 for (url in listOf("", "file:///get.php?username=a&password=b", "https://example.test/list.m3u?username=a&password=b", "https://example.test/get.php?username=a", "https://example.test/get.php?username=a&password=", "https://example.test/get.php?username=a&username=other&password=b", "https://example.test/get.php?username=a&password=b%ZZ", "https://user:pw@example.test/get.php?username=a&password=b")) {check(M3uXtreamResolver.resolve(source(url))==null);println("PASS rejects invalid or ambiguous conversion")}
}
