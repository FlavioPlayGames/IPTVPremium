from pathlib import Path
import tempfile,subprocess,os,shutil,hashlib,json,zipfile
r=Path('/workspace/movie-loading-107/IPTVPremium');o=Path('/workspace/outputs/importacao-livre-1.07');script=o/'Preparar-Importacao-Livre-1.07.ps1';entries=json.loads((o/'manifest.json').read_text());results=[]
def run(root,*args,ok=True,installer=script):
 e=dict(os.environ,HOME='/workspace/storage-toolchain',XDG_CACHE_HOME='/workspace/storage-toolchain/cache',XDG_CONFIG_HOME='/workspace/storage-toolchain/config',XDG_DATA_HOME='/workspace/storage-toolchain/data')
 x=subprocess.run(['/workspace/storage-toolchain/powershell/pwsh','-NoProfile','-File',str(installer),'-Projeto',str(root),*args],capture_output=True,text=True,env=e)
 assert (x.returncode==0)==ok,x.stdout+x.stderr
 return x
with tempfile.TemporaryDirectory(dir='/workspace') as d,zipfile.ZipFile('/workspace/attachments/38412b52-3867-435e-96ae-8b7aa1d9162a/IPTVPremium (6).zip') as z:
 root=Path(d);(root/'gradlew.bat').touch();original={}
 for entry in entries:
  rel=entry['path'];p=root/rel;p.parent.mkdir(parents=True,exist_ok=True);original[rel]=z.read('IPTVPremium/'+rel);p.write_bytes(original[rel])
 marker=root/'local.properties';marker.write_text('preserve-user-config')
 run(root,'-Verificar');assert all((root/e['path']).read_bytes()==original[e['path']] for e in entries);results.append('PASS verificar does not modify')
 run(root,'-SomenteAplicar');assert all((root/e['path']).read_bytes()==(r/e['path']).read_bytes() for e in entries);results.append('PASS applies exact seven files')
 assert marker.read_text()=='preserve-user-config';results.append('PASS preserves configuration')
 backups=list((root/'.navigation-backups').glob('*'));assert len(backups)==1
 assert all((backups[0]/e['path']).read_bytes()==original[e['path']] for e in entries);results.append('PASS exact backup')
 run(root,'-SomenteAplicar');results.append('PASS idempotent reapplication')
 p=root/entries[-1]['path'];p.write_text('unknown edits');snapshot={e['path']:(root/e['path']).read_bytes()for e in entries};run(root,'-SomenteAplicar',ok=False);assert all((root/rel).read_bytes()==raw for rel,raw in snapshot.items());results.append('PASS unknown version rejected before any changes')
 for e in entries:(root/e['path']).write_bytes(original[e['path']])
 broken=root/'broken.ps1';s=script.read_text(encoding='utf-8-sig');needle="foreach ($entry in $entries) { [IO.File]::WriteAllBytes((Join-Path $Projeto $entry.path), [Convert]::FromBase64String($entry.data)) }";assert needle in s;s=s.replace(needle,needle[:-2]+"; throw 'injected copy failure' }");broken.write_text(s,encoding='utf-8-sig');run(root,'-SomenteAplicar',ok=False,installer=broken);assert all((root/e['path']).read_bytes()==original[e['path']]for e in entries);results.append('PASS injected copy failure rolls back original files')
(o/'testes-instalador.txt').write_text('\n'.join(results)+'\n');print('\n'.join(results))
# Site extraction never deploys with -NaoPublicar.
with tempfile.TemporaryDirectory(dir='/workspace') as d:
 x=subprocess.run(['/workspace/storage-toolchain/powershell/pwsh','-NoProfile','-File',str(o/'Publicar-Central-Listas-1.07.ps1'),'-PastaDestino',d,'-NaoPublicar'],capture_output=True,text=True,env=dict(os.environ,HOME='/workspace/storage-toolchain',XDG_CACHE_HOME='/workspace/storage-toolchain/cache',XDG_CONFIG_HOME='/workspace/storage-toolchain/config',XDG_DATA_HOME='/workspace/storage-toolchain/data'));assert x.returncode==0,x.stdout+x.stderr
 sites=list(Path(d).glob('Central-IPTV-listas-*'));assert len(sites)==1
 for rel in ['worker-atualizacao-abi.js','playlist-validation.js','public/app.js','public/index.html','public/admin/index.html','wrangler.jsonc']:
  assert (sites[0]/rel).read_bytes()==(Path('/workspace/playlist-validation-site')/rel).read_bytes(),rel
 print('PASS site installer extracts exact package without deployment');(o/'testes-instalador-site.txt').write_text('PASS site installer extracts exact package without deployment\n')
