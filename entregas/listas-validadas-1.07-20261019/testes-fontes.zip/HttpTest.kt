package br.com.flaviotorres.iptvpremium.data.remote
import java.net.ServerSocket
import java.util.concurrent.CountDownLatch
import kotlin.concurrent.thread
import kotlinx.coroutines.*
import br.com.flaviotorres.iptvpremium.data.sync.SharedSync
fun main()= runBlocking {
 val client=DefaultPlaylistHttpClient()
 suspend fun serve(status:Int,body:String,check:suspend(String)->Unit) {
  val server=ServerSocket(0);val worker=thread(isDaemon=true) { server.accept().use { socket ->
   val reader=socket.getInputStream().bufferedReader();while(reader.readLine()?.isNotEmpty()==true){}
   socket.getOutputStream().write("HTTP/1.1 $status Test\r\nContent-Length: ${body.toByteArray().size}\r\nContent-Type: application/json\r\nConnection: close\r\n\r\n$body".toByteArray());socket.getOutputStream().flush()
  }}
  try {check("http://127.0.0.1:${server.localPort}/player_api.php")} finally {server.close();worker.join(1000)}
 }
 serve(200,"[1,2,3]"){ url ->check(client.withReader(url){it.readText()}=="[1,2,3]");println("PASS streaming successful body unchanged") }
 for (status in listOf(401,403)) {
  serve(status,"{}"){url ->val failure=runCatching { client.withReader(url){it.readText()} }.exceptionOrNull();check(failure is PlaylistAccessDeniedException);println("PASS streaming permanent denial $status classified")}
  serve(status,"{}"){url ->val failure=runCatching { client.get(url) }.exceptionOrNull();check(failure is PlaylistAccessDeniedException);println("PASS authentication permanent denial $status classified")}
 }
 val server=ServerSocket(0);val accepted=CompletableDeferred<Unit>();val stop=CountDownLatch(1)
 val importScope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
 val shared=SharedSync<String,String>(importScope)
 val worker=thread(isDaemon=true) { server.accept().use { socket ->
  val reader=socket.getInputStream().bufferedReader();while(reader.readLine()?.isNotEmpty()==true){}
  socket.getOutputStream().write("HTTP/1.1 200 OK\r\nContent-Length: 1000\r\n\r\n[".toByteArray());socket.getOutputStream().flush();stop.await()
 }}
 try {
  val job=launch(Dispatchers.IO) { shared.run("list-id","same-configuration") {
   client.withReader("http://127.0.0.1:${server.localPort}/get.php"){reader ->reader.read();accepted.complete(Unit);reader.readText()}
  }}
  withTimeout(2000){accepted.await()};val start=System.nanoTime();job.cancel();withTimeout(2500){job.join()};check(job.isCancelled);println("PASS import caller released during blocked streaming in ${(System.nanoTime()-start)/1000000}ms")
 } finally {stop.countDown();server.close();worker.join(1000);importScope.cancel();withTimeout(2500){importScope.coroutineContext[Job]!!.join()}}
}
