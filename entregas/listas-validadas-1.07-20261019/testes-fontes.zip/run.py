from pathlib import Path
import subprocess
r=Path('/workspace/storage-toolchain');t=r/'tests/importacao-livre-107';b=Path('/workspace/movie-loading-107/IPTVPremium/app/src/main/java/br/com/flaviotorres/iptvpremium');cp=(r/'tests/xtream.classpath').read_text().strip();java=str(r/'jdk-25.0.4.1/bin/java')
files=list(t.glob('*.kt'))+[b/x for x in ['domain/model/PlaylistSource.kt','data/resolver/M3uXtreamResolver.kt','data/remote/PlaylistHttpClient.kt','data/remote/DefaultPlaylistHttpClient.kt','data/sync/SharedSync.kt']]
x=subprocess.run([java,'-cp',str(r/'gradle-9.6.0/lib/*'),'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',str(t/'tests.jar'),*map(str,files)],capture_output=True,text=True)
if x.returncode:print(x.stderr);raise SystemExit(x.returncode)
results=''
for name in ['br.com.flaviotorres.iptvpremium.data.resolver.ResolverTestKt','br.com.flaviotorres.iptvpremium.data.remote.HttpTestKt']:
 x=subprocess.run([java,'-cp',str(t/'tests.jar')+':'+cp,name],capture_output=True,text=True,timeout=30);results+=x.stdout+x.stderr;print(x.stdout+x.stderr)
 if x.returncode:raise SystemExit(x.returncode)
(t/'results.txt').write_text(results)
