import {test} from 'node:test';
import assert from 'node:assert/strict';
import {validatePlaylistLink,xtreamFromLink} from '/workspace/playlist-validation-site/playlist-validation.js';
const base='https://provider.example.com/get.php?username=alice&password=secret&type=m3u_plus';
const active=()=>Response.json({user_info:{auth:1,status:'Active'}});
const m3u=()=>new Response('#EXTM3U\n#EXTINF:-1,Channel\nhttps://media.example.com/live.ts\n');
test('get.php -> Xtream configuration, original prefix/port and encoded credentials',async()=>{
 const url='https://provider.example.com:8443/panel/get.php?username=a%2Bb&password=x%26y%3Dz';let seen;
 const x=await validatePlaylistLink(' Minha lista ',url,{fetcher:async(u,o)=>{seen=new URL(u);assert.equal(o.redirect,'manual');return active()}});
 assert.equal(x.playlist.type,'xtream');assert.equal(x.playlist.name,'Minha lista');assert.equal(x.playlist.serverUrl,'https://provider.example.com:8443/panel');assert.equal(seen.searchParams.get('password'),'x&y=z');assert.equal(x.playlist.username,'a+b');assert.equal('playlistUrl' in x.playlist,false);
});
test('HTML and Markdown clipboard links recognized',()=>{
 for(const link of [base.replaceAll('&','&amp;'),base.replaceAll('&','\\&'),base.replace('username','USERNAME').replace('password','PASSWORD')])assert.equal(xtreamFromLink('List',link).password,'secret');
});
test('generic M3U stays M3U, never invents credentials',async()=>{
 let calls=0;const x=await validatePlaylistLink('List','https://provider.example.com/list.m3u',{fetcher:async(u,o)=>{calls++;assert.equal(o.headers.Range,'bytes=0-65535');return m3u()}});assert.equal(x.playlist.type,'m3u');assert.equal(calls,1);assert.equal('username'in x.playlist,false);
});
test('unsupported API falls back to validated M3U',async()=>{
 let calls=0;const x=await validatePlaylistLink('List',base,{fetcher:async u=>{calls++;return u.includes('player_api')?new Response('<html>Unsupported</html>'):m3u()}});assert.equal(calls,2);assert.equal(x.playlist.type,'m3u');
});
test('API denial can still send M3U only if M3U itself validates',async()=>{
 const x=await validatePlaylistLink('List',base,{fetcher:async u=>u.includes('player_api')?new Response('',{status:403}):m3u()});assert.equal(x.playlist.type,'m3u');
 await assert.rejects(validatePlaylistLink('List',base,{fetcher:async()=>new Response('',{status:401})}),/não confirmou uma lista válida/);
});
test('auth zero does not override a false Active status',async()=>{
 const x=await validatePlaylistLink('List',base,{fetcher:async u=>u.includes('player_api')?Response.json({user_info:{auth:0,status:'Active'}}):m3u()});assert.equal(x.playlist.type,'m3u');
});
test('expired account is not confirmed as Xtream',async()=>{
 const x=await validatePlaylistLink('List',base,{fetcher:async u=>u.includes('player_api')?Response.json({user_info:{auth:1,status:'Expired'}}):m3u()});assert.equal(x.playlist.type,'m3u');
});
test('invalid responses are rejected without returning raw body or credentials',async()=>{
 await assert.rejects(validatePlaylistLink('List',base,{fetcher:async()=>new Response('<html>secret INTERNAL STACK</html>')}),e=>!e.message.includes('secret')&&!e.message.includes('STACK'));
});
test('metadata-only JSON is not an authenticated API',async()=>{
 const x=await validatePlaylistLink('List',base,{fetcher:async u=>u.includes('player_api')?Response.json({server_info:{}}):m3u()});assert.equal(x.playlist.type,'m3u');
});
test('huge M3U probe reads only first valid entry, cancels stream',async()=>{
 let cancelled=false,pulls=0;const encoder=new TextEncoder();const stream=new ReadableStream({pull(c){pulls++;c.enqueue(encoder.encode('#EXTM3U\n#EXTINF:-1,First\nhttps://media.example.com/a.ts\n'))},cancel(){cancelled=true}});
 const x=await validatePlaylistLink('List','https://provider.example.com/list.m3u',{fetcher:async()=>new Response(stream)});assert.equal(x.playlist.type,'m3u');assert(cancelled);assert(pulls<=3);
});
test('BOM, CRLF and final stream without newline accepted',async()=>{
 const x=await validatePlaylistLink('List','https://provider.example.com/list.m3u',{fetcher:async()=>new Response('\uFEFF#EXTM3U\r\n#EXTINF:-1,First\r\n#EXTVLCOPT:http-referrer=example\r\nhttps://media.example.com/a.ts')});assert.equal(x.playlist.type,'m3u');
});
test('playlist without a real stream rejected',async()=>{
 await assert.rejects(validatePlaylistLink('List','https://provider.example.com/list.m3u',{fetcher:async()=>new Response('#EXTM3U\n#EXTINF:-1,Name\n')}),/entrada M3U válida/);
});
test('oversized probe is bounded',async()=>{
 let n=0,cancelled=false;const stream=new ReadableStream({pull(c){n++;c.enqueue(new TextEncoder().encode('#EXTM3U\n'+'#'.repeat(8192)))},cancel(){cancelled=true}});
 await assert.rejects(validatePlaylistLink('List','https://provider.example.com/list.m3u',{fetcher:async()=>new Response(stream)}));assert(n<=9);assert(cancelled);
});
test('private destinations rejected before any provider request',async()=>{
 for(const host of ['127.0.0.1','10.0.0.1','169.254.169.254','localhost','192.168.1.1','[::1]','0x7f000001'])await assert.rejects(validatePlaylistLink('List',`http://${host}/list.m3u`,{fetcher:()=>{throw Error('must never fetch')}}),/endereço público/);
});
test('redirect target checked before following',async()=>{
 let calls=0;await assert.rejects(validatePlaylistLink('List','https://provider.example.com/list.m3u',{fetcher:async()=>{calls++;return new Response('',{status:302,headers:{Location:'http://127.0.0.1/private'}})}}));assert.equal(calls,1);
});
test('redirect loop bounded',async()=>{
 let calls=0;await assert.rejects(validatePlaylistLink('List','https://provider.example.com/list.m3u',{fetcher:async()=>{calls++;return new Response('',{status:302,headers:{Location:'/again'}})}}),/redirecionando/);assert.equal(calls,4);
});
test('timeout returns a useful failure without provider exceptions',async()=>{
 const started=Date.now();await assert.rejects(validatePlaylistLink('List','https://provider.example.com/list.m3u',{timeoutMs:30,fetcher:(u,o)=>new Promise((resolve,reject)=>o.signal.addEventListener('abort',()=>reject(new Error('secret URL'))))}),e=>e.message.includes('demorou')&&!e.message.includes('secret'));assert(Date.now()-started<500);
});
test('invalid name and unsupported schemes do not trigger network calls',async()=>{
 for(const [name,url] of [['',base],['List','file:///etc/passwd'],['List','javascript:alert(1)']])await assert.rejects(validatePlaylistLink(name,url,{fetcher:()=>{throw Error('must never fetch')}}));
});
