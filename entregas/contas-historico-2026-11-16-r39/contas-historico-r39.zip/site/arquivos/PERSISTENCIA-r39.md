# Persistência r39 — fontes oficiais

Manter e editar este site em C:\Users\flavi\AndroidStudioProjects\Site IPTV. Publicar-Site.ps1 continua verificando, empacotando e registrando a publicação nessa pasta. Não usar .worker-preview como fonte.

A r39 adiciona device-persistence.js. Usa D1 existente e a chave de criptografia já configurada da central; não usa R2. Cria automaticamente device_backups e device_open_accounts nas primeiras chamadas autenticadas. Backup permanente separado de snapshots e fila temporária, sem TTL. São dados lógicos de listas/histórico e chaves; nenhuma legenda manual/baixada ou catálogo completo.

Login OpenSubtitles validado no provedor é mantido criptografado com vínculo à TV, para renovar tokens. O navegador não recebe o token nem a senha de volta. Desconectar apaga a credencial cifrada e mantém apenas marcador de versão para impedir que um login antigo em andamento recrie a conta. As rotas de recuperação exigem a credencial privada da TV, não somente o MAC. Um cadastro excluído remove seus dados por vínculo estrangeiro.

Depois de publicar, instalar a r39 do APK e refazer o login OpenSubtitles uma vez. Antes de testar limpeza, usar Sincronizar agora na TV e aguardar sucesso. Mudanças ainda não enviadas não podem ser recuperadas. A restauração importa só a lista ativa; demais listas ficam cadastradas para importar nas trocas.

Verificar npm test e npm run check. A publicação real depende da sua sessão Wrangler. Não compartilhar APP_KEY, tokens, credenciais ou pastas de configuração do Wrangler. Aplicar os fontes não realiza deploy e não apaga backups do banco.
