const openSchema='CREATE TABLE IF NOT EXISTS device_open_accounts(device_id TEXT PRIMARY KEY REFERENCES devices(id) ON DELETE CASCADE, version TEXT NOT NULL, cipher TEXT NOT NULL, updated_at INTEGER NOT NULL)';
export async function openAccountVersion(env,id){await env.DB.prepare(openSchema).run();return (await env.DB.prepare('SELECT version FROM device_open_accounts WHERE device_id=?').bind(id).first())?.version??null;}
export async function storeOpenCredentials(env,id,credentials,expected,seal,fail){
 const version=crypto.randomUUID(),cipher=await seal(env,credentials,id+':open-account'),now=Date.now();
 const result=expected===null?await env.DB.prepare('INSERT OR IGNORE INTO device_open_accounts VALUES(?,?,?,?)').bind(id,version,cipher,now).run():await env.DB.prepare('UPDATE device_open_accounts SET version=?,cipher=?,updated_at=? WHERE device_id=? AND version=?').bind(version,cipher,now,id,expected).run();
 if(result.meta.changes!==1)fail(409,'A conta mudou durante o login. Tente novamente.');
}
export async function revokeOpenCredentials(env,id){
 await env.DB.prepare(openSchema).run();
 await env.DB.batch([
  env.DB.prepare("INSERT INTO device_open_accounts VALUES(?,?,'',?) ON CONFLICT(device_id) DO UPDATE SET version=excluded.version,cipher='',updated_at=excluded.updated_at").bind(id,crypto.randomUUID(),Date.now()),
  env.DB.prepare("UPDATE commands SET cipher=NULL,state='cancelled',finished_at=? WHERE device_id=? AND kind='subtitle_session' AND state IN ('pending','delivering')").bind(Date.now(),id)
 ]);
}
// Encrypted device backup; manual/downloaded subtitle files are deliberately excluded.
export function createDevicePersistence({deviceAuth,readBody,seal,unseal,json,fail,connectOpenAccount,openConfigured,limit}) {
 const ready=new WeakSet();
 async function schema(db){if(ready.has(db))return;await db.batch([
  db.prepare('CREATE TABLE IF NOT EXISTS device_backups(device_id TEXT PRIMARY KEY REFERENCES devices(id) ON DELETE CASCADE, revision INTEGER NOT NULL, cipher TEXT NOT NULL, updated_at INTEGER NOT NULL)'),
  db.prepare('CREATE TABLE IF NOT EXISTS device_open_accounts(device_id TEXT PRIMARY KEY REFERENCES devices(id) ON DELETE CASCADE, version TEXT NOT NULL, cipher TEXT NOT NULL, updated_at INTEGER NOT NULL)')
 ]);ready.add(db);}
 async function authenticate(env,input){try{return await connectOpenAccount(env,input);}catch(e){if([422,429,502,503].includes(e.status))fail(e.status,e.message);throw e;}}
 async function validData(b){
  if(typeof b!=='string'||b.length>220000||!/^[A-Za-z0-9+/]*={0,2}$/.test(b))return false;
  try{
   const bytes=Uint8Array.from(atob(b),c=>c.charCodeAt(0));
   const reader=new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip')).getReader();
   let size=0;const chunks=[];
   try{while(true){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>4000000){await reader.cancel();return false;}chunks.push(value);}}
   finally{reader.releaseLock();}
   const raw=new Uint8Array(size);let offset=0;for(const c of chunks){raw.set(c,offset);offset+=c.length;}
   const state=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(raw));
   return state?.v===1&&Array.isArray(state.registry?.lists)&&state.prefs!==null&&typeof state.prefs==='object'&&!Array.isArray(state.prefs);
  }catch{return false;}
 }
 async function account(env,id){const row=await env.DB.prepare('SELECT version,cipher FROM device_open_accounts WHERE device_id=?').bind(id).first();return row?.cipher?{version:row.version,value:await unseal(env,row.cipher,id+':open-account')}:null;}
 return async function(r,env){
  const p=new URL(r.url).pathname,m=r.method,d=await deviceAuth(r,env);await schema(env.DB);
  if(p==='/api/device/persistence'&&m==='GET'){
   const row=await env.DB.prepare('SELECT revision,cipher FROM device_backups WHERE device_id=?').bind(d.id).first();
   return json({revision:row?.revision||0,data:row?await unseal(env,row.cipher,d.id+':backup'):null,openAvailable:!!await account(env,d.id)});
  }
  if(p==='/api/device/persistence'&&m==='PUT'){
   const b=await readBody(r);if(!Number.isSafeInteger(b.revision)||b.revision<0||!await validData(b.data))fail(422,'Backup incompatível.');
   const cipher=await seal(env,b.data,d.id+':backup'),now=Date.now();
   const result=b.revision===0?await env.DB.prepare('INSERT OR IGNORE INTO device_backups VALUES(?,?,?,?)').bind(d.id,1,cipher,now).run():await env.DB.prepare('UPDATE device_backups SET revision=revision+1,cipher=?,updated_at=? WHERE device_id=? AND revision=?').bind(cipher,now,d.id,b.revision).run();
   if(result.meta.changes!==1)fail(409,'O backup foi atualizado em outra sessão.');return json({revision:b.revision+1});
  }
  if(p==='/api/device/opensubtitles/logout'&&m==='POST'){
   await revokeOpenCredentials(env,d.id);return json({ok:true});
  }
  if(p==='/api/device/opensubtitles/login'&&m==='POST'){
   await limit(env,'persistent-open-login:'+d.id,6,600);
   const expected=await openAccountVersion(env,d.id);
   const b=await readBody(r);const credentials={username:b.username,password:b.password};
   const payload=await authenticate(env,b);
   await storeOpenCredentials(env,d.id,credentials,expected,seal,fail);
   return json(payload);
  }
  if(p==='/api/device/opensubtitles/refresh'&&m==='POST'){
   if(!openConfigured(env))fail(503,'OpenSubtitles não configurado.');
   await limit(env,'persistent-open-refresh:'+d.id,6,600);
   const saved=await account(env,d.id);if(!saved)fail(404,'Conecte sua conta do OpenSubtitles pelo site.');
   const payload=await authenticate(env,{...saved.value});
   const current=await env.DB.prepare('SELECT version FROM device_open_accounts WHERE device_id=?').bind(d.id).first();
   if(current?.version!==saved.version)fail(409,'A conta foi alterada durante a renovação.');
   return json(payload);
  }
  fail(404,'Caminho não encontrado.');
 };
}
