﻿[CmdletBinding()]
param([string]$Site="$env:USERPROFILE\AndroidStudioProjects\Site IPTV")
$ErrorActionPreference='Stop'
& "$PSScriptRoot\Aplicar-Site.ps1" -Site $Site
& "$Site\Publicar-Site.ps1"
