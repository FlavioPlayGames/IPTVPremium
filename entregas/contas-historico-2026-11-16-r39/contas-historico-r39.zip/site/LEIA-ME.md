# Site — persistência r39

Aplicar-Site.ps1 -Site "$env:USERPROFILE\AndroidStudioProjects\Site IPTV" verifica a base r31 conhecida e cria recuperação externa. Atualizar-Publicar.ps1 aplica e chama Publicar-Site.ps1 da pasta oficial, mantendo suas verificações, pacote de fontes e comprovante. Nenhuma configuração/secret, imagem ou estilo fora do texto explicativo do login é substituído. Base divergente não deve ser contornada: rebase os fontes atuais. Desfazer-Site.ps1 -Backup restaura apenas fontes que ainda conferem com a atualização; não apaga dados guardados no banco.
