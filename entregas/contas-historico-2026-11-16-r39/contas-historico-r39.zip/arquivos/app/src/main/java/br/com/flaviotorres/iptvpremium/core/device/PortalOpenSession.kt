package br.com.flaviotorres.iptvpremium.core.device

import android.content.Context
import org.json.JSONObject

/** Login secrets are sent over the authenticated portal channel, never stored in the APK backup. */
internal object PortalOpenSession {
    fun request(context:Context,action:String,body:JSONObject=JSONObject()):JSONObject {
        require(action in listOf("login","refresh"))
        val state=PortalIdentityStore(context).load()
        check(state.has("mac")){"Aguardando conexao com a central"}
        val marker=context.getSharedPreferences("device_persistent_backup_v1",Context.MODE_PRIVATE)
        if(action=="refresh")check(!marker.getBoolean("openLogoutPending",false)){"Conta desconectada"}
        return DevicePortalSync(context).call("/api/device/opensubtitles/$action","POST",body,state.getString("secret"))
    }
}
