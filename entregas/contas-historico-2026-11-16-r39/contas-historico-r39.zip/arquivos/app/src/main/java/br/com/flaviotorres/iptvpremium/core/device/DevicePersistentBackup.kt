package br.com.flaviotorres.iptvpremium.core.device

import android.content.Context
import br.com.flaviotorres.iptvpremium.core.player.*
import br.com.flaviotorres.iptvpremium.data.storage.PlaylistStorage
import br.com.flaviotorres.iptvpremium.data.history.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

/** Logical data only. No APK, catalogue, cover cache, subtitle file or Android Keystore ciphertext. */
internal class DevicePersistentBackup(context:Context) {
    private val app=context.applicationContext
    private val marker=app.getSharedPreferences("device_persistent_backup_v1",Context.MODE_PRIVATE)
    companion object {
        private val mutex=Mutex()
        internal val names=listOf("iptvpremium_watch_history_v1","iptvpremium_library_handoff_v2",
            "iptvpremium_shared_library_v1","iptvpremium_movies_assistir_v1","iptvpremium_series_assistir_v1")
            .flatMap{listOf(it,"${it}_kids")}+"iptvpremium_favorites_v1"
    }
    suspend fun observeChanges():Unit=coroutineScope {
        val events=Channel<Unit>(Channel.CONFLATED)
        val listener=android.content.SharedPreferences.OnSharedPreferenceChangeListener{_,_->events.trySend(Unit)}
        val watched=names.map{app.getSharedPreferences(it,Context.MODE_PRIVATE)}
        watched.forEach{it.registerOnSharedPreferenceChangeListener(listener)}
        val registry=launch{PlaylistStorage(app).selection.collect{events.trySend(Unit)}}
        val providers=launch{SubtitleProviderUpdates.revision.collect{events.trySend(Unit)}}
        val retry=launch{while(isActive){delay(30_000L);events.trySend(Unit)}}
        try {
            events.trySend(Unit)
            for(event in events) {
                delay(1_500L)
                br.com.flaviotorres.iptvpremium.data.cache.MediaOpeningPriority.awaitIdle()
                try{syncRegistered()}
                catch(cancelled:CancellationException){throw cancelled}
                catch(_:Exception){android.util.Log.w("DeviceBackup","Backup pendente; ultima copia preservada")}
            }
        }finally{watched.forEach{it.unregisterOnSharedPreferenceChangeListener(listener)};registry.cancel();providers.cancel();retry.cancel();events.close()}
    }
    suspend fun syncRegistered() {
        val state=PortalIdentityStore(app).load()
        if(state.has("mac"))sync(DevicePortalSync(app),state.getString("secret"))
    }
    suspend fun sync(portal:DevicePortalSync,secret:String)=mutex.withLock {
        if(marker.getBoolean("openLogoutPending",false)) {
            portal.call("/api/device/opensubtitles/logout","POST",JSONObject(),secret)
            check(marker.edit().putBoolean("openLogoutPending",false).commit())
        }
        val storage=PlaylistStorage(app)
        val initialData=encode(snapshot(storage))
        if(marker.getBoolean("initialized",false) && marker.getString("digest",null)==fingerprint(initialData) &&
            !marker.getBoolean("openRestorePending",false))return@withLock
        val remote=portal.call("/api/device/persistence","GET",null,secret)
        if(!marker.getBoolean("initialized",false)) {
            val local=storage.persistentSnapshot()
            val localHistory=SubdlCredentialStore(app).isConfigured() || SubsourceCredentialStore(app).isConfigured() || listOf("iptvpremium_watch_history_v1","iptvpremium_watch_history_v1_kids").any{
                app.getSharedPreferences(it,Context.MODE_PRIVATE).getString("items","[]").let{value->value!=null && value!="[]"}}

            if((marker.getBoolean("restoring",false) || (local.getJSONArray("lists").length()==0 && !localHistory)) && !remote.isNull("data")) {
                check(marker.edit().putBoolean("restoring",true).commit())
                restore(decode(remote.getString("data")),storage)
            }
            check(marker.edit().putBoolean("initialized",true).putBoolean("restoring",false).commit())
            check(marker.edit().putBoolean("openRestorePending",remote.optBoolean("openAvailable")).commit())
        }
        if(marker.getBoolean("openRestorePending",false) && System.currentTimeMillis()>=marker.getLong("openRestoreAfter",0L)) {
            val connected=runCatching {
                if(!remote.optBoolean("openAvailable"))true else {
                    val client=openSubtitlesClient(app)
                    val expected=client.sessionGeneration()
                    client.acceptPortalSession(portal.call("/api/device/opensubtitles/refresh","POST",JSONObject(),secret),expected)
                }
            }.getOrDefault(false)
            check(marker.edit().putBoolean("openRestorePending",!connected).putLong("openRestoreAfter",System.currentTimeMillis()+120_000L).commit())
        }
        val data=encode(snapshot(storage))
        val digest=fingerprint(data)
        if(marker.getString("digest",null)!=digest || remote.optLong("revision")==0L) {
            portal.call("/api/device/persistence","PUT",JSONObject().put("revision",remote.getLong("revision")).put("data",data),secret)
            check(marker.edit().putString("digest",digest).commit())
        }
    }
    private suspend fun snapshot(storage:PlaylistStorage):JSONObject {
        val prefs=JSONObject()
        names.forEach{name->
            val values=JSONObject()
            app.getSharedPreferences(name,Context.MODE_PRIVATE).all.toSortedMap().forEach{(key,value)->
                // Projection caches are rebuilt from the active catalogue, never restored across generations.
                if(key.startsWith("target_cache"))return@forEach
                val type=when(value){is String->"s";is Long->"l";is Int->"i";is Boolean->"b";is Float->"f";is Set<*>->"set";else->null}
                if(type!=null)values.put(key,JSONObject().put("t",type).put("v",if(value is Set<*>)JSONArray(value.filterIsInstance<String>().sorted())else value))
            }
            prefs.put(name,values)
        }
        return JSONObject().put("v",1).put("registry",storage.persistentSnapshot()).put("prefs",prefs)
            .put("subdl",SubdlCredentialStore(app).readKey() ?: JSONObject.NULL)
            .put("subsource",SubsourceCredentialStore(app).readKey() ?: JSONObject.NULL)
    }
    private suspend fun restore(data:JSONObject,storage:PlaylistStorage) {
        require(data.getInt("v")==1)
        storage.validatePersistentSnapshot(data.getJSONObject("registry"))
        for(provider in listOf("subdl","subsource"))if(!data.isNull(provider)) {
            val key=data.getString(provider)
            require(key.length in 8..512 && key.none{it.isWhitespace()||it.isISOControl()})
        }
        val prefs=data.getJSONObject("prefs")
        require(prefs.keys().asSequence().all{it in names})
        // Validate every preference before the first write.
        val prepared=names.associateWith{name->
            val values=prefs.optJSONObject(name) ?: JSONObject()
            values.keys().asSequence().associateWith { key->
                val item=values.getJSONObject(key)
                when(item.getString("t")) {
                    "s"->item.getString("v");"l"->item.getLong("v");"i"->item.getInt("v");"b"->item.getBoolean("v");"f"->item.getDouble("v").toFloat()
                    "set"->item.getJSONArray("v").let{a->(0 until a.length()).map{a.getString(it)}.toSet()}
                    else->error("Tipo de backup invalido")
                }
            }
        }
        prepared.forEach{(name,values)->
            val edit=app.getSharedPreferences(name,Context.MODE_PRIVATE).edit().clear()
            values.forEach{(key,value)->when(value){is String->edit.putString(key,value);is Long->edit.putLong(key,value);is Int->edit.putInt(key,value);is Boolean->edit.putBoolean(key,value);is Float->edit.putFloat(key,value);is Set<*>->edit.putStringSet(key,value.filterIsInstance<String>().toSet())}}
            check(edit.commit())
        }
        if(!data.isNull("subdl"))check(SubdlCredentialStore(app).saveKeyFromPortal(data.getString("subdl")))
        if(!data.isNull("subsource"))check(SubsourceCredentialStore(app).saveKeyFromPortal(data.getString("subsource")))
        listOf(false,true).forEach{SharedLibraryStore.get(app,it).reloadPersistentState()}
        WatchHistoryStore.changes.value++
        // Single atomic DataStore edit requests exactly one active import. Others remain registered only.
        storage.restorePersistentSnapshot(data.getJSONObject("registry"))
        SubtitleProviderUpdates.changed()
    }
    private fun encode(value:JSONObject):String {
        val raw=value.toString().toByteArray(Charsets.UTF_8)
        check(raw.size<=4_000_000){"Historico muito grande para o backup"}
        val bytes=java.io.ByteArrayOutputStream().also{out->java.util.zip.GZIPOutputStream(out).use{it.write(raw)}}.toByteArray()
        return java.util.Base64.getEncoder().encodeToString(bytes).also{check(it.length<=220_000){"Backup excede o limite da central"}}
    }
    private fun decode(value:String):JSONObject {
        require(value.length<=220_000)
        val input=java.util.zip.GZIPInputStream(java.io.ByteArrayInputStream(java.util.Base64.getDecoder().decode(value)))
        val out=java.io.ByteArrayOutputStream()
        input.use{val buffer=ByteArray(8192);while(true){val n=it.read(buffer);if(n<0)break;require(out.size()+n<=4_000_000);out.write(buffer,0,n)}}
        return JSONObject(out.toString("UTF-8"))
    }
}
