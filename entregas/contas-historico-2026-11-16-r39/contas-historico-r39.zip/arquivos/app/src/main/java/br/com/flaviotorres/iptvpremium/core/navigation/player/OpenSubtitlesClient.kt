package br.com.flaviotorres.iptvpremium.core.player

import kotlinx.coroutines.sync.withLock

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import kotlin.coroutines.coroutineContext

internal data class OpenSubtitleAppConfig(val apiKey:String,val userAgent:String) {
    val available get()=apiKey.length in 8..512 && apiKey.none{it.isWhitespace()||it.isISOControl()} &&
        userAgent.length in 3..200 && userAgent.none{it.isISOControl()}
    val fingerprint get()=openSubtitleDigest(apiKey)
}
internal interface OpenSubtitleAccounts {
    fun generation():Long
    fun read():OpenSubtitleSession?
    fun save(token:String,base:String,expiresAt:Long,appFingerprint:String,expectedGeneration:Long,accountScope:String):Boolean
    fun disconnect(expectedToken:String?=null):Boolean
}
internal data class OpenSubtitleResponse(val code:Int,val data:ByteArray,val retryAfterSeconds:Long?=null)
internal fun interface OpenSubtitleTransport {
    suspend fun request(url:String,method:String,headers:Map<String,String>,body:String?,limit:Int):OpenSubtitleResponse
}

/** Bounded HTTPS transport. API requests never follow redirects with credentials. */
internal class OpenSubtitleHttpTransport:OpenSubtitleTransport {
    override suspend fun request(url:String,method:String,headers:Map<String,String>,body:String?,limit:Int):OpenSubtitleResponse {
        coroutineContext.ensureActive()
        val uri=java.net.URI(url)
        require(uri.scheme=="https" && uri.userInfo==null && uri.port in setOf(-1,443))
        val con=URL(url).openConnection() as HttpURLConnection
        try {
            con.requestMethod=method;con.instanceFollowRedirects=false
            con.connectTimeout=7000;con.readTimeout=10000
            headers.forEach{(k,v)->con.setRequestProperty(k,v)}
            if(body!=null) {
                val data=body.toByteArray(Charsets.UTF_8);con.doOutput=true
                con.setRequestProperty("Content-Type","application/json")
                con.setFixedLengthStreamingMode(data.size);con.outputStream.use{it.write(data)}
            }
            val code=con.responseCode
            if(code in 300..399) {
                val location=con.getHeaderField("Location").orEmpty()
                // Only public file downloads can redirect; still no token or API key.
                return OpenSubtitleResponse(code,location.toByteArray(Charsets.UTF_8))
            }
            val retryHeader=con.getHeaderField("Retry-After")
            val retry=retryHeader?.toLongOrNull() ?: runCatching {
                val instant=java.time.ZonedDateTime.parse(retryHeader,java.time.format.DateTimeFormatter.RFC_1123_DATE_TIME).toInstant()
                (instant.toEpochMilli()-System.currentTimeMillis())/1000
            }.getOrNull()
            if(code !in 200..299)return OpenSubtitleResponse(code,byteArrayOf(),retry)
            if(con.contentLengthLong>limit)return OpenSubtitleResponse(413,byteArrayOf())
            val data=con.inputStream.use { input->
                val out=ByteArrayOutputStream();val buffer=ByteArray(8192)
                while(out.size()<=limit) {
                    coroutineContext.ensureActive()
                    val n=input.read(buffer,0,minOf(buffer.size,limit+1-out.size()))
                    if(n<0)break
                    if(n>0)out.write(buffer,0,n)
                }
                out.toByteArray()
            }
            return if(data.size>limit)OpenSubtitleResponse(413,byteArrayOf()) else OpenSubtitleResponse(code,data)
        }finally{con.disconnect()}
    }
}

/** No password persistence, no URL/token logging, no subtitle download during search. */
internal class OpenSubtitlesClient(
    private val config:()->OpenSubtitleAppConfig,
    private val accounts:OpenSubtitleAccounts,
    private val transport:OpenSubtitleTransport=OpenSubtitleHttpTransport(),
    private val trace:(String)->Unit={},
    private val now:()->Long=System::currentTimeMillis,
    private val renew:(suspend ()->JSONObject)?=null,
    private val portalLogin:(suspend (String,String)->JSONObject)?=null,
    private val onDisconnect:()->Unit={},
    private val onConnected:()->Unit={}
) {
    companion object { private val renewalMutex=kotlinx.coroutines.sync.Mutex(); private val limits=java.util.concurrent.ConcurrentHashMap<String,Long>() }
    val appAvailable get()=config().available
    fun scope():String? {
        val app=config();if(!app.available)return null
        return accounts.read()?.takeIf{it.appFingerprint==app.fingerprint}?.scope
    }
    fun connected()=scope()!=null
    fun disconnect(){accounts.disconnect();onDisconnect()}
    val registrationFingerprint get()=config().takeIf{it.available}?.fingerprint.orEmpty()
    /** Only an authenticated device pull can call this; no password is delivered by the portal. */
    fun sessionGeneration()=accounts.generation()
    fun acceptPortalSession(data:JSONObject,expectedGeneration:Long=accounts.generation()):Boolean {
        val app=config();if(!app.available)return false
        val expected=expectedGeneration
        val session=decodeOpenPortalSession(data,app.fingerprint,now())?:return false
        return accounts.save(session.token,session.apiBase,session.expiresAt,app.fingerprint,expected,session.scope).also{if(it)onConnected()}
    }
    private suspend fun session():OpenSubtitleSession = renewalMutex.withLock {
        if(!appAvailable)throw OpenSubtitleException(OpenSubtitleProblem.APP_UNAVAILABLE)
        val s=accounts.read() ?: throw OpenSubtitleException(OpenSubtitleProblem.LOGIN_REQUIRED)
        if(s.appFingerprint!=config().fingerprint)throw OpenSubtitleException(OpenSubtitleProblem.SESSION_EXPIRED)
        if(s.expiresAt>now()+60_000L)return@withLock s
        val refresh=renew ?: throw OpenSubtitleException(OpenSubtitleProblem.SESSION_EXPIRED)
        val expected=accounts.generation()
        val next=decodeOpenPortalSession(refresh(),config().fingerprint,now())
            ?:throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)
        if(next.scope!=s.scope || !accounts.save(next.token,next.apiBase,next.expiresAt,next.appFingerprint,expected,next.scope))
            throw OpenSubtitleException(OpenSubtitleProblem.SESSION_EXPIRED)
        next
    }
    fun checkScope(scope:String) {
        val current=accounts.read()
        if(current?.scope!=scope || current.appFingerprint!=config().fingerprint)
            throw OpenSubtitleException(OpenSubtitleProblem.SESSION_EXPIRED)
    }
    suspend fun login(username:String,password:String):Unit=withContext(Dispatchers.IO) {
        val app=config();if(!app.available)throw OpenSubtitleException(OpenSubtitleProblem.APP_UNAVAILABLE)
        if(username.trim().length !in 1..320 || password.length !in 1..1024 ||
            username.any{it.isISOControl()} || password.any{it.isISOControl()})
            throw OpenSubtitleException(OpenSubtitleProblem.INVALID_LOGIN)
        if(portalLogin!=null) {
            val expected=accounts.generation()
            val value=decodeOpenPortalSession(portalLogin.invoke(username.trim(),password),app.fingerprint,now())
                ?:throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)
            if(!accounts.save(value.token,value.apiBase,value.expiresAt,app.fingerprint,expected,value.scope))
                throw OpenSubtitleException(OpenSubtitleProblem.STORAGE)
            onConnected();return@withContext
        }
        val generation=accounts.generation()
        val result=call("https://api.opensubtitles.com/api/v1/login","POST",null,
            JSONObject().put("username",username.trim()).put("password",password).toString(),true)
        val token=result.optString("token")
        if(token.length !in 8..16000 || token.any{it.isWhitespace()||it.isISOControl()})
            throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)
        val rawBase=result.optString("base_url").ifBlank{"api.opensubtitles.com"}
        val base=openSubtitleApiBase(rawBase) ?: throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)
        val expires=runCatching {
            val jwt=token.split('.');if(jwt.size!=3)return@runCatching null
            val decoded=String(java.util.Base64.getUrlDecoder().decode(jwt[1]),Charsets.UTF_8)
            JSONObject(decoded).optLong("exp",0).takeIf{it>now()/1000}?.times(1000)
        }.getOrNull() ?: (now()+23*60*60*1000L)
        val userId=result.optJSONObject("user")?.optString("user_id")
            ?.takeIf{it.matches(Regex("[1-9][0-9]{0,17}"))}
        val identity=userId?.let{"id:$it"}?:"name:${username.trim().lowercase(java.util.Locale.ROOT)}"
        val accountScope=openSubtitleDigest("${app.fingerprint}|$identity")
        coroutineContext.ensureActive()
        if(config().fingerprint!=app.fingerprint || !accounts.save(token,base,expires,app.fingerprint,generation,accountScope))
            throw OpenSubtitleException(OpenSubtitleProblem.STORAGE)
    }
    suspend fun search(query:OpenSubtitleQuery):Pair<String,List<OpenSubtitleHit>> = withContext(Dispatchers.IO) {
        val s=session()
        suspend fun fetch(language:String):Pair<List<OpenSubtitleHit>,Boolean> {
            val json=call("${s.apiBase}/subtitles?${query.parameters(language)}","GET",s,null)
            checkScope(s.scope)
            if(json.optJSONArray("data")==null)throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)
            val hits=decodeOpenSubtitleHits(json,query)
            trace("stage=search language=$language identity=${if(query.tmdbId?.toLongOrNull()?.let{it>0}==true)"TMDB"else"TITLE"} kind=${if(query.isEpisode)"EPISODE"else"MOVIE"} received=${json.getJSONArray("data").length()} matched=${hits.size}")
            return hits to (json.optInt("total_pages",1)>1)
        }
        val (initial,morePages)=fetch("pt-br,pt-pt,en,es")
        val found=initial.toMutableList()
        // A popular English release must not crowd PT-BR or Spanish out of page one.
        for((code,label)in listOf("pt-br" to "pt-BR","pt-pt" to "pt-PT","en" to "en","es" to "es")) {
            if(morePages && found.none{it.language==label})found.addAll(fetch(code).first)
        }
        checkScope(s.scope)
        val bounded=found.distinctBy{it.fileId}.groupBy{it.language}
        s.scope to listOf("pt-BR","pt-PT","en","es").flatMap{bounded[it].orEmpty().take(30)}

    }
    /** Exactly one quota-consuming POST, only after explicit selection/cache miss. */
    suspend fun download(fileId:String,expectedScope:String):ByteArray=withContext(Dispatchers.IO) {
        require(fileId.matches(Regex("[1-9][0-9]{0,17}")))
        checkScope(expectedScope);val s=session()
        val response=call("${s.apiBase}/download","POST",s,
            JSONObject().put("file_id",fileId.toLong()).toString())
        checkScope(expectedScope)
        var link=response.optString("link")
        repeat(3) {
            if(!openSubtitleDownloadUrl(link))throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)
            // Never send Api-Key, Authorization, cookies or a password to the download host.
            val r=safeRequest(link,"GET",mapOf("User-Agent" to config().userAgent),null,5_000_000)
            checkScope(expectedScope)
            if(r.code in 300..399) {
                link=runCatching{URL(URL(link),String(r.data,Charsets.UTF_8)).toString()}.getOrElse{
                    throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)}
            }else {
                if(r.code !in 200..299)throw OpenSubtitleException(
                    if(r.code in setOf(406,429))OpenSubtitleProblem.LIMITED else OpenSubtitleProblem.UNAVAILABLE)
                return@withContext r.data
            }
        }
        throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)
    }
    private suspend fun call(url:String,method:String,s:OpenSubtitleSession?,body:String?,login:Boolean=false):JSONObject {
        val app=config();if(!app.available)throw OpenSubtitleException(OpenSubtitleProblem.APP_UNAVAILABLE)
        if(now()<(limits[app.fingerprint]?:0))throw OpenSubtitleException(OpenSubtitleProblem.LIMITED)
        val headers=mutableMapOf("Api-Key" to app.apiKey,"User-Agent" to app.userAgent,"Accept" to "application/json")
        if(s!=null)headers["Authorization"]="Bearer ${s.token}"
        var address=url
        var response:OpenSubtitleResponse?=null
        val visited=hashSetOf(address)
        for(hop in 0..2) {
            val started=System.nanoTime()
            val received=safeRequest(address,method,headers,body,2_000_000)
            val endpoint=java.net.URI(address).path.trimEnd('/').substringAfterLast('/').takeIf{it in setOf("login","subtitles","download")}?:"other"
            trace("stage=http endpoint=$endpoint httpStatus=${received.code} elapsedMs=${(System.nanoTime()-started)/1_000_000}")
            coroutineContext.ensureActive()
            if(method=="GET" && endpoint=="subtitles" && received.code in setOf(301,302,307,308)) {
                val next=openSubtitleSearchRedirect(address,String(received.data,Charsets.UTF_8))
                if(next==null || !visited.add(next)) {
                    trace("stage=redirect status=BLOCKED hop=${hop+1}")
                    throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)
                }
                if(hop==2) {
                    trace("stage=redirect status=LIMIT hop=3")
                    throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)
                }
                trace("stage=redirect status=FOLLOWED hop=${hop+1}")
                address=next
            } else {response=received;break}
        }
        val r=response?:throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)
        coroutineContext.ensureActive()
        if(r.code==401) {
            val expected=accounts.generation()
            if(s!=null && accounts.read()?.token==s.token)accounts.save(s.token,s.apiBase,0L,s.appFingerprint,expected,s.scope)
            throw OpenSubtitleException(if(login)OpenSubtitleProblem.INVALID_LOGIN else OpenSubtitleProblem.SESSION_EXPIRED)
        }
        if(r.code==429) {
            limits[app.fingerprint]=now()+(r.retryAfterSeconds?:60).coerceIn(1,86400)*1000
            throw OpenSubtitleException(OpenSubtitleProblem.LIMITED)
        }
        if(r.code==406)throw OpenSubtitleException(OpenSubtitleProblem.LIMITED)
        if(r.code==403)throw OpenSubtitleException(OpenSubtitleProblem.ACCESS_DENIED)
        if(r.code in setOf(400,404,422))throw OpenSubtitleException(OpenSubtitleProblem.QUERY_REJECTED)
        if(r.code !in 200..299)throw OpenSubtitleException(
            if(login && r.code==403)OpenSubtitleProblem.APP_UNAVAILABLE else OpenSubtitleProblem.UNAVAILABLE)
        return try{JSONObject(String(r.data,Charsets.UTF_8))}catch(_:Exception){
            throw OpenSubtitleException(OpenSubtitleProblem.INVALID_RESPONSE)}
    }
    private suspend fun safeRequest(url:String,method:String,headers:Map<String,String>,body:String?,limit:Int):OpenSubtitleResponse=try {
        transport.request(url,method,headers,body,limit)
    }catch(cancelled:CancellationException){throw cancelled}
    catch(error:OpenSubtitleException){throw error}
    catch(error:Exception){
        val type=when(error){
            is java.net.SocketTimeoutException->"TIMEOUT"
            is java.net.UnknownHostException->"DNS"
            is javax.net.ssl.SSLException->"TLS"
            is java.io.IOException->"IO"
            else->"OTHER"
        }
        trace("stage=transport error=$type")
        throw OpenSubtitleException(OpenSubtitleProblem.UNAVAILABLE)
    }
}
