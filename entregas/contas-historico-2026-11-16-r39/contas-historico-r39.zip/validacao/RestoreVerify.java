import java.util.*;
import java.io.*;
import java.lang.reflect.*;
import org.json.*;
import androidx.datastore.preferences.core.*;
import br.com.flaviotorres.iptvpremium.data.storage.PlaylistStorage;
import br.com.flaviotorres.iptvpremium.core.device.DevicePersistentBackup;
import kotlinx.coroutines.BuildersKt;
import kotlin.coroutines.EmptyCoroutineContext;
public class RestoreVerify {
 static int checks;
 static void check(boolean b,String reason){if(!b)throw new AssertionError(reason);checks++;System.out.println("PASS "+reason);}
 static Method method(Object target,String name){return Arrays.stream(target.getClass().getDeclaredMethods()).filter(m->m.getName().equals(name)||m.getName().startsWith(name+"$")).findFirst().map(m->{m.setAccessible(true);return m;}).orElseThrow();}
 static Object suspend(Object target,String name,Object... args)throws Exception{return BuildersKt.runBlocking(EmptyCoroutineContext.INSTANCE,(scope,continuation)->{try{Object[] a=Arrays.copyOf(args,args.length+1);a[args.length]=continuation;return method(target,name).invoke(target,a);}catch(Exception e){throw new RuntimeException(e);}});}
 static JSONObject value(String type,Object v){return new JSONObject().put("t",type).put("v",v);}
 public static void main(String[] args)throws Exception {
  File temp=java.nio.file.Files.createTempDirectory("restore-r39-").toFile();
  var ds=PreferenceDataStoreFactory.INSTANCE.create(()->new File(temp,"playlist.preferences_pb"));
  var storage=new PlaylistStorage(ds);var context=new android.content.Context();var backup=new DevicePersistentBackup(context);
  JSONArray lists=new JSONArray();for(String id:List.of("A","B","C"))lists.put(new JSONObject().put("id",id).put("name",id).put("isEnabled",true).put("type","m3u").put("playlistUrl","https://example.invalid/"+id));
  JSONObject registry=new JSONObject().put("lists",lists).put("active","B");
  var movie=new br.com.flaviotorres.iptvpremium.core.player.PlaybackMedia("movie",br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType.MOVIE,"Movie","https://example.invalid/movie",null,null,null,3600000L,null,null,null,null,null,null,2020);
  var episode=new br.com.flaviotorres.iptvpremium.core.player.PlaybackMedia("episode",br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType.EPISODE,"Episode","https://example.invalid/episode",null,null,null,2400000L,"series",5,6,null,null,"Series",2020);
  new br.com.flaviotorres.iptvpremium.data.history.WatchHistoryStore(context,false).save("B",movie,600000L,3600000L,null,null,false);
  new br.com.flaviotorres.iptvpremium.data.history.WatchHistoryStore(context,true).save("A",episode,120000L,2400000L,"Series",null,false);
  JSONObject normal=new JSONObject().put("items",value("s",context.getSharedPreferences("iptvpremium_watch_history_v1",0).getString("items","[]")));
  JSONObject kids=new JSONObject().put("items",value("s",context.getSharedPreferences("iptvpremium_watch_history_v1_kids",0).getString("items","[]")));
  JSONObject prefs=new JSONObject().put("iptvpremium_watch_history_v1",normal).put("iptvpremium_watch_history_v1_kids",kids)
   .put("iptvpremium_favorites_v1",new JSONObject().put("movies_B",value("set",new JSONArray().put("movie"))));
  JSONObject data=new JSONObject().put("v",1).put("registry",registry).put("prefs",prefs).put("subdl",JSONObject.NULL).put("subsource",JSONObject.NULL);
  context.getSharedPreferences("manual_subtitles_v1",0).edit().putString("items","manual-untouched").commit();
  suspend(backup,"restore",data,storage);
  JSONObject restored=(JSONObject)suspend(storage,"persistentSnapshot");
  check(restored.getJSONArray("lists").length()==3,"all list registrations restored");
  check(restored.getString("active").equals("B"),"previous active list retained");
  Method load=method(storage,"getPortalLoadRequest");Object flow=load.invoke(storage);
  // Read the actual DataStore snapshot: exactly one request references the active list.
  final Object[] state={null};BuildersKt.runBlocking(EmptyCoroutineContext.INSTANCE,(scope,cont)->kotlinx.coroutines.flow.FlowKt.first(ds.getData(),cont));
  Preferences saved=(Preferences)BuildersKt.runBlocking(EmptyCoroutineContext.INSTANCE,(scope,cont)->kotlinx.coroutines.flow.FlowKt.first(ds.getData(),cont));
  long requests=saved.asMap().entrySet().stream().filter(e->e.getKey().getName().equals("portal_load_request")&&e.getValue().toString().contains("\"id\":\"B\"")).count();
  check(requests==1,"only active list gets an import request");
  check(saved.asMap().keySet().stream().noneMatch(k->k.getName().equals("changed_disabled_catalogs")),"inactive lists are not scheduled for bulk refresh");
  check(context.getSharedPreferences("iptvpremium_watch_history_v1",0).getString("items","").contains("600000"),"movie/series progress restored");
  check(context.getSharedPreferences("iptvpremium_watch_history_v1_kids",0).getString("items","").contains("120000"),"Kids history remains separate");
  check(new br.com.flaviotorres.iptvpremium.data.history.WatchHistoryStore(context,false).allLocal().get(0).getInProgress(),"restored movie is usable by real history decoder");
  check(new br.com.flaviotorres.iptvpremium.data.history.WatchHistoryStore(context,true).allLocal().get(0).getEpisodeNumber()==6,"restored series retains episode coordinates");
  check(context.getSharedPreferences("iptvpremium_favorites_v1",0).getStringSet("movies_B",Set.of()).contains("movie"),"favorite sets retain their type");
  check(context.getSharedPreferences("manual_subtitles_v1",0).getString("items","").equals("manual-untouched"),"manual subtitles excluded from restoration");
  JSONObject snapshot=(JSONObject)suspend(backup,"snapshot",storage);
  check(!snapshot.getJSONObject("prefs").has("manual_subtitles_v1"),"manual subtitle settings excluded from backup");
  check(!snapshot.toString().contains("manual-untouched"),"no manual subtitle content in payload");
  String encoded=(String)method(backup,"encode").invoke(backup,snapshot);
  JSONObject decoded=(JSONObject)method(backup,"decode").invoke(backup,encoded);
  check(decoded.getJSONObject("registry").getJSONArray("lists").length()==3,"bounded gzip backup round trip");
  JSONObject malicious=new JSONObject(data.toString());malicious.getJSONObject("prefs").put("unapproved_preferences",new JSONObject());
  try{suspend(backup,"restore",malicious,storage);throw new AssertionError("unapproved preference accepted");}catch(RuntimeException expected){}
  check(!context.getSharedPreferences("iptvpremium_watch_history_v1",0).getString("items","").isEmpty(),"invalid backup rejected before modifying history");
  JSONObject empty=new JSONObject().put("lists",new JSONArray()).put("active",JSONObject.NULL);
  suspend(storage,"restorePersistentSnapshot",empty);
  check(((JSONObject)suspend(storage,"persistentSnapshot")).getJSONArray("lists").isEmpty(),"deliberately empty registry remains empty");
  System.out.println("TOTAL "+checks+" restoration checks passed with actual DataStore and production classes");
 }
}
