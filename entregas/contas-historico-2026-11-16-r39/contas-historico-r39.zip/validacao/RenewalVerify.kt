package br.com.flaviotorres.iptvpremium.core.player
import kotlinx.coroutines.*
import org.json.JSONObject
private class Accounts:OpenSubtitleAccounts {
 var value:OpenSubtitleSession?=null;var gen=0L
 override fun read()=value
 override fun generation()=gen
 override fun save(token:String,base:String,expiresAt:Long,appFingerprint:String,expectedGeneration:Long,accountScope:String):Boolean {
  if(gen!=expectedGeneration)return false
  gen++;value=OpenSubtitleSession(token,base,accountScope,expiresAt,appFingerprint);return true
 }
 override fun disconnect(expectedToken:String?):Boolean{if(expectedToken!=null&&value?.token!=expectedToken)return false;value=null;gen++;return true}
}
private var count=0
private fun verify(ok:Boolean,label:String){check(ok){label};count++;println("PASS $label")}
fun main()=runBlocking {
 val app=OpenSubtitleAppConfig("test-registration-key","IPTVPremium v1.13")
 val clock=1_800_000_000_000L;val scope="a".repeat(64);val query=OpenSubtitleQuery("Title",2020,null)
 fun payload()=JSONObject().put("provider","opensubtitles").put("token","new-session-token").put("apiHost","api.opensubtitles.com")
  .put("appFingerprint",app.fingerprint).put("accountScope",scope).put("expiresAt",clock+3_600_000).put("issuedAt",clock)
 val accounts=Accounts().also{it.value=OpenSubtitleSession("old-session-token","https://api.opensubtitles.com/api/v1",scope,clock-1,app.fingerprint)}
 var renewals=0;var requests=0
 val transport=OpenSubtitleTransport{_,method,headers,_,_->
  requests++;check(method=="GET");check(headers["Authorization"]=="Bearer new-session-token")
  OpenSubtitleResponse(200,"{\"data\":[],\"total_pages\":1}".toByteArray())
 }
 val client=OpenSubtitlesClient({app},accounts,transport,now={clock},renew={renewals++;delay(20);payload()})
 verify(client.connected(),"expired token retains connected account")
 coroutineScope{(1..4).map{async{client.search(query)}}.awaitAll()}
 verify(renewals==1&&requests==4,"concurrent searches renew once, then use renewed token")
 verify(accounts.value?.token=="new-session-token","renewed token persisted")
 var logout=false
 val disconnecting=OpenSubtitlesClient({app},accounts,transport,now={clock},onDisconnect={logout=true})
 disconnecting.disconnect();verify(logout&&!disconnecting.connected(),"explicit disconnect clears account and requests server revocation")
 val raceAccounts=Accounts().also{it.value=OpenSubtitleSession("expired-token","https://api.opensubtitles.com/api/v1",scope,clock-1,app.fingerprint)}
 lateinit var racing:OpenSubtitlesClient
 racing=OpenSubtitlesClient({app},raceAccounts,transport,now={clock},renew={racing.disconnect();payload()})
 try{racing.search(query);error("renewal after logout accepted")}catch(_:OpenSubtitleException){}
 verify(!racing.connected(),"renewal finishing after disconnect cannot reconnect account")
 val unavailableAccounts=Accounts().also{it.value=OpenSubtitleSession("expired-token","https://api.opensubtitles.com/api/v1",scope,clock-1,app.fingerprint)}
 val unavailable=OpenSubtitlesClient({app},unavailableAccounts,transport,now={clock},renew={throw java.io.IOException("offline")})
 try{unavailable.search(query);error("expected network failure")}catch(_:java.io.IOException){}
 verify(unavailable.connected(),"temporary network failure does not discard saved account")
 val portal=OpenSubtitlesClient({app},Accounts(),transport,now={clock})
 val generation=portal.sessionGeneration();portal.disconnect()
 verify(!portal.acceptPortalSession(payload(),generation),"stale portal delivery after logout rejected")
 println("TOTAL $count renewal checks passed")
}
