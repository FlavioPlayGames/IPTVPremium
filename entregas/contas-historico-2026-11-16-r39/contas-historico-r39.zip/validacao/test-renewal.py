from pathlib import Path
import subprocess
v=Path('/workspace/persistencia-r39');t=Path('/workspace/iptv-tools');r=Path('/workspace/iptv-visual-r32/app/src/main/java/br/com/flaviotorres/iptvpremium/core/navigation/player')
cp=':'.join(map(str,t.glob('*.jar')));java=str(t/'jdk25/bin/java')
for args in [[java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',str(v/'renewal-tests.jar'),str(r/'OpenSubtitlesProtocol.kt'),str(r/'OpenSubtitlesClient.kt'),str(v/'RenewalVerify.kt')],[java,'-cp',str(v/'renewal-tests.jar')+':'+cp,'br.com.flaviotorres.iptvpremium.core.player.RenewalVerifyKt']]:
 p=subprocess.run(args,capture_output=True,text=True);print(p.stdout+p.stderr);assert p.returncode==0
