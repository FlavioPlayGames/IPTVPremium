package android.content;
import java.lang.reflect.*;
import java.util.*;
/** JVM test host only. No replacement Android code is shipped in the APK. */
public class Context {
 public static final int MODE_PRIVATE=0;
 private final Map<String,SharedPreferences> files=new HashMap<>();
 private final java.io.File root=new java.io.File(System.getProperty("java.io.tmpdir"),"manual-subtitles-store-"+java.util.UUID.randomUUID());
 public java.io.File getFilesDir(){java.io.File f=new java.io.File(root,"files");f.mkdirs();return f;}
 public java.io.File getCacheDir(){java.io.File f=new java.io.File(root,"cache");f.mkdirs();return f;}
 public java.io.File getNoBackupFilesDir(){java.io.File f=new java.io.File(root,"noBackup");f.mkdirs();return f;}
 public Context getApplicationContext(){return this;}
 public SharedPreferences getSharedPreferences(String name,int mode){return files.computeIfAbsent(name,n->memory());}
 private SharedPreferences memory(){
  Map<String,Object> values=new HashMap<>();
  Set<SharedPreferences.OnSharedPreferenceChangeListener> listeners=new HashSet<>();
  final SharedPreferences[] owner=new SharedPreferences[1];
  owner[0]=(SharedPreferences)Proxy.newProxyInstance(getClass().getClassLoader(),new Class[]{SharedPreferences.class},(proxy,m,args)->{
   String op=m.getName();
   if(op.equals("edit")) {
    Map<String,Object> pending=new HashMap<>();
    return Proxy.newProxyInstance(getClass().getClassLoader(),new Class[]{SharedPreferences.Editor.class},(editor,method,a)->{
     String action=method.getName();
     if(action.startsWith("put")){pending.put((String)a[0],a[1]);return editor;}
     if(action.equals("apply")||action.equals("commit")){
      values.putAll(pending);
      for(String key:pending.keySet())for(SharedPreferences.OnSharedPreferenceChangeListener l:new HashSet<>(listeners))l.onSharedPreferenceChanged(owner[0],key);
      return action.equals("commit")?true:null;
     }
     if(action.equals("remove")){values.remove(a[0]);return editor;}
     if(action.equals("clear")){values.clear();return editor;}
     return null;
    });
   }
   if(op.startsWith("get")&&args!=null&&args.length==2)return values.getOrDefault(args[0],args[1]);
   if(op.equals("getAll"))return new HashMap<>(values);
   if(op.equals("contains"))return values.containsKey(args[0]);
   if(op.equals("registerOnSharedPreferenceChangeListener")){listeners.add((SharedPreferences.OnSharedPreferenceChangeListener)args[0]);return null;}
   if(op.equals("unregisterOnSharedPreferenceChangeListener")){listeners.remove(args[0]);return null;}
   if(op.equals("hashCode"))return System.identityHashCode(proxy);
   if(op.equals("equals"))return proxy==args[0];
   return null;
  });return owner[0];
 }
}
