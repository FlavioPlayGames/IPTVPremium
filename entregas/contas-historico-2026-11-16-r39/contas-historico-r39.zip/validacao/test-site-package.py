from pathlib import Path
import tempfile,subprocess,shutil,json,os,hashlib
out=Path('/workspace/entregas/contas-historico-r39/site');base=Path('/workspace/site-d1-r31');items=json.loads((out/'manifesto.json').read_text());pw='/workspace/iptv-tools/powershell/pwsh'
env=os.environ.copy()
for n in ['CACHE','CONFIG','DATA']:env['XDG_'+n+'_HOME']='/workspace/iptv-tools/xdg-'+n.lower()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()if p.is_file()else None
def call(args,ok=True):
 p=subprocess.run([pw,'-NoProfile',*args],capture_output=True,text=True,env=env);assert (p.returncode==0)==ok,(p.stdout,p.stderr);return p
with tempfile.TemporaryDirectory(prefix='site-r39-')as name:
 temp=Path(name);site=temp/'Site IPTV';site.mkdir();downloads=temp/'Downloads';downloads.mkdir()
 for item in items:
  if item['before']:
   p=site/item['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/item['path'],p)
 args=['-File',str(out/'Aplicar-Site.ps1'),'-Site',str(site),'-Downloads',str(downloads)]
 call(args);call(args);assert all(sha(site/i['path'])==i['after']for i in items)
 backup=next(downloads.glob('IPTV-site-restauracao-r39-*'))
 first=site/items[0]['path'];saved=first.read_bytes();first.write_bytes(saved+b'// later edit')
 rollback=['-File',str(out/'Desfazer-Site.ps1'),'-Backup',str(backup)]
 call(rollback,False);first.write_bytes(saved);call(rollback)
 assert all(sha(site/i['path'])==i['before']for i in items)
 first.write_bytes(first.read_bytes()+b'// divergent base');call(args,False)
 print('PASS site apply/repeat/restore, later edit protection and divergent base rejection')
 for f in out.glob('*.ps1'):
  command="$t=$null;$e=$null;[System.Management.Automation.Language.Parser]::ParseFile('"+str(f)+"',[ref]$t,[ref]$e)|Out-Null;if($e.Count){$e;exit 1}"
  call(['-Command',command])
 print('PASS site PowerShell parsers')
