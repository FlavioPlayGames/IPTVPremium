from pathlib import Path
import subprocess,os
v=Path('/workspace/persistencia-r39');t=Path('/workspace/iptv-tools');c=Path('/workspace/iptv-visual-r32/app/build/intermediates/built_in_kotlinc/desempenho/compileDesempenhoKotlin/classes');fake=v/'host';fake.mkdir(exist_ok=True)
s=Path('/workspace/iptv-visual-r32/validacao/r37/preferences-fake/android/content/Context.java').read_text().replace(' public Context getApplicationContext()', ' public java.io.File getNoBackupFilesDir(){java.io.File f=new java.io.File(root,"noBackup");f.mkdirs();return f;}\n public Context getApplicationContext()')
f=v/'Context.java';f.write_text(s)
cp=os.pathsep.join(map(str,[fake,c]+list(t.glob('*.jar'))+list(Path('/workspace/.gradle-cache/caches/modules-2/files-2.1/androidx.datastore').glob('*/*/*/*.jar'))+list(Path('/workspace/.gradle-cache/caches/9.6.0/transforms').glob('*/transformed/*-runtime.jar'))+[Path('/workspace/android-sdk/platforms/android-37.0/android.jar')]))
for args in [[str(t/'jdk25/bin/javac'),'-cp',cp,'-d',str(fake),str(f),str(v/'RestoreVerify.java')],[str(t/'jdk25/bin/java'),'-cp',cp,'RestoreVerify']]:
 p=subprocess.run(args,capture_output=True,text=True);print(p.stdout+p.stderr);assert p.returncode==0
