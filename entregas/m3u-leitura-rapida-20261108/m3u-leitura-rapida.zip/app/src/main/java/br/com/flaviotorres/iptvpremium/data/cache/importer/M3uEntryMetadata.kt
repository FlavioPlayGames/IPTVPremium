package br.com.flaviotorres.iptvpremium.data.cache.importer

/** One scan for known metadata; first occurrence and empty tvg-id presence stay unchanged. */
internal object M3uEntryMetadata {
    data class Fields(val group: String?, val logo: String?, val tvgId: String?, val hasXuiId: Boolean)
    private val attributes = java.util.regex.Pattern.compile(
        "(?:^|\\s)(?:(group-title|tvg-logo|tvg-id)\\s*=\\s*\"([^\"]*)\"|(xui-id)\\s*=)",
        java.util.regex.Pattern.CASE_INSENSITIVE or java.util.regex.Pattern.UNICODE_CASE
    )
    // Keep the legacy type hint when an xui-id token occurs inside a quoted value.
    private val embeddedXui = java.util.regex.Pattern.compile(
        "\\sxui-id\\s*=", java.util.regex.Pattern.CASE_INSENSITIVE or java.util.regex.Pattern.UNICODE_CASE
    )
    private fun embedded(value: String?): Boolean =
        value != null && value.indexOf('=') >= 0 && embeddedXui.matcher(value).find()

    fun parse(line: String): Fields {
        var group: String? = null
        var logo: String? = null
        var tvgId: String? = null
        var hasXuiId = false
        val matcher = attributes.matcher(line)
        while (matcher.find()) {
            val key = matcher.group(1)
            if (!hasXuiId && key != null && embedded(matcher.group(2))) hasXuiId = true
            when {
                key == null -> hasXuiId = true
                key.equals("group-title", true) && group == null -> group = matcher.group(2)
                key.equals("tvg-logo", true) && logo == null -> logo = matcher.group(2)
                key.equals("tvg-id", true) && tvgId == null -> tvgId = matcher.group(2)
            }
        }
        return Fields(group, logo, tvgId, hasXuiId)
    }
}
