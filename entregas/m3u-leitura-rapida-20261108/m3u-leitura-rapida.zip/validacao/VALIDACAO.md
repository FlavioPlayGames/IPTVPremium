# Validação e limites

- Compilação Kotlin e Lint aprovadas.
- Paridade da extração de metadados em nove exemplos e 6.000 linhas geradas, incluindo atributos repetidos/vazios, maiúsculas, Unicode e indicação XUI.
- Benchmark local: 180 mil entradas por execução, aquecimento e cinco comparações alternadas; mediana de aproximadamente 922 ms antes e 271 ms depois na etapa isolada de atributos. Não é tempo de importação na TV.
- Dezesseis cenários do importador completo com DAO e HTTP simulados: catálogo final idêntico (IDs, campos, ordem), 20 mil filmes, séries, canais, falhas, limites de lote e cancelamentos. A comparação sintética com esperas de leitura/banco não mostrou melhoria relevante, pois essas esperas dominavam.
- Quinze cenários do sincronizador preservam M3U direta sem API, fallback, reavaliação de lista existente e catálogo ativo, além do teste de armazenamento/codec.
- Instaladores testados em importadores conhecidos recentes/anteriores, reaplicação, desfazer, corrupção/versão desconhecida/conflito; sintaxe PowerShell verificada.
- Filtro do relatório de tempos testado com URL/senha fictícios: somente métricas permitidas são retidas. ADB real e Windows do usuário não usados aqui.

Sem medição na TV, sem contato com provedor real, sem instalação/publicação automática. O pacote otimiza processamento local, preserva a importação M3U completa e não promete igualar o tempo total do Xtream. O coletor incluído permite investigar download, decodificação, parsing, filas e banco na TV.
