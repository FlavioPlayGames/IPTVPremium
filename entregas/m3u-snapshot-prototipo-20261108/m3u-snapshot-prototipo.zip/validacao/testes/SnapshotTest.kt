package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.m3usnapshot.*
import br.com.flaviotorres.iptvpremium.data.cache.importer.OriginalM3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import androidx.sqlite.db.*
import androidx.room.RoomOpenDelegate
import android.database.Cursor
import java.io.*
import java.nio.file.*
import java.lang.reflect.Proxy
import java.sql.*
import kotlinx.coroutines.*

private class NativeBridge(val connection:Connection){
 var success=false;var transactions=0
 val database=Proxy.newProxyInstance(SupportSQLiteDatabase::class.java.classLoader,arrayOf(SupportSQLiteDatabase::class.java)){_,m,a0->
  val a=a0.orEmpty()
  when(m.name){
   "beginTransactionNonExclusive"->{check(connection.autoCommit);connection.autoCommit=false;success=false;transactions++;null}
   "setTransactionSuccessful"->{success=true;null}
   "endTransaction"->{if(success)connection.commit()else connection.rollback();connection.autoCommit=true;null}
   "execSQL"->{connection.prepareStatement(a[0]as String).use{s->if(a.size>1)(a[1]as Array<*>).forEachIndexed{i,v->s.setObject(i+1,v)};s.execute()};null}
   "compileStatement"->{val s=connection.prepareStatement(a[0]as String)
    Proxy.newProxyInstance(SupportSQLiteStatement::class.java.classLoader,arrayOf(SupportSQLiteStatement::class.java)){_,method,args0->val args=args0.orEmpty();when(method.name){
     "bindString"->{s.setString(args[0]as Int,args[1]as String);null}
     "bindLong"->{s.setLong(args[0]as Int,args[1]as Long);null}
     "bindNull"->{s.setNull(args[0]as Int,Types.NULL);null}
     "executeInsert"->{s.executeUpdate();1L}
     "close"->{s.close();null}
     else->error("statement ${method.name}")
    }}as SupportSQLiteStatement}
   "query"->{val s=connection.prepareStatement(a[0]as String);if(a.size>1)(a[1]as Array<*>).forEachIndexed{i,v->s.setObject(i+1,v)};val r=s.executeQuery()
    Proxy.newProxyInstance(Cursor::class.java.classLoader,arrayOf(Cursor::class.java)){_,method,args->when(method.name){
     "moveToFirst","moveToNext"->r.next()
     "getString"->r.getString((args!![0]as Int)+1)
     "getLong"->r.getLong((args!![0]as Int)+1)
     "getInt"->r.getInt((args!![0]as Int)+1)
     "close"->{r.close();s.close();null}
     else->error("cursor ${method.name}")
    }}as Cursor}
   else->error("database ${m.name}")
  }
 } as SupportSQLiteDatabase
}
private class Lines(var lines:List<String>):PlaylistHttpClient{
 override suspend fun get(url:String)=error("unused")
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit){for(line in lines)onLine(line)}
}
private fun row(name:String,group:String,url:String,poster:String="poster")=listOf("#EXTINF:-1 group-title=\"$group\" tvg-logo=\"$poster\",$name",url)
private fun prepare(lines:List<String>,file:File,ensure:()->Unit={}):SnapshotParser.Counts=FileOutputStream(file).use{raw->
 val out=DataOutputStream(BufferedOutputStream(raw));val result=SnapshotParser.prepare(lines.joinToString("\n").reader().buffered(),out,"p","new",ensure);out.flush();result
}
private fun removeIndexes(c:Connection){for(sql in SnapshotSchema.indexes){val name=Regex("`([^`]+)`").find(sql)!!.groupValues[1];c.createStatement().use{it.execute("DROP INDEX `$name`")}}}
fun main(args:Array<String>)=runBlocking {
 Class.forName("org.sqlite.JDBC");val folder=Path.of("/workspace/m3u-snapshot-prototipo/tests");Files.createDirectories(folder)
 var n=0;fun ok(b:Boolean,label:String){check(b){label};n++;println("PASS $label")}
 if(args.firstOrNull()=="stress"){
  val source=folder.resolve("large.m3u").toFile();val spool=folder.resolve("large.bin").toFile()
  source.bufferedWriter().use{out->
   out.write("#EXTM3U\n")
   fun entry(name:String,group:String,url:String,poster:String){out.write("#EXTINF:-1 group-title=\"$group\" tvg-logo=\"$poster\",$name\n$url\n")}
   repeat(2355){entry("Canal $it","Canais ${it%12}","http://x/live/$it.ts","c$it")}
   repeat(44099){entry("Filme $it (2024)","Filmes ${it%32}","http://x/movie/$it.mkv","m$it")}
   repeat(283278){val series=(it.toLong()*9800/283278).toInt();entry("Série $series S01E${it%40+1}","Séries ${series%60}","http://x/series/$it.mkv","s$series")}
  }
  val counts=FileOutputStream(spool).use{raw->val out=DataOutputStream(BufferedOutputStream(raw,256*1024));val result=source.bufferedReader().use{SnapshotParser.prepare(it,out,"p","new")};out.flush();raw.fd.sync();result}
  RealSqlDb(folder.resolve("large.db")).use{candidate->
   removeIndexes(candidate.c);val bridge=NativeBridge(candidate.c);val loaded=SnapshotLoader.load(bridge.database,spool,"p","new");SnapshotLoader.indexes(bridge.database)
   val stored=SnapshotLoader.validate(bridge.database,counts)
   ok(stored.contentEquals(longArrayOf(104,2355,44099,9800,283278)),"329732-record incremental fixture persists every expected unique record with finalized indexes")
   ok(loaded.rows[3]==9800L&&bridge.transactions==2,"large fixture uses one series write per series and two bulk/index transactions")
   println("Functional volume test under -Xmx128m; no network, Android driver, publication or TV performance claim")
  }
  source.delete();spool.delete();return@runBlocking
 }
 val fixtures=listOf(
  listOf("\uFEFF#EXTM3U")+row("Live","Canais","https://example.invalid/live/1.ts")+row("Filme (2024)","Filmes","https://example.invalid/movie/1.mkv")+(1..500).flatMap{row("Ação S01E$it","Séries","https://example.invalid/series/$it.mkv",if(it%3==0)""else "poster-$it")},
  listOf("#EXTM3U")+(1..60).flatMap{i->row("Série A S02E$i","Séries A","http://x/series/a$i",if(i%2==0)""else "a")+row("Série B Temporada 3 Episódio $i","Séries B","http://x/series/b$i","b$i")},
  listOf("#EXTM3U")+row("Filme","Filmes","http://x/movie/a","first")+row("Outro","Filmes","http://x/movie/b")+row("Filme","Nova categoria","http://x/movie/a","last")+row("Série S01E01","Séries","http://x/series/a","first")+row("Série S01E01","Séries","http://x/series/a","last"),
  listOf("#EXTM3U","#EXTINF:-1 xui-id=\"1\" tvg-id=\"\" group-title=\"Filmes e Séries\",Sem extensão","http://x/opaque","#EXTINF:-1 xui-id=\"2\" group-title=\"Anime\",Show S01E1000","http://x/opaque2","#EXTINF:-1,Sem categoria","http://x/unclassified")
 )
 for((i,lines)in fixtures.withIndex()){
  RealSqlDb(folder.resolve("oracle-$i.db")).use{oracle->RealSqlDb(folder.resolve("snapshot-$i.db")).use{candidate->
   val old=OriginalM3uCacheImporter(Lines(lines),oracle.dao,PlaylistCacheGenerationManager(oracle.dao)).import("p","http://x/list")
   val expected=oracle.canonical(old);val spool=folder.resolve("records-$i.bin").toFile();val counts=prepare(lines,spool)
   removeIndexes(candidate.c);val bridge=NativeBridge(candidate.c)
   val loaded=SnapshotLoader.load(bridge.database,spool,"p","new")
   SnapshotLoader.indexes(bridge.database);SnapshotLoader.validate(bridge.database,counts)
   ok(candidate.canonical("new").drop(0)==expected,"fixture $i preserves every field, stable ID, provider order, last metadata and duplicate policy")
   ok(loaded.rows[3]==counts.series.toLong(),"fixture $i writes series once after consolidating all metadata")
   val impl=PlaylistCacheDatabase_Impl();val m=impl.javaClass.getDeclaredMethod("createOpenDelegate");m.isAccessible=true
   ok((m.invoke(impl)as RoomOpenDelegate).onValidateSchema(SqlConnection(candidate.c)).isValid,"fixture $i final indexes/tables match actual generated Room schema")
   check(bridge.transactions==2);spool.delete()
  }}
 }
 for(kind in listOf("cancel","truncated","bad_tag"))RealSqlDb(folder.resolve("failure-$kind.db")).use{db->
  val file=folder.resolve("failure-$kind.bin").toFile();prepare(listOf("#EXTM3U")+(1..50).flatMap{row("F $it","Filmes","http://x/movie/$it")},file)
  if(kind=="truncated")RandomAccessFile(file,"rw").use{it.setLength(it.length()-5)}
  if(kind=="bad_tag")RandomAccessFile(file,"rw").use{it.seek(4);it.writeByte(99)}
  var checks=0;val cancellation=CancellationException("cancel");val bridge=NativeBridge(db.c)
  val result=runCatching{SnapshotLoader.load(bridge.database,file,"p","new",ensure={if(kind=="cancel"&&++checks==20)throw cancellation})}
  ok(result.isFailure&&db.count("cached_movies")==0,"$kind rolls back complete private load instead of leaving partial rows")
  if(kind=="cancel")ok(result.exceptionOrNull()===cancellation,"original cancellation is preserved")
  file.delete()
 }
 val invalid=folder.resolve("invalid.bin").toFile()
 ok(runCatching{prepare(listOf("<html>not M3U</html>"),invalid)}.isFailure,"invalid source is rejected before database load")

 println("$n checks; real SQLite via JDBC and generated Room schema, no Android TV timing")
}
