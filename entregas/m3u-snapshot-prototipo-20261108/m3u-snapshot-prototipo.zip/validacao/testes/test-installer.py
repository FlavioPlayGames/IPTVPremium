from pathlib import Path
import json,subprocess,os,uuid,hashlib
w=Path('/workspace/m3u-snapshot-prototipo');o=Path('/workspace/outputs/m3u-snapshot-prototipo');m=json.loads((o/'manifest.json').read_text());root=w/'installer-tests'/uuid.uuid4().hex
pw='/workspace/storage-toolchain/powershell/pwsh';env=dict(os.environ,XDG_CACHE_HOME='/workspace/storage-toolchain/xdg-cache',XDG_DATA_HOME='/workspace/storage-toolchain/xdg-data',XDG_CONFIG_HOME='/workspace/storage-toolchain/xdg-config')
assert all(e['allowMissing']and not e['before']for e in m)
def run(script,r):return subprocess.run([pw,'-NoProfile','-File',str(o/script),'-Projeto',str(r)],capture_output=True,text=True,env=env)
def sha(p):return hashlib.sha256(p.read_text(encoding='utf-8-sig').replace('\r\n','\n').encode()).hexdigest()
logs=[]
for case in ['normal','unknown','corrupt','undo-conflict']:
 r=root/case;r.mkdir(parents=True);(r/'gradlew.bat').write_text('fixture')
 existing=None
 if case=='unknown':
  existing=r/m[0]['path'];existing.parent.mkdir(parents=True);existing.write_text('custom content')
 asset=o/m[0]['path'];original=asset.read_bytes()
 if case=='corrupt':asset.write_bytes(original+b'bad')
 try:result=run('Aplicar.ps1',r)
 finally:asset.write_bytes(original)
 assert(result.returncode==0)==(case in ['normal','undo-conflict']),(case,result.stdout,result.stderr)
 if case in ['normal','undo-conflict']:
  assert all(sha(r/e['path'])==e['sha']for e in m)
  backups=r/'.m3u-snapshot-prototipo-backups';assert len(list(backups.iterdir()))==1
  assert run('Aplicar.ps1',r).returncode==0;assert len(list(backups.iterdir()))==1
  if case=='undo-conflict':
   p=r/m[0]['path'];p.write_bytes(p.read_bytes()+b'// modified');state={e['path']:(r/e['path']).read_bytes()for e in m}
   assert run('Desfazer.ps1',r).returncode!=0;assert all((r/path).read_bytes()==data for path,data in state.items())
  else:
   result=run('Desfazer.ps1',r);assert result.returncode==0,(result.stdout,result.stderr)
   assert all(not(r/e['path']).exists()for e in m)
 else:
  assert not(r/'.m3u-snapshot-prototipo-backups').exists()
  if existing:assert existing.read_text()=='custom content'
  assert all(not(r/e['path']).exists()for e in m if r/e['path']!=existing)
 logs.append('PASS installer '+case)
(w/'installer-results.txt').write_text('\n'.join(logs)+'\n');print('\n'.join(logs))
