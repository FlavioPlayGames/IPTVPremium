package br.com.flaviotorres.iptvpremium.data.m3usnapshot

import android.app.Activity
import android.os.Bundle
import android.widget.TextView
import android.view.Gravity
import br.com.flaviotorres.iptvpremium.data.storage.PlaylistStorage
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import br.com.flaviotorres.iptvpremium.data.remote.DefaultPlaylistHttpClient
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first

/** ADB-only performance experiment; no launcher entry and no connection to the active catalogue UI. */
class SnapshotPrototypeActivity:Activity(){
    private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main.immediate)
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        val text=TextView(this).apply{setTextColor(0xffffffff.toInt());setBackgroundColor(0xff122033.toInt());textSize=23f;gravity=Gravity.CENTER;setPadding(40,30,40,30)}
        setContentView(text)
        text.text="Protótipo independente de M3U\nPreparando teste…\nVoltar cancela o teste."
        // A recreated activity does not automatically repeat a download after rotation/process recovery.
        if(savedInstanceState!=null){text.text="Teste interrompido. Execute novamente pelo PowerShell.";return}
        scope.launch{
            val started=System.nanoTime()
            try{
                if(intent.getBooleanExtra("clear_prototype",false)){
                    SnapshotRunner.clear(applicationContext)
                    text.text="Arquivos do protótipo removidos.\nO catálogo do aplicativo foi preservado.\nPressione Voltar para retornar."
                    return@launch
                }
                val selection=PlaylistStorage(applicationContext).selection.first()
                val source=selection.playlists.singleOrNull{it.id==selection.activeId&&it.isEnabled} as? PlaylistSource.M3u
                if(source==null){text.text="Selecione uma lista M3U no aplicativo antes de executar este teste.";android.util.Log.i(SnapshotRunner.TAG,"stage=summary status=NO_M3U");return@launch}
                val labels=mapOf("cleanup" to "Limpando arquivos de testes interrompidos", "download" to "Baixando a lista", "prepare" to "Preparando os registros em disco", "bootstrap" to "Preparando o catálogo separado", "defer_indexes" to "Preparando a carga", "load" to "Gravando o catálogo", "indexes" to "Criando os índices", "validate" to "Conferindo os dados", "ready" to "Finalizando o banco", "room_validate" to "Validando a leitura pelo aplicativo", "checkpoint" to "Confirmando a gravação final", "finalize" to "Finalizando os arquivos", "publish" to "Publicando o protótipo", "complete" to "Concluído")
                val result=br.com.flaviotorres.iptvpremium.core.storage.StorageMaintenance.foregroundImport {
                    SnapshotRunner(applicationContext,DefaultPlaylistHttpClient()).run(source.id,source.playlistUrl){stage->runOnUiThread{text.text="Protótipo independente de M3U\n${labels[stage]?:stage}\nVoltar cancela o teste."}}
                }
                val total=(System.nanoTime()-started)/1_000_000
                android.util.Log.i(SnapshotRunner.TAG,"stage=complete status=OK totalMs=$total")
                text.text="Protótipo concluído em ${total/1000.0} s\nCanais: ${result.counts[1]} · Filmes: ${result.counts[2]}\nSéries: ${result.counts[3]} · Episódios: ${result.counts[4]}\nCatálogo separado validado.\nPressione Voltar para retornar."
            }catch(cancelled:CancellationException){android.util.Log.i(SnapshotRunner.TAG,"stage=activity status=CANCELLED");throw cancelled}
            catch(error:Exception){android.util.Log.i(SnapshotRunner.TAG,"stage=activity status=ERROR code=FAILED");text.text="Não foi possível concluir o protótipo.\nO catálogo do aplicativo foi preservado.\nEnvie o diagnóstico do PowerShell."}
        }
    }
    override fun onDestroy(){scope.cancel();super.onDestroy()}
}
