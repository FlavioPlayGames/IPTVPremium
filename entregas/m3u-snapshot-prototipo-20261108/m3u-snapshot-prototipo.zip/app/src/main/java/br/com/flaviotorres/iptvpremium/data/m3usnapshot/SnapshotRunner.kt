package br.com.flaviotorres.iptvpremium.data.m3usnapshot

import android.content.Context
import android.util.AtomicFile
import android.util.Log
import androidx.room.Room
import androidx.room.RoomDatabase
import br.com.flaviotorres.iptvpremium.data.cache.PlaylistCacheDatabase
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import java.io.*
import java.security.MessageDigest
import java.util.UUID
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

/** Independent experiment. Does not open the production singleton or change its active catalogue. */
internal class SnapshotRunner(private val context:Context,private val http:PlaylistHttpClient) {
    data class Result(val totalMs:Long,val counts:LongArray,val processed:Long,val database:File)
    companion object {
        private val mutex=Mutex(); const val TAG="IPTV_SNAPSHOT"
        suspend fun clear(context:Context)=mutex.withLock {
            withContext(Dispatchers.IO){
                val root=File(context.filesDir,"m3u_snapshot_prototype")
                check(!root.exists()||root.deleteRecursively()){"PROTOTYPE_CLEANUP"}
                Log.i(TAG,"stage=summary status=CLEANED")
            }
        }
    }
    suspend fun run(playlist:String,url:String,notify:(String)->Unit={}):Result=mutex.withLock {
        withContext(Dispatchers.IO){
            val began=System.nanoTime();val job=currentCoroutineContext().job
            check(PlaylistCacheDatabase.SCHEMA_VERSION==5){"SCHEMA_VERSION"}
            val ensure={job.ensureActive()}
            val root=File(context.filesDir,"m3u_snapshot_prototype").also{check(it.mkdirs()||it.isDirectory)}
            val key=MessageDigest.getInstance("SHA-256").digest(playlist.toByteArray()).joinToString(""){"%02x".format(it)}
            val pointer=AtomicFile(File(root,"ready-$key"))
            val run=UUID.randomUUID().toString();val session=File(root,run).also{check(it.mkdir())}
            val source=File(session,"source.m3u");val spool=File(session,"prepared.bin");val database=File(session,"snapshot.db")
            var publishing=false;var published=false;var lastStage="start"
            suspend fun <T> phase(name:String,body:suspend()->T):T {
                ensure();lastStage=name;notify(name);val start=System.nanoTime()
                try{return body()}finally{Log.i(TAG,"stage=$name startNs=$start endNs=${System.nanoTime()} durationMs=${(System.nanoTime()-start)/1_000_000}")}
            }
            fun room()=Room.databaseBuilder(context.applicationContext,PlaylistCacheDatabase::class.java,database.absolutePath)
                .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING).build()
            try{
                Log.i(TAG,"stage=start revision=SNAPSHOT_R1 status=RUNNING")
                phase("cleanup"){
                    val ready=Regex("ready-[0-9a-f]{64}")
                    val pointerNames=root.listFiles().orEmpty().filter{!it.isDirectory}.map{it.name.removeSuffix(".bak").removeSuffix(".new")}.filter{ready.matches(it)}.distinct()
                    val live=mutableSetOf(run)
                    var readable=true
                    for(name in pointerNames){
                        val old=runCatching{AtomicFile(File(root,name)).openRead().use{it.readBytes().toString(Charsets.US_ASCII)}}.getOrNull()
                        if(old==null||!Regex("[0-9a-f-]{36}").matches(old)){readable=false;break}else live.add(old)
                    }
                    if(readable)root.listFiles().orEmpty().filter{it.isDirectory&&Regex("[0-9a-f-]{36}").matches(it.name)&&it.name !in live}.forEach{orphan->
                        ensure();if(orphan.canonicalFile.parentFile==root.canonicalFile)orphan.deleteRecursively()
                    }
                }
                val signature=MessageDigest.getInstance("SHA-256")
                phase("download"){
                    FileOutputStream(source).use{raw->
                        val writer=OutputStreamWriter(java.security.DigestOutputStream(raw,signature),Charsets.UTF_8).buffered(128*1024)
                        http.readLines(url){line->ensure();writer.write(line);writer.newLine()}
                        writer.flush();raw.fd.sync()
                    }
                }
                val sourceHash=signature.digest().joinToString(""){"%02x".format(it)}
                Log.i(TAG,"stage=source sourceHash=$sourceHash sourceBytes=${source.length()}")
                check(root.usableSpace>=maxOf(64L*1024*1024,source.length()*8)){"SPACE"}
                val generation=UUID.randomUUID().toString()
                val counts=phase("prepare"){
                    FileOutputStream(spool).use{raw->
                        val out=DataOutputStream(BufferedOutputStream(raw,256*1024))
                        val parsed=source.bufferedReader(Charsets.UTF_8,128*1024).use{reader->SnapshotParser.prepare(reader,out,playlist,generation,ensure){n->Log.i(TAG,"stage=prepare_progress entries=$n")}}
                        out.flush();raw.fd.sync();parsed
                    }
                }
                phase("bootstrap") {val boot=room();try{boot.openHelper.writableDatabase}finally{boot.close()}}
                // A separate helper for ONLY this run's private file; never production playlist_cache.db.
                val helper=androidx.sqlite.db.framework.FrameworkSQLiteOpenHelperFactory().create(
                    androidx.sqlite.db.SupportSQLiteOpenHelper.Configuration.builder(context.applicationContext)
                        .name(database.absolutePath).callback(object:androidx.sqlite.db.SupportSQLiteOpenHelper.Callback(PlaylistCacheDatabase.SCHEMA_VERSION){
                            override fun onCreate(db:androidx.sqlite.db.SupportSQLiteDatabase)=error("MISSING_BOOTSTRAP")
                            override fun onUpgrade(db:androidx.sqlite.db.SupportSQLiteDatabase,oldVersion:Int,newVersion:Int)=error("WRONG_VERSION")
                        }).build())
                helper.setWriteAheadLoggingEnabled(true)
                val stored:LongArray
                helper.use{
                    val db=it.writableDatabase
                    phase("defer_indexes"){
                        db.beginTransactionNonExclusive()
                        try{
                            val journal=db.query("PRAGMA journal_mode").use{check(it.moveToFirst());it.getString(0)}
                            val sync=db.query("PRAGMA synchronous").use{check(it.moveToFirst());it.getInt(0)}
                            Log.i(TAG,"stage=settings journal=$journal synchronous=$sync")
                            SnapshotSchema.indexes.forEach{sql->ensure();val name=Regex("`([^`]+)`").find(sql)!!.groupValues[1];db.execSQL("DROP INDEX `$name`")};db.setTransactionSuccessful()}
                        finally{db.endTransaction()}
                    }
                    val loaded=phase("load") {SnapshotLoader.load(db,spool,playlist,generation,ensure){n->Log.i(TAG,"stage=load_progress rows=$n")}}
                    check(loaded.rows.contentEquals(longArrayOf(counts.categories.toLong(),counts.channels,counts.movies,counts.series.toLong(),counts.episodes))){"ATTEMPT_COUNTS"}
                    Log.i(TAG,"stage=commit durationMs=${loaded.commitNs/1_000_000}")
                    phase("indexes"){SnapshotLoader.indexes(db,ensure)}
                    stored=phase("validate"){SnapshotLoader.validate(db,counts)}
                    phase("ready"){
                        ensure();db.execSQL("UPDATE playlist_cache_generations SET status='ACTIVE',completedAtEpochMillis=?,activatedAtEpochMillis=? WHERE playlistId=? AND generationId=?",arrayOf(System.currentTimeMillis(),System.currentTimeMillis(),playlist,generation))
                        // Force Room's real schema validator to run on reopen, not just trust the bootstrap hash.
                        db.execSQL("DROP TABLE room_master_table")
                        SnapshotLoader.checkpoint(db)
                    }
                }
                phase("room_validate"){
                    val verified=room()
                    try{
                        verified.openHelper.writableDatabase
                        check(verified.playlistCacheDao().getActiveGeneration(playlist)?.generationId==generation){"ROOM_VALIDATE"}
                    }finally{verified.close()}
                }
                phase("checkpoint"){
                    // Room validation may write its identity into WAL. Explicitly flush that final write too.
                    try{SnapshotLoader.checkpoint(helper.writableDatabase)}finally{helper.close()}
                }
                phase("finalize"){
                    // No file is published while WAL pages still need to be transferred.
                    val wal=File(database.path+"-wal");check(!wal.exists()||wal.length()==0L){"PENDING_WAL"}
                    RandomAccessFile(database,"rw").use{it.fd.sync()}
                    check(source.delete()&&spool.delete()){"TEMP_CLEANUP"}
                }
                phase("publish"){
                    ensure();publishing=true
                    val old=runCatching{pointer.openRead().use{it.readBytes().toString(Charsets.US_ASCII)}}.getOrNull()
                    val stream=pointer.startWrite()
                    try{stream.write(run.toByteArray(Charsets.US_ASCII));pointer.finishWrite(stream);published=true}
                    catch(error:Throwable){pointer.failWrite(stream);throw error}
                    // Prototype owns these directories; the production database and registry are untouched.
                    if(old!=null&&old!=run&&Regex("[0-9a-f-]{36}").matches(old)){
                        val obsolete=File(root,old)
                        if(obsolete.canonicalFile.parentFile==root.canonicalFile)obsolete.deleteRecursively()
                    }
                }
                val total=(System.nanoTime()-began)/1_000_000
                notify("complete")
                Log.i(TAG,"stage=summary revision=SNAPSHOT_R1 status=OK totalMs=$total processed=${counts.entries} categories=${stored[0]} channels=${stored[1]} movies=${stored[2]} series=${stored[3]} episodes=${stored[4]} databaseBytes=${database.length()}")
                Result(total,stored,counts.entries,database)
            }catch(cancelled:CancellationException){Log.i(TAG,"stage=summary status=CANCELLED failedStage=$lastStage");throw cancelled}
            catch(error:Throwable){
                val code=when {error.message=="SPACE"->"SPACE";error is IOException->"IO";error is IllegalArgumentException->"INVALID_INPUT";error is IllegalStateException->"VALIDATION";else->"FAILED"}
                Log.i(TAG,"stage=summary status=ERROR failedStage=$lastStage code=$code");throw error
            }
            finally{if(!published&&!publishing)session.deleteRecursively()}
        }
    }
}
