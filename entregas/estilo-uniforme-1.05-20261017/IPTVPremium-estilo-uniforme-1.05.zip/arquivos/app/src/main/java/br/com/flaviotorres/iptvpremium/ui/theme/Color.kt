package br.com.flaviotorres.iptvpremium.ui.theme

import androidx.compose.ui.graphics.Color

// Fundos
val AppBackground get() = ThemeColors.background
val AppSurface get() = ThemeColors.panel
val AppSurfaceVariant get() = ThemeColors.control

// Dourado principal
val AppGold get() = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFD4AF37)
val AppGoldLight get() = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFF1D77A)
val AppGoldDark get() = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFF9E7C18)

// Textos
val AppTextPrimary = Color(0xFFF5F5F5)
val AppTextSecondary = Color(0xFFB7B7BD)

// Estados
val AppError = Color(0xFFFF6B6B)
