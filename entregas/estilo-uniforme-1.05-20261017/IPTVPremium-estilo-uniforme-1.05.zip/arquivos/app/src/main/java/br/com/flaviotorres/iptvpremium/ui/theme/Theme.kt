package br.com.flaviotorres.iptvpremium.ui.theme

import androidx.compose.runtime.Composable
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.darkColorScheme

private val IPTVPremiumColorScheme get() = darkColorScheme(
    primary = AppGold,
    onPrimary = AppTextPrimary,

    secondary = AppGoldLight,
    onSecondary = AppTextPrimary,

    tertiary = AppGoldDark,
    onTertiary = AppTextPrimary,

    background = AppBackground,
    onBackground = AppTextPrimary,

    surface = AppSurface,
    onSurface = AppTextPrimary,

    surfaceVariant = AppSurfaceVariant,
    onSurfaceVariant = AppTextSecondary,

    error = AppError
)

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
fun IPTVPremiumTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = IPTVPremiumColorScheme,
        typography = Typography,
        content = content
    )
}