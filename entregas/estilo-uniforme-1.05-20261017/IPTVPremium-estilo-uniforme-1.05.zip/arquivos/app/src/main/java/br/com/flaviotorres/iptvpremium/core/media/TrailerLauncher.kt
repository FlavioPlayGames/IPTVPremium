package br.com.flaviotorres.iptvpremium.core.media

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import java.net.URI
import java.net.URLDecoder
import java.net.URLEncoder

internal fun trailerAddress(raw: String?, title: String): String? {
    val value=raw?.trim().orEmpty()
    val youtubeId=Regex("[A-Za-z0-9_-]{11}")
    if (youtubeId.matches(value)) return "https://www.youtube.com/watch?v=$value"
    val uri=runCatching { URI(value) }.getOrNull()
    if (uri != null && uri.scheme?.lowercase() in listOf("http","https") && !uri.host.isNullOrBlank() && uri.rawUserInfo == null) {
        val host=uri.host.lowercase()
        val id=when (host) {
            "youtu.be", "www.youtu.be" -> uri.path.trim('/').substringBefore('/')
            "youtube.com", "www.youtube.com", "m.youtube.com", "youtube-nocookie.com", "www.youtube-nocookie.com" -> {
                if (uri.path.startsWith("/embed/") || uri.path.startsWith("/shorts/") || uri.path.startsWith("/live/")) uri.path.split('/').getOrNull(2)
                else uri.rawQuery?.split('&')?.firstOrNull { it.substringBefore('=')=="v" }?.substringAfter('=')?.let { runCatching { URLDecoder.decode(it,"UTF-8") }.getOrNull() }
            }
            else -> return uri.toASCIIString()
        }
        if (id != null && youtubeId.matches(id)) return "https://www.youtube.com/watch?v=$id"
    }
    return title.trim().takeIf { it.isNotEmpty() }?.let {
        "https://www.youtube.com/results?search_query=" + URLEncoder.encode("$it trailer oficial","UTF-8")
    }
}

internal fun openTrailer(context: Context, raw: String?, title: String) {
    val address=trailerAddress(raw,title)
    if (address == null) { Toast.makeText(context,"Trailer indisponível.",Toast.LENGTH_SHORT).show();return }
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW,Uri.parse(address)))
        if (address.startsWith("https://www.youtube.com/results?")) Toast.makeText(context,"Buscando trailer no YouTube.",Toast.LENGTH_SHORT).show()
    } catch (_: android.content.ActivityNotFoundException) {
        Toast.makeText(context,"Instale o YouTube ou um navegador para abrir o trailer.",Toast.LENGTH_LONG).show()
    } catch (_: SecurityException) {
        Toast.makeText(context,"O Android não permitiu abrir o trailer.",Toast.LENGTH_SHORT).show()
    }
}
