package br.com.flaviotorres.iptvpremium.ui.theme

import kotlin.math.*

/** Separable Lanczos-3 minification in premultiplied alpha; never invents larger artwork. */
internal fun resampleArtwork(pixels: IntArray, width: Int, height: Int, outWidth: Int, outHeight: Int): IntArray {
    require(width > 0 && height > 0 && outWidth in 1..width && outHeight in 1..height)
    require(pixels.size == width * height)
    if (width == outWidth && height == outHeight) return pixels
    // Cheap area prefilter for very small toolbar icons; the final Lanczos pass
    // then visits only a small neighborhood, even on slower TV processors.
    if (width / 2 >= outWidth * 2 && height / 2 >= outHeight * 2) {
        val reducedWidth = (width + 1) / 2
        val reducedHeight = (height + 1) / 2
        val reduced = IntArray(reducedWidth * reducedHeight) { index ->
            val left = index % reducedWidth * 2
            val top = index / reducedWidth * 2
            var a=0; var r=0; var g=0; var b=0; var count=0
            for (y in top until minOf(top+2,height)) for (x in left until minOf(left+2,width)) {
                val pixel=pixels[y*width+x]; val alpha=pixel ushr 24
                a+=alpha; r+=((pixel ushr 16) and 255)*alpha
                g+=((pixel ushr 8) and 255)*alpha; b+=(pixel and 255)*alpha; count++
            }
            if (a==0) 0 else (((a+count/2)/count) shl 24) or (((r+a/2)/a) shl 16) or (((g+a/2)/a) shl 8) or ((b+a/2)/a)
        }
        return resampleArtwork(reduced,reducedWidth,reducedHeight,outWidth,outHeight)
    }
    data class Weights(val start: Int, val values: DoubleArray)
    fun weights(source: Int, target: Int) = Array(target) { index ->
        val ratio = source.toDouble() / target
        val center = (index + .5) * ratio - .5
        val start = max(0, ceil(center - 3 * ratio).toInt())
        val end = min(source - 1, floor(center + 3 * ratio).toInt())
        val values = DoubleArray(end - start + 1) { offset ->
            val x = (start + offset - center) / ratio
            if (abs(x) < 1e-9) 1.0 else if (abs(x) >= 3) 0.0 else sin(PI*x)*sin(PI*x/3)/(PI*PI*x*x/3)
        }
        val sum = values.sum()
        for (i in values.indices) values[i] /= sum
        Weights(start, values)
    }
    fun packed(a: Double, r: Double, g: Double, b: Double): Int {
        val alpha = a.roundToInt().coerceIn(0, 255)
        fun channel(value: Double) = value.roundToInt().coerceIn(0, alpha)
        return (alpha shl 24) or (channel(r) shl 16) or (channel(g) shl 8) or channel(b)
    }
    val horizontal = weights(width, outWidth)
    val vertical = weights(height, outHeight)
    val intermediate = IntArray(outWidth * height)
    for (y in 0 until height) for (x in 0 until outWidth) {
        val w = horizontal[x]
        var a=0.0; var r=0.0; var g=0.0; var b=0.0
        for (i in w.values.indices) {
            val pixel=pixels[y*width+w.start+i]; val alpha=(pixel ushr 24).toDouble(); val weight=w.values[i]
            a+=alpha*weight; r+=((pixel ushr 16) and 255)*alpha/255*weight
            g+=((pixel ushr 8) and 255)*alpha/255*weight; b+=(pixel and 255)*alpha/255*weight
        }
        intermediate[y*outWidth+x]=packed(a,r,g,b)
    }
    return IntArray(outWidth*outHeight) { index ->
        val x=index%outWidth; val y=index/outWidth; val w=vertical[y]
        var a=0.0; var r=0.0; var g=0.0; var b=0.0
        for (i in w.values.indices) {
            val pixel=intermediate[(w.start+i)*outWidth+x]; val weight=w.values[i]
            a+=(pixel ushr 24)*weight; r+=((pixel ushr 16) and 255)*weight
            g+=((pixel ushr 8) and 255)*weight; b+=(pixel and 255)*weight
        }
        val alpha=a.roundToInt().coerceIn(0,255)
        fun channel(value: Double) = if (alpha==0) 0 else (value.coerceIn(0.0,alpha.toDouble())*255/alpha).roundToInt().coerceIn(0,255)
        (alpha shl 24) or (channel(r) shl 16) or (channel(g) shl 8) or channel(b)
    }
}
