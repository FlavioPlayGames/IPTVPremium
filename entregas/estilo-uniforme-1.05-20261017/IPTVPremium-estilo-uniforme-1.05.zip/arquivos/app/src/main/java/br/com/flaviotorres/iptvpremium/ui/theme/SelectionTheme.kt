package br.com.flaviotorres.iptvpremium.ui.theme

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/** One selection treatment for every theme: colored fill and white text/numbers. */
object SelectionTheme {
    val contentColor get() = Color.White
    fun colors(alpha: Float = 1f): List<Color> = listOf(color(alpha), color(alpha))
    fun brush(alpha: Float = 1f): Brush = Brush.verticalGradient(colors(alpha))
    fun color(alpha: Float = 1f): Color = ThemeColors.selection.copy(alpha = alpha.coerceIn(0f, 1f))
}
