﻿[CmdletBinding()]
param([string]$Projeto="$env:USERPROFILE\Downloads\site-identidade-aprovada")
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($Projeto).TrimEnd('\','/')
if(!(Test-Path -LiteralPath (Join-Path $root 'package.json') -PathType Leaf)){throw 'A pasta indicada nao contem package.json. Confira a pasta atual do site.'}
$items=ConvertFrom-Json -InputObject (Get-Content -LiteralPath "$PSScriptRoot\manifesto.json" -Raw)
$items=@($items)
foreach($item in $items) {
    if($item.path -notin @('SITE-LEIA-PRIMEIRO.md','manutencao-iptv/Manter-Site.ps1','manutencao-iptv/.gitignore')){throw 'Arquivo fora do escopo da padronizacao.'}
    $source=Join-Path "$PSScriptRoot\arquivos" $item.path
    if((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256){throw 'Arquivo do pacote nao confere.'}
    $dest=Join-Path $root $item.path
    foreach($path in @($dest,(Split-Path -Parent $dest))) {
        if((Test-Path -LiteralPath $path) -and ((Get-Item -LiteralPath $path -Force).Attributes -band [IO.FileAttributes]::ReparsePoint)){throw 'Destino de manutencao usa link de sistema; confira a pasta.'}
    }
    if(Test-Path -LiteralPath $dest) {
        if(!(Test-Path -LiteralPath $dest -PathType Leaf)){throw 'Destino inesperado.'}
        if((Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash.ToLowerInvariant() -ne $item.sha256){throw "Rotina existente com alteracoes: $($item.path). Nenhum arquivo foi substituido."}
    }
}
foreach($item in $items) {
    $dest=Join-Path $root $item.path
    if(!(Test-Path -LiteralPath $dest)) {
        New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
        Copy-Item -LiteralPath (Join-Path "$PSScriptRoot\arquivos" $item.path) -Destination $dest
    }
}
& (Join-Path $root 'manutencao-iptv/Manter-Site.ps1') -Projeto $root -Acao Inventario
Write-Host "Padrao instalado. Leia: $(Join-Path $root 'SITE-LEIA-PRIMEIRO.md')"
Write-Host 'Os fontes e a configuracao atual do site foram preservados. Nenhum deploy foi executado.'
