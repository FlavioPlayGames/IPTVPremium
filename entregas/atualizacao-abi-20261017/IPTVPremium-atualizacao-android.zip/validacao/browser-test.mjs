import {createServer} from 'node:http';
import {readFile,writeFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {environment,worker,token,csrf} from './worker-fixture.mjs';
const {chromium}=createRequire(import.meta.url)('playwright');
const state=environment();const errors=[];
const server=createServer(async(req,res)=>{try{
 const path=new URL(req.url,'http://localhost').pathname;
 let response;
 if(path==='/api/admin/update'){
  const chunks=[];for await(const chunk of req)chunks.push(chunk);
  const r=new Request('http://'+req.headers.host+req.url,{method:req.method,headers:req.headers,...(chunks.length?{body:Buffer.concat(chunks)}:{})});
  response=await worker.fetch(r,state.env,{});
 }else if(path==='/favicon.ico')response=new Response(null,{status:204});
 else if(path==='/api/session')response=Response.json({role:'admin',csrf});
 else if(path.startsWith('/api/'))response=Response.json({items:[],total:0,page:1,counts:{total:0,active:0,blocked:0}});
 else{
  const file=path==='/'?'/index.html':path==='/admin/'?'/admin/index.html':path;
  if(file.includes('..'))throw Error('Invalid path');
  response=new Response(await readFile('/workspace/update-worker-work/public'+file),{headers:{'Content-Type':file.endsWith('.js')?'text/javascript':file.endsWith('.css')?'text/css':file.endsWith('.html')?'text/html':'application/octet-stream'}});
 }
 res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
 }catch(e){res.writeHead(500);res.end(String(e));errors.push(String(e))}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const base='http://127.0.0.1:'+server.address().port;
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
try{
 const context=await browser.newContext({viewport:{width:1366,height:900}});await context.addCookies([{name:'iptv_session',value:token,url:base}]);
 const page=await context.newPage();page.on('pageerror',e=>errors.push(String(e)));page.on('dialog',d=>d.accept());
 await page.goto(base+'/admin/');await page.locator('#update-settings').click();await page.locator('#update-modal').waitFor({state:'visible'});
 await page.locator('#update-code').fill('9');await page.locator('#update-name').fill('1.09');await page.locator('#update-notes').fill('Melhorias desta versão');
 const fillArtifact=async(name)=>{await page.locator('#update-url').fill('https://downloads.example/'+name+'.apk');await page.locator('#update-size').fill('12345');await page.locator('#update-sha').fill('a'.repeat(64))};
 await fillArtifact('universal');
 await page.locator('#update-artifact').selectOption('arm64-v8a');assert.equal(await page.locator('#update-url').isDisabled(),true);
 await page.locator('#update-artifact-enabled').check();await fillArtifact('arm64-v8a');
 await page.locator('#update-artifact').selectOption('armeabi-v7a');await page.locator('#update-artifact-enabled').check();await fillArtifact('armeabi-v7a');
 await page.locator('#update-artifact').selectOption('universal');assert.equal(await page.locator('#update-url').inputValue(),'https://downloads.example/universal.apk');
 await page.locator('#publish-update').click();await page.waitForFunction(()=>document.getElementById('update-feedback').textContent.includes('Atualização publicada!'));
 let saved=JSON.parse(state.stored);assert.equal(saved.variants['arm64-v8a'].url,'https://downloads.example/arm64-v8a.apk');assert.equal(Object.keys(saved.variants).length,2);
 console.log('PASS real browser + Worker publish three APKs; switching preserves individual metadata');
 await page.locator('#update-modal').evaluate(el=>el.scrollTop=0);
 await page.screenshot({path:'/workspace/outputs/atualizacao-painel-desktop.png'});
 await page.locator('#update-artifact').selectOption('arm64-v8a');await page.locator('#update-artifact-enabled').uncheck();await page.locator('#publish-update').click();
 await page.waitForFunction(()=>document.getElementById('publish-update').disabled===false);await page.waitForTimeout(150);
 saved=JSON.parse(state.stored);assert.equal(saved.variants['arm64-v8a'],undefined);assert.ok(saved.variants['armeabi-v7a']);
 console.log('PASS disabling one optional APK leaves universal and other variant intact');
 await page.locator('#update-artifact').selectOption('universal');
 const data=Buffer.from('APK browser hashing test');await page.locator('#update-apk').setInputFiles({name:'universal.apk',mimeType:'application/vnd.android.package-archive',buffer:data});
 await page.waitForFunction(()=>document.getElementById('update-sha').value.length===64);
 assert.equal(await page.locator('#update-sha').inputValue(),createHash('sha256').update(data).digest('hex'));
 assert.equal(await page.locator('#update-size').inputValue(),String(data.length));
 console.log('PASS local APK size and SHA-256 match selected bytes');
 await page.evaluate(()=>{const original=crypto.subtle.digest.bind(crypto.subtle);crypto.subtle.digest=async(...args)=>{await new Promise(r=>setTimeout(r,350));return original(...args)}});
 await page.locator('#update-apk').setInputFiles({name:'other.apk',mimeType:'application/vnd.android.package-archive',buffer:Buffer.from('other')});
 await page.locator('#update-artifact').selectOption('x86');await page.waitForTimeout(450);assert.equal(await page.locator('#update-sha').inputValue(),'');assert.equal(await page.locator('#update-apk').inputValue(),'');
 console.log('PASS late hash from another APK cannot overwrite the selected architecture');
 await page.locator('#update-artifact').selectOption('armeabi-v7a');await page.setViewportSize({width:390,height:844});
 await page.locator('#update-modal').evaluate(el=>el.scrollTop=0);
 await page.screenshot({path:'/workspace/outputs/atualizacao-painel-celular.png'});
 assert.equal(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth),true);
 console.log('PASS existing panel style remains usable at mobile width');
 await page.setViewportSize({width:1366,height:900});await page.locator('#remove-update').click();await page.waitForFunction(()=>document.getElementById('update-feedback').textContent.includes('Exigência suspensa'));
 assert.equal(state.stored,null);console.log('PASS suspension through browser clears published update');
 assert.deepEqual(errors,[]);console.log('6 browser scenarios passed; no JavaScript errors');
}finally{await browser.close();await new Promise(r=>server.close(r))}
