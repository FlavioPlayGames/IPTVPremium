package br.com.flaviotorres.iptvpremium.core.update
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

fun main() {
 var passed=0
 fun test(name:String,task:()->Unit){task();println("PASS $name");passed++}
 fun artifact(abi:String)=JSONObject().put("url","https://downloads.example/$abi.apk").put("sha256","a".repeat(64)).put("sizeBytes",12345)
 fun legacy()=artifact("universal").put("versionCode",7).put("versionName","1.07").put("mandatory",true).put("notes","Atualização")
 val abis=listOf("armeabi-v7a","arm64-v8a","x86","x86_64")
 fun multi():JSONObject=legacy().put("variants",JSONObject().also{v->abis.forEach{v.put(it,artifact(it))}})
 fun rejects(task:()->Unit){check(runCatching(task).isFailure)}
 test("legacy universal policy remains readable"){check(AppUpdatePolicy.parse(legacy(),listOf("arm64-v8a")).abi=="universal")}
 test("four native architectures choose their artifact"){abis.forEach{abi->val p=AppUpdatePolicy.parse(multi(),listOf(abi));check(p.abi==abi&&p.url.endsWith("/$abi.apk"))}}
 test("32-bit Android never selects ARM64"){check(AppUpdatePolicy.parse(multi(),listOf("armeabi-v7a","armeabi")).abi=="armeabi-v7a")}
 test("OS ABI preference order respected"){check(AppUpdatePolicy.parse(multi(),listOf("arm64-v8a","armeabi-v7a")).abi=="arm64-v8a");check(AppUpdatePolicy.parse(multi(),listOf("x86_64","x86","arm64-v8a")).abi=="x86_64")}
 test("missing variant falls back to supported secondary or universal"){val p=multi();p.getJSONObject("variants").remove("arm64-v8a");check(AppUpdatePolicy.parse(p,listOf("arm64-v8a","armeabi-v7a")).abi=="armeabi-v7a");check(AppUpdatePolicy.parse(p,listOf("arm64-v8a")).abi=="universal");check(AppUpdatePolicy.parse(p,emptyList()).abi=="universal")}
 test("selected policy persists and restores as flat cache"){abis.forEach{abi->val p=AppUpdatePolicy.parse(multi(),listOf(abi));check(AppUpdatePolicy.parse(p.json(),listOf(abi))==p)}}
 test("invalid metadata rejected before selection"){for(key in listOf("versionCode","sizeBytes")){rejects{AppUpdatePolicy.parse(legacy().put(key,1.5),abis)};rejects{AppUpdatePolicy.parse(legacy().put(key,"7"),abis)}};rejects{AppUpdatePolicy.parse(legacy().put("url","http://bad.example"),abis)};rejects{AppUpdatePolicy.parse(legacy().put("url","https://u:p@host.example/a"),abis)};rejects{AppUpdatePolicy.parse(legacy().put("sha256","x"),abis)}}
 test("unknown or corrupt variants and incompatible cache rejected"){rejects{AppUpdatePolicy.parse(multi().put("variants",JSONObject().put("mips",artifact("mips"))),abis)};rejects{AppUpdatePolicy.parse(multi().put("variants",JSONObject.NULL),abis)};val p=multi();p.getJSONObject("variants").getJSONObject("x86").put("sizeBytes",0);rejects{AppUpdatePolicy.parse(p,listOf("arm64-v8a"))};rejects{AppUpdatePolicy.parse(legacy().put("abi","arm64-v8a"),listOf("armeabi-v7a"))}}
 fun apk(vararg native:String):File=File.createTempFile("update-test-",".apk").also{f->ZipOutputStream(f.outputStream()).use{out->out.putNextEntry(ZipEntry("AndroidManifest.xml"));out.write(byteArrayOf(1));out.closeEntry();native.forEach{abi->out.putNextEntry(ZipEntry("lib/$abi/libtest.so"));out.write(byteArrayOf(1));out.closeEntry()}}}
 test("APK native ABI inspection accepts correct split and universal"){for(abi in abis){val f=apk(abi);try{verifyUpdateApkAbi(f,abi,listOf(abi));verifyUpdateApkAbi(f,"universal",listOf(abi))}finally{f.delete()}};val f=apk(*abis.toTypedArray());try{verifyUpdateApkAbi(f,"universal",listOf("arm64-v8a"))}finally{f.delete()}}
 test("mislabeled and incompatible APKs rejected"){val f=apk("x86");try{rejects{verifyUpdateApkAbi(f,"arm64-v8a",listOf("arm64-v8a"))};rejects{verifyUpdateApkAbi(f,"universal",listOf("armeabi-v7a"))}}finally{f.delete()}}
 test("pure Java universal accepted; claimed native split rejected"){val f=apk();try{verifyUpdateApkAbi(f,"universal",listOf("arm64-v8a"));rejects{verifyUpdateApkAbi(f,"arm64-v8a",listOf("arm64-v8a"))}}finally{f.delete()}}
 println("$passed Android policy/ABI scenarios passed")
}
