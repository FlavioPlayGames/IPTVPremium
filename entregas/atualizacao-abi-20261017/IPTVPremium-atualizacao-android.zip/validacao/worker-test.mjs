import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import {createHash} from 'node:crypto';
const {default:worker}=await import(pathToFileURL('/workspace/update-worker-work/worker.js'));
export const origin='https://portal.example';
export const token='a'.repeat(64),csrf='csrf-test-only';
export function environment(){
 let value=null;let userRole='admin';
 const env={APP_KEY:'1'.repeat(64),ADMIN_PASSWORD:'test-password-never-used',ASSETS:{fetch:()=>new Response('asset')},DB:{prepare(sql){let args=[];return{bind(...a){args=a;return this},async first(){
  if(sql.startsWith('SELECT value FROM settings'))return value===null?null:{value};
  if(sql.startsWith('SELECT * FROM sessions'))return args[0]===createHash('sha256').update(token).digest('hex')?{role:userRole,csrf,expires:Date.now()+60000}:null;
  throw Error('Unexpected SQL: '+sql);
 },async run(){if(sql.startsWith("INSERT INTO settings"))value=args[0];else if(sql.startsWith('DELETE FROM settings'))value=null;else throw Error('Unexpected SQL');return{meta:{changes:1}}}}}}};
 return {env,get stored(){return value},setRole(v){userRole=v}};
}
export function request(path,method='GET',body,extra={}){return new Request(origin+path,{method,headers:{Origin:origin,Cookie:'iptv_session='+token,'X-CSRF-Token':csrf,'Content-Type':'application/json',...extra},...(body===undefined?{}:{body:JSON.stringify(body)})})}
const state=environment();let n=0;
async function test(name,task){await task();console.log('PASS '+name);n++}
const artifact=abi=>({url:'https://downloads.example/'+abi+'.apk',sha256:'b'.repeat(64),sizeBytes:12345});
const legacy={versionCode:4,versionName:'1.04',...artifact('universal'),notes:'teste'};
async function call(r){return worker.fetch(r,state.env,{})}
await test('legacy publication and public response',async()=>{let r=await call(request('/api/admin/update','PUT',legacy));assert.equal(r.status,200);let b=await r.json();assert.equal(b.update.url,legacy.url);assert.equal(b.update.mandatory,true);assert.equal(b.update.variants,undefined);assert.equal((await call(request('/api/app/update'))).status,200)});
const multi={...legacy,variants:Object.fromEntries(['armeabi-v7a','arm64-v8a','x86','x86_64'].map(abi=>[abi,artifact(abi)]))};
await test('four architectures + universal retain same version; uppercase SHA normalizes',async()=>{multi.variants.x86.sha256='A'.repeat(64);let r=await call(request('/api/admin/update','PUT',multi));assert.equal(r.status,200);let b=await r.json();assert.equal(Object.keys(b.update.variants).length,4);assert.equal(b.update.variants.x86.sha256,'a'.repeat(64));assert.equal(b.update.url,legacy.url)});
await test('invalid variants reject atomically',async()=>{for(const variants of [null,[],{'mips':artifact('mips')},{'arm64-v8a':{...artifact('arm64'),url:'http://bad.example/a.apk'}},{'x86':{...artifact('x86'),versionCode:99}},{'x86':{...artifact('x86'),sha256:'bad'}},{'x86':{...artifact('x86'),sizeBytes:1.2}}]){const before=state.stored;assert.equal((await call(request('/api/admin/update','PUT',{...legacy,variants}))).status,422);assert.equal(state.stored,before)}});
await test('universal remains mandatory; versions and metadata bounded',async()=>{for(const b of [{...multi,url:''},{...multi,versionCode:1.3},{...multi,versionCode:0},{...multi,sizeBytes:536870913}])assert.equal((await call(request('/api/admin/update','PUT',b))).status,422)});
await test('old-client 16 KiB response limit enforced',async()=>{const b=structuredClone(multi);for(const v of [b,...Object.values(b.variants)])v.url='https://downloads.example/'+ 'a'.repeat(3900)+'.apk';assert.equal((await call(request('/api/admin/update','PUT',b))).status,422)});
await test('admin authentication, CSRF and origin preserved',async()=>{assert.equal((await call(request('/api/admin/update','PUT',multi,{Cookie:''}))).status,401);assert.equal((await call(request('/api/admin/update','PUT',multi,{'X-CSRF-Token':'bad'}))).status,403);assert.equal((await call(request('/api/admin/update','PUT',multi,{Origin:'https://other.example'}))).status,403);state.setRole('user');assert.equal((await call(request('/api/admin/update'))).status,403);state.setRole('admin')});
await test('delete publication affects setting only',async()=>{assert.equal((await call(request('/api/admin/update','DELETE',{}))).status,200);assert.equal(state.stored,null);assert.deepEqual(await (await call(request('/api/app/update'))).json(),{update:null})});
await test('assets forwarding unchanged',async()=>assert.equal(await (await call(request('/'))).text(),'asset'));
console.log(n+' Worker scenarios passed');
