import assert from 'node:assert/strict';
import {createUpdateDraft,buildUpdateBody,samePublishedUpdate} from '/workspace/update-worker-work/public/update-artifacts.js';
const a={url:'https://downloads.example/universal.apk',sha256:'A'.repeat(64),sizeBytes:'100'};
let n=0;function test(name,task){task();console.log('PASS '+name);n++}
const meta={versionCode:'4',versionName:'1.04',notes:'Olá'};
test('legacy publication initializes optional APKs disabled',()=>{const d=createUpdateDraft({...meta,...a});assert.equal(d.universal.enabled,true);assert.equal(d['arm64-v8a'].enabled,false)});
test('optional APKs published independently; hash normalized',()=>{const d=createUpdateDraft(null);Object.assign(d.universal,a);Object.assign(d['arm64-v8a'],a,{enabled:true,url:'https://downloads.example/arm64.apk'});const b=buildUpdateBody(meta,d);assert.equal(b.sha256,'a'.repeat(64));assert.equal(Object.keys(b.variants).length,1)});
test('incomplete optional metadata identifies its architecture',()=>{const d=createUpdateDraft(null);Object.assign(d.universal,a);d.x86.enabled=true;assert.throws(()=>buildUpdateBody(meta,d),e=>e.abi==='x86')});
test('unsafe URLs, fractional sizes and invalid hashes rejected',()=>{for(const v of [{url:'http://bad.example/a'},{url:'https://u:p@host.example/a'},{sizeBytes:'1.5'},{sha256:'bad'}]){const d=createUpdateDraft(null);Object.assign(d.universal,a,v);assert.throws(()=>buildUpdateBody(meta,d))}});
test('all artifacts required in server confirmation; old server cannot silently drop variants',()=>{const d=createUpdateDraft(null);Object.assign(d.universal,a);Object.assign(d.x86,a,{enabled:true});const b=buildUpdateBody(meta,d);const actual={...b,mandatory:true,publishedAt:123};assert.equal(samePublishedUpdate(b,actual),true);assert.equal(samePublishedUpdate(b,{...actual,variants:undefined}),false);assert.equal(samePublishedUpdate(b,{...actual,url:'https://other.example/a.apk'}),false)});
console.log(n+' frontend contract scenarios passed');
