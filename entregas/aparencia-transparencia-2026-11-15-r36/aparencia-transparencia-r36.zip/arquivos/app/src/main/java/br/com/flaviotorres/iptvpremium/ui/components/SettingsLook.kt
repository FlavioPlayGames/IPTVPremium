package br.com.flaviotorres.iptvpremium.ui.components

import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp

internal object SettingsLook {
    val background get()=CatalogControlLook.background
    val panel get()=if(CatalogStyle.light)Color(0xFFC3C6CA).copy(alpha=.76f)else Color(0xFF35383C).copy(alpha=.78f)
    val control get()=if(CatalogStyle.light)Color(0xFFB9BEC4).copy(alpha=.60f)else Color(0xFF393D42).copy(alpha=.62f)
    val edge get()=if(CatalogStyle.light)Color(0xFF929AA4)else Color(0xFF535A62)
    val selection get()=lerp(control.copy(alpha=1f),CatalogStyle.accent,if(CatalogStyle.light).10f else .14f).copy(alpha=.82f)
    val text get()=CatalogStyle.text
    val secondary get()=CatalogStyle.secondary
    fun border(focused:Boolean)=SolidColor(if(focused)CatalogStyle.accent else edge)
}
@Composable
internal fun SettingsBackdrop(modifier:Modifier=Modifier) {
    CatalogThemeBackdrop(modifier)
}
