package br.com.flaviotorres.iptvpremium.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.ui.components.SettingsLook
import br.com.flaviotorres.iptvpremium.ui.theme.PremiumTheme
import br.com.flaviotorres.iptvpremium.ui.theme.homeThemeAccent

/** Only the panel opacity changes; scenery and all previews belong to their existing renderers. */
@Composable
internal fun AppearanceGlassPanel(modifier:Modifier=Modifier,content:@Composable ColumnScope.()->Unit) {
    val shape=RoundedCornerShape(14.dp)
    Column(modifier.background(SettingsLook.panel.copy(alpha=.34f),shape)
        .border(1.dp,SettingsLook.edge.copy(alpha=.75f),shape).padding(10.dp),
        verticalArrangement=Arrangement.spacedBy(6.dp),content=content)
}

@Composable
internal fun AppearanceMenuRow(label:String,value:String,icon:SubtitleSettingsIcon,modifier:Modifier=Modifier,onClick:()->Unit) {
    var focused by remember {mutableStateOf(false)}
    val shape=RoundedCornerShape(9.dp)
    Row(modifier.heightIn(min=36.dp).onFocusChanged{focused=it.isFocused}.clip(shape)
        .background(if(focused)SettingsLook.selection else SettingsLook.control)
        .border(if(focused)1.5.dp else .7.dp,SettingsLook.border(focused),shape)
        .clickable(role=Role.Button,interactionSource=remember{MutableInteractionSource()},indication=null,onClick=onClick)
        .padding(horizontal=10.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically,
        horizontalArrangement=Arrangement.spacedBy(9.dp)) {
        SubtitleSettingsGlyph(icon,Modifier.size(19.dp),SettingsLook.text)
        Box(Modifier.height(19.dp).width(1.dp).background(SettingsLook.edge))
        Text(label,color=SettingsLook.text,fontSize=14.sp,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f))
        Text(value,color=SettingsLook.secondary,fontSize=12.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.widthIn(max=110.dp))
        SubtitleSettingsGlyph(SubtitleSettingsIcon.CHEVRON,Modifier.size(13.dp),SettingsLook.secondary)
    }
}

@Composable
internal fun AppearanceThemeLegend(modifier:Modifier=Modifier) {
    val shape=RoundedCornerShape(9.dp)
    Row(modifier.heightIn(min=36.dp).background(SettingsLook.control,shape)
        .border(.7.dp,SettingsLook.edge,shape).semantics {contentDescription="Temas: ${PremiumTheme.entries.joinToString { it.label }}"}
        .padding(horizontal=10.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(9.dp)) {
        PremiumTheme.entries.forEach { theme->Box(Modifier.size(17.dp).background(homeThemeAccent(theme),CircleShape)) }
        Text("Cores do tema",color=SettingsLook.secondary,fontSize=11.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
    }
}

@Composable
internal fun AppearanceOption(label:String,isSelected:Boolean,modifier:Modifier=Modifier,swatch:Color?=null,onClick:()->Unit) {
    var focused by remember {mutableStateOf(false)}
    val shape=RoundedCornerShape(9.dp)
    Row(modifier.heightIn(min=36.dp).onFocusChanged{focused=it.isFocused}.clip(shape)
        .background(if(focused)SettingsLook.selection else SettingsLook.control)
        .border(if(focused)1.5.dp else .7.dp,SettingsLook.border(focused),shape)
        .semantics{selected=isSelected}
        .clickable(role=Role.RadioButton,interactionSource=remember{MutableInteractionSource()},indication=null,onClick=onClick)
        .padding(horizontal=10.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(8.dp)) {
        if(swatch!=null)Box(Modifier.size(16.dp).background(swatch,CircleShape))
        Text(label,color=SettingsLook.text,fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis,modifier=Modifier.weight(1f))
        if(isSelected)SubtitleSettingsGlyph(SubtitleSettingsIcon.CHECK,Modifier.size(15.dp),SettingsLook.text)
    }
}

@Composable
internal fun AppearanceMenuReturn(onClick:()->Unit) {
    var focused by remember {mutableStateOf(false)}
    Row(Modifier.onFocusChanged{focused=it.isFocused}.clip(RoundedCornerShape(6.dp))
        .background(if(focused)SettingsLook.selection else Color.Transparent)
        .clickable(role=Role.Button,interactionSource=remember{MutableInteractionSource()},indication=null,onClick=onClick)
        .padding(horizontal=8.dp,vertical=5.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(6.dp)) {
        SubtitleSettingsGlyph(SubtitleSettingsIcon.BACK,Modifier.size(13.dp),SettingsLook.text)
        Text("Menu",color=SettingsLook.text,fontSize=12.sp)
    }
}

/** Original full scenes, scaled as a unit by the original Home/Kids/catalogue composables. */
@Composable
internal fun AppearanceOriginalPreview(label:String,modifier:Modifier=Modifier,content:@Composable ()->Unit) {
    var focused by remember {mutableStateOf(false)}
    val shape=RoundedCornerShape(10.dp)
    Column(modifier.onFocusChanged{focused=it.isFocused}
        .border(if(focused)1.5.dp else 0.dp,SettingsLook.border(focused),shape)
        .semantics{contentDescription="Prévia: $label"}.focusable().padding(4.dp),verticalArrangement=Arrangement.spacedBy(6.dp)) {
        Text(label,color=SettingsLook.text,fontSize=13.sp,maxLines=1,overflow=TextOverflow.Ellipsis)
        content()
    }
}
