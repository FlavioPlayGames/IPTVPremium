﻿param(
 [Parameter(Mandatory=$true)][string]$Projeto,
 [ValidateSet('ORIGINAL','G1','G4','G8')][string]$Estrategia='G8',
 [ValidateRange(3,9)][int]$Repeticoes=3,
 [string]$PastaSaida=(Join-Path $env:USERPROFILE 'Downloads'),
 [string]$Dispositivo=''
)
$ErrorActionPreference='Stop'
$root=(Resolve-Path -LiteralPath $Projeto).Path
Write-Host ('Estrategia: '+$Estrategia+'. Use a mesma lista, TV e cenario em todas as rodadas.')
Write-Host 'Este roteiro compila, instala e mede. Nao apaga dados nem dispara importacoes sozinho.'
Push-Location $root
try {
 & .\gradlew.bat --no-daemon --no-configuration-cache --max-workers=2 :app:assembleDesempenho ("-PiptvM3uProfile="+$Estrategia)
 if($LASTEXITCODE -ne 0){throw 'Compilacao falhou.'}
} finally {Pop-Location}
$deviceArgs=@{}
if($Dispositivo){$deviceArgs.Dispositivo=$Dispositivo}
& (Join-Path $PSScriptRoot 'Instalar-TV.ps1') -Projeto $root @deviceArgs
for($round=1;$round -le $Repeticoes;$round++) {
 Write-Host ("Rodada $round de $Repeticoes. Abra a TV na mesma tela de atualizacao da lista.")
 Read-Host 'Pressione Enter para iniciar a captura ANTES de atualizar a lista na TV' | Out-Null
 & (Join-Path $PSScriptRoot 'Medir-Importacao-M3U.ps1') -Formato M3U -Estrategia $Estrategia -Rodada $round -PastaSaida $PastaSaida @deviceArgs
}
Write-Host 'Coletas concluidas. Envie os arquivos TXT para comparacao da mediana, maior tempo e integridade.'
