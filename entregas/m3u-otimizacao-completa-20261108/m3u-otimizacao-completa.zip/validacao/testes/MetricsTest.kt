import br.com.flaviotorres.iptvpremium.data.cache.dao.*
import br.com.flaviotorres.iptvpremium.data.cache.entity.*
import kotlinx.coroutines.*
import br.com.flaviotorres.iptvpremium.data.cache.M3uTransactionMetrics
import java.lang.reflect.*
fun main()=runBlocking {
 val calls=mutableListOf<String>();var failure:Throwable?=null
 val dao=Proxy.newProxyInstance(PlaylistCacheDao::class.java.classLoader,arrayOf(PlaylistCacheDao::class.java)){p,m,args ->
  if(m.isDefault) try { InvocationHandler::class.java.getMethod("invokeDefault",Any::class.java,Method::class.java,Array<Any>::class.java).invoke(null,p,m,args.orEmpty()) } catch (error: InvocationTargetException) { throw error.cause!! }
  else { calls+=m.name;Thread.sleep(2);if(m.name=="insertEpisodes")failure?.let{throw it};Unit }
 } as PlaylistCacheDao
 @Suppress("UNCHECKED_CAST")
 suspend fun invoke(metrics:ImportBatchWriteMetrics?)=dao.insertImportBatch(listOf(null) as List<CachedCategoryEntity>,listOf(null) as List<CachedChannelEntity>,listOf(null) as List<CachedMovieEntity>,listOf(null) as List<CachedSeriesEntity>,listOf(null) as List<CachedEpisodeEntity>,metrics)
 val expected=listOf("insertCategories","insertChannels","insertMovies","insertSeries","insertEpisodes")
 val metrics=ImportBatchWriteMetrics();val start=System.nanoTime();invoke(metrics);val total=System.nanoTime()-start
 check(calls==expected);check(metrics.bodyEntered);check(metrics.failedStage==null)
 check(ImportBatchWriteMetrics.Stage.entries.all{metrics.nanos(it)>0})
 check(metrics.bodyNanos()>=ImportBatchWriteMetrics.Stage.entries.sumOf{metrics.nanos(it)})
 check(metrics.outsideBodyNanos(total)==total-metrics.bodyNanos());check(metrics.outsideBodyNanos(0)==0L)
 println("PASS actual DAO default body measures five stages in original order")
 calls.clear();invoke(null);check(calls==expected);println("PASS null metrics preserves insertion order")
 calls.clear();val empty=ImportBatchWriteMetrics();dao.insertImportBatch(emptyList(),emptyList(),emptyList(),emptyList(),emptyList(),empty)
 check(calls.isEmpty());check(ImportBatchWriteMetrics.Stage.entries.all{empty.nanos(it)==0L});println("PASS empty batch measures no insertion")
 for(error in listOf(IllegalStateException("simulated"),CancellationException("simulated"))) {
  failure=error;val broken=ImportBatchWriteMetrics();try{invoke(broken);error("expected exception")}catch(actual:Throwable){check(actual===error)}
  check(broken.failedStage==ImportBatchWriteMetrics.Stage.EPISODES);check(broken.bodyNanos()>0);println("PASS ${error.javaClass.simpleName} preserved with stage and final timing")
 }
 val outer=M3uTransactionMetrics();check(M3uTransactionMetrics.current()==null)
 withContext(Dispatchers.IO+outer){
  check(M3uTransactionMetrics.current()===outer);delay(1);check(M3uTransactionMetrics.current()===outer)
  val inner=M3uTransactionMetrics();withContext(inner){check(M3uTransactionMetrics.current()===inner)}
  check(M3uTransactionMetrics.current()===outer)
 }
 check(M3uTransactionMetrics.current()==null)
 println("PASS transaction trace follows dispatcher changes and restores nested thread context")

}
