package br.com.flaviotorres.iptvpremium.data.cache
import androidx.room.RoomOpenDelegate
import androidx.room.EntityInsertAdapter
import androidx.sqlite.SQLiteConnection
import androidx.sqlite.SQLiteStatement
import br.com.flaviotorres.iptvpremium.data.cache.dao.*
import br.com.flaviotorres.iptvpremium.data.cache.importer.*
import br.com.flaviotorres.iptvpremium.data.cache.entity.*
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import java.sql.*
import java.lang.reflect.*
import java.nio.file.*
import kotlinx.coroutines.*
private class SqlConnection(val raw:Connection):SQLiteConnection {
 override fun prepare(sql:String):SQLiteStatement=SqlStatement(raw.prepareStatement(sql))
 override fun close()=raw.close()
}
private class SqlStatement(private val s:PreparedStatement):SQLiteStatement{
 private var rs:ResultSet?=null;private var executed=false
 override fun bindBlob(index:Int,value:ByteArray)=s.setBytes(index,value)
 override fun bindDouble(index:Int,value:Double)=s.setDouble(index,value)
 override fun bindLong(index:Int,value:Long)=s.setLong(index,value)
 override fun bindText(index:Int,value:String)=s.setString(index,value)
 override fun bindNull(index:Int)=s.setNull(index,Types.NULL)
 override fun getBlob(index:Int)=rs!!.getBytes(index+1)
 override fun getDouble(index:Int)=rs!!.getDouble(index+1)
 override fun getLong(index:Int)=rs!!.getLong(index+1)
 override fun getText(index:Int)=rs!!.getString(index+1)
 override fun isNull(index:Int)=rs!!.getObject(index+1)==null
 override fun getColumnCount():Int{ensureExecuted();return rs?.metaData?.columnCount?:0}
 override fun getColumnName(index:Int):String{ensureExecuted();return rs!!.metaData.getColumnName(index+1)}
 override fun getColumnType(index:Int)=when(rs!!.getObject(index+1)){null->5;is ByteArray->4;is String->3;is Double,is Float->2;else->1}
 private fun ensureExecuted(){if(!executed){executed=true;if(s.execute())rs=s.resultSet}}
 override fun step():Boolean{ensureExecuted();return rs?.next()?:false}
 override fun reset(){rs?.close();rs=null;executed=false}
 override fun clearBindings()=s.clearParameters()
 override fun close(){rs?.close();s.close()}
}

private class RealSqlDb(val file:Path) : AutoCloseable {
 val c=DriverManager.getConnection("jdbc:sqlite:"+file)
 val connection=SqlConnection(c)
 val db=PlaylistCacheDatabase_Impl()
 val generated=br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao_Impl(db)
 var groups=0;var chunks=0;var peak=0;var failedAtChunk:Int?=null;var injectedFailure:Throwable=IllegalStateException("simulated transaction failure")
 var beforeUs=0L;var afterUs=0L;val stages=LongArray(5)
 val dao:PlaylistCacheDao
 init {
  c.createStatement().use{it.execute("PRAGMA journal_mode=WAL");it.execute("PRAGMA synchronous=NORMAL")}
  val method=db.javaClass.getDeclaredMethod("createOpenDelegate");method.isAccessible=true
  (method.invoke(db) as RoomOpenDelegate).createAllTables(connection)
  dao=Proxy.newProxyInstance(PlaylistCacheDao::class.java.classLoader,arrayOf(PlaylistCacheDao::class.java)){proxy,m,args0->
   val args=args0.orEmpty()
   fun body():Any?=try {InvocationHandler::class.java.getMethod("invokeDefault",Any::class.java,Method::class.java,Array<Any>::class.java).invoke(null,proxy,m,args)}catch(e:InvocationTargetException){throw e.cause!!}
   fun insert(fieldName:String,items:Any?) {
    val f=generated.javaClass.getDeclaredField(fieldName);f.isAccessible=true
    @Suppress("UNCHECKED_CAST") val adapter=f.get(generated) as EntityInsertAdapter<Any>
    @Suppress("UNCHECKED_CAST") adapter.insert(connection,items as List<Any>)
   }
   when(m.name){
    "insertM3uGroup","insertImportBatch" -> {
     val g=if(m.name=="insertM3uGroup")args[0] as M3uWriteGroup else null
     peak=maxOf(peak,g?.batches?.sumOf{it.entries}?:((args[1]as List<*>).size+(args[2]as List<*>).size+(args[4]as List<*>).size))
     val trace=M3uTransactionMetrics.current();val begin=System.nanoTime();c.autoCommit=false;trace?.recordBegin(System.nanoTime()-begin)
     try {val result=body();c.commit();groups++;result} catch(e:Throwable){c.rollback();throw e}
     finally{c.autoCommit=true}
    }
    "insertImportBatchBody" -> {chunks++;if(chunks==failedAtChunk)throw injectedFailure;body()}
    "insertCategories" -> {insert("__insertAdapterOfCachedCategoryEntity",args[0]);Unit}
    "insertChannels" -> {insert("__insertAdapterOfCachedChannelEntity",args[0]);Unit}
    "insertMovies" -> {insert("__insertAdapterOfCachedMovieEntity_1",args[0]);Unit}
    "insertSeries" -> {insert("__insertAdapterOfCachedSeriesEntity_1",args[0]);Unit}
    "insertEpisodes" -> {insert("__insertAdapterOfCachedEpisodeEntity",args[0]);Unit}
    "upsertGeneration" -> {insert("__insertAdapterOfPlaylistCacheGenerationEntity",listOf(args[0]!!));Unit}
    "updateGenerationStatus" -> {c.prepareStatement("UPDATE playlist_cache_generations SET status=?,completedAtEpochMillis=? WHERE playlistId=? AND generationId=?").use{s->s.setString(1,args[2]as String);s.setLong(2,args[3]as Long);s.setString(3,args[0]as String);s.setString(4,args[1]as String);s.executeUpdate()};Unit}
    "discardIncompleteImport" -> {c.prepareStatement("DELETE FROM playlist_cache_generations WHERE playlistId=? AND generationId=? AND status!='ACTIVE'").use{s->s.setString(1,args[0]as String);s.setString(2,args[1]as String);s.executeUpdate()};true}
    else -> if(m.isDefault)body() else error("Unexpected DAO method "+m.name)
   }
  } as PlaylistCacheDao
 }
 fun count(table:String,generation:String?=null):Int=c.createStatement().use{s->s.executeQuery("SELECT COUNT(*) FROM "+table+(generation?.let{" WHERE generationId='"+it+"'"}?:"")).use{it.next();it.getInt(1)}}
 fun canonical(generation:String)=listOf("cached_categories","cached_channels","cached_movies","cached_series","cached_episodes").map{table->
  c.createStatement().use{s->s.executeQuery("SELECT * FROM $table WHERE generationId='$generation' ORDER BY 1,3,4").use{r->buildList{while(r.next())add((1..r.metaData.columnCount).filter{r.metaData.getColumnName(it)!="generationId"}.map{r.getObject(it)})}}}
 }
 override fun close(){connection.close();Files.deleteIfExists(file);Files.deleteIfExists(Path.of(file.toString()+"-wal"));Files.deleteIfExists(Path.of(file.toString()+"-shm"))}
}
private class SyntheticHttp(val scale:Int=1):PlaylistHttpClient {
 override suspend fun get(url:String):String=error("No network in this benchmark")
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit) {
  onLine("#EXTM3U")
  suspend fun row(name:String,group:String,url:String,i:Int){onLine("#EXTINF:-1 tvg-logo=\"https://images.example/poster/$i.jpg\" group-title=\"$group\",$name");onLine(url)}
  repeat(2355/scale){row("Canal $it","Live ${it%12}","https://example.invalid/live/$it.ts",it)}
  repeat(44099/scale){row("Filme $it (2024)","Filmes ${it%32}","https://example.invalid/movie/$it.mkv",it)}
  repeat(283278/scale){val series=(it.toLong()*9800/283278).toInt();row("Série $series S01E${it%40+1}","Séries ${series%60}","https://example.invalid/series/$it.mkv",series)}
 }
}
fun main(args:Array<String>)=runBlocking {
 Class.forName("org.sqlite.JDBC")
 val folder=Path.of("/workspace/m3u-otimizacao-completa/sqlite-tests");Files.createDirectories(folder)
 if(args.firstOrNull() in listOf("bench","bench-refresh")) {
  val refresh=args.firstOrNull()=="bench-refresh"
  val lines=mutableListOf("strategy,run,wallMs,groups,chunks,peakGroupEntries,channels,movies,series,episodes")
  // One untimed warmup avoids comparing class-loading against a warm JVM.
  RealSqlDb(folder.resolve("warmup.db")).use{d->M3uCacheImporter(SyntheticHttp(100),d.dao,PlaylistCacheGenerationManager(d.dao),250,transactionBatches=4,originalWriter=false).import("p","https://example.invalid/list")}
  for(run in 1..3) for(mode in listOf("ORIGINAL","G1","G4","G8")) {
   RealSqlDb(folder.resolve("bench-$mode-$run.db")).use{d->
    if(refresh){
     val old=OriginalM3uCacheImporter(SyntheticHttp(),d.dao,PlaylistCacheGenerationManager(d.dao)).import("p","https://example.invalid/list")
     d.c.createStatement().use{it.execute("UPDATE playlist_cache_generations SET status='ACTIVE' WHERE generationId='$old'")}
     d.groups=0;d.chunks=0;d.peak=0
    }
    val policy=M3uWritePolicy.named(mode);val t=System.nanoTime()
    val g=if(mode=="ORIGINAL") OriginalM3uCacheImporter(SyntheticHttp(),d.dao,PlaylistCacheGenerationManager(d.dao)).import("p","https://example.invalid/list") else M3uCacheImporter(SyntheticHttp(),d.dao,PlaylistCacheGenerationManager(d.dao),policy.batchSize,transactionBatches=policy.transactionBatches,originalWriter=false).import("p","https://example.invalid/list")
    val ms=(System.nanoTime()-t)/1_000_000
    val counts=listOf("cached_channels","cached_movies","cached_series","cached_episodes").map{d.count(it,g)}
    check(counts==listOf(2355,44099,9800,283278)){"Missing records: $counts"}
    val line=listOf(mode,run,ms,d.groups,d.chunks,d.peak,*counts.toTypedArray()).joinToString(",");lines+=line;println(line)
    Files.write(folder.resolve(if(refresh)"refresh.csv"else"bench.csv"),lines)
   }
  }
 } else {
  var expected:List<List<List<Any?>>>?=null
  for(mode in listOf("ORIGINAL","G1","G4","G8")) RealSqlDb(folder.resolve("parity-$mode.db")).use{d->
   val policy=M3uWritePolicy.named(mode);val http=SyntheticHttp(100)
   val g=M3uCacheImporter(http,d.dao,PlaylistCacheGenerationManager(d.dao),policy.batchSize,transactionBatches=policy.transactionBatches,originalWriter=mode=="ORIGINAL").import("p","https://example.invalid/list")
   val values=d.canonical(g);if(expected==null)expected=values else check(expected==values){"Metadata mismatch $mode"}
   val g2=M3uCacheImporter(http,d.dao,PlaylistCacheGenerationManager(d.dao),policy.batchSize,transactionBatches=policy.transactionBatches,originalWriter=mode=="ORIGINAL").import("p","https://example.invalid/list")
   check(d.canonical(g)==values && d.canonical(g2)==values);check(g!=g2)
   check(d.peak<=2000);println("PASS $mode real SQLite + generated Room adapters preserve every field across first import and refresh")
  }
  RealSqlDb(folder.resolve("manual-refresh.db")).use{d->
   var lines=listOf("#EXTM3U","#EXTINF:-1 group-title=\"Filmes\" tvg-logo=\"first\",A (2020)","https://example.invalid/movie/a.mp4","#EXTINF:-1 group-title=\"Filmes\",B","https://example.invalid/movie/b.mp4")
   val http=object:PlaylistHttpClient{override suspend fun get(url:String)=error("unused");override suspend fun readLines(url:String,onLine:suspend(String)->Unit){for(line in lines)onLine(line)}}
   val importer=M3uCacheImporter(http,d.dao,PlaylistCacheGenerationManager(d.dao),250,transactionBatches=8,originalWriter=false)
   val old=importer.import("p","https://example.invalid/list");val oldValues=d.canonical(old)
   d.c.createStatement().use{it.execute("UPDATE playlist_cache_generations SET status='ACTIVE' WHERE generationId='$old'")}
   lines=listOf("#EXTM3U","#EXTINF:-1 group-title=\"Filmes\" tvg-logo=\"new\",A (2020)","https://example.invalid/movie/a.mp4","#EXTINF:-1 group-title=\"Filmes\",C","https://example.invalid/movie/c.mp4")
   val fresh=importer.import("p","https://example.invalid/list")
   check(d.canonical(old)==oldValues);check(d.count("cached_movies",fresh)==2)
   d.c.createStatement().use{stmt->stmt.executeQuery("SELECT name,posterUrl FROM cached_movies WHERE generationId='$fresh' ORDER BY name").use{r->check(r.next()&&r.getString(1)=="A (2020)"&&r.getString(2)=="new");check(r.next()&&r.getString(1)=="C");check(!r.next())}}
   println("PASS manual refresh adds, removes and changes metadata in a new generation while preserving ACTIVE rows")
  }
  RealSqlDb(folder.resolve("null-duplicate.db")).use{d->
   val e=CachedEpisodeEntity("p","new","e","s",null,null,"Ação ' Unicode","https://example.invalid/e?x='",null,null)
   suspend fun write(value:CachedEpisodeEntity){val b=M3uWriteBatch(emptyList(),emptyList(),emptyList(),emptyList(),listOf(value),0);val trace=M3uTransactionMetrics();withContext(trace){d.dao.insertM3uGroup(M3uWriteGroup(listOf(b)),trace)}}
   write(e);write(e.copy(posterUrl="last",durationSeconds=2700))
   check(d.count("cached_episodes")==1)
   d.c.createStatement().use{stmt->stmt.executeQuery("SELECT seasonNumber,episodeNumber,name,streamUrl,posterUrl,durationSeconds FROM cached_episodes").use{r->check(r.next()&&r.getObject(1)==null&&r.getObject(2)==null&&r.getString(3)==e.name&&r.getString(4)==e.streamUrl&&r.getString(5)=="last"&&r.getLong(6)==2700L)}}
   d.c.createStatement().use{stmt->stmt.executeQuery("PRAGMA integrity_check").use{r->check(r.next()&&r.getString(1)=="ok")}}
   println("PASS original conflict policy, nulls, Unicode, quotes, updated episode fields and SQLite integrity preserved")
  }
  RealSqlDb(folder.resolve("rollback.db")).use{d->
   val entry=CachedEpisodeEntity("p","new","e","s",null,null,"Título ' ação","https://example.invalid/e",null,null)
   val b=M3uWriteBatch(emptyList(),emptyList(),emptyList(),emptyList(),listOf(entry),0)
   val trace=M3uTransactionMetrics();d.failedAtChunk=2
   try{withContext(trace){d.dao.insertM3uGroup(M3uWriteGroup(listOf(b,b)),trace)};error("expected failure")}catch(e:IllegalStateException){check(e.message=="simulated transaction failure")}
   check(d.count("cached_episodes")==0);println("PASS failure in second chunk rolls back first chunk in the same SQLite transaction")
  }
  RealSqlDb(folder.resolve("cancel.db")).use{d->
   val e=CachedEpisodeEntity("p","new","e","s",null,null,"Título","https://example.invalid/e",null,null)
   val b=M3uWriteBatch(emptyList(),emptyList(),emptyList(),emptyList(),listOf(e),0)
   val cancelled=CancellationException("simulated cancel");d.injectedFailure=cancelled;d.failedAtChunk=2
   try{withContext(M3uTransactionMetrics()){d.dao.insertM3uGroup(M3uWriteGroup(listOf(b,b)),M3uTransactionMetrics())};error("expected cancel")}catch(e:CancellationException){check(e===cancelled)}
   check(d.count("cached_episodes")==0);println("PASS cancellation during second chunk rolls back transaction and propagates original cancellation")
  }

 }
}
