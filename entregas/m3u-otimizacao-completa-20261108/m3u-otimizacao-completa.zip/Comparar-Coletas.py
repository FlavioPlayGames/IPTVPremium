"""Optional offline aggregation. Python 3 only; never reads playlist URLs or credentials."""
import argparse,re,statistics,csv,sys
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('pasta',type=Path);args=ap.parse_args();groups={}
for p in sorted(args.pasta.glob('diagnostico-importacao-*.txt')):
 lines=p.read_text(encoding='utf-8-sig').splitlines()
 fields=lambda l:dict(re.findall(r'\b(\w+)=([^\s]+)',l))
 config=[fields(l)for l in lines if 'IPTV_PERF:' in l and 'stage=config ' in l]
 summaries=[fields(l)for l in lines if 'IPTV_PERF:' in l and 'stage=summary ' in l]
 sync=[fields(l)for l in lines if 'SYNC_RESUMO ' in l]
 if len(config)!=1 or len(summaries)!=1 or len(sync)!=1 or sync[0].get('resultado')!='SUCESSO':continue
 c,s,t=config[0],summaries[0],sync[0]
 mode='ORIGINAL' if c.get('original')=='1' else 'G'+c['transactionBatches']
 actual=[fields(l)for l in lines if 'IPTV_PERF:' in l and 'stage=group ' in l and 'status=OK' in l]
 if len(actual)!=int(s['groups']):continue
 groups.setdefault(mode,[]).append((int(t['duracaoMs']),int(s['peakGroupMs']),int(s['heapPeakObservedKb']),tuple(int(s[k])for k in ['entries','channels','movies','series','episodes','categories'])))
writer=csv.writer(sys.stdout);writer.writerow(['estrategia','capturas_validas','mediana_total_ms','maior_total_ms','maior_grupo_ms','maior_heap_java_observado_kb','mesmas_contagens','minimo_3'])
for mode,rows in sorted(groups.items()):writer.writerow([mode,len(rows),statistics.median(r[0]for r in rows),max(r[0]for r in rows),max(r[1]for r in rows),max(r[2]for r in rows),len({r[3]for r in rows})==1,len(rows)>=3])
