package br.com.flaviotorres.iptvpremium.data.cache.importer

import br.com.flaviotorres.iptvpremium.data.cache.dao.ImportBatchWriteMetrics
import br.com.flaviotorres.iptvpremium.data.cache.entity.*

/** Fully prepared records. The writer never waits for the producer while inside a transaction. */
data class M3uWriteBatch(
    val categories: List<CachedCategoryEntity>, val channels: List<CachedChannelEntity>,
    val movies: List<CachedMovieEntity>, val series: List<CachedSeriesEntity>,
    val episodes: List<CachedEpisodeEntity>, val characters: Long,
    val metrics: ImportBatchWriteMetrics = ImportBatchWriteMetrics()
) { val entries: Int get() = channels.size + movies.size + episodes.size }

data class M3uWriteGroup(val batches: List<M3uWriteBatch>)
