package br.com.flaviotorres.iptvpremium.data.cache.importer

import br.com.flaviotorres.iptvpremium.BuildConfig

internal data class M3uWritePolicy(val name: String, val batchSize: Int, val transactionBatches: Int) {
    companion object {
        fun named(name: String): M3uWritePolicy = when (name) {
            "ORIGINAL" -> M3uWritePolicy(name, 2000, 1)
            "G1" -> M3uWritePolicy(name, 250, 1)
            "G8" -> M3uWritePolicy(name, 250, 8)
            "G4" -> M3uWritePolicy(name, 250, 4)
            else -> error("Perfil M3U inválido")
        }
        fun configured() = named(BuildConfig.M3U_IMPORT_PROFILE)
    }
}
