package br.com.flaviotorres.iptvpremium.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import br.com.flaviotorres.iptvpremium.R
import br.com.flaviotorres.iptvpremium.ui.theme.themeBackdropPainter
import br.com.flaviotorres.iptvpremium.ui.theme.themePainterResource

/** Shared catalogue wallpaper; only this static decorative layer is blurred. */
@Composable
internal fun CatalogThemeBackdrop(modifier: Modifier = Modifier) {
    if (br.com.flaviotorres.iptvpremium.ui.kids.KidsAppearance.active) {
        br.com.flaviotorres.iptvpremium.ui.kids.KidsScenery(modifier)
        return
    }
    Box(modifier.background(Brush.verticalGradient(listOf(
        CatalogStyle.panel, CatalogStyle.background, CatalogStyle.background))))

}

/** Neutral smoked glass avoids tinting all panels brown/olive in the Gold theme. */
internal object CatalogGlass {
    val panelBrush get() = if (br.com.flaviotorres.iptvpremium.ui.kids.KidsAppearance.active)
        Brush.verticalGradient(if(br.com.flaviotorres.iptvpremium.ui.kids.KidsAppearance.style == br.com.flaviotorres.iptvpremium.ui.kids.KidsStyle.PINK)
            listOf(Color(0xEB230A25),Color(0xDD120718)) else listOf(Color(0xEB05152C),Color(0xDD060B1B)))
        else Brush.verticalGradient(listOf(CatalogStyle.panel, CatalogStyle.panel))
    fun surface(source: Long): Color = CatalogStyle.surface(source)
}
