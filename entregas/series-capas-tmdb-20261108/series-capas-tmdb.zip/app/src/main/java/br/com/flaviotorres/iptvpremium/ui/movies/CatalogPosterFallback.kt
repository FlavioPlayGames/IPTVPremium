package br.com.flaviotorres.iptvpremium.ui.movies

import android.content.Context
import android.util.Log
import androidx.compose.ui.graphics.ImageBitmap
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.remote.TmdbClientProvider
import br.com.flaviotorres.iptvpremium.data.repository.SeriesCatalogPosterResolver
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

private val verifiedPosterSlots=Semaphore(2)
internal fun peekCatalogPoster(url:String?,kind:PosterKind,name:String,year:Int?,tmdbId:String?,imdbId:String?):ImageBitmap? =
    MoviePosterLoader.peekBitmap(if(kind==PosterKind.SERIES)SeriesCatalogPosterResolver.peek(name,year,tmdbId,imdbId)?.url else url)

internal suspend fun loadCatalogPoster(context:Context,url:String?,kind:PosterKind,name:String,year:Int?,tmdbId:String?,imdbId:String?):ImageBitmap? {
    if(kind!=PosterKind.SERIES)return MoviePosterLoader.loadWithRetry(context,url,kind)
    MediaOpeningPriority.awaitIdle();CatalogImportPriority.busy.first{!it}
    return verifiedPosterSlots.withPermit {
        var completed=false
        val result=withTimeoutOrNull(15_000L){
            val poster=SeriesCatalogPosterResolver.resolve(name,year,tmdbId,imdbId,TmdbClientProvider.client::get)
            val image=poster?.let{MoviePosterLoader.loadWithRetry(context,it.url,kind)}
            if(poster!=null)Log.i("SeriesPosterPerf","stage=image status=${if(image!=null)"READY"else"UNAVAILABLE"} workHash=${poster.workHash} tmdbId=${poster.tmdbId}")
            completed=true;image
        }
        if(!completed)Log.i("SeriesPosterPerf","stage=image status=TIMEOUT")
        result
    }
}
