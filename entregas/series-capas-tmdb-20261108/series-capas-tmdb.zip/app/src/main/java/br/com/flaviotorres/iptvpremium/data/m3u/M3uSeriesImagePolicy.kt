package br.com.flaviotorres.iptvpremium.data.m3u
import java.net.URI
internal object M3uSeriesImagePolicy {
    private fun url(s:String)=s.length<=8192&&(s.startsWith("http://",true)||s.startsWith("https://",true))
    fun catalogueImage(s:String):Boolean {
        if(!url(s))return false
        val uri=runCatching{URI(s)}.getOrNull()?:return false
        if(!uri.host.equals("image.tmdb.org",true))return true
        val path=uri.path.orEmpty()
        if(path.startsWith("/t/p/w1280/"))return false
        val m=Regex("/w([0-9]+)_and_h([0-9]+)[^/]*/").find(path)?:return true
        return (m.groupValues[2].toLongOrNull()?:0)>(m.groupValues[1].toLongOrNull()?:Long.MAX_VALUE)
    }
}
