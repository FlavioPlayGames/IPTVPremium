﻿param([string]$Dispositivo='', [string]$PastaSaida=(Get-Location).Path, [string]$AdbPath='')
$ErrorActionPreference='Stop'
if(!$AdbPath){
 if($env:LOCALAPPDATA){$AdbPath=Join-Path $env:LOCALAPPDATA 'Android/Sdk/platform-tools/adb.exe'}
 if(!$AdbPath -or !(Test-Path -LiteralPath $AdbPath)){$found=Get-Command adb -ErrorAction SilentlyContinue;if($found){$AdbPath=$found.Source}}
}
if(!$AdbPath -or !(Test-Path -LiteralPath $AdbPath)){throw 'ADB nao encontrado. Informe -AdbPath.'}
$devices=@(& $AdbPath devices | ForEach-Object {if($_ -match '^(\S+)\s+device\s*$'){$Matches[1]}})
if($LASTEXITCODE -ne 0){throw 'Falha ao consultar aparelhos.'}
if(!$Dispositivo){if($devices.Count -ne 1){throw 'Informe -Dispositivo com o serial exibido por adb devices.'};$Dispositivo=$devices[0]}
if($Dispositivo -notin $devices -or $Dispositivo -notmatch '^[A-Za-z0-9_.:-]+$'){throw 'Aparelho nao conectado ou serial invalido.'}
New-Item -ItemType Directory -Force -Path $PastaSaida | Out-Null
$report=Join-Path $PastaSaida ('diagnostico-capas-series-'+[DateTime]::UtcNow.ToString('yyyyMMdd-HHmmss')+'.txt')
$temp=Join-Path ([IO.Path]::GetTempPath()) ('iptv-capas-'+[guid]::NewGuid().ToString('N'))
$stdout=$temp+'.out';$stderr=$temp+'.err';$process=$null
function Safe-Metrics([string[]]$Lines){
 foreach($line in $Lines){
  if($line -notmatch '\bSeriesPosterPerf\s*:\s*(.*)$'){continue};$body=$Matches[1];$fields=@()
  foreach($m in [regex]::Matches($body,'\b([A-Za-z][A-Za-z0-9]*)=([^\s]+)')){
   $key=$m.Groups[1].Value;$value=$m.Groups[2].Value
   if(($key -ceq 'stage' -and $value -cmatch '^(identity|image)$') -or
      ($key -ceq 'status' -and $value -cmatch '^(OK|UNRESOLVED|READY|UNAVAILABLE|TIMEOUT|ERROR)$') -or
      ($key -ceq 'source' -and $value -cmatch '^(REMOTE|CACHE)$') -or
      ($key -ceq 'workHash' -and $value -cmatch '^[a-f0-9]{12}$') -or
      ($key -ceq 'tmdbId' -and $value -cmatch '^[1-9][0-9]*$')){$fields+=($key+'='+$value)}
  }
  if($fields.Count -gt 0){'SeriesPosterPerf: '+($fields -join ' ')}
 }
}
$baseline=@(& $AdbPath -s $Dispositivo logcat -d -t 1 -v threadtime -s 'SeriesPosterPerf:I' '*:S')
if($LASTEXITCODE -ne 0){throw 'Nao foi possivel iniciar a leitura do log.'}
try{
 $arguments=@('-s',$Dispositivo,'logcat','-v','threadtime','-T','1','-s','SeriesPosterPerf:I','*:S')
 $process=Start-Process -FilePath $AdbPath -ArgumentList $arguments -RedirectStandardOutput $stdout -RedirectStandardError $stderr -PassThru -NoNewWindow
 Write-Host 'Captura iniciada. Abra o catalogo de series, encontre a serie desejada e aguarde as capas.'
 Write-Host 'Saia e abra o mesmo catalogo novamente para conferir o cache. Nao precisa atualizar a lista.'
 Read-Host 'Quando terminar, pressione Enter para salvar' | Out-Null
}finally{
 if($process -and !$process.HasExited){Stop-Process -Id $process.Id -ErrorAction SilentlyContinue;$process.WaitForExit()}
 $lines=@();if(Test-Path -LiteralPath $stdout){$lines=@(Get-Content -LiteralPath $stdout | Where-Object {$_ -notin $baseline})}
 $safe=@(Safe-Metrics $lines)
 @('IPTV Premium - capas verificadas de series',('UTC: '+[DateTime]::UtcNow.ToString('o')),'Somente metricas de capas; sem titulos, URLs ou credenciais.','---')+$safe | Set-Content -LiteralPath $report -Encoding UTF8
 Remove-Item -LiteralPath $stdout,$stderr -Force -ErrorAction SilentlyContinue
 Write-Host ('Diagnostico salvo: '+$report)
 if($safe.Count -eq 0){Write-Host 'Nenhuma metrica nova. Confira se instalou esta revisao e abriu o catalogo durante a captura.'}
}
