package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.DeferredM3uEpisodes
import br.com.flaviotorres.iptvpremium.data.m3u.M3uCatalogWriter
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import java.io.*
import java.nio.file.Files
import kotlinx.coroutines.*
private class Http:PlaylistHttpClient {
 var native=0;var api=0
 override suspend fun get(url:String):String{api++;error("No artwork API in import")}
 override suspend fun <T> withReader(url:String,consume:suspend(Reader)->T):T{api++;error("No bulk covers lookup")}
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit){native++;listOf("#EXTM3U","""#EXTINF:-1 group-title="Séries" tvg-logo="https://image.tmdb.org/t/p/w1280/episode.jpg",O Conto da Aia S01E01""","http://example.invalid/series/1").forEach{onLine(it)}}
}
fun main()=runBlocking {
 val root=Files.createTempDirectory("no-bulk-covers").toFile()
 try{RealSqlDb(File(root,"db").toPath()).use{d->
  val h=Http();val episodes=DeferredM3uEpisodes(File(root,"episodes"));val bridge=NativeBridge(d.c)
  val g=M3uCacheImporter(h,d.dao,PlaylistCacheGenerationManager(d.dao),episodes,File(root,"work"),{_,_,_->}){spool,p,g,c,ensure->d.c.autoCommit=false;try{M3uCatalogWriter.write(bridge.database,spool,p,g,c,ensure);d.c.commit()}catch(e:Throwable){d.c.rollback();throw e}finally{d.c.autoCommit=true}}.import("p","http://example.invalid/get.php?username=u&password=p&type=m3u_plus&output=mpegts")
  check(h.api==0&&h.native==1&&d.count("cached_series",g)==1&&d.count("cached_episodes",g)==0&&episodes.sourceCounts("p",g)==(1 to 1L))
  println("PASS a compatible M3U import performs no covers API requests and keeps catalogue, native identity and deferred episode source")
 }}finally{root.deleteRecursively()}
 Unit
}
