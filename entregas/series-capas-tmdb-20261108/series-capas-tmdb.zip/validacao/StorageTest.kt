package br.com.flaviotorres.iptvpremium.data.sync
import br.com.flaviotorres.iptvpremium.data.storage.PlaylistStorage
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.emptyPreferences
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
private class MemoryStore:DataStore<Preferences>{
 private val values=MutableStateFlow(emptyPreferences());private val lock=Mutex()
 override val data:Flow<Preferences> = values
 override suspend fun updateData(transform:suspend(Preferences)->Preferences):Preferences=lock.withLock{transform(values.value).also{values.value=it}}
}
fun main()=runBlocking{
 val storage=PlaylistStorage(MemoryStore());val source=PlaylistSource.M3u("same-id","List",true,"https://provider.example/get.php?username=u&password=p")
 storage.applyPortalOperation(source.id,source);val first=storage.selection.first().loadRequest!!;storage.markPortalCatalogReady(first)
 storage.applyPortalOperation(source.id,source);check(storage.selection.first().loadRequest==first&&storage.isPortalCatalogReady(first))
 storage.applyPortalOperation(source.id,source,refreshCatalog=true);val edited=storage.selection.first();check(edited.loadRequest!=first&&!storage.isPortalCatalogReady(edited.loadRequest!!));check(edited.playlists==listOf(source)&&edited.activeId==source.id)
 val direct=source.copy(forceM3u=true);storage.applyPortalOperation(source.id,direct,refreshCatalog=true);val reloaded=storage.playlists.first().single() as PlaylistSource.M3u;check(reloaded.forceM3u&&reloaded.id==source.id);val portal=br.com.flaviotorres.iptvpremium.core.device.encodePortalLists(listOf(reloaded));check((br.com.flaviotorres.iptvpremium.core.device.decodePortalLists(portal).single() as PlaylistSource.M3u).forceM3u)
 println("PASS direct M3U survives real storage encode/decode and keeps the same list ID")
 println("PASS explicit portal edit refreshes the exact same list without duplicates; ordinary repeated storage operation preserves ready catalogue")
}
