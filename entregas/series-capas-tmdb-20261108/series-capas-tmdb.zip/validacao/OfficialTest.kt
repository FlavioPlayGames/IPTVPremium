package br.com.flaviotorres.iptvpremium.data.cache

import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.m3u.*
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.*
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import br.com.flaviotorres.iptvpremium.domain.model.*
import br.com.flaviotorres.iptvpremium.ui.kids.CatalogSections
import androidx.room.RoomOpenDelegate
import androidx.room.migration.Migration
import java.io.*
import java.nio.file.Files
import java.sql.DriverManager
import kotlinx.coroutines.*

private class Http:PlaylistHttpClient {
 var reads=0;var fail=false;var hold=false;var onRead:suspend()->Unit={}
 var lines=listOf("#EXTM3U url-tvg=\"https://example.invalid/epg.xml\"",
 """#EXTINF:-1 group-title="Z canais",Zeta""","http://example.invalid/live/1.ts",
 """#EXTINF:-1 group-title="A canais",Alfa""","http://example.invalid/live/2.ts",
 """#EXTINF:-1 group-title="Z filmes",Zulu (2025)""","http://example.invalid/movie/3.mp4",
 """#EXTINF:-1 group-title="A filmes",Alfa (2024)""","http://example.invalid/movie/4.mp4",
 """#EXTINF:-1 group-title="Z séries" tvg-logo="p",Zulu S01E1000""","http://example.invalid/series/5.mkv",
 """#EXTINF:-1 group-title="A séries",Alfa S01E01""","http://example.invalid/series/6.mkv",
 """#EXTINF:-1 group-title="Z séries",Zulu S01E1001""","http://example.invalid/series/7.mkv",
 """#EXTINF:-1 group-title="Z filmes",Zulu (2025)""","http://example.invalid/movie/3.mp4")
 override suspend fun get(url:String):String=error("API must not run")
 override suspend fun readLines(url:String,onLine:suspend(String)->Unit){reads++;for(line in lines){onRead();onLine(line)};if(fail)throw IOException("test");if(hold)awaitCancellation()}
}
private fun query(d:RealSqlDb,sql:String):List<List<Any?>> = d.c.createStatement().use{it.executeQuery(sql).use{r->buildList{while(r.next())add((1..r.metaData.columnCount).map{r.getObject(it)})}}}
fun main()=runBlocking {
 val root=Files.createTempDirectory("official-m3u").toFile()
 fun pass(s:String)=println("PASS $s")
 RealSqlDb(File(root,"main.db").toPath()).use{d->
  val http=Http();val store=DeferredM3uEpisodes(File(root,"sources"));val manager=PlaylistCacheGenerationManager(d.dao)
  var xmltv=emptyList<String>();var failWrite=false;var cancelWrite=false;var corruptWrite=false
  val bridge=NativeBridge(d.c)
  fun importer()=M3uCacheImporter(http,d.dao,manager,store,File(root,"work"),{_,_,v->xmltv=v}){spool,p,g,c,ensure->
   if(corruptWrite)RandomAccessFile(spool,"rw").use{it.setLength(spool.length()-1)}
   d.c.autoCommit=false
   try{
    var calls=0
    M3uCatalogWriter.write(bridge.database,spool,p,g,c){ensure();calls++;if(failWrite&&calls==4)throw IOException("disk");if(cancelWrite&&calls==4)throw CancellationException("cancel")}
    d.c.commit()
   }catch(e:Throwable){d.c.rollback();throw e}finally{d.c.autoCommit=true}
  }
  val g=importer().import("p","http://example.invalid/list")
  check(query(d,"SELECT status FROM playlist_cache_generations WHERE generationId='$g'").single().single()=="READY")
  check(d.count("cached_episodes",g)==0&&store.sourceCounts("p",g)==(2 to 3L));pass("official importer publishes READY metadata with all indexed sources and zero initial Room episodes")
  check(xmltv==listOf("https://example.invalid/epg.xml"));pass("official preparation preserves XMLTV discovery")
  check(File(root,"work").listFiles().orEmpty().isEmpty());pass("download/spool temporary files are removed after success")
  check(query(d,"SELECT name FROM cached_channels WHERE generationId='$g' ORDER BY channelNumber").map{it[0]}==listOf("Zeta","Alfa"));pass("channel DEFAULT order follows the source, not A-Z")
  check(query(d,"SELECT name FROM cached_series WHERE generationId='$g' ORDER BY providerOrder").map{it[0]}==listOf("Zulu","Alfa"));pass("series DEFAULT order follows first provider occurrence")
  check(query(d,"SELECT name FROM cached_movies WHERE generationId='$g' ORDER BY providerOrder").map{it[0]}==listOf("Alfa (2024)","Zulu (2025)"));pass("duplicate film keeps last occurrence and its source position")
  check(query(d,"SELECT name FROM cached_categories WHERE generationId='$g' AND type='SERIES' ORDER BY providerOrder").map{it[0]}==listOf("Z séries","A séries"));pass("explicit category positions preserve nonalphabetical source order")
  // Compare each official metadata record with the approved prototype's semantic output.
  val reference=File(root,"reference.bin");DataOutputStream(reference.outputStream()).use{ReferenceParser.prepare(http.lines.joinToString("\n").reader().buffered(),it,"p",g)}
  val expected=mutableMapOf<Int,MutableMap<Any?,List<Any?>>>()
  DataInputStream(reference.inputStream()).use{input->check(input.readInt()==0x4D335331);while(true){val (kind,row)=ReferenceParser.read(input)?:break;if(kind<4)expected.getOrPut(kind){linkedMapOf()}[row[2]]=row.toList()}}
  for((kind,table)in listOf("cached_categories","cached_channels","cached_movies","cached_series").withIndex()){
   val actual=query(d,"SELECT * FROM $table WHERE generationId='$g'").associate{it[2]to (if(kind==0)it.dropLast(1)else it).map{v->if(v is Number)v.toLong()else v}};check(actual==expected[kind]){"metadata $table"}
  };pass("all metadata fields, stable IDs, nullable posters and duplicates equal the approved prototype")
  d.c.createStatement().use{it.executeUpdate("UPDATE playlist_cache_generations SET status='ACTIVE',activatedAtEpochMillis=1 WHERE generationId='$g'")}
  val ids=query(d,"SELECT seriesId FROM cached_series WHERE generationId='$g' ORDER BY providerOrder").map{it[0]as String}
  check(store.ensure(d.dao,"p",g,ids[0]));check(d.count("cached_episodes",g)==2)
  check(query(d,"SELECT episodeNumber FROM cached_episodes WHERE generationId='$g' ORDER BY episodeNumber").map{(it[0]as Number).toInt()}==listOf(1000,1001));pass("opening one series hydrates only its episodes and preserves episode numbers above 999")
  val calls=d.episodeCalls;check(store.ensure(d.dao,"p",g,ids[0]));check(d.episodeCalls==calls&&http.reads==1);pass("reopening series reuses persistent cache with no HTTP call")
  val active=d.canonical(g)
  for(mode in listOf("transport","write","cancel-write","invalid","corrupt-spool")){
   http.fail=mode=="transport";failWrite=mode=="write";cancelWrite=mode=="cancel-write";corruptWrite=mode=="corrupt-spool";val old=http.lines;if(mode=="invalid")http.lines=listOf("<html>error</html>")
   check(runCatching{importer().import("p","http://example.invalid/list")}.isFailure);http.lines=old
   check(d.canonical(g)==active);check(query(d,"SELECT status FROM playlist_cache_generations").all{it[0]=="ACTIVE"});check(File(root,"work").listFiles().orEmpty().isEmpty())
   pass("$mode failure preserves ACTIVE catalogue, removes staging and never publishes partial metadata")
  };http.fail=false;failWrite=false;cancelWrite=false;corruptWrite=false
  val entered=CompletableDeferred<Unit>();http.onRead={entered.complete(Unit);awaitCancellation()}
  val loading=launch(Dispatchers.Default){importer().import("p","http://example.invalid/list")};entered.await();loading.cancelAndJoin();http.onRead={}
  check(d.canonical(g)==active&&File(root,"work").listFiles().orEmpty().isEmpty());pass("cancelling a live download preserves ACTIVE catalogue and cleans temporary files")
  // Malformed prepared records cannot target another playlist or generation.
  val wrong=File(root,"wrong.bin");wrong.writeBytes(reference.readBytes());d.c.autoCommit=false
  try{check(runCatching{M3uCatalogWriter.write(bridge.database,wrong,"other","other",M3uCatalogParser.Counts(2,3,3,2,6)) {}}.isFailure)}finally{d.c.rollback();d.c.autoCommit=true};check(d.canonical(g)==active);pass("bulk writer refuses a non-IMPORTING generation before inserting")
  val next=importer().import("p","http://example.invalid/list");check(next!=g&&d.count("cached_episodes",next)==0&&d.canonical(g)==active);pass("refresh builds a separate generation without touching the active one")
 }
 val categories=listOf(Category("z","Zeta",CategoryType.SERIES,CategorySource.PROVIDER,0),Category("a","Alfa",CategoryType.SERIES,CategorySource.PROVIDER,1))
 check(CatalogSections.orderedCategories(categories).map{it.id}==listOf("z","a"));check(CatalogSections.orderedCategories(categories.map{it.copy(providerOrder=null)}).map{it.id}==listOf("a","z"));pass("shared UI policy preserves explicit M3U order and existing unranked Xtream category sorting")
 // Apply the actual migration to the exact prior schema; validate against the generated Room-6 delegate.
 DriverManager.getConnection("jdbc:sqlite::memory:").use{c->
  val native=NativeBridge(c);ReferenceSchema.tables.forEach{native.database.execSQL(it)};ReferenceSchema.indexes.forEach{native.database.execSQL(it)}
  native.database.execSQL("INSERT INTO cached_categories VALUES('p','g','c','Old','SERIES','XTREAM')")
  val field=PlaylistCacheDatabase::class.java.getDeclaredField("MIGRATION_5_6");field.isAccessible=true;(field.get(null)as Migration).migrate(native.database)
  val db=PlaylistCacheDatabase_Impl();val f=db.javaClass.getDeclaredMethod("createOpenDelegate");f.isAccessible=true
  val result=(f.invoke(db)as RoomOpenDelegate).onValidateSchema(SqlConnection(c));check(result.isValid){result.expectedFoundMsg.orEmpty()}
  check(c.createStatement().executeQuery("SELECT name,providerOrder FROM cached_categories").use{it.next()&&it.getString(1)=="Old"&&it.getObject(2)==null});pass("actual 5-to-6 migration preserves existing categories and validates against generated Room schema")
 }
 root.deleteRecursively();Unit
}
