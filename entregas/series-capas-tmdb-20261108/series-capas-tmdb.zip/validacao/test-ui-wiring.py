from pathlib import Path
b=Path('/workspace/backup-reviewed-build/app/src/main/java/br/com/flaviotorres/iptvpremium')
f=(b/'ui/movies/CatalogPosterFallback.kt').read_text();assert 'if(kind!=PosterKind.SERIES)return MoviePosterLoader.loadWithRetry(context,url,kind)'in f
assert f.count('loadWithRetry(context,url')==1 and 'SeriesCatalogPosterResolver.resolve(name,year,tmdbId,imdbId' in f
for n in ['ui/components/UnifiedMediaCatalog.kt','ui/kids/KidsMediaCatalog.kt']:
 s=(b/n).read_text();assert 'peekCatalogPoster(entry.url,kind,entry.name,entry.year,entry.tmdbId,entry.imdbId)'in s and 'MoviePosterLoader.peekBitmap(entry.url)'not in s;assert 'loadWhilePosterVisible(snapshotFlow { visible })'in s
print('PASS normal and Kids series cards use verified identity for initial cache painting and visible-only requests; movies retain provider loading')
s=(b/'core/navigation/player/PlaybackCatalogBrowser.kt').read_text();assert 'artworkTmdbId=row.tmdbId' in s and 'artworkImdbId=row.imdbId' in s and 'peekCatalogPoster(url,kind,title,artworkYear,artworkTmdbId,artworkImdbId)'in s and 'loadEpisodeThumbnail(images' in s
print('PASS player series covers carry external IDs and verified initial cache; explicit season/episode artwork paths remain present')
s=(b/'ui/movies/CategoryPosterPrefetch.kt').read_text();assert 'viewport.busy || kind==PosterKind.SERIES'in s and 'if(kind==PosterKind.SERIES)emptyList()else viewport.urls'in s and 'recoverCatalogViewport'in s
print('PASS series no longer anticipate unverified provider URLs while viewport/paging recovery remains active')
s=(b/'data/cache/importer/M3uCacheImporter.kt').read_text();assert 'apiCovers'not in s and 'series_covers'not in s
assert not(b/'data/m3u/M3uProviderSeriesCovers.kt').exists()
print('PASS bulk provider cover lookup is absent from native import')
