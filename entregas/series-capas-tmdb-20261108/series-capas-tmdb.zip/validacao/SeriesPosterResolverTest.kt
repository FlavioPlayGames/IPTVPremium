package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.repository.*
import kotlinx.coroutines.*
import org.json.*
import java.util.concurrent.atomic.AtomicInteger
private fun root(id:Int,name:String,year:Int=2017,path:String="/poster-$id.jpg")=JSONObject().put("id",id).put("name",name).put("original_name",name).put("first_air_date","$year-01-01").put("poster_path",path).put("external_ids",JSONObject().put("imdb_id","tt$id"))
private fun search(vararg rows:JSONObject)=JSONObject().put("results",JSONArray().also{a->rows.forEach{a.put(it)}}).toString()
fun main()=runBlocking {
 fun pass(s:String)=println("PASS $s")
 val calls=AtomicInteger()
 val aia=root(69478,"O Conto da Aia")
 val get:suspend(String,Map<String,String>)->String={path,q->calls.incrementAndGet();when(path){"/search/tv"->{check(q["query"]=="o conto da aia"&&q["language"]=="pt-BR");search(aia)};"/tv/69478"->aia.toString();else->error(path)}}
 val result=SeriesCatalogPosterResolver.resolve("O Conto Da Aia 2017 (2017)",2017,null,null,get)
 check(result?.tmdbId==69478&&result.url=="https://image.tmdb.org/t/p/w500/poster-69478.jpg"&&calls.get()==2);pass("O Conto da Aia resolves to its verified official poster with pt-BR search and duplicated-year cleanup")
 check(SeriesCatalogPosterResolver.resolve("O Conto da Aia",2017,null,null,{_,_->error("Must reuse cache")})?.url==result.url)
 check(SeriesCatalogPosterResolver.peek("O Conto da Aia",2017,null,null)?.url==result.url);pass("compatible title variants reuse the verified work cache and expose its own URL to initial painting")
 val unknown=root(70001,"Unknown Year Work",2020);val count=AtomicInteger()
 val unknownGet:suspend(String,Map<String,String>)->String={p,_->count.incrementAndGet();if(p=="/search/tv")search(unknown)else unknown.toString()}
 check(SeriesCatalogPosterResolver.resolve("Unknown Year Work",null,null,null,unknownGet)?.tmdbId==70001)
 check(SeriesCatalogPosterResolver.resolve("Unknown Year Work",null,null,null,{_,_->error("No second search")})!=null&&count.get()==2);pass("a unique verified title without source year is cached instead of searched on every opening")
 val sameA=root(70101,"Ambiguous Work",2011);val sameB=root(70102,"Ambiguous Work",2021)
 val ambiguous=SeriesCatalogPosterResolver.resolve("Ambiguous Work",null,null,null,{p,_->check(p=="/search/tv");search(sameA,sameB)})
 check(ambiguous==null);pass("unknown-year homonyms are refused instead of choosing the first search result")
 check(SeriesCatalogPosterResolver.resolve("Ambiguous Work",2021,null,null,{p,_->if(p=="/search/tv")search(sameA,sameB)else sameB.toString()})?.tmdbId==70102);pass("the release year disambiguates matching official series")
 val conflict=root(70201,"Year Conflict Work",2020)
 check(SeriesCatalogPosterResolver.resolve("Year Conflict Work",2017,null,null,{p,_->if(p=="/search/tv")search(conflict)else conflict.toString()})==null);pass("a conflicting release year cannot substitute another work's cover")
 val wrongName=root(70301,"Other Work",2018)
 check(SeriesCatalogPosterResolver.resolve("Expected Name Work",2018,null,null,{p,_->if(p=="/search/tv")search(root(70301,"Expected Name Work",2018))else wrongName.toString()})==null);pass("details must confirm the official name; a misleading search label is insufficient")
 val legacyKey=catalogMetadataKey("tv","Legacy Poison Work",2019,null,null)
 CatalogMetadataCache.load(legacyKey){root(70401,"Wrong Cached Work",2019)}
 val correct=root(70402,"Legacy Poison Work",2019)
 check(SeriesCatalogPosterResolver.resolve("Legacy Poison Work",2019,null,null,{p,_->if(p=="/search/tv")search(correct)else correct.toString()})?.tmdbId==70402);pass("new catalogue identity namespace bypasses older provider-image-biased metadata cache")
 val numeric=root(70501,"1923",2022)
 check(SeriesCatalogPosterResolver.resolve("1923",1923,null,null,{p,_->if(p=="/search/tv")search(numeric)else numeric.toString()})?.tmdbId==70501);pass("a numeric title is not mistaken for its own release year")
 val noPoster=root(70601,"Official Poster Alternatives",2022).also{it.remove("poster_path");it.put("images",JSONObject().put("posters",JSONArray().put(JSONObject().put("file_path","/english.jpg").put("iso_639_1","en").put("aspect_ratio",0.66)).put(JSONObject().put("file_path","/portuguese.jpg").put("iso_639_1","pt").put("aspect_ratio",0.66)).put(JSONObject().put("file_path","/landscape.jpg").put("iso_639_1","pt").put("aspect_ratio",1.77))))}
 check(SeriesCatalogPosterResolver.resolve("Official Poster Alternatives",2022,null,null,{p,_->if(p=="/search/tv")search(noPoster)else noPoster.toString()})?.url=="https://image.tmdb.org/t/p/w500/portuguese.jpg");pass("missing primary poster can use a portrait belonging to the same verified work, preferring Portuguese")
 val external=root(70701,"External ID Work",2015)
 check(SeriesCatalogPosterResolver.resolve("External ID Work",null,"70701","tt999",{p,_->check(p=="/tv/70701");external.toString()})==null);pass("conflicting explicit external identifiers cannot seed a wrong cache entry")
 val unsafe=root(70801,"Unsafe Poster Work",2017,"https://example.invalid/wrong.jpg")
 check(SeriesCatalogPosterResolver.resolve("Unsafe Poster Work",2017,null,null,{p,_->if(p=="/search/tv")search(unsafe)else unsafe.toString()})==null);pass("poster paths are restricted to actual TMDB image assets, never arbitrary replacement URLs")
 val aliasRootA=root(70901,"Original Alias A",2017).put("alternative_titles",JSONObject().put("results",JSONArray().put(JSONObject().put("title","Verified Alternate Name"))))
 val aliasRootB=root(70902,"Original Alias B",2018)
 check(SeriesCatalogPosterResolver.resolve("Verified Alternate Name",null,null,null,{p,_->when(p){"/search/tv"->search(aliasRootA,aliasRootB);"/tv/70901"->aliasRootA.toString();else->aliasRootB.toString()}})?.tmdbId==70901);pass("an exact official alternate title can identify a work without a source year")
 val aliasAmbA=root(71001,"Different Original A").put("alternative_titles",JSONObject().put("results",JSONArray().put(JSONObject().put("title","Ambiguous Alternate"))))
 val aliasAmbB=root(71002,"Different Original B").put("alternative_titles",JSONObject().put("results",JSONArray().put(JSONObject().put("title","Ambiguous Alternate"))))
 check(SeriesCatalogPosterResolver.resolve("Ambiguous Alternate",null,null,null,{p,_->when(p){"/search/tv"->search(aliasAmbA,aliasAmbB);"/tv/71001"->aliasAmbA.toString();else->aliasAmbB.toString()}})==null);pass("multiple matching official aliases remain unresolved rather than guessed")
 val concurrent=root(71101,"Concurrent Poster Work");val concurrentCalls=AtomicInteger()
 val concurrentGet:suspend(String,Map<String,String>)->String={p,_->concurrentCalls.incrementAndGet();delay(30);if(p=="/search/tv")search(concurrent)else concurrent.toString()}
 coroutineScope{val a=async{SeriesCatalogPosterResolver.resolve("Concurrent Poster Work",2017,null,null,concurrentGet)};val b=async{SeriesCatalogPosterResolver.resolve("Concurrent Poster Work",2017,null,null,concurrentGet)};check(a.await()?.url==b.await()?.url)}
 check(concurrentCalls.get()==2);pass("concurrent cards share one metadata resolution for the same work")
 val entered=CompletableDeferred<Unit>()
 val job=launch{SeriesCatalogPosterResolver.resolve("Cancelled Poster Work",2017,null,null,{_,_->entered.complete(Unit);awaitCancellation()})};entered.await();job.cancelAndJoin()
 val retry=root(71201,"Cancelled Poster Work")
 check(SeriesCatalogPosterResolver.peek("Cancelled Poster Work",2017,null,null)==null)
 check(SeriesCatalogPosterResolver.resolve("Cancelled Poster Work",2017,null,null,{p,_->if(p=="/search/tv")search(retry)else retry.toString()})?.tmdbId==71201);pass("cancelling an off-screen request does not persist a failure or partial identity")
 check(catalogMetadataTtlMillis(SERIES_CATALOG_POSTER_PREFIX+"work")==30L*24*60*60*1000&&catalogMetadataTtlMillis("tv:details")==6L*60*60*1000);pass("verified cover mappings use a 30-day disk policy while existing detail metadata stays at six hours")
 Unit
}
