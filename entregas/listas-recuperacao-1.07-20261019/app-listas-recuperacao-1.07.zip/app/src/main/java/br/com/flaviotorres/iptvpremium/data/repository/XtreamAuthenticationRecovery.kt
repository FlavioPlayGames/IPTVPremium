package br.com.flaviotorres.iptvpremium.data.repository

import kotlinx.coroutines.delay

/** Distinguishes a malformed/empty auth response from a confirmed account denial. */
internal class XtreamAuthenticationResponseException(message: String) : IllegalStateException(message)

internal object XtreamAuthenticationRecovery {
    fun validateResponse(content: String) {
        val root =
            try {
                org.json.JSONObject(content.trimStart { it.isWhitespace() || it == '\uFEFF' })
            } catch (_: Exception) {
                throw XtreamAuthenticationResponseException(
                    "O servidor não retornou uma resposta Xtream Codes válida."
                )
            }

        val userInfo =
            root.optJSONObject("user_info")
                ?: throw XtreamAuthenticationResponseException(
                    "Não foi possível validar o usuário no servidor."
                )

        val authValue =
            userInfo.opt("auth")
                ?.takeUnless { it == org.json.JSONObject.NULL }
                ?.toString()
                ?.trim()

        val status =
            userInfo
                .optString("status")
                .trim()

        if (authValue.isNullOrBlank() && status.isBlank()) {
            throw XtreamAuthenticationResponseException("Autenticacao Xtream sem dados de conta.")
        }
        val active = status.equals("Active", ignoreCase = true)
        val authenticated = (authValue == "1" || authValue == null && active) &&
            (status.isBlank() || active)

        if (!authenticated) {
            throw br.com.flaviotorres.iptvpremium.data.remote.PlaylistAccessDeniedException(
                "Usuário ou senha inválidos, ou a conta não está ativa."
            )
        }
    }

    suspend fun confirm(load: suspend () -> String, validate: (String) -> Unit, onRetry: () -> Unit = {}) {
        try { validate(load()) }
        catch (error: XtreamAuthenticationResponseException) {
            onRetry()
            delay(300)
            validate(load())
        }
    }
}
