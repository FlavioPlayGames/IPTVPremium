# Aplicativo 1.03 / número interno 5

Aplica cinco arquivos de atualização opcional; não altera favoritos, histórico, listas, banco de catálogo, temas ou teclado.
Mantém a assinatura e configurações locais; o APK deve ser compilado no computador original.
O aviso oferece Mais tarde (também Voltar), preserva a navegação e adia novos avisos por 15 dias.
O prazo fica salvo no aparelho; após vencer, a próxima abertura/consulta bem-sucedida volta a avisar.
Uma nova publicação durante o adiamento também respeita o prazo. A busca manual permite antecipar a atualização.
Para retomar, Configurações > Atualização > Verificar atualização.
A autorização do Android mostra uma orientação curta e retoma a instalação ao voltar com a permissão concedida.
O instalador devolve o resultado ao aplicativo. Cancelamento permite tentar novamente com o APK já baixado ou adiar por 15 dias.
Falha de instalação recebe mensagem diferente de cancelamento. As verificações de integridade e assinatura continuam obrigatórias.
Os APKs continuam sendo selecionados pelas ABIs suportadas pelo Android.
O Android ainda exige autorização para instalar de fora da loja e confirmação da instalação.

O preparador cria backup, confere os hashes antes de alterar fontes e prepara exatamente 1.03/code5.
Se o projeto já estiver acima de code5, aborta para não rebaixar a versão.
Preserva os bytes de todas as demais propriedades locais. Detecta o Java do Android Studio para compilar.
Nenhum APK gerado na nuvem está incluído neste pacote.

TESTE PRIMEIRO: instalar por cima da 1.02, com adb install -r ou pelo Android Studio, sem desinstalar ou limpar dados.
Comparar favoritos e continuar assistindo de filmes e séries; fechar e reabrir e comparar novamente.
O usuário confirmou favoritos e progresso preservados ao atualizar o primeiro pacote para 1.03/code5.
Repetir a conferência nesta revisão e validar autorização/cancelamento no aparelho; esses retornos dependem do instalador Android.
O script não instala nem publica automaticamente.
Aceita as fontes da 1.02/code4 ou do primeiro pacote de teste da 1.03/code5.
Quem já aplicou o pacote anterior pode aplicar este; os arquivos já iguais são reconhecidos.
A versão continua 1.03/code5 porque esta é a revisão final antes da publicação.
Instalar por cima pelo computador também funciona sobre a primeira compilação de teste 1.03/code5.

O painel opcional é entregue separadamente. Aplicativos antigos recebem update:null do novo Worker
porque não conseguem exibir o botão Mais tarde; precisam instalar uma vez a nova versão manualmente.
Depois disso, publicações seguintes podem ser adiadas dentro do aplicativo.

Validação: compilação Android, políticas/ABI, ciclo do gerenciador com serviços Android simulados,
Worker, sincronização autenticada de comandos criptografados e navegador real.
Esses testes não substituem o teste de instalação e navegação por controle remoto.
