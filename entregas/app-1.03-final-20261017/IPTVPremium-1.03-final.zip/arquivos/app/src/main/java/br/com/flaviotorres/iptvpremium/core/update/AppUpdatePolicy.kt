package br.com.flaviotorres.iptvpremium.core.update

import android.os.Build
import org.json.JSONObject
import java.io.File
import java.net.URL
import java.util.zip.ZipFile

private val updateAbis = setOf("armeabi-v7a", "arm64-v8a", "x86", "x86_64")

/** Root artifact remains universal for old clients; the selected artifact is cached flat. */
internal data class AppUpdatePolicy(
    val versionCode: Long, val versionName: String, val url: String,
    val sha256: String, val sizeBytes: Long, val notes: String, val abi: String = "universal"
) {
    fun json(): JSONObject = JSONObject().put("versionCode", versionCode).put("versionName", versionName)
        .put("url", url).put("sha256", sha256).put("sizeBytes", sizeBytes).put("notes", notes)
        .put("mandatory", false).put("abi", abi)

    companion object {
        fun parse(data: JSONObject, supportedAbis: List<String> = Build.SUPPORTED_ABIS.toList()): AppUpdatePolicy {
            fun integer(obj: JSONObject, key: String, max: Long): Long {
                val raw = obj.get(key)
                require(raw is Number) { "Número inválido na atualização." }
                val value = raw.toLong()
                require(value in 1..max && raw.toDouble() == value.toDouble()) { "Número inválido na atualização." }
                return value
            }
            val code = integer(data, "versionCode", 2_100_000_000L)
            val name = data.getString("versionName")
            require(name.length in 1..40 && data.get("mandatory") is Boolean)
            val notes = data.optString("notes").take(500)
            fun artifact(obj: JSONObject, abi: String): AppUpdatePolicy {
                val size = integer(obj, "sizeBytes", 536_870_912L)
                val url = obj.getString("url")
                val parsed = URL(url)
                val digest = obj.getString("sha256")
                require(url.length in 1..4096 && parsed.protocol == "https" && parsed.host.isNotBlank() && parsed.userInfo == null && parsed.ref == null)
                require(digest.matches(Regex("[0-9a-f]{64}")))
                return AppUpdatePolicy(code, name, url, digest, size, notes, abi)
            }
            val cachedAbi = data.optString("abi", "universal")
            require(cachedAbi == "universal" || cachedAbi in updateAbis && cachedAbi in supportedAbis)
            val universal = artifact(data, cachedAbi)
            if (!data.has("variants")) return universal
            require(cachedAbi == "universal")
            val variants = data.getJSONObject("variants")
            val parsedVariants = mutableMapOf<String, AppUpdatePolicy>()
            for (key in variants.keys()) {
                require(key in updateAbis) { "Arquitetura inválida na atualização." }
                parsedVariants[key] = artifact(variants.getJSONObject(key), key)
            }
            return supportedAbis.firstNotNullOfOrNull { parsedVariants[it] } ?: universal
        }
    }
}

/** Inspect ZIP names only; do not extract native libraries or decompress the APK. */
internal fun verifyUpdateApkAbi(file: File, selectedAbi: String, supportedAbis: List<String>) {
    require(selectedAbi == "universal" || selectedAbi in supportedAbis)
    val nativeAbis = mutableSetOf<String>()
    ZipFile(file).use { apk ->
        val entries = apk.entries()
        while (entries.hasMoreElements()) {
            val entry = entries.nextElement()
            val parts = entry.name.split('/')
            if (!entry.isDirectory && parts.size == 3 && parts[0] == "lib" && parts[2].endsWith(".so")) nativeAbis += parts[1]
        }
    }
    require(if (selectedAbi == "universal") nativeAbis.isEmpty() || supportedAbis.any { it in nativeAbis } else selectedAbi in nativeAbis) {
        "O APK publicado não é compatível com este aparelho. Peça ao administrador para conferir a arquitetura do arquivo."
    }
}
