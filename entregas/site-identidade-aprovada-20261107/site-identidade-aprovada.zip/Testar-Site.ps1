[CmdletBinding()]
param()
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) { throw 'Instale o Node.js 22 ou mais recente antes de continuar.' }
$nodeVersion = & node --version
if ([int]($nodeVersion.TrimStart('v').Split('.')[0]) -lt 22) { throw 'Use Node.js 22 ou mais recente.' }
if (-not (Test-Path -LiteralPath (Join-Path $PSScriptRoot 'node_modules\wrangler\bin\wrangler.js'))) {
    & npm.cmd install --no-audit --no-fund
    if ($LASTEXITCODE -ne 0) { throw 'Falha ao instalar as dependencias do site.' }
}
& npm.cmd run check
if ($LASTEXITCODE -ne 0) { throw 'A verificacao do site falhou. Envie a mensagem exibida.' }
Write-Host 'Verificacao concluida. O teste nao publicou o site nem modificou o banco.' -ForegroundColor Green
