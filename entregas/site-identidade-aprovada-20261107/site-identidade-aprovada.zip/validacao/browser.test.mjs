import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);
const {chromium}=require('playwright');
import {fileURLToPath} from 'node:url';
import http from 'node:http';import {readFile, mkdir} from 'node:fs/promises';import path from 'node:path';import assert from 'node:assert/strict';
const root=fileURLToPath(new URL('../public/',import.meta.url)),out=fileURLToPath(new URL('../previas-teste/',import.meta.url));await mkdir(out,{recursive:true});
const server=http.createServer(async(req,res)=>{try{let name=new URL(req.url,'http://localhost').pathname;if(name==='/')name='/index.html';if(name==='/admin/')name='/admin/index.html';const file=path.join(root,name);const b=await readFile(file);res.setHeader('Content-Type',file.endsWith('.js')?'application/javascript':file.endsWith('.css')?'text/css':file.endsWith('.html')?'text/html':file.endsWith('.png')?'image/png':file.endsWith('.ttf')?'font/ttf':'application/octet-stream');res.end(b)}catch{res.statusCode=404;res.end('not found')}});
await new Promise(r=>server.listen(0,'127.0.0.1',r));const origin='http://127.0.0.1:'+server.address().port;let checks=0,browser;
const ok=(v,msg)=>{assert(v,msg);checks++;};
async function fits(page,label){ok(await page.evaluate(()=>document.documentElement.scrollWidth<=innerWidth+1),label+' horizontal overflow');}
async function setup(page,role){
 const errors=[];page.on('pageerror',e=>errors.push(e.message));const calls=[];
 const now=Date.now(),subtitles={textColor:'FFFFFF',background:'TRANSLUCENT',sizeSp:22,typeface:'DEFAULT',edge:'OUTLINE'};
 const accounts={};for(const [id,label,mac]of [['tv-a','TV da sala','02:11:22:33:44:10'],['tv-b','TV do quarto','02:11:22:33:44:20']])accounts[id]={id,mac,label,code:'123456',model:'TV teste',license:{state:'licensed',licenseUntil:now+86400000*90},renewal:{acquiredAt:now-86400000*30,expiresAt:now+86400000*90,daysRemaining:90},commands:[],snapshot:{receivedAt:now-60000,lists:[{id:id+'-list',name:id==='tv-a'?'Minha lista':'Lista do quarto',type:'xtream',serverUrl:'https://provider.example',username:'fake-user',password:'fake-password',isEnabled:true},{id:id+'-m3u',name:'Lista da família',type:'m3u',playlistUrl:'https://provider.example/list.m3u',isEnabled:true}],subtitles,providers:{subdl:false,opensubtitles:false},subtitleProtocol:2,openSubtitlesFingerprint:'a'.repeat(64)},openSubtitlesAvailable:true};
 let acceptOpen=false,offline=false;
 await page.route('**/api/**',async route=>{const req=route.request(),u=new URL(req.url()),body=req.postData()?JSON.parse(req.postData()):null;calls.push({path:u.pathname,device:u.searchParams.get('device'),body});let status=200,data={ok:true};const a=accounts[u.searchParams.get('device')||'tv-a'];
 if(['/api/session','/api/qr-login','/api/login','/api/admin/login'].includes(u.pathname))data={role,csrf:'test-csrf'};
 else if(u.pathname==='/api/account')data=a;
 else if(u.pathname==='/api/admin/devices')data={items:Object.values(accounts).map(a=>({...a,status:'active',lastSeen:now})),total:2,counts:{total:2,active:2,blocked:0}};
 else if(u.pathname==='/api/commands'){
  if(offline){status=503;data={error:'TV indisponível para consulta.'}}else{if(!a.commands.some(c=>c.id===body.requestId))a.commands.push({id:body.requestId,kind:body.kind,provider:body.data?.provider,state:'pending',created_at:now});data={id:body.requestId,state:'pending'};}
 }else if(u.pathname==='/api/lists/validate'){data={message:'Lista verificada. Confira antes de enviar.',playlist:body.format==='xtream'?{type:'xtream',name:body.name,serverUrl:body.serverUrl,username:body.username,password:body.password,isEnabled:true}:{type:'m3u',name:body.name,playlistUrl:body.link,isEnabled:true}};}
 else if(u.pathname==='/api/opensubtitles/connect'){
  if(!acceptOpen){status=422;data={error:'Confira seu usuário e senha do OpenSubtitles.com.'}}else{a.commands.push({id:body.requestId,kind:'subtitle_session',provider:'opensubtitles',state:'pending',created_at:now});data={id:body.requestId,state:'pending'};}
 }else if(u.pathname==='/api/rename'){a.label=body.label;}
 else if(u.pathname==='/api/admin/pix')data={key:'fake-pix',name:'Recebedor teste',city:'São Paulo',amountCents:3000};
 else if(u.pathname==='/api/admin/update')data={update:null,supportsVariants:true};
 else if(u.pathname==='/api/admin/payments')data={items:[]};
 else if(u.pathname==='/api/payment')data={amountCents:3000,mac:a.mac,txid:'TESTE',recipient:'Recebedor teste',payload:'000201TESTEPIX'};
 else if(u.pathname==='/api/logout')data={ok:true};
 await route.fulfill({status,contentType:'application/json',body:JSON.stringify(data)});
 });return {calls,errors,accounts,setOpen(v){acceptOpen=v},setOffline(v){offline=v}};
}
try{
 for(const [label,width,height]of [['mobile',390,844],['narrow',360,800],['tablet',768,1024],['desktop',1440,1000]]){
  browser=await chromium.launch({headless:true});
  const page=await browser.newPage({viewport:{width,height},deviceScaleFactor:1});const f=await setup(page,'user');
  await page.goto(origin);await page.locator('#list-rows .list').first().waitFor();
  await page.waitForFunction(()=>document.querySelector('#context-sync').textContent.includes('Consultando'));
  ok(f.calls.filter(c=>c.path==='/api/commands'&&c.body.kind==='snapshot').length===1,'one automatic snapshot even with cached lists');
  ok(!await page.locator('#fetch-device-lists').count(),'no manual list fetch button');
  ok(await page.locator('#license-title').isHidden(),'license stays in device section');await fits(page,label+' lists');
  if(['mobile','desktop'].includes(label))await page.screenshot({path:out+'/'+label+'-listas.png',fullPage:true});
  await page.locator('#nav-style').click();await page.locator('#subdl-connect').waitFor({state:'visible'});
  ok(await page.locator('#subdl-form').isHidden(),'provider overview separate from editor');
  ok(await page.locator('#lists-view').isHidden(),'lists hidden inside subtitles');await fits(page,label+' subtitles');
  if(['mobile','desktop'].includes(label))await page.screenshot({path:out+'/'+label+'-legendas.png',fullPage:true});
  await page.locator('#open-connect').click();if(['mobile','desktop'].includes(label))await page.screenshot({path:out+'/'+label+'-opensubtitles.png',fullPage:true});await page.locator('#open-user').fill('viewer');await page.locator('#open-password').fill('bad-password');await page.locator('#open-send').click();
  await page.waitForFunction(()=>document.querySelector('#toast').textContent.includes('Confira'));
  ok(await page.locator('#app-view').isVisible(),'bad provider password keeps portal session');ok(await page.locator('#open-password').inputValue()==='','provider password cleared');
  f.setOpen(true);await page.locator('#open-password').fill(' fake password ');await page.locator('#open-send').click();await page.locator('#subdl-connect').waitFor({state:'visible'});
  ok(f.calls.some(c=>c.path==='/api/opensubtitles/connect'&&c.body.password===' fake password '),'provider password sent only on click preserving spaces');
  ok(!await page.locator('#pending-commands').innerText().then(t=>t.includes('OpenSubtitles')),'subtitle delivery absent from lists');
  ok(await page.locator('#subtitle-commands').innerText().then(t=>t.includes('OpenSubtitles')),'subtitle delivery visible in subtitles');
  await page.locator('#subdl-connect').click();if(['mobile','desktop'].includes(label))await page.screenshot({path:out+'/'+label+'-subdl.png',fullPage:true});await page.locator('#subdl-key').fill('fake-personal-subdl-key');await page.locator('#subdl-send').click();await page.locator('#subdl-connect').waitFor({state:'visible'});
  ok(f.calls.some(c=>c.path==='/api/commands'&&c.body.kind==='subtitle_key'),'SubDL command sent');
  await page.locator('#show-appearance').click();await page.locator('#style-form').waitFor({state:'visible'});await fits(page,label+' appearance');if(['mobile','desktop'].includes(label))await page.screenshot({path:out+'/'+label+'-aparencia.png',fullPage:true});
  await page.locator('#size').selectOption('26');await page.locator('#style-form button.primary').click();
  await page.waitForTimeout(120);ok(f.calls.some(c=>c.body?.kind==='subtitle_style'&&c.body.data.sizeSp===26),'subtitle appearance sent');
  await page.locator('#nav-lists').click();await page.locator('#new-list').click();if(['mobile','desktop'].includes(label))await page.screenshot({path:out+'/'+label+'-adicionar-m3u.png',fullPage:true});await page.locator('#list-name').fill('Nova lista');await page.locator('#list-url').fill('https://provider.example/new.m3u');
  await page.locator('#validate-list').click();await page.locator('#send-list').waitFor({state:'visible'});
  ok(await page.locator('#list-input-step').isHidden(),'validation goes to confirmation');ok(!f.calls.some(c=>c.body?.kind==='list_upsert'),'no list sent before confirmation');await fits(page,label+' confirmation');if(['mobile','desktop'].includes(label))await page.screenshot({path:out+'/'+label+'-confirmar-lista.png',fullPage:true});
  await page.locator('#list-back-input').click();ok(await page.locator('#list-name').inputValue()==='Nova lista','back preserves inputs');
  await page.locator('#list-input-format').selectOption('xtream');await page.locator('#list-xtream-server').fill('https://provider.example');await page.locator('#list-xtream-user').fill('test-user');await page.locator('#list-xtream-pass').fill('fake-pass');
  if(['mobile','desktop'].includes(label))await page.screenshot({path:out+'/'+label+'-adicionar-xtream.png',fullPage:true});
  await page.locator('#validate-list').click();await page.locator('#send-list').waitFor({state:'visible'});await page.locator('#send-list').click();await page.locator('#list-modal').waitFor({state:'hidden'});
  ok(f.calls.some(c=>c.body?.kind==='list_upsert'&&c.body.data.type==='xtream'),'confirmed Xtream send works');ok(await page.locator('#pending-commands').innerText().then(t=>t.includes('lista')),'list receipt shown in lists');
  await page.locator('#nav-device').click();await page.locator('#license-title').waitFor({state:'visible'});ok(await page.locator('#lists-view').isHidden(),'device isolated from lists');await fits(page,label+' device');
  if(['mobile','desktop'].includes(label))await page.screenshot({path:out+'/'+label+'-aparelho.png',fullPage:true});
  await page.locator('#pay-license').click();await page.locator('#payment-modal').waitFor({state:'visible'});await fits(page,label+' Pix');if(['mobile','desktop'].includes(label))await page.screenshot({path:out+'/'+label+'-pix.png',fullPage:true});await page.locator('#close-payment').click();
  const storage=await page.evaluate(()=>JSON.stringify({local:{...localStorage},session:{...sessionStorage}}));ok(!storage.includes('fake password')&&!storage.includes('fake-pass'),'credentials not stored in browser');ok(!f.errors.length,'no user JS errors: '+f.errors.join(','));
  if(label==='mobile'){
   const before=f.accounts['tv-a'].snapshot.lists.length;
   f.accounts['tv-a'].snapshot.lists.push({id:'received-new',name:'Nova lista recebida',type:'m3u',playlistUrl:'https://provider.example/received.m3u'});
   for(const command of f.accounts['tv-a'].commands)command.state='received';f.accounts['tv-a'].snapshot.receivedAt=Date.now();
   await page.locator('#nav-lists').click();await page.waitForFunction(()=>document.querySelector('#list-rows').textContent.includes('Nova lista recebida'),{},{timeout:12000});
   ok(await page.locator('#list-rows .list').count()===before+1,'automatic poll receives fresh TV snapshot');ok(await page.locator('#context-sync').innerText()==='Últimos dados recebidos','received state replaces waiting only after snapshot');
  }
  // Admin opens the selected TV and automatically requests data for that TV.
  const admin=await browser.newPage({viewport:{width,height}});const a=await setup(admin,'admin');await admin.goto(origin+'/admin/');await admin.locator('#device-rows tr').first().waitFor();await fits(admin,label+' admin overview');
  if(['mobile','desktop'].includes(label))await admin.screenshot({path:out+'/'+label+'-admin.png',fullPage:true});
  const ids=await admin.locator('[id]').evaluateAll(nodes=>nodes.map(n=>n.id));ok(new Set(ids).size===ids.length,'unique HTML IDs');
  await admin.locator('#device-rows tr').nth(1).getByRole('button',{name:'Abrir'}).click();await admin.waitForFunction(()=>document.querySelector('#context-name').textContent==='TV do quarto');
  await admin.waitForTimeout(150);ok(a.calls.some(c=>c.path==='/api/commands'&&c.device==='tv-b'&&c.body.kind==='snapshot'),'admin auto snapshot bound to selected TV');
  ok(await admin.locator('#list-rows').innerText().then(t=>t.includes('Lista do quarto')&&!t.includes('Minha lista')),'admin sees selected TV only');await fits(admin,label+' admin device');if(['mobile','desktop'].includes(label))await admin.screenshot({path:out+'/'+label+'-admin-tv.png',fullPage:true});
  await admin.locator('#nav-device').click();await admin.locator('#repair-action').click();await admin.locator('#access-modal').waitFor({state:'visible'});await fits(admin,label+' admin access');if(['mobile','desktop'].includes(label))await admin.screenshot({path:out+'/'+label+'-admin-acesso.png',fullPage:true});await admin.locator('#close-access').click();
  await admin.locator('#nav-devices').click();await admin.locator('#admin-view').waitFor({state:'visible'});
  await admin.locator('#nav-pix').click();await admin.locator('#pix-modal').waitFor({state:'visible'});await fits(admin,label+' Pix configuration');if(['mobile','desktop'].includes(label))await admin.screenshot({path:out+'/'+label+'-admin-pix.png',fullPage:true});await admin.locator('#cancel-pix').click();
  await admin.locator('#nav-update').click();await admin.locator('#update-modal').waitFor({state:'visible'});await fits(admin,label+' updates');if(['mobile','desktop'].includes(label))await admin.screenshot({path:out+'/'+label+'-admin-atualizacao.png',fullPage:true});await admin.locator('#cancel-update').click();
  ok(!a.errors.length,'no admin JS errors: '+a.errors.join(','));
  if(label==='desktop'){
   // Offline consultation must keep cached content and never announce the TV online.
   const off=await browser.newPage({viewport:{width:390,height:844}});const o=await setup(off,'user');o.setOffline(true);await off.goto(origin);await off.waitForFunction(()=>document.querySelector('#context-sync').textContent==='Consulta indisponível');
   ok(await off.locator('#list-rows').innerText().then(t=>t.includes('Minha lista')),'offline TV keeps cached lists');ok(await off.locator('#snapshot-status').innerText().then(t=>t.includes('Não foi possível')),'failed auto query explained');
   // Unsupported Open registration shows an explanation without requesting credentials.
   o.accounts['tv-a'].openSubtitlesAvailable=false;await off.reload();await off.locator('#nav-style').click();await off.locator('#open-availability').waitFor({state:'visible'});ok(await off.locator('#open-connect').isDisabled(),'unavailable Open registration disabled');ok(await off.locator('#open-form').isHidden(),'no password asked when Open unavailable');
   // Fresh app without a snapshot still consults automatically, with no user action.
   const fresh=await browser.newPage({viewport:{width:390,height:844}});const n=await setup(fresh,'user');n.accounts['tv-a'].snapshot=null;await fresh.goto(origin);await fresh.waitForFunction(()=>document.querySelector('#context-sync').textContent.includes('Consultando'));
   ok(n.calls.some(c=>c.body?.kind==='snapshot'),'no cached snapshot auto query');ok(await fresh.locator('#list-rows .list').count()===0,'no fabricated lists without snapshot');
   // Login and log out, with no credentials retained in the form.
   const login=await browser.newPage({viewport:{width:390,height:844}});const l=await setup(login,'user');await login.route('**/api/session',r=>r.fulfill({status:401,contentType:'application/json',body:JSON.stringify({error:'Entre na sua conta.'})}));await login.goto(origin);await login.locator('#login-view').waitFor({state:'visible'});await login.screenshot({path:out+'/mobile-login.png',fullPage:true});
   await login.locator('#login-mac').fill('02:11:22:33:44:10');await login.locator('#login-code').fill('123456');await login.locator('#login-form button').click();await login.locator('#list-rows .list').first().waitFor();ok(l.calls.some(c=>c.path==='/api/login'),'manual portal login works');await login.locator('#nav-device').click();await login.locator('#device-logout').click();await login.locator('#login-view').waitFor({state:'visible'});ok(await login.locator('#login-code').inputValue()==='','logout clears login code');
   // A delayed query for TV B must not replace TV A after the admin switches.
   let release;const gate=new Promise(r=>release=r);const rapid=await browser.newPage({viewport:{width:1440,height:1000}});const q=await setup(rapid,'admin');await rapid.route('**/api/commands?device=tv-b',async route=>{await gate;await route.fulfill({status:200,contentType:'application/json',body:JSON.stringify({id:'slow-query',state:'pending'})});});
   await rapid.goto(origin+'/admin/');await rapid.locator('#device-rows tr').nth(1).getByRole('button',{name:'Abrir'}).click();await rapid.waitForFunction(()=>document.querySelector('#context-name').textContent==='TV do quarto');await rapid.locator('#nav-devices').click();await rapid.locator('#admin-view').waitFor({state:'visible'});await rapid.locator('#device-rows tr').first().getByRole('button',{name:'Abrir'}).click();await rapid.waitForFunction(()=>document.querySelector('#context-name').textContent==='TV da sala');release();await rapid.waitForTimeout(200);
   ok(await rapid.locator('#context-name').innerText()==='TV da sala','late old query cannot replace selected TV');ok(q.calls.some(c=>c.path==='/api/commands'&&c.device==='tv-a'&&c.body.kind==='snapshot'),'latest TV still automatically queried');
  }

  await browser.close();browser=null;console.log('PASS '+label+': auto TV data, cached list, navigation, provider login, separate commands, list confirmation, device access, Pix, admin TV binding and forms, no overflow.');
 }
 console.log(checks+' browser checks passed (mock API; no production changes).');
}finally{if(browser)await browser.close();await new Promise(r=>server.close(r));}
