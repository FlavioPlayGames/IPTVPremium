# Verificação da entrega

- 152 verificações em navegador Chromium: 360, 390, 768 e 1440 px. Navegação, listas M3U/Xtream, verificação/confirmação, retorno preservando dados, envio/recebimento, provedores, aparência, Pix, áreas administrativas, dados automáticos com/sem cache, erro de consulta e troca rápida de TV.
- 24 verificações de servidor: SQLite em memória, criptografia, isolamento entre TVs, sessões, autenticação/CSRF, respostas limitadas e senha fora de banco/fila.
- Worker empacotado em dry-run; configuração DB e ASSETS reconhecida, sem deploy.
- Sintaxe do script PowerShell verificada.
- Base do Worker comparada ao código recuperado; configuração enviada preservada.

Serviços externos e TV simulados nos testes. Sem publicação, operação no D1 remoto, login real OpenSubtitles ou teste na TV real. O serviço OpenSubtitles ainda depende da chave técnica do app no APK e no servidor.
