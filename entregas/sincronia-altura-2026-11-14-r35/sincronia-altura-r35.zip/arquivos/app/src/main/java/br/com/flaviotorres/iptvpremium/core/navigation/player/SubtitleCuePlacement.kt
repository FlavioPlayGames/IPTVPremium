package br.com.flaviotorres.iptvpremium.core.player

import androidx.media3.common.text.Cue

/** Authored placement is preserved at the default. A custom height moves text, never image cues. */
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
internal fun positionedSubtitleCues(cues:List<Cue>,appearance:SubtitleAppearance):List<Cue> {
    if(appearance.bottomPercent==DEFAULT_SUBTITLE_BOTTOM_PERCENT)return cues
    return cues.map { cue ->
        if(cue.text==null || cue.bitmap!=null)cue
        else cue.buildUpon().setLine(1f-subtitleBottomFraction(appearance.bottomPercent),Cue.LINE_TYPE_FRACTION)
            .setLineAnchor(Cue.ANCHOR_TYPE_END).build()
    }
}
