package br.com.flaviotorres.iptvpremium.core.player

internal const val DEFAULT_SUBTITLE_BOTTOM_PERCENT=8
internal const val MAX_SUBTITLE_BOTTOM_PERCENT=80
internal fun normalizedSubtitleBottomPercent(value:Int)=value.coerceIn(0,MAX_SUBTITLE_BOTTOM_PERCENT)
internal fun adjustedSubtitleBottomPercent(value:Int,delta:Int)=
    (value.toLong()+delta.toLong()).coerceIn(0L,MAX_SUBTITLE_BOTTOM_PERCENT.toLong()).toInt()
internal fun subtitleBottomFraction(value:Int)=normalizedSubtitleBottomPercent(value)/100f

/** External cues keep their previous baseline at the default; only the requested shift is added. */
internal fun externalSubtitleBottomDp(viewportHeightDp:Float,baseBottomDp:Float,bottomPercent:Int):Float =
    (baseBottomDp+viewportHeightDp*(normalizedSubtitleBottomPercent(bottomPercent)-DEFAULT_SUBTITLE_BOTTOM_PERCENT)/100f).coerceAtLeast(0f)
