package br.com.flaviotorres.iptvpremium.core.player

import android.view.KeyEvent as AndroidKeyEvent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text

@Composable
internal fun SubtitleHeightBar(bottomPercent:Int,onHeight:(Int)->Unit,focus:FocusRequester,
    modifier:Modifier=Modifier,onClose:()->Unit) {
    Row(modifier.widthIn(max=720.dp).fillMaxWidth(.80f).heightIn(min=48.dp)
        .background(NeutralPlayerPalette.panel,RoundedCornerShape(4.dp))
        .onPreviewKeyEvent { event ->
            val delta=when(event.nativeKeyEvent.keyCode){AndroidKeyEvent.KEYCODE_DPAD_UP->1;AndroidKeyEvent.KEYCODE_DPAD_DOWN->-1;else->0}
            if(delta==0)false else {if(event.type==KeyEventType.KeyDown)onHeight(adjustedSubtitleBottomPercent(bottomPercent,delta));true}
        }.semantics {stateDescription="Altura da legenda: $bottomPercent por cento"}
        .padding(horizontal=12.dp,vertical=6.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
        Column(Modifier.weight(1.1f)) {
            Text("Altura da legenda",color=NeutralPlayerPalette.text,fontSize=13.sp)
            Text("$bottomPercent% · use ↑ ou ↓",color=NeutralPlayerPalette.secondary,fontSize=10.sp)
        }
        SubtitleControlAction("Descer",SubtitleControlGlyph.DOWN,Modifier.weight(.85f)){onHeight(adjustedSubtitleBottomPercent(bottomPercent,-1))}
        SubtitleControlAction("Subir",SubtitleControlGlyph.UP,Modifier.weight(.85f),focus=focus){onHeight(adjustedSubtitleBottomPercent(bottomPercent,1))}
        SubtitleControlAction("Padrão",SubtitleControlGlyph.RESET,Modifier.weight(.85f)){onHeight(DEFAULT_SUBTITLE_BOTTOM_PERCENT)}
        SubtitleControlAction("Fechar",SubtitleControlGlyph.CLOSE,Modifier.weight(.85f),onClick=onClose)
    }
}
