package br.com.flaviotorres.iptvpremium.core.player

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text

internal val subtitleSyncBarHeight=48.dp
internal val subtitleSyncBarBottom=12.dp
internal val subtitleSyncCaptionGap=12.dp
internal val subtitleAssistantExplainHeight=148.dp

internal enum class SubtitleControlGlyph(val path:String) {
    ADJUST("M2 5H22 M2 12H22 M2 19H22 M7 2V8 M16 9V15 M10 16V22"),
    MINUS("M4 12H20"), PLUS("M4 12H20 M12 4V20"),
    RESET("M5 5A9 9 0 1 1 3 14 M5 1V6H10"),
    HELP("M21 12A9 9 0 1 1 3 12A9 9 0 1 1 21 12 M9 9A3 3 0 0 1 15 9C15 11 12 11 12 14 M12 18H12.1"),
    CLOSE("M5 5L19 19 M19 5L5 19"),
    UP("M5 12L12 5L19 12 M12 5V21"), DOWN("M5 12L12 19L19 12 M12 19V3")
}

@Composable
internal fun SubtitleControlIcon(icon:SubtitleControlGlyph,color:Color,modifier:Modifier=Modifier.size(19.dp)) {
    val path=remember(icon){PathParser().parsePathString(icon.path).toPath()}
    Canvas(modifier) {scale(size.width/24f,size.height/24f,pivot=Offset.Zero){
        drawPath(path,color,style=Stroke(1.6f,cap=StrokeCap.Round,join=androidx.compose.ui.graphics.StrokeJoin.Round))
    }}
}

/** Same unboxed icon/text vocabulary and focus accent as the transport controls. */
@Composable
internal fun SubtitleControlAction(label:String,icon:SubtitleControlGlyph?,modifier:Modifier=Modifier,
    focus:FocusRequester?=null,detail:String?=null,description:String=label,onClick:()->Unit) {
    var focused by remember{mutableStateOf(false)}
    val accent=playerThemeAccent()
    val color=if(focused)accent else NeutralPlayerPalette.text
    Row(modifier.heightIn(min=36.dp).then(if(focus!=null)Modifier.focusRequester(focus)else Modifier)
        .onFocusChanged{focused=it.isFocused}.semantics{contentDescription=description}
        .clickable(role=Role.Button,interactionSource=remember{MutableInteractionSource()},indication=null,onClick=onClick)
        .padding(horizontal=5.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp,Alignment.CenterHorizontally)) {
        if(icon!=null)SubtitleControlIcon(icon,color)
        Column(verticalArrangement=Arrangement.spacedBy(1.dp)) {
            Text(label,color=color,fontSize=12.sp,fontWeight=FontWeight.Medium,maxLines=1,overflow=TextOverflow.Ellipsis)
            if(detail!=null)Text(detail,color=NeutralPlayerPalette.secondary,fontSize=10.sp,maxLines=1)
        }
    }
}

@Composable
internal fun SubtitleSyncBar(offsetMs:Long,stepMs:Long,onOffset:(Long,String)->Unit,onStep:()->Unit,onAssistant:()->Unit,
    focus:FocusRequester,modifier:Modifier=Modifier,onClose:()->Unit={}) {
    val step=java.lang.String.format(java.util.Locale.forLanguageTag("pt-BR"),"%.1f s",stepMs/1000.0)
    Row(modifier.widthIn(max=920.dp).fillMaxWidth(.86f).height(subtitleSyncBarHeight)
        .background(NeutralPlayerPalette.panel,RoundedCornerShape(4.dp)).padding(horizontal=10.dp,vertical=4.dp),
        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(5.dp)) {
        SubtitleControlAction("Ajuste",SubtitleControlGlyph.ADJUST,Modifier.weight(1f),detail=step,
            description="Intervalo por clique: $step. Pressione para alterar.",onClick=onStep)
        Text(externalSubtitleOffsetLabel(offsetMs),color=NeutralPlayerPalette.text,fontSize=12.sp,fontWeight=FontWeight.Medium,
            modifier=Modifier.widthIn(min=44.dp).semantics{contentDescription="Ajuste atual: ${externalSubtitleOffsetLabel(offsetMs)}"})
        SubtitleControlAction("Adiantar",SubtitleControlGlyph.MINUS,Modifier.weight(1.05f),description="Menos: adiantar legenda em $step"){onOffset(offsetMs-stepMs,"CHANGE")}
        SubtitleControlAction("Atrasar",SubtitleControlGlyph.PLUS,Modifier.weight(1.05f),focus=focus,description="Mais: atrasar legenda em $step"){onOffset(offsetMs+stepMs,"CHANGE")}
        SubtitleControlAction("Zerar",SubtitleControlGlyph.RESET,Modifier.weight(.8f)){onOffset(0L,"RESET")}
        SubtitleControlAction("Auxílio",SubtitleControlGlyph.HELP,Modifier.weight(.9f),onClick=onAssistant)
        SubtitleControlAction("Fechar",SubtitleControlGlyph.CLOSE,Modifier.weight(.9f),onClick=onClose)
    }
}

/** Always present, with the same visual row as the rest of the subtitle menu. */
@Composable
internal fun SubtitleTimingMenuButton(enabled:Boolean,offsetMs:Long,onClick:()->Unit) {
    var focused by remember{mutableStateOf(false)}
    val accent=playerThemeAccent()
    val color=if(!enabled)NeutralPlayerPalette.secondary.copy(alpha=.45f)else if(focused)accent else NeutralPlayerPalette.text
    Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(5.dp)) {
        Box(Modifier.fillMaxWidth().height(1.dp).background(NeutralPlayerPalette.secondary.copy(alpha=.22f)))
        Row(Modifier.fillMaxWidth().heightIn(min=42.dp).onFocusChanged{focused=it.isFocused}
            .clickable(enabled=enabled,role=Role.Button,interactionSource=remember{MutableInteractionSource()},indication=null,onClick=onClick)
            .padding(horizontal=6.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp)) {
            br.com.flaviotorres.iptvpremium.ui.settings.SubtitleSettingsGlyph(br.com.flaviotorres.iptvpremium.ui.settings.SubtitleSettingsIcon.SYNC,Modifier.size(21.dp),color)
            Text("Sincronia",color=color,fontSize=14.sp,fontWeight=FontWeight.Medium,modifier=Modifier.weight(1f))
            if(enabled)Text(externalSubtitleOffsetLabel(offsetMs),color=NeutralPlayerPalette.text,fontSize=11.sp)
        }
        if(!enabled)Text("Ative uma legenda para ajustar",color=NeutralPlayerPalette.secondary,fontSize=11.sp)
    }
}
