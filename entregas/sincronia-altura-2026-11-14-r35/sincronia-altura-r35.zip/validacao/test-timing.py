from pathlib import Path
import subprocess,os
r=Path('/workspace/iptv-visual-r32');f=r/'app/src/main/java/br/com/flaviotorres/iptvpremium/core/navigation/player';tools=Path('/workspace/iptv-tools');java=str(tools/'jdk25/bin/java')
jars=list(tools.glob('*.jar'))+list(Path('/workspace/.gradle-cache/caches/9.6.0/transforms').glob('*/transformed/*-runtime.jar'))+[Path('/workspace/android-sdk/platforms/android-37.0/android.jar')]
cp=os.pathsep.join(map(str,jars));jar=r/'validacao/timing-tests.jar'
result=subprocess.run([java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',str(jar),str(f/'SubtitleTiming.kt'),str(f/'SubtitleTimingRenderer.kt'),str(r/'validacao/TimingVerify.kt')],capture_output=True,text=True)
print((result.stdout+result.stderr)[-2000:]);assert result.returncode==0
result=subprocess.run([java,'-cp',str(jar)+os.pathsep+cp,'br.com.flaviotorres.iptvpremium.core.player.TimingVerifyKt'],capture_output=True,text=True)
print((result.stdout+result.stderr)[-2000:]);assert result.returncode==0
