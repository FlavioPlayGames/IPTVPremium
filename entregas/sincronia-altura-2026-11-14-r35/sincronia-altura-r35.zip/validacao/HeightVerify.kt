package br.com.flaviotorres.iptvpremium.core.player

import androidx.media3.common.text.Cue
import kotlin.math.abs
private fun near(a:Float,b:Float){check(abs(a-b)<.001f){"$a != $b"}}
@androidx.annotation.OptIn(androidx.media3.common.util.UnstableApi::class)
fun main() {
    val legacy=SubtitleAppearance()
    check(legacy.bottomPercent==8)
    check(legacy.copy(sizeSp=30).bottomPercent==8)
    check(legacy.copy(bottomPercent=35).copy(edge=SubtitleEdge.NONE).bottomPercent==35)
    check(normalizedSubtitleBottomPercent(-500)==0 && normalizedSubtitleBottomPercent(500)==80)
    check(adjustedSubtitleBottomPercent(0,-1)==0 && adjustedSubtitleBottomPercent(80,1)==80)
    check(adjustedSubtitleBottomPercent(80,Int.MAX_VALUE)==80 && adjustedSubtitleBottomPercent(0,Int.MIN_VALUE)==0)
    for(h in listOf(360f,540f,720f,1080f)) {
        near(externalSubtitleBottomDp(h,48f,8),48f) // Existing baseline preserved at every resolution.
        near(externalSubtitleBottomDp(h,48f,18),48f+h*.1f)
        for(percent in 0..79) {
            check(externalSubtitleBottomDp(h,48f,percent+1)>=externalSubtitleBottomDp(h,48f,percent))
            check(subtitleBottomFraction(percent) in 0f..1f)
        }
        check(externalSubtitleBottomDp(h,48f,0)>=0f)
    }
    val authored=Cue.Builder().setText("Exemplo").setLine(.25f,Cue.LINE_TYPE_FRACTION).setLineAnchor(Cue.ANCHOR_TYPE_START).setPosition(.4f).build()
    val cues=listOf(authored)
    check(positionedSubtitleCues(cues,legacy)===cues)
    val moved=positionedSubtitleCues(cues,legacy.copy(bottomPercent=30)).single()
    near(moved.line,.7f);check(moved.lineType==Cue.LINE_TYPE_FRACTION && moved.lineAnchor==Cue.ANCHOR_TYPE_END)
    near(moved.position,authored.position);check(moved.text.toString()=="Exemplo")
    check(positionedSubtitleCues(emptyList(),legacy.copy(bottomPercent=30)).isEmpty())
    println("PASS height: legacy baseline, independent style edits, clamp/overflow, resolution scaling, monotonic movement and actual Media3 text cue placement.")
}
