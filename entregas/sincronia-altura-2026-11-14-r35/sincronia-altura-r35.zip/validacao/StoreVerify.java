package br.com.flaviotorres.iptvpremium.core.player;
public final class StoreVerify {
 private static void check(boolean ok){if(!ok)throw new AssertionError();}
 public static void main(String[] args)throws Exception {
  android.content.Context context=new android.content.Context();
  SubtitleAppearanceStore store=new SubtitleAppearanceStore(context);
  check(store.load().getBottomPercent()==8);
  int[] callbacks={0};
  AutoCloseable observer=store.observe(()->{callbacks[0]++;return kotlin.Unit.INSTANCE;});
  SubtitleAppearance a=store.load();
  SubtitleAppearance custom=new SubtitleAppearance(a.getTextArgb(),a.getBackground(),a.getSizeSp(),SubtitleTypeface.SERIF,a.getEdge(),37);
  store.save(custom);
  SubtitleAppearanceStore reopened=new SubtitleAppearanceStore(context);
  check(reopened.load().equals(custom));
  a=reopened.load();reopened.save(a.copy(a.getTextArgb(),a.getBackground(),30,a.getTypeface(),a.getEdge(),a.getBottomPercent()));
  check(store.load().getBottomPercent()==37 && store.load().getSizeSp()==30 && callbacks[0]>0);
  a=reopened.load();reopened.save(a.copy(a.getTextArgb(),a.getBackground(),a.getSizeSp(),a.getTypeface(),a.getEdge(),8));
  check(store.load().getBottomPercent()==8 && store.load().getTypeface()==SubtitleTypeface.SERIF);
  int before=callbacks[0];observer.close();a=reopened.load();reopened.save(a.copy(a.getTextArgb(),a.getBackground(),a.getSizeSp(),a.getTypeface(),a.getEdge(),20));check(callbacks[0]==before);
  context.getSharedPreferences("subtitle_appearance_v1",0).edit().putInt("bottom_percent",900).apply();
  check(reopened.load().getBottomPercent()==80);
  System.out.println("PASS actual compiled SubtitleAppearanceStore: legacy default, save/reopen, independent fields, height-only reset, observer cleanup and invalid saved value clamp (in-memory preferences host).");
 }
}
