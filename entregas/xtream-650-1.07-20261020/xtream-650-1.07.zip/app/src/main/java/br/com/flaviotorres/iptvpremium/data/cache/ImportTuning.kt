package br.com.flaviotorres.iptvpremium.data.cache

import android.content.Context
import android.util.Log
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import br.com.flaviotorres.iptvpremium.BuildConfig

internal object ImportTuning {
    private const val PREFS = "importacao_diagnostico"
    fun load(context: Context): ImportProfile = ImportProfile.stored(
        if (BuildConfig.DEBUG) context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("perfil", null) else null,
        BuildConfig.DEBUG
    ).also { ImportTuningState.profile = it }
    fun saveForDebug(context: Context, profile: ImportProfile) {
        check(BuildConfig.DEBUG) { "Diagnostico disponivel apenas em debug." }
        check(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("perfil", profile.name).commit())
    }
    fun <T: RoomDatabase> configure(builder: RoomDatabase.Builder<T>, profile: ImportProfile): RoomDatabase.Builder<T> {
        if (profile.forceWal) builder.setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
        return builder.addCallback(object: RoomDatabase.Callback() {
            override fun onOpen(db: SupportSQLiteDatabase) {
                if (profile.normal) {
                    // execSQL executes on the writer connection; no lazy cursor is left unstepped.
                    db.execSQL("PRAGMA synchronous=NORMAL")
                }
                val settings = writerSettings(db)
                Log.i("DbPerf", "revisao=db-r2 perfil=${profile.name} journal=${settings.first} synchronous=${settings.second} lote=${profile.batchSize} limiteCaracteres=${profile.batchCharacters} loteM3u=${profile.m3uBatchSize} limiteCaracteresM3u=${profile.m3uBatchCharacters}")
            }
        })
    }
    /** A transaction pins reads to the writer; pooled reader settings can differ. */
    fun writerSettings(db: SupportSQLiteDatabase): Pair<String, Int> {
        val ownsTransaction = !db.inTransaction()
        if (ownsTransaction) db.beginTransactionNonExclusive()
        try {
            val journal = db.query("PRAGMA journal_mode").use { check(it.moveToFirst()); it.getString(0) }
            val synchronous = db.query("PRAGMA synchronous").use { check(it.moveToFirst()); it.getInt(0) }
            return journal to synchronous
        } finally { if (ownsTransaction) db.endTransaction() }
    }

}
