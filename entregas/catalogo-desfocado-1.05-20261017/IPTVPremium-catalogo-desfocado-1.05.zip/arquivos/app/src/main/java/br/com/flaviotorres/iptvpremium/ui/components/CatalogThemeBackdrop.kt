package br.com.flaviotorres.iptvpremium.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import br.com.flaviotorres.iptvpremium.R
import br.com.flaviotorres.iptvpremium.ui.theme.themePainterResource

/** Shared catalogue wallpaper; only this static decorative layer is blurred. */
@Composable
internal fun CatalogThemeBackdrop(modifier: Modifier = Modifier) {
    Box(modifier.clipToBounds()) {
        Image(themePainterResource(R.drawable.home_background), null,
            modifier = Modifier.fillMaxSize().blur(24.dp), contentScale = ContentScale.Crop)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(
            Color.Black.copy(alpha = .38f), Color.Black.copy(alpha = .32f), Color.Black.copy(alpha = .45f)))))
    }
}

/** Neutral smoked glass avoids tinting all panels brown/olive in the Gold theme. */
internal object CatalogGlass {
    val panelBrush get() = Brush.verticalGradient(listOf(Color(0xC00B0D10), Color(0xC00B0D10)))
    fun surface(source: Long): Color = Color(source)
}
