package br.com.flaviotorres.iptvpremium.core.device

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.tv.material3.Text
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DateFormat
import java.text.NumberFormat
import java.util.Date
import java.util.Locale

@Composable
internal fun PortalRenewalOverlay() {
    val reminder by PortalRenewalState.reminder.collectAsState()
    val context = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    var showPayment by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val current = reminder
    if (current == null && !showPayment) return
    val rim = Brush.linearGradient(listOf(br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFF7A5215), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFFFFE6A0), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFFD6A32E), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFFFFF5CD)))
    Dialog(onDismissRequest = { if (showPayment && !saving) showPayment = false }, properties = DialogProperties(
        dismissOnClickOutside = false, dismissOnBackPress = showPayment, usePlatformDefaultWidth = false)) {
        Column(Modifier.widthIn(max = 660.dp).fillMaxWidth(0.92f).fillMaxHeight(0.9f)
            .background(Color(0xFF0B0D0F), RoundedCornerShape(16.dp)).border(1.dp, rim, RoundedCornerShape(16.dp))
            .verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text(if (showPayment) "RENOVAR ASSINATURA" else "SUA ASSINATURA", color = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE6A0), fontSize = 22.sp)
            if (showPayment) {
                Text("Acesse a central pelo celular para renovar por Pix. A liberação ocorre após a confirmação do administrador. Se renovar antes, seus dias restantes serão preservados.", color = Color.White, fontSize = 16.sp)
                DevicePortalQr(destination = "payment", compact = true)
                PortalOutlineButton("Voltar ao aplicativo", onClick = { showPayment = false })
            } else if (current != null) {
                val amount = current.amountCents?.let { NumberFormat.getCurrencyInstance(Locale.forLanguageTag("pt-BR")).format(it / 100.0) }
                val date = DateFormat.getDateInstance(DateFormat.SHORT, Locale.forLanguageTag("pt-BR")).format(Date(current.expiresAt))
                Text("Agradecemos pela preferência pelo IPTV Premium!", color = Color.White, fontSize = 18.sp)
                Text("Para continuar usando nosso aplicativo, será necessário renovar sua assinatura anual${if (amount != null) " por $amount" else ". Consulte o valor na central"}. Faltam ${current.daysRemaining} dia(s) para o vencimento, em $date.", color = Color.White, fontSize = 16.sp)
                Text("Você pode renovar agora ou no vencimento. Renovar antecipadamente preserva o prazo já contratado.", color = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE6A0), fontSize = 15.sp)
                val choose: (String) -> Unit = { choice ->
                    if (!saving) {
                        saving = true
                        error = null
                        scope.launch {
                            try {
                                withContext(Dispatchers.IO) { DevicePortalSync(context).chooseRenewal(choice, current) }
                                if (choice == "now") showPayment = true
                                else android.widget.Toast.makeText(context, "Escolha registrada: renovar no vencimento.", android.widget.Toast.LENGTH_LONG).show()
                            } catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
                            catch (_: Exception) { error = "Não foi possível registrar sua escolha. Confira a conexão e tente novamente. Se a assinatura mudou, reabra o aplicativo." }
                            finally { saving = false }
                        }
                    }
                }
                PortalOutlineButton(if (saving) "Registrando…" else "Renovar agora", enabled = !saving, onClick = { choose("now") })
                PortalOutlineButton("Renovar no vencimento", enabled = !saving, onClick = { choose("due") })
                error?.let { Text(it, color = Color.White, fontSize = 14.sp) }
            }
        }
    }
}
