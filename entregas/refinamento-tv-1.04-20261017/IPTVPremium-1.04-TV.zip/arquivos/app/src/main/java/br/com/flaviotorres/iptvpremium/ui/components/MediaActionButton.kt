package br.com.flaviotorres.iptvpremium.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.ui.theme.SelectionTheme

/** Shared visual treatment; callbacks remain owned by each details screen. */
@Composable
fun MediaActionButton(
    text: String, compactLayout: Boolean, onClick: () -> Unit,
    focusRequester: FocusRequester? = null,
    buttonWidth: Dp = if (compactLayout) 118.dp else 130.dp,
    buttonHeight: Dp = if (compactLayout) 28.dp else 30.dp
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(if (compactLayout) 7.dp else 8.dp)
    val rim = Brush.linearGradient(listOf(br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFF7A5215), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFFFFE6A0), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFFD6A32E), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFFFFF5CD), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFF926315)))
    Row(
        modifier = Modifier.then(if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier)
            .width(buttonWidth).height(buttonHeight)
            .scale(if (focused) 1.035f else 1f)
            .shadow(if (focused) 4.dp else 0.dp, shape, ambientColor = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0x30D4AF37), spotColor = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0x30D4AF37))
            .clip(shape)
            .background(if (focused) SelectionTheme.brush() else Brush.verticalGradient(listOf(Color(0x50111419), Color(0x600B0C10))))
            .border(if (focused) 1.7.dp else 1.dp, rim, shape)

            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick).padding(horizontal = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp, Alignment.CenterHorizontally)
    ) {
        Canvas(Modifier.size(if (compactLayout) 14.dp else 15.dp)) {
            val w = size.width; val h = size.height; val stroke = Stroke(1.2.dp.toPx())
            if (text.contains("trailer", ignoreCase = true)) {
                drawRoundRect(rim, Offset(w * .12f, h * .39f), Size(w * .76f, h * .50f), CornerRadius(w * .04f), style = stroke)
                val top = Path().apply {
                    moveTo(w * .10f, h * .22f); lineTo(w * .80f, h * .06f)
                    lineTo(w * .86f, h * .26f); lineTo(w * .15f, h * .42f); close()
                }
                drawPath(top, rim, style = stroke)
                drawLine(rim, Offset(w * .29f, h * .18f), Offset(w * .44f, h * .35f), 1.dp.toPx())
                drawLine(rim, Offset(w * .56f, h * .12f), Offset(w * .71f, h * .29f), 1.dp.toPx())
            } else {
                val play = Path().apply {
                    moveTo(w * .23f, h * .10f); lineTo(w * .86f, h * .50f)
                    lineTo(w * .23f, h * .90f); close()
                }
                drawPath(play, rim, style = stroke)
            }
        }
        Text(text, color = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE991), fontSize = if (compactLayout) 11.sp else 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}

// IPTV_POLISH_LOADING_HOLD_V1
