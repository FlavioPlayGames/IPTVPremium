package br.com.flaviotorres.iptvpremium.ui.playlist

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.type
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.layout.fillMaxHeight
import android.view.KeyEvent as AndroidKeyEvent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import br.com.flaviotorres.iptvpremium.ui.theme.themePainterResource as painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.R
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import kotlinx.coroutines.delay

private val MetallicGoldBrush get() = Brush.linearGradient(
    listOf(br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFF7A5215), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFFFFE6A0), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFFD6A32E), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFFFFF5CD), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.borderColor(0xFF926315))
)

@Composable
fun PlaylistListScreen(
    playlists: List<PlaylistSource>,
    activePlaylistId: String? = null,
    loadingPlaylistId: String? = null,
    onPlaylistClick: (PlaylistSource) -> Unit,
    onAddClick: () -> Unit,
    onDeleteClick: (PlaylistSource) -> Unit
) {
    var selectionFeedback by remember {
        mutableStateOf<String?>(null)
    }

    LaunchedEffect(selectionFeedback) {
        if (selectionFeedback != null) {
            delay(2_500L)
            selectionFeedback = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF08090C))
    ) {

        /*
         * MESMO FUNDO DA HOME
         */
        /*
         * PAINEL PRINCIPAL
         */
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    horizontal = 36.dp,
                    vertical = 28.dp
                )
                .border(
                    width = 1.5.dp,
                    brush = MetallicGoldBrush,
                    shape = RoundedCornerShape(22.dp)
                )
                .background(
                    color = Color(0xC008090B),
                    shape = RoundedCornerShape(22.dp)
                )
                .padding(28.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {

                /*
                 * CABEÇALHO
                 */
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp),
                    horizontalArrangement =
                        Arrangement.SpaceBetween,
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "MINHAS LISTAS",
                            style = TextStyle(
                                brush = MetallicGoldBrushText,
                                fontSize = 24.sp,
                                fontFamily = androidx.compose.ui.text.font.FontFamily(androidx.compose.ui.text.font.Font(R.font.cinzel_semibold)),
                                fontWeight = FontWeight.SemiBold
                            )
                        )

                        Text(
                            text = "Selecione uma lista para utilizar",
                            color = Color(0xFFF2F2F2),
                            fontSize = 14.sp
                        )
                    }

                    AddPlaylistButton(
                        onClick = onAddClick
                    )
                }

                Box(
                    modifier = Modifier.height(20.dp)
                )

                /*
                 * CONTEÚDO
                 */
                if (playlists.isEmpty()) {
                    EmptyPlaylistState(
                        modifier = Modifier
                            .fillMaxSize()
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize(),
                        verticalArrangement =
                            Arrangement.spacedBy(12.dp)
                    ) {
                        items(
                            items = playlists,
                            key = { playlist ->
                                playlist.id
                            }
                        ) { playlist ->
                            PlaylistCard(
                                playlist = playlist,
                                isActive =
                                    playlist.id ==
                                            activePlaylistId,
                                isLoading =
                                    playlist.id ==
                                            loadingPlaylistId,
                                onClick = {
                                    if (
                                        playlist.id !=
                                        loadingPlaylistId
                                    ) {
                                        selectionFeedback =
                                            if (
                                                playlist.id ==
                                                activePlaylistId
                                            ) {
                                                "Atualizando lista: ${playlist.name}"
                                            } else {
                                                "Lista selecionada: ${playlist.name}"
                                            }

                                        onPlaylistClick(
                                            playlist
                                        )
                                    }
                                },
                                onDeleteClick = {
                                    if (
                                        playlist.id !=
                                        loadingPlaylistId
                                    ) {
                                        onDeleteClick(
                                            playlist
                                        )
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
        if (selectionFeedback != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 42.dp)
                    .background(
                        color = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xF21A170E),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .border(
                        width = 1.5.dp,
                        brush = MetallicGoldBrush,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(
                        horizontal = 22.dp,
                        vertical = 12.dp
                    )
            ) {
                Text(
                    text = selectionFeedback.orEmpty(),
                    color = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFF1D77A),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun AddPlaylistButton(
    onClick: () -> Unit
) {
    var isFocused by remember {
        mutableStateOf(false)
    }

    val shape =
        RoundedCornerShape(12.dp)

    Box(
        modifier = Modifier
            .size(48.dp)
            .scale(
                if (isFocused) {
                    1.08f
                } else {
                    1f
                }
            )
            .border(
                width =
                    if (isFocused) {
                        2.dp
                    } else {
                        1.5.dp
                    },
                brush = MetallicGoldBrush,
                shape = shape
            )
            .background(
                color = if (isFocused) br.com.flaviotorres.iptvpremium.ui.theme.SelectionTheme.color() else Color(0x60111419),
                shape = shape
            )
            .onFocusChanged {
                isFocused = it.isFocused
            }
            .clickable(
                onClickLabel = "Cadastrar nova lista",
                onClick = onClick
            )
            .focusable(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "+",
            style = TextStyle(
                brush = MetallicGoldBrushText,
                fontSize = 30.sp,
                fontWeight = FontWeight.Normal
            )
        )
    }
}

@Composable
private fun PlaylistCard(
    playlist: PlaylistSource,
    isActive: Boolean,
    isLoading: Boolean,
    onClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var isFocused by remember {
        mutableStateOf(false)
    }

    val selectFocus = remember { FocusRequester() }
    val deleteFocus = remember { FocusRequester() }
    val shape =
        RoundedCornerShape(14.dp)

    val typeText =
        when (playlist) {
            is PlaylistSource.XtreamCodes -> {
                "XTREAM CODES"
            }

            is PlaylistSource.M3u -> {
                "M3U"
            }
        }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(82.dp)
            .then(
                if (isFocused || isActive || isLoading) {
                    Modifier.border(
                        width = 2.dp,
                        brush = MetallicGoldBrush,
                        shape = shape
                    )
                } else {
                    Modifier.border(
                        width = 1.dp,
                        brush = MetallicGoldBrush,
                        shape = shape
                    )
                }
            )
            .background(
                color =
                    if (isActive || isFocused) { br.com.flaviotorres.iptvpremium.ui.theme.SelectionTheme.color() } else {
                        Color(0x600B0C10)
                    },
                shape = shape
            )
            .padding(
                start = 20.dp,
                end = 12.dp
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize(),
            horizontalArrangement =
                Arrangement.SpaceBetween,
            verticalAlignment =
                Alignment.CenterVertically
        ) {
            Row(
                modifier = Modifier.weight(1f).fillMaxHeight()
                    .focusRequester(selectFocus)
                    .focusProperties { if (!isLoading) right = deleteFocus }
                    .onFocusChanged { isFocused = it.isFocused }
                    .onPreviewKeyEvent { event ->
                        if (!isLoading && event.nativeKeyEvent.keyCode == AndroidKeyEvent.KEYCODE_DPAD_RIGHT) {
                            if (event.type == KeyEventType.KeyDown && event.nativeKeyEvent.repeatCount == 0) deleteFocus.requestFocus()
                            true
                        } else false
                    }
                    .clickable(enabled = !isLoading, onClickLabel = "Carregar lista", onClick = onClick),
                verticalAlignment =
                    Alignment.CenterVertically,
                horizontalArrangement =
                    Arrangement.spacedBy(18.dp)
            ) {
                PlaylistTypeBadge(
                    type = typeText,
                    highlighted =
                        isFocused || isActive || isLoading
                )

                Column(
                    verticalArrangement =
                        Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = playlist.name,
                        color = Color(0xFFF5F5F5),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text =
                            when {
                                isLoading && isActive ->
                                    "$typeText • ATUALIZANDO..."

                                isLoading ->
                                    "$typeText • CARREGANDO..."

                                isActive ->
                                    "$typeText • LISTA ATIVA"

                                else ->
                                    typeText
                            },
                        color =
                            if (isActive || isLoading) {
                                br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFF1D77A)
                            } else {
                                Color(0xFFF2F2F2)
                            },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            if (isLoading) {
                PlaylistLoadingIndicator()
            } else {
                DeletePlaylistButton(
                    focusRequester = deleteFocus,
                    onMoveLeft = { selectFocus.requestFocus() },
                    name = playlist.name,
                    onClick = onDeleteClick
                )
            }
        }
    }
}

@Composable
private fun PlaylistLoadingIndicator() {
    val transition =
        rememberInfiniteTransition(
            label = "playlistLoading"
        )

    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 900,
                easing = LinearEasing
            )
        ),
        label = "playlistLoadingRotation"
    )

    Canvas(
        modifier = Modifier.size(34.dp)
    ) {
        drawArc(
            brush = MetallicGoldBrush,
            startAngle = rotation,
            sweepAngle = 265f,
            useCenter = false,
            style = Stroke(
                width = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
        )
    }
}

@Composable
private fun PlaylistTypeBadge(
    type: String,
    highlighted: Boolean
) {
    Box(
        modifier = Modifier
            .width(112.dp)
            .height(34.dp)
            .then(
                if (highlighted) {
                    Modifier.border(
                        width = 1.5.dp,
                        brush = MetallicGoldBrush,
                        shape = RoundedCornerShape(8.dp)
                    )
                } else {
                    Modifier.border(
                        width = 1.dp,
                        color = Color(0xFF454A55),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            )
            .background(
                color = Color(0x60111419),
                shape = RoundedCornerShape(8.dp)
            ),
        contentAlignment =
            Alignment.Center
    ) {
        if (highlighted) {
            Text(
                text = type,
                style = TextStyle(
                    brush = MetallicGoldBrushText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            )
        } else {
            Text(
                text = type,
                color = Color(0xFFF2F2F2),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DeletePlaylistButton(
    focusRequester: FocusRequester,
    onMoveLeft: () -> Unit,
    name: String,
    onClick: () -> Unit
) {
    var isFocused by remember {
        mutableStateOf(false)
    }

    val shape =
        RoundedCornerShape(9.dp)

    Box(
        modifier = Modifier
            .size(40.dp)
            .scale(
                if (isFocused) {
                    1.08f
                } else {
                    1f
                }
            )
            .border(
                width =
                    if (isFocused) {
                        1.5.dp
                    } else {
                        1.dp
                    },
                brush = MetallicGoldBrush,
                shape = shape
            )
            .background(
                color = if (isFocused) br.com.flaviotorres.iptvpremium.ui.theme.SelectionTheme.color() else Color(0x60111419),
                shape = shape
            )
            .focusRequester(focusRequester)
            .semantics { contentDescription = "Excluir lista $name" }
            .onPreviewKeyEvent { event ->
                if (event.nativeKeyEvent.keyCode == AndroidKeyEvent.KEYCODE_DPAD_LEFT) {
                    if (event.type == KeyEventType.KeyDown && event.nativeKeyEvent.repeatCount == 0) onMoveLeft()
                    true
                } else false
            }
            .onFocusChanged {
                isFocused = it.isFocused
            }
            .clickable(
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "×",
            color =
                if (isFocused) {
                    br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFF1D77A)
                } else {
                    Color(0xFFF2F2F2)
                },
            fontSize = 24.sp,
            fontWeight = FontWeight.Normal
        )
    }
}

@Composable
private fun EmptyPlaylistState(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment =
                Alignment.CenterHorizontally,
            verticalArrangement =
                Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Nenhuma lista cadastrada",
                color = Color(0xFFF5F5F5),
                fontSize = 19.sp,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = "Use o botão + para adicionar sua primeira lista.",
                color = Color(0xFF9FA2AA),
                fontSize = 14.sp
            )
        }
    }
}

// IPTV_GLOBAL_GRAPHITE_V1

// IPTV_POLISH_LOADING_HOLD_V1

// IPTV_LISTS_SUBTITLES_CHANNELS_V1

// IPTV_PLAYLIST_ENTRY_BRAND_V1

// IPTV_LIST_LOADING_AND_PLAYER_INPUT_V1

// Text retains the approved palette; blue darkening applies to rims.
private val MetallicGoldBrushText get() = Brush.linearGradient(
    listOf(br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFF7A5215), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE6A0), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFD6A32E), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFF5CD), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFF926315))
)
