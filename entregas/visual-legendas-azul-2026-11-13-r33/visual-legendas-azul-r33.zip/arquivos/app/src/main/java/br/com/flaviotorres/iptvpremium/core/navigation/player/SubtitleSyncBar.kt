package br.com.flaviotorres.iptvpremium.core.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text

internal val subtitleSyncBarHeight=48.dp
internal val subtitleSyncBarBottom=12.dp
internal val subtitleSyncCaptionGap=12.dp

@Composable
internal fun SubtitleSyncBar(offsetMs:Long,stepMs:Long,onOffset:(Long,String)->Unit,onStep:()->Unit,onAssistant:()->Unit,
    focus:FocusRequester,modifier:Modifier=Modifier,onClose:()->Unit={}) {
    val accent=playerThemeAccent();val small=LocalConfiguration.current.screenWidthDp<700
    val font=if(small)11.sp else 13.sp
    val step=java.lang.String.format(java.util.Locale.forLanguageTag("pt-BR"),"%.1f s",stepMs/1000.0)
    Row(modifier.fillMaxWidth(.92f).height(subtitleSyncBarHeight)
        .background(Color(0xF0212224),RoundedCornerShape(9.dp))
        .border(1.dp,Color(0xFF77797C),RoundedCornerShape(9.dp)).padding(6.dp),
        verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(7.dp)) {
        @Composable fun Button(label:String,description:String,initial:Boolean=false,weight:Float=1f,action:()->Unit) {
            var focused by remember{mutableStateOf(false)}
            Box(Modifier.weight(weight).fillMaxHeight().then(if(initial)Modifier.focusRequester(focus)else Modifier)
                .onFocusChanged{focused=it.isFocused}
                .background(if(focused)accent else Color(0xFF28292B),RoundedCornerShape(7.dp))
                .border(if(focused)2.dp else 1.dp,if(focused)accent else Color(0xFF77797C),RoundedCornerShape(7.dp))
                .semantics{contentDescription=description}
                .clickable(interactionSource=remember{MutableInteractionSource()},indication=null,onClick=action)
                .padding(horizontal=5.dp),contentAlignment=Alignment.Center) {
                Text(label,color=if(focused&&accent.luminance()>.179f)Color(0xFF161616)else Color.White,fontSize=font,fontWeight=FontWeight.SemiBold,maxLines=1,overflow=TextOverflow.Ellipsis)
            }
        }
        // The existing increment choices remain accessible without a second tall settings panel.
        Button("Ajuste","Intervalo por clique: $step. Pressione para alterar.",weight=.65f,action=onStep)
        Text(externalSubtitleOffsetLabel(offsetMs),color=Color.White,fontSize=font,fontWeight=FontWeight.SemiBold,modifier=Modifier.widthIn(min=50.dp))
        Button("− Adiantar","Adiantar legenda em $step",weight=1.1f){onOffset(offsetMs-stepMs,"CHANGE")}
        Button("+ Atrasar","Atrasar legenda em $step",initial=true,weight=1.1f){onOffset(offsetMs+stepMs,"CHANGE")}
        Button("Zerar","Zerar ajuste salvo",weight=.75f){onOffset(0L,"RESET")}
        Button("Auxílio","Auxiliar de sincronização",weight=.8f,action=onAssistant)
        Button("× Fechar","Fechar ajuste",weight=.8f,action=onClose)
    }
}

/** Pinned below the scrolling subtitle choices, including while captions are off. */
@Composable
internal fun SubtitleTimingMenuButton(enabled:Boolean,offsetMs:Long,onClick:()->Unit) {
    var focused by remember{mutableStateOf(false)};val accent=playerThemeAccent();val shape=RoundedCornerShape(8.dp)
    Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(5.dp),horizontalAlignment=Alignment.CenterHorizontally) {
        Row(Modifier.fillMaxWidth().heightIn(min=42.dp).onFocusChanged{focused=it.isFocused}
            .background(if(focused)accent.copy(alpha=.24f)else Color(0xFF262729),shape)
            .border(if(focused)2.dp else 1.dp,if(enabled)accent else Color(0xFF656668),shape)
            .clickable(enabled=enabled,interactionSource=remember{MutableInteractionSource()},indication=null,onClick=onClick)
            .padding(horizontal=16.dp,vertical=10.dp),verticalAlignment=Alignment.CenterVertically,horizontalArrangement=Arrangement.spacedBy(10.dp,Alignment.CenterHorizontally)) {
            br.com.flaviotorres.iptvpremium.ui.settings.SubtitleSettingsGlyph(br.com.flaviotorres.iptvpremium.ui.settings.SubtitleSettingsIcon.SYNC,
                Modifier.size(20.dp),if(enabled)accent else Color(0xFF999A9C))
            Text("Sincronia",color=if(enabled)accent else Color(0xFF999A9C),fontSize=14.sp,fontWeight=FontWeight.SemiBold)
        }
        Text(if(enabled)externalSubtitleOffsetLabel(offsetMs)else"Ative uma legenda para ajustar",color=Color.LightGray,fontSize=11.sp)
    }
}
