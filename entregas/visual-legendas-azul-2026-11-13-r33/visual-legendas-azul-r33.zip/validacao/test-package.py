from pathlib import Path
import tempfile,shutil,json,hashlib,subprocess,os
out=Path('/workspace/entregas/visual-legendas-azul-r33');base=Path('/workspace/iptv-visual-r33-base/app/src/main/java');current=Path('/workspace/iptv-visual-r32');items=json.loads((out/'manifesto.json').read_text());guards=json.loads((out/'guardas.json').read_text());pw='/workspace/iptv-tools/powershell/pwsh'
env=os.environ.copy()
for n in ['CACHE','CONFIG','DATA']:env['XDG_'+n+'_HOME']='/workspace/iptv-tools/xdg-'+n.lower()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
def original(name):return base/name.removeprefix('app/src/main/java/') if name.startswith('app/src/main/java/') else current/name
def call(argv,ok=True):
 r=subprocess.run(argv,capture_output=True,text=True,env=env);assert (r.returncode==0)==ok,(r.stdout,r.stderr);return r
with tempfile.TemporaryDirectory(prefix='iptv-r33-patch-')as temp:
 t=Path(temp);env['USERPROFILE']=str(t);(t/'Downloads').mkdir()
 for simulate in [False,True]:
  project=t/('project-'+str(simulate));project.mkdir();(project/'gradlew.bat').write_text('stub');p=project/'app/src/main/AndroidManifest.xml';p.parent.mkdir(parents=True);p.write_text('<manifest/>')
  for item in items:
   if item['beforeHash']:
    p=project/item['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original(item['path']),p)
  for guard in guards:
   p=project/guard['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original(guard['path']),p)
  args=[pw,'-NoProfile','-File','/workspace/iptv-validacao/Testar-Aplicador-JSON.ps1','-Pacote',str(out),'-Projeto',str(project)]+(['-SimularWinPS51']if simulate else[])
  call(args);call(args);assert all(sha(project/i['path'])==i['afterHash'] for i in items)
  backup=next(p for p in(t/'Downloads').glob('IPTV-restauracao-r33-*') if json.loads((p/'estado.json').read_text(encoding='utf-8-sig'))['projeto']==str(project))
  modified=next(i for i in items if i['beforeHash']);p=project/modified['path'];saved=p.read_bytes();p.write_bytes(saved+b'// user change')
  call(args+['-Acao','Desfazer.ps1','-Backup',str(backup)],False);p.write_bytes(saved)
  call(args+['-Acao','Desfazer.ps1','-Backup',str(backup)]);assert all(sha(project/i['path'])==i['beforeHash'] for i in items)
  p.write_bytes(p.read_bytes()+b'// newer base');call(args,False)
  print('PASS apply/repeat/undo and guarded edits;', 'Windows PowerShell 5.1 JSON shape'if simulate else'PowerShell 7')
 script=t/'parse.ps1';script.write_text("$tokens=$null;$errors=$null;[System.Management.Automation.Language.Parser]::ParseFile($args[0],[ref]$tokens,[ref]$errors)|Out-Null;if($errors.Count){$errors|Write-Output;exit 1}")
 for file in out.glob('*.ps1'):call([pw,'-NoProfile','-File',str(script),str(file)])
 print('PASS all PowerShell scripts parse')
# No dependency or budget edits leak into the patch.
assert all(i['path'].startswith(('app/src/main/java/','app/src/main/res/drawable-nodpi/'))for i in items)
assert not any('cache' in i['path'].lower() or 'build.gradle' in i['path']for i in items)
assert sum((out/'arquivos'/i['path']).stat().st_size for i in items if i['path'].endswith('.webp'))==0
print('PASS only intended source/art files; no new image; no Gradle, keys, cache or signature payload')
