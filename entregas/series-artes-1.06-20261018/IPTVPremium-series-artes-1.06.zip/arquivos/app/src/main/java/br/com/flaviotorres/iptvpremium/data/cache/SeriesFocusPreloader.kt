package br.com.flaviotorres.iptvpremium.data.cache

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Usado na thread da UI. O clique preserva uma consulta ja iniciada pelo foco. */
internal class SeriesFocusPreloader(
    private val scope: CoroutineScope,
    private val load: suspend (String) -> Unit
) {
    private var selected: String? = null
    private var job: Job? = null
    private var started = false
    private var committed = false
    fun focus(id: String) {
        if (committed || (selected == id && job?.isActive == true)) return
        clear()
        if (id.isBlank()) return
        selected = id
        job = scope.launch {
            delay(150L)
            started = true
            load(id)
        }
    }
    fun blur(id: String) { if (selected == id) clear() }
    fun clear() {
        if (committed) return
        job?.cancel(); job = null; selected = null; started = false
    }
    fun commit(id: String) {
        if (selected != id || !started) { job?.cancel(); job = null }
        committed = true
    }
    fun dispose() { if (!committed) clear() }
}
