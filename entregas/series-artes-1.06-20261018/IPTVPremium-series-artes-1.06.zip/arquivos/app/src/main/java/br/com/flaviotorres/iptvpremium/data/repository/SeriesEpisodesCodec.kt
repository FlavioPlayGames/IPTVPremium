package br.com.flaviotorres.iptvpremium.data.repository
import org.json.JSONArray
import org.json.JSONObject

/** Grava apenas campos necessarios, excluindo direct_source e dados de autenticacao da resposta. */
internal fun encodeSeriesEpisodes(result: SeriesEpisodesResult): String {
    val info = JSONObject().put("name", result.title).put("plot", result.plot)
        .put("cover", result.posterUrl).put("youtube_trailer", result.trailerUrl)
        .put("backdrop_path", JSONArray(listOfNotNull(result.backdropUrl)))
    val episodes = JSONArray()
    for (e in result.episodes) episodes.put(JSONObject().put("id", e.id).put("season", e.seasonNumber)
        .put("episode_num", e.episodeNumber).put("title", e.title).put("container_extension", e.containerExtension)
        .put("info", JSONObject().put("movie_image", e.thumbnailUrl).put("plot", e.synopsis).put("duration_secs", e.durationSeconds)))
    val seasons = JSONArray()
    for (s in result.seasons) seasons.put(JSONObject().put("season_number", s.number).put("name", s.title).put("cover", s.coverUrl))
    return JSONObject().put("info", info).put("episodes", episodes).put("seasons", seasons).toString()
}
