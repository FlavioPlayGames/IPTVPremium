package br.com.flaviotorres.iptvpremium.data.repository

/** Uma lista importada com episodios reais nao precisa esperar uma chamada remota. */
internal suspend fun loadSeriesEpisodeContent(
    local: suspend () -> SeriesEpisodesResult?,
    remote: suspend () -> SeriesEpisodesResult?
): SeriesEpisodesResult? {
    local()?.takeIf { it.episodes.isNotEmpty() }?.let { return it }
    return remote()?.takeIf { it.episodes.isNotEmpty() }
}

/** A imagem fornecida pela lista nao espera a consulta de imagens do TMDB. */
internal fun episodeReferenceImages(tmdb: String?, provider: String?, secondary: String? = null): List<String> =
    listOfNotNull(provider, tmdb, secondary).map(String::trim)
        .filter { it.startsWith("https://", true) || it.startsWith("http://", true) }.distinct()
