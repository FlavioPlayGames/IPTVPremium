package br.com.flaviotorres.iptvpremium.data.repository

import java.io.File
import java.security.MessageDigest

/** Somente detalhes consultados, nao o catalogo inteiro. Limpar cache remove estes arquivos. */
internal class SeriesEpisodeDiskCache(
    private val directory: File,
    private val clock: () -> Long = System::currentTimeMillis,
    private val maxBytes: Long = 12L * 1024 * 1024,
    private val maxEntries: Int = 40,
    private val ttlMs: Long = 6L * 60 * 60 * 1000
) {
    private fun file(key: String): File {
        val hash = MessageDigest.getInstance("SHA-256").digest(key.toByteArray()).joinToString("") { "%02x".format(it.toInt() and 255) }
        return File(directory, "$hash.json")
    }
    @Synchronized fun read(key: String): String? = try {
        val f = file(key)
        if (!f.isFile) null
        else if (clock() - f.lastModified() !in 0..ttlMs || f.length() > MAX_ENTRY_BYTES) { f.delete(); null }
        else f.readText()
    } catch (_: Exception) { null }
    @Synchronized fun write(key: String, value: String) {
        val bytes = value.toByteArray()
        if (bytes.size > MAX_ENTRY_BYTES || bytes.size > maxBytes) return
        val target = file(key); val temp = File(directory, target.name + ".part")
        try {
            if (!directory.isDirectory && !directory.mkdirs()) return
            temp.writeBytes(bytes)
            if (!temp.renameTo(target)) return
            target.setLastModified(clock())
            val entries = directory.listFiles().orEmpty().filter { it.name.matches(Regex("[0-9a-f]{64}\\.json")) }.sortedBy { it.lastModified() }
            var total = entries.sumOf { it.length() }; var count = entries.size
            for (entry in entries) {
                if (total <= maxBytes && count <= maxEntries) break
                val n = entry.length(); if (entry.delete()) { total -= n; count-- }
            }
        } catch (_: Exception) { /* Cache nao impede a abertura da serie. */ }
        finally { temp.delete() }
    }
    private companion object { const val MAX_ENTRY_BYTES = 4L * 1024 * 1024 }
}
