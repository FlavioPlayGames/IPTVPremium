package br.com.flaviotorres.iptvpremium.data.cache.entity

import androidx.room.Entity

/** Only progressive generations have rows; legacy/full snapshots are already complete. */
@Entity(tableName = "cached_sections", primaryKeys = ["playlistId", "generationId", "section"])
data class CachedSectionEntity(val playlistId: String, val generationId: String,
    val section: String, val ready: Boolean = false)
