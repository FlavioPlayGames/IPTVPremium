package br.com.flaviotorres.iptvpremium.data.sync

import android.content.Context
import android.util.Log
import br.com.flaviotorres.iptvpremium.data.cache.PlaylistCacheGenerationManager
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistContent
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.selects.select
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.util.UUID

enum class CatalogSection { LIVE_TV, MOVIES, SERIES }

object SectionCatalogMode {
    private const val PREFS = "section_catalog_test_18"
    fun enabled(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean("enabled", true)
    fun setEnabled(context: Context, enabled: Boolean) {
        check(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("enabled", enabled).commit())
    }
}

/** One writer, small buffers and private stages. Requests preempt only unfinished sections. */
class SectionCatalogLoader internal constructor(
    private val repository: ProgressiveXtreamRepository?,
    private val importer: M3uCacheImporter,
    private val dao: PlaylistCacheDao,
    private val manager: PlaylistCacheGenerationManager,
    private val fallback: suspend (PlaylistSource.M3u) -> String
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mutex = Mutex()
    private val mutableErrors = MutableStateFlow<Map<String, Map<CatalogSection, String>>>(emptyMap())
    val errors = mutableErrors.asStateFlow()
    private var session: Session? = null
    private class Session(val source: PlaylistSource, val generation: String, val directory: File) {
        val requests = Channel<CatalogSection>(Channel.CONFLATED)
        var job: Job? = null
    }

    suspend fun open(source: PlaylistSource, cacheDirectory: File): String = mutex.withLock {
        val previous = session
        if (previous?.source == source && previous.job?.isActive == true) return@withLock previous.generation
        previous?.job?.cancelAndJoin()
        var generation = manager.getActiveGenerationId(source.id)
        if (generation == null) generation = manager.prepareSectionShell(source.id)
        if (dao.pendingSections(source.id, generation).isEmpty()) return@withLock generation
        val item = Session(source, generation, File(cacheDirectory, "catalog-sections-" + UUID.randomUUID()))
        session = item
        // Own files only, including leftovers from a process killed during its download.
        cacheDirectory.listFiles()?.filter { it.name.startsWith("catalog-sections-") && it.isDirectory }?.forEach { it.deleteRecursively() }
        mutableErrors.value = mutableErrors.value - source.id
        Log.i("SectionCatalog", "etapa=HOME_LIBERADA tipo=${if (source is PlaylistSource.M3u) "M3U" else "XTREAM"}")
        item.job = scope.launch {
            val started = android.os.SystemClock.elapsedRealtime()
            br.com.flaviotorres.iptvpremium.core.storage.StorageMaintenance.foregroundImport {
                try { run(item) }
                catch (cancelled: CancellationException) { throw cancelled }
                catch (error: Exception) {
                    val pending = dao.pendingSections(source.id, item.generation)
                    for (section in CatalogSection.entries.filter { it.name in pending }) fail(item, section, error)
                } finally {
                    withContext(NonCancellable) {
                        val active = manager.getActiveGenerationId(source.id)
                        val count = active?.let { dao.pendingSections(source.id, it).size } ?: 3
                        val result = if (item.job?.isCancelled == true) "CANCELADA" else if (count == 0) "SUCESSO" else "ERRO"
                        Log.i("SectionCatalog", "CATALOGO_RESUMO tipo=${if (source is PlaylistSource.M3u) "M3U" else "XTREAM"} resultado=$result duracaoMs=${android.os.SystemClock.elapsedRealtime()-started} pendentes=$count")
                        item.directory.deleteRecursively()
                    }
                }
            }
        }
        generation
    }

    fun prioritize(playlist: String, section: CatalogSection) {
        session?.takeIf { it.source.id == playlist }?.let {
            Log.i("SectionCatalog", "etapa=PRIORIDADE secao=$section")
            it.requests.trySend(section)
        }
    }

    suspend fun hasPending(playlist: String): Boolean {
        val generation = manager.getActiveGenerationId(playlist) ?: return true
        return dao.pendingSections(playlist, generation).isNotEmpty()
    }

    suspend fun stopPlaylist(playlist: String) = mutex.withLock {
        if (session?.source?.id == playlist) { session?.job?.cancelAndJoin(); session = null }
    }

    suspend fun stop() = mutex.withLock { session?.job?.cancelAndJoin(); session = null }

    private fun fail(item: Session, section: CatalogSection, error: Exception) {
        mutableErrors.value = mutableErrors.value + (item.source.id to
            (mutableErrors.value[item.source.id].orEmpty() + (section to "Não foi possível carregar esta seção. Volte à Home e tente novamente.")))
        Log.w("SectionCatalog", "secao=$section resultado=ERRO tipo=${error.javaClass.simpleName}")
    }

    private suspend fun run(item: Session) = supervisorScope {
        val source = item.source
        var files: Map<CatalogSection, File>? = null
        if (source is PlaylistSource.M3u) files = importer.downloadSections(source.playlistUrl, item.directory)
        else {
            source as PlaylistSource.XtreamCodes
            try { checkNotNull(repository).authenticateCatalog(source) }
            catch (cancelled: CancellationException) { throw cancelled }
            catch (error: Exception) { if (useFallback(item, source)) return@supervisorScope else throw error }
        }
        delay(700) // Let the Home render and collect an initial section choice.
        val failed = mutableSetOf<CatalogSection>()
        var preferred = item.requests.tryReceive().getOrNull()
        while (true) {
            currentCoroutineContext().ensureActive()
            val pending = dao.pendingSections(source.id, item.generation).map(CatalogSection::valueOf)
            val next = preferred?.takeIf { it in pending && it !in failed }
                ?: CatalogSection.entries.firstOrNull { it in pending && it !in failed } ?: break
            preferred = null
            val task = async { loadSection(item, next, files?.getValue(next)) }
            var preempted = false
            try {
                while (!task.isCompleted) {
                    select<Unit> {
                        task.onAwait { }
                        item.requests.onReceive { requested ->
                            failed.remove(requested)
                            if (requested != next && requested in pending && requested !in failed) {
                                preferred = requested
                                preempted = true
                                task.cancelAndJoin()
                            }
                        }
                    }
                    if (preempted) break
                }
                if (!preempted) task.await()
            } catch (cancelled: CancellationException) {
                if (!preempted) throw cancelled
            } catch (error: Exception) {
                if (source is PlaylistSource.XtreamCodes && !storageFailure(error) && useFallback(item, source)) return@supervisorScope
                failed.add(next)
                fail(item, next, error)
            }
            if (!preempted) preferred = item.requests.tryReceive().getOrNull()
        }
        Log.i("SectionCatalog", "catalogo=FINALIZADO pendentes=${dao.pendingSections(source.id, item.generation).size}")
    }

    private fun storageFailure(error: Throwable, depth: Int = 0): Boolean =
        error is XtreamCatalogWriteException || error is android.database.sqlite.SQLiteException ||
            (depth < 5 && error.cause?.takeIf { it !== error }?.let { storageFailure(it, depth + 1) } == true)

    private suspend fun useFallback(item: Session, source: PlaylistSource.XtreamCodes): Boolean {
        val link = source.fallbackM3uUrl?.takeIf { it.isNotBlank() } ?: return false
        Log.i("SectionCatalog", "alternativa=M3U catalogo_anterior=preservado")
        fallback(PlaylistSource.M3u(source.id, source.name, source.isEnabled, link))
        currentCoroutineContext().ensureActive()
        manager.activateReadyGenerationOnStartup(source.id)
        mutableErrors.value = mutableErrors.value - source.id
        return true
    }

    private suspend fun loadSection(item: Session, section: CatalogSection, file: File?) {
        val started = android.os.SystemClock.elapsedRealtime()
        val stage = manager.beginImport(item.source.id)
        val writer = XtreamCatalogWriter(dao, manager, item.source.id, stage)
        try {
            if (file != null) importer.importSectionFile(item.source.id, stage, file)
            else checkNotNull(repository).importSection(item.source as PlaylistSource.XtreamCodes, section,
                object : XtreamCatalogSink by writer {
                    override suspend fun append(endpoint: String, content: PlaylistContent) {
                        writer.append(endpoint, content)
                        delay(6) // Yield between bounded writes instead of competing continuously with UI reads.
                    }
                })
            writer.closeStages()
            currentCoroutineContext().ensureActive()
            dao.publishSection(item.source.id, stage, item.generation, section.name)
            mutableErrors.value = mutableErrors.value + (item.source.id to (mutableErrors.value[item.source.id].orEmpty() - section))
            Log.i("SectionCatalog", "secao=$section resultado=PRONTA totalMs=${android.os.SystemClock.elapsedRealtime()-started}")
        } finally {
            withContext(NonCancellable) {
                try { writer.closeStages() } finally { manager.discardImport(item.source.id, stage) }
            }
        }
    }
}
