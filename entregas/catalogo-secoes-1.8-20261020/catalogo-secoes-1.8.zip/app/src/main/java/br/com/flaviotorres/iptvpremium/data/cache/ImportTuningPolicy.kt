package br.com.flaviotorres.iptvpremium.data.cache

/** Diagnostic profiles; release always uses the stable 250/2000 defaults. No full-catalog materialization. */
internal enum class ImportProfile(val forceWal: Boolean, val normal: Boolean, val batchSize: Int, val batchCharacters: Int,
    val m3uBatchSize: Int = batchSize,
    val m3uBatchCharacters: Int = if (batchSize == 2000) batchCharacters else Int.MAX_VALUE
) {
    PADRAO(false, false, 250, 256 * 1024, 2000, 2 * 1024 * 1024),
    ATUAL(false, false, 250, 256 * 1024),
    WAL(true, false, 250, 256 * 1024),
    NORMAL(true, true, 250, 256 * 1024),
    LOTES(true, true, 2000, 2 * 1024 * 1024),
    XTREAM_1000(false, false, 1000, 512 * 1024, 2000, 2 * 1024 * 1024),
    XTREAM_500(false, false, 500, 256 * 1024, 2000, 2 * 1024 * 1024),
    XTREAM_650(false, false, 650, 256 * 1024, 2000, 2 * 1024 * 1024);
    companion object {
        val DEFAULT: ImportProfile get() = PADRAO
        fun stored(value: String?, debug: Boolean): ImportProfile =
            if (debug) entries.firstOrNull { it.name == value } ?: DEFAULT else DEFAULT
        fun requested(value: String): ImportProfile = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Perfil de importacao invalido.")
    }
}
internal object ImportTuningState {
    @Volatile var profile: ImportProfile = ImportProfile.DEFAULT
}
