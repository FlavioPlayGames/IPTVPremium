package br.com.flaviotorres.iptvpremium.data.sync

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.platform.app.InstrumentationRegistry
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import br.com.flaviotorres.iptvpremium.domain.model.*
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.io.IOException
import java.util.UUID

class SectionCatalogDeviceTest {
    private val source = PlaylistSource.XtreamCodes("sections-fixture", "Fixture", true, "https://example.invalid", "fixture", "fixture")
    private class Client : PlaylistHttpClient {
        var calls = 0
        var payload = listOf("#EXTM3U", "#EXTINF:-1 group-title=\"Canais\",Canal", "https://example.invalid/live/u/p/1.ts",
            "#EXTINF:-1 group-title=\"Filmes\",Filme", "https://example.invalid/movie/u/p/2.mp4",
            "#EXTINF:-1 group-title=\"Series\",Serie S01E01", "https://example.invalid/series/u/p/3.mp4")
        override suspend fun get(url: String): String = error("Must stream")
        override suspend fun readLines(url: String, onLine: suspend (String) -> Unit) { calls++; payload.forEach { onLine(it) } }
    }
    private class Provider : ProgressiveXtreamRepository {
        override val supportsSectionCatalog = true
        var auth = 0
        val order = java.util.Collections.synchronizedList(mutableListOf<CatalogSection>())
        val cancelled = java.util.Collections.synchronizedList(mutableListOf<CatalogSection>())
        var hold = emptySet<CatalogSection>()
        var fail: CatalogSection? = null
        override suspend fun authenticateCatalog(source: PlaylistSource.XtreamCodes) { auth++ }
        override suspend fun importXtream(source: PlaylistSource.XtreamCodes, sink: XtreamCatalogSink) = error("Must use sections")
        override suspend fun importSection(source: PlaylistSource.XtreamCodes, section: CatalogSection, sink: XtreamCatalogSink) {
            order.add(section)
            try {
                val content = when (section) {
                    CatalogSection.LIVE_TV -> PlaylistContent(categories = listOf(Category("live", "Live", CategoryType.LIVE_TV, CategorySource.PROVIDER)))
                    CatalogSection.MOVIES -> PlaylistContent(movies = listOf(Movie("movie", "Movie", null, null, null, "https://example.invalid/movie.mp4", null, null, null)))
                    CatalogSection.SERIES -> PlaylistContent(categories = listOf(Category("series", "Series", CategoryType.SERIES, CategorySource.PROVIDER)))
                }
                sink.append(if (section == CatalogSection.MOVIES) "get_vod_streams" else "get_series_categories", content)
                if (section in hold) awaitCancellation()
                if (section == fail) throw IOException("Fixture failure")
            } catch (error: CancellationException) { cancelled.add(section); throw error }
        }
    }
    private class Fixture(val db: PlaylistCacheDatabase, val dir: File) {
        val dao = db.playlistCacheDao()
        val manager = PlaylistCacheGenerationManager(dao)
        val provider = Provider()
        val client = Client()
        val importer = M3uCacheImporter(client, dao, manager)
        var fallbacks = 0
        val loader = SectionCatalogLoader(provider, importer, dao, manager) { fallbacks++; error("Unexpected fallback") }
    }
    private fun fixture(block: suspend (Fixture) -> Unit) = runBlocking {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val db = Room.inMemoryDatabaseBuilder(context, PlaylistCacheDatabase::class.java).build()
        val f = Fixture(db, File(context.cacheDir, "sections-test-" + UUID.randomUUID()).apply { mkdirs() })
        try { withTimeout(20_000) { block(f) } } finally { f.loader.stop(); db.close(); f.dir.deleteRecursively() }
    }
    private suspend fun waitUntil(check: suspend () -> Boolean) { withTimeout(10_000) { while (!check()) delay(10) } }

    @Test fun homeOpensBeforeAnySectionCompletes() = fixture { f ->
        f.provider.hold = CatalogSection.entries.toSet()
        val gen = f.loader.open(source, f.dir)
        assertEquals(gen, f.manager.getActiveGenerationId(source.id))
        assertEquals(3, f.dao.pendingSections(source.id, gen).size)
        assertEquals(0, f.dao.getMovieCount(source.id, gen))
        assertEquals(0, f.fallbacks)
        assertNull(f.dao.observeReadySectionGenerationId(source.id, "LIVE_TV").first())
    }
    @Test fun selectedMoviesArePublishedBeforeBackgroundLive() = fixture { f ->
        f.provider.hold = setOf(CatalogSection.LIVE_TV)
        val gen = f.loader.open(source, f.dir)
        f.loader.prioritize(source.id, CatalogSection.MOVIES)
        waitUntil { "MOVIES" !in f.dao.pendingSections(source.id, gen) }
        assertEquals(CatalogSection.MOVIES, f.provider.order.first())
        assertEquals(gen, f.dao.observeReadySectionGenerationId(source.id, "MOVIES").first())
        assertNull(f.dao.observeReadySectionGenerationId(source.id, "LIVE_TV").first())
        assertEquals(1, f.dao.getMovieCount(source.id, gen))
        assertTrue("LIVE_TV" in f.dao.pendingSections(source.id, gen))
    }
    @Test fun selectingSeriesCancelsOnlyUnfinishedBackgroundSection() = fixture { f ->
        f.provider.hold = setOf(CatalogSection.LIVE_TV, CatalogSection.MOVIES)
        val gen = f.loader.open(source, f.dir)
        waitUntil { f.provider.order.contains(CatalogSection.LIVE_TV) }
        f.loader.prioritize(source.id, CatalogSection.SERIES)
        waitUntil { "SERIES" !in f.dao.pendingSections(source.id, gen) }
        assertTrue(f.provider.cancelled.contains(CatalogSection.LIVE_TV))
        assertTrue("LIVE_TV" in f.dao.pendingSections(source.id, gen))
        assertEquals(gen, f.manager.getActiveGenerationId(source.id))
    }
    @Test fun failedMovieStageDoesNotPublishHalfACatalog() = fixture { f ->
        f.provider.fail = CatalogSection.MOVIES
        val gen = f.loader.open(source, f.dir)
        waitUntil { f.loader.errors.value[source.id]?.containsKey(CatalogSection.MOVIES) == true }
        assertEquals(0, f.dao.getMovieCount(source.id, gen))
        assertTrue("MOVIES" in f.dao.pendingSections(source.id, gen))
        waitUntil { "SERIES" !in f.dao.pendingSections(source.id, gen) }
        assertEquals(0, f.fallbacks)
    }
    @Test fun completeCacheNeverDownloadsAgain() = fixture { f ->
        val gen = f.manager.beginImport(source.id)
        f.manager.markImportReady(source.id, gen)
        f.manager.activateReadyGenerationOnStartup(source.id)
        assertEquals(gen, f.loader.open(source, f.dir))
        delay(50)
        assertEquals(0, f.provider.auth)
        assertEquals(0, f.client.calls)
    }
    @Test fun interruptedImportResumesOnlyMissingSections() = fixture { f ->
        f.provider.hold = setOf(CatalogSection.LIVE_TV)
        val gen = f.loader.open(source, f.dir)
        f.loader.prioritize(source.id, CatalogSection.MOVIES)
        waitUntil { "MOVIES" !in f.dao.pendingSections(source.id, gen) }
        f.loader.stop()
        val movieCalls = f.provider.order.count { it == CatalogSection.MOVIES }
        f.provider.hold = emptySet()
        assertEquals(gen, f.loader.open(source, f.dir))
        waitUntil { f.dao.pendingSections(source.id, gen).isEmpty() }
        assertEquals(movieCalls, f.provider.order.count { it == CatalogSection.MOVIES })
        assertEquals(1, f.dao.getMovieCount(source.id, gen))
    }
    @Test fun m3uUsesOneDownloadAndKeepsAllKindsAndEpisodes() = fixture { f ->
        val m3u = PlaylistSource.M3u("m3u-sections-fixture", "Fixture", true, "https://example.invalid/list.m3u")
        val gen = f.loader.open(m3u, f.dir)
        f.loader.prioritize(m3u.id, CatalogSection.SERIES)
        waitUntil { f.dao.pendingSections(m3u.id, gen).isEmpty() }
        assertEquals(1, f.client.calls)
        assertEquals(1, f.dao.getMovieCount(m3u.id, gen))
        assertEquals(1, f.dao.getSeriesCount(m3u.id, gen))
        assertEquals(1, f.dao.getChannelCount(m3u.id, gen))
        // Compare identifiers and episode mapping against the original full importer.
        val old = f.importer.import("m3u-reference", m3u.playlistUrl)
        val progressiveSeries = f.dao.streamSeriesStage(m3u.id, gen, 10, -1).single()
        val referenceSeries = f.dao.streamSeriesStage("m3u-reference", old, 10, -1).single()
        assertEquals(referenceSeries.seriesId, progressiveSeries.seriesId)
        assertEquals(1, f.dao.getEpisodesPage(m3u.id, gen, progressiveSeries.seriesId, 10, 0).size)
    }
    @Test fun invalidM3uReportsFailureWithoutPublishingSections() = fixture { f ->
        f.client.payload = listOf("<html>Provider error</html>")
        val m3u = PlaylistSource.M3u("bad-m3u", "Fixture", true, "https://example.invalid/list.m3u")
        val gen = f.loader.open(m3u, f.dir)
        waitUntil { f.loader.errors.value[m3u.id]?.size == 3 }
        assertEquals(3, f.dao.pendingSections(m3u.id, gen).size)
        assertEquals(0, f.dao.getMovieCount(m3u.id, gen))
    }
    @Test fun publicationConflictRollsBackCategoriesAndKeepsSectionPending() = fixture { f ->
        val parent = f.manager.prepareSectionShell(source.id)
        val stage = f.manager.beginImport(source.id)
        val writer = XtreamCatalogWriter(f.dao, f.manager, source.id, parent)
        val movie = Movie("duplicate", "Movie", null, null, null, "https://example.invalid/movie.mp4", null, null, null)
        writer.append("get_vod_streams", PlaylistContent(movies = listOf(movie)))
        val stageWriter = XtreamCatalogWriter(f.dao, f.manager, source.id, stage)
        stageWriter.append("get_vod_streams", PlaylistContent(movies = listOf(movie), categories = listOf(
            Category("category", "Movies", CategoryType.MOVIES, CategorySource.PROVIDER))))
        try { f.dao.publishSection(source.id, stage, parent, "MOVIES"); fail() }
        catch (_: android.database.sqlite.SQLiteConstraintException) { }
        assertEquals(3, f.dao.pendingSections(source.id, parent).size)
        assertTrue(f.dao.getCategoriesByType(source.id, parent, "MOVIES").isEmpty())
        assertEquals(1, f.dao.getCategoriesByType(source.id, stage, "MOVIES").size)
        assertEquals(1, f.dao.getMovieCount(source.id, stage))
        assertEquals(1, f.dao.getMovieCount(source.id, parent))
        f.manager.discardImport(source.id, stage)
    }
    @Test fun migrationPreservesExistingActiveCatalog() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        val name = "section-migration-" + UUID.randomUUID() + ".db"
        var db = Room.databaseBuilder(context, PlaylistCacheDatabase::class.java, name).build()
        try {
            val manager = PlaylistCacheGenerationManager(db.playlistCacheDao())
            val gen = manager.beginImport(source.id)
            manager.markImportReady(source.id, gen)
            manager.activateReadyGenerationOnStartup(source.id)
            db.openHelper.writableDatabase.execSQL("DROP TABLE cached_sections")
            db.openHelper.writableDatabase.execSQL("PRAGMA user_version=4")
            db.close()
            db = Room.databaseBuilder(context, PlaylistCacheDatabase::class.java, name).addMigrations(PlaylistCacheDatabase.MIGRATION_4_5).build()
            assertEquals(gen, db.playlistCacheDao().getActiveGeneration(source.id)?.generationId)
            assertTrue(db.playlistCacheDao().pendingSections(source.id, gen).isEmpty())
        } finally { db.close(); context.deleteDatabase(name) }
    }
    @Test fun configureMode() {
        val argument = InstrumentationRegistry.getArguments().getString("catalog_sections_enabled") ?: return
        val enabled = when (argument) { "true" -> true; "false" -> false; else -> error("Invalid mode") }
        val context = ApplicationProvider.getApplicationContext<android.content.Context>()
        SectionCatalogMode.setEnabled(context, enabled)
        assertEquals(enabled, SectionCatalogMode.enabled(context))
        println("CATALOGO_POR_SECOES=" + if (enabled) "ATIVADO" else "DESATIVADO")
    }
}
