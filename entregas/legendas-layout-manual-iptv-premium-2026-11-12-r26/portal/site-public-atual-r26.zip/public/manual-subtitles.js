export function createManualSubtitlePortal({$,api,target,getAccount}) {
 let request=null,timer=null,ticket=0,controller=null,bound='',sending=false,errorMessage='';
 const path=(route,id=null,name=null)=>{const u=new URL(target(route),location.origin);if(id)u.searchParams.set('id',id);if(name)u.searchParams.set('name',name);return u.pathname+u.search;};
 function pause(){clearTimeout(timer);timer=null;ticket++;controller?.abort();controller=null;sending=false;}
 function wipe(){pause();request=null;bound='';errorMessage='';$('manual-file').value='';render();}
 function render(){
  const account=getAccount();$('manual-tv').textContent=account?.label||'—';
  $('manual-title').textContent=request?.target?.title||'Aguardando escolha na TV';
  const t=request?.target;
  $('manual-target').textContent=!t?'Escolha o conteúdo no aplicativo.':t.kind==='movie'?'Filme':t.kind==='season'?`Temporada ${t.season} · ${t.episodes.length} episódios`:`Temporada ${t.season} · Episódio ${t.episode}`;
  const labels={waiting:'Conectado à TV · selecione o arquivo',uploading:'Recebendo o arquivo no site…',ready:'Arquivo enviado · confira e salve na TV',received:'Legenda recebida pela TV',cancelled:'Pedido cancelado ou substituído na TV',expired:'O pedido expirou. Inicie outro na TV.'};
  $('manual-status').textContent=errorMessage||(request?(request.message||labels[request.state]||'Consultando a TV…'):'Na TV, abra Configurações → Legendas → Envio manual e escolha filme, temporada ou episódio. Depois, selecione Conectar para enviar.');
  $('manual-upload-form').hidden=!request||request.state!=='waiting';
  $('manual-file').disabled=sending;$('manual-send').disabled=sending;
  $('manual-send').textContent=sending?'Enviando…':'Enviar para a TV';
  $('manual-saved-count').textContent=request?.state==='received'?`${request.receivedCount} legenda(s) salva(s). Você já pode escolher “Legenda manual” no player.`:'';
 }
 function bind(account){if(account?.id!==bound){wipe();bound=account?.id||'';}}
 async function load(id=null){
  const account=getAccount();if(!account||document.hidden||$('manual-settings').hidden)return;
  bind(account);clearTimeout(timer);const generation=++ticket,owner=account.id;
  try{
   const data=await api(path('/api/manual-subtitles/request',id||request?.id));
   if(generation!==ticket||getAccount()?.id!==owner)return;
   request=data.request;errorMessage='';render();
   if(request&&['waiting','uploading','ready'].includes(request.state))timer=setTimeout(()=>load(request.id),5000);
  }catch(error){if(generation===ticket){$('manual-status').textContent=error.message;$('manual-upload-form').hidden=true;}}
 }
 $('manual-refresh').onclick=()=>{request=null;load();};
 $('manual-upload-form').onsubmit=async event=>{
  event.preventDefault();if(sending||request?.state!=='waiting')return;
  const file=$('manual-file').files[0];
  if(!file||!/\.(srt|zip)$/i.test(file.name)||file.size<1||file.size>8*1024*1024){$('manual-status').textContent='Selecione SRT ou ZIP de até 8 MB.';return;}
  if(/\.srt$/i.test(file.name)&&file.size>1024*1024){$('manual-status').textContent='Cada SRT deve ter até 1 MB.';return;}
  clearTimeout(timer);const generation=++ticket,owner=getAccount()?.id,id=request.id;
  controller=new AbortController();sending=true;render();$('manual-status').textContent='Enviando o arquivo para a TV selecionada…';
  try{
   await api(path('/api/manual-subtitles/upload',id,file.name),{method:'POST',body:file,headers:{'Content-Type':'application/octet-stream'},signal:controller.signal});
   if(generation!==ticket||getAccount()?.id!==owner)return;
   $('manual-file').value='';sending=false;await load(id);
  }catch(error){if(generation===ticket){sending=false;errorMessage=error.message;render();}}
  finally{if(generation===ticket){sending=false;controller=null;render();}}
 };
 document.addEventListener('visibilitychange',()=>{if(document.hidden){clearTimeout(timer);timer=null;}else if(!$('manual-settings').hidden)load();});
 window.addEventListener('pagehide',wipe);
 return {open:(id=null)=>load(id),pause,wipe,bind};
}
