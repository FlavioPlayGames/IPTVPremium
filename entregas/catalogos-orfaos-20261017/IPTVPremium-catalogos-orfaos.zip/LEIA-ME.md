# Catálogos sem lista cadastrada

Este complemento requer o primeiro pacote de armazenamento já aplicado. Corrige a falta de conciliação entre os IDs do catálogo e os IDs das listas cadastradas. A remoção pelo portal alterava as preferências sem garantir a remoção do catálogo local.

A manutenção lê o cadastro de maneira estrita, sob a mesma serialização usada pelas alterações locais e do portal. Cadastro ausente ou inválido suspende a limpeza de órfãos. Listas desativadas também são preservadas, assim como o ID selecionado, pedidos de carregamento pendentes e importações em andamento.

Somente gerações ACTIVE de IDs ausentes desse conjunto de proteção, cuja última ativação tenha mais de 15 minutos, são marcadas STALE para a limpeza existente em lotes. READY não é removida por esta conciliação. A guarda de importação compartilha um mutex com o início das importações. As preferências não são modificadas pela conferência.

Nada muda no visual, player, teclado, credenciais, favoritos, histórico ou sincronização de rede. Não há VACUUM automático. A remoção de registros pode aumentar as páginas livres sem reduzir imediatamente o arquivo SQLite.

Após compilar, atualize o aplicativo por cima da instalação atual, abra e aguarde a limpeza. Execute Medir-armazenamento.ps1 -Serial CODIGO_DO_CELULAR e envie o relatório. A linha phase=registry informa registered_lists, catalog_playlists, unregistered_catalogs e retired_generations, sem divulgar IDs ou nomes. phase=after informa o término da passagem; db_free_pages indica espaço reutilizável.

Validação: assembleDebug aprovado; 8 cenários do gerenciador real com persistência simulada; 5 cenários do parser do cadastro; consulta de aposentadoria testada no SQLite com listas válidas/desativadas/pendentes/em importação, órfãs, recentes, READY e IMPORTING. Testes do instalador e do comando PowerShell descritos na entrega. Ainda não medido no telefone.
