package br.com.flaviotorres.iptvpremium.core.storage
fun main() {
    var count = 0
    fun test(name: String, block: () -> Unit) { block(); count++; println("PASS $name") }
    test("registered, disabled and unknown types retain their IDs") {
        check(RegisteredCatalogIds.parse("""[{"id":"a"},{"id":"b","isEnabled":false},{"id":"future","type":"future"}]""",null,null) == setOf("a","b","future"))
    }
    test("active selection and pending portal operation remain protected") {
        check(RegisteredCatalogIds.parse("[]","active","""{"id":"pending"}""") == setOf("active","pending"))
    }
    test("explicit empty registry is valid") { check(RegisteredCatalogIds.parse("[]",null,null).isEmpty()) }
    test("missing blank or corrupt registry fails closed") {
        for (raw in listOf(null,"","bad","{}","[{}]","[null]","[{\"id\":1}]","[{\"id\":\"\"}]")) {
            check(runCatching { RegisteredCatalogIds.parse(raw,null,null) }.isFailure)
        }
    }
    test("partial or invalid pending operation fails closed") {
        for (pending in listOf("bad","{}","{\"id\":5}")) {
            check(runCatching { RegisteredCatalogIds.parse("[]",null,pending) }.isFailure)
        }
    }
    println("$count registry scenarios passed")
}
