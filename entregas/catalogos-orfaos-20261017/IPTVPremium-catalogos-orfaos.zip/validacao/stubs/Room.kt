package androidx.room
annotation class Dao
annotation class Entity(val tableName: String = "", val primaryKeys: Array<String> = [], val indices: Array<Index> = [])
annotation class Index(val value: Array<String>, val name: String = "", val unique: Boolean = false)
annotation class Query(val value: String)
annotation class Insert(val onConflict: Int = 0)
annotation class Transaction
object OnConflictStrategy { const val REPLACE = 1 }
