package android.util
object Log { fun d(tag: String, msg: String) = 0; fun i(tag: String, msg: String) = 0 }
