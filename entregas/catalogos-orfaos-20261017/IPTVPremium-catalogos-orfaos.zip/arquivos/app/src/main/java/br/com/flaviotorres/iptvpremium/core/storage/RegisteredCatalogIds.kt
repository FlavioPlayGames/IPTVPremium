package br.com.flaviotorres.iptvpremium.core.storage

import org.json.JSONArray
import org.json.JSONObject

/** Fail closed: an unreadable registry is never treated as an empty list. */
internal object RegisteredCatalogIds {
    fun parse(raw: String?, activeId: String?, pendingRequest: String?): Set<String> {
        check(!raw.isNullOrBlank()) { "Registry unavailable" }
        val array = JSONArray(raw)
        val ids = mutableSetOf<String>()
        for (index in 0 until array.length()) {
            val entry = array.getJSONObject(index)
            val id = entry.get("id")
            check(id is String && id.isNotBlank()) { "Invalid registry identity" }
            ids.add(id)
        }
        activeId?.takeIf { it.isNotBlank() }?.let(ids::add)
        if (pendingRequest != null) {
            val id = JSONObject(pendingRequest).get("id")
            check(id is String && id.isNotBlank()) { "Invalid pending identity" }
            ids.add(id)
        }
        return ids
    }
}
