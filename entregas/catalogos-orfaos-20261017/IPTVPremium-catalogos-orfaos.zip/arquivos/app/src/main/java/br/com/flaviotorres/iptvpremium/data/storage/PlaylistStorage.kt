package br.com.flaviotorres.iptvpremium.data.storage

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.playlistDataStore by preferencesDataStore(
    name = "playlist_storage"
)

class PlaylistStorage(
    private val context: Context
) {

    private val playlistsKey =
        stringPreferencesKey("playlists")

    private val activePlaylistIdKey =
        stringPreferencesKey("active_playlist_id")

    private val portalLoadKey = stringPreferencesKey("portal_load_request")
    data class Selection(val playlists: List<PlaylistSource>, val activeId: String?, val loadRequest: String?)
    // One emission for all three values: never combine an old active ID with a new list.
    val selection: Flow<Selection> = context.playlistDataStore.data.map { preferences ->
        Selection(decodePlaylists(preferences[playlistsKey].orEmpty()),
            preferences[activePlaylistIdKey]?.takeIf { it.isNotBlank() }, preferences[portalLoadKey])
    }
    /** Serialize the registry check with all local/portal edits. Never modifies preferences. */
    internal suspend fun withProtectedCatalogIds(action: suspend (Set<String>, Int) -> Unit) {
        context.playlistDataStore.edit { preferences ->
            val raw = preferences[playlistsKey]
            val protected = br.com.flaviotorres.iptvpremium.core.storage.RegisteredCatalogIds.parse(
                raw, preferences[activePlaylistIdKey], preferences[portalLoadKey]
            )
            action(protected, JSONArray(raw).length())
        }
    }

    suspend fun requestActiveCatalogLoad() {
        context.playlistDataStore.edit { preferences ->
            val id = preferences[activePlaylistIdKey] ?: return@edit
            if (decodePlaylists(preferences[playlistsKey].orEmpty()).none { it.id == id && it.isEnabled }) return@edit
            if (preferences[portalLoadKey] == null) preferences[portalLoadKey] = JSONObject().put("id", id)
                .put("request", java.util.UUID.randomUUID().toString()).toString()
        }
    }

    val portalLoadRequest: Flow<String?> = context.playlistDataStore.data.map { it[portalLoadKey] }

    suspend fun finishPortalLoad(request: String) {
        context.playlistDataStore.edit { preferences ->
            if (preferences[portalLoadKey] == request) preferences.remove(portalLoadKey)
        }
    }

    val playlists: Flow<List<PlaylistSource>> =
        context.playlistDataStore.data.map { preferences ->
            decodePlaylists(
                preferences[playlistsKey]
                    .orEmpty()
            )
        }

    val activePlaylistId: Flow<String?> =
        context.playlistDataStore.data.map { preferences ->
            preferences[activePlaylistIdKey]
                ?.takeIf { it.isNotBlank() }
        }

    suspend fun savePlaylists(
        playlists: List<PlaylistSource>
    ) {
        context.playlistDataStore.edit { preferences ->
            preferences[playlistsKey] =
                encodePlaylists(playlists)
        }
    }

    /** Apply a portal snapshot only if no local edit happened during its network request. */
    suspend fun applyPortalSnapshot(expected: List<PlaylistSource>, remote: List<PlaylistSource>): Boolean {
        var applied = false
        context.playlistDataStore.edit { preferences ->
            if (decodePlaylists(preferences[playlistsKey].orEmpty()) == expected) {
                preferences[playlistsKey] = encodePlaylists(remote)
                val active = preferences[activePlaylistIdKey]
                if (remote.none { it.id == active }) {
                    remote.firstOrNull { it.isEnabled }?.id?.let { preferences[activePlaylistIdKey] = it }
                        ?: preferences.remove(activePlaylistIdKey)
                }
                applied = true
            }
        }
        return applied
    }

    /** Apply one portal operation atomically against the latest local lists. */
    suspend fun applyPortalOperation(id: String, source: PlaylistSource?) {
        context.playlistDataStore.edit { preferences ->
            val current = decodePlaylists(preferences[playlistsKey].orEmpty())
            val next = if (source == null) current.filterNot { it.id == id }
                else if (current.any { it.id == id }) current.map { if (it.id == id) source else it }
                else current + source
            require(next.size <= 30)
            preferences[playlistsKey] = encodePlaylists(next)
            if (source != null && source.isEnabled) {
                preferences[activePlaylistIdKey] = id
                preferences[portalLoadKey] = JSONObject().put("id", id)
                    .put("request", java.util.UUID.randomUUID().toString()).toString()
            } else if (source == null) {
                val pending = preferences[portalLoadKey]
                if (pending != null && runCatching { JSONObject(pending).optString("id") == id }.getOrDefault(false)) {
                    preferences.remove(portalLoadKey)
                }
            }
            val active = preferences[activePlaylistIdKey]
            if (next.none { it.id == active }) {
                next.firstOrNull { it.isEnabled }?.id?.let { preferences[activePlaylistIdKey] = it }
                    ?: preferences.remove(activePlaylistIdKey)
            }
        }
    }

    suspend fun saveActivePlaylistId(
        playlistId: String?
    ) {
        context.playlistDataStore.edit { preferences ->
            if (playlistId.isNullOrBlank()) {
                preferences.remove(
                    activePlaylistIdKey
                )
            } else {
                preferences[activePlaylistIdKey] =
                    playlistId
            }
        }
    }

    suspend fun clear() {
        context.playlistDataStore.edit { preferences ->
            preferences.remove(playlistsKey)
            preferences.remove(activePlaylistIdKey)
            preferences.remove(portalLoadKey)
        }
    }

    private fun encodePlaylists(
        playlists: List<PlaylistSource>
    ): String {
        val array = JSONArray()

        playlists.forEach { playlist ->
            val item = JSONObject()

            item.put(
                "id",
                playlist.id
            )

            item.put(
                "name",
                playlist.name
            )

            item.put(
                "isEnabled",
                playlist.isEnabled
            )

            when (playlist) {
                is PlaylistSource.XtreamCodes -> {
                    item.put(
                        "type",
                        "xtream"
                    )

                    item.put(
                        "serverUrl",
                        playlist.serverUrl
                    )

                    item.put(
                        "username",
                        playlist.username
                    )

                    item.put(
                        "password",
                        playlist.password
                    )
                }

                is PlaylistSource.M3u -> {
                    item.put(
                        "type",
                        "m3u"
                    )

                    item.put(
                        "playlistUrl",
                        playlist.playlistUrl
                    )
                }
            }

            array.put(item)
        }

        return array.toString()
    }

    private fun decodePlaylists(
        raw: String
    ): List<PlaylistSource> {
        if (raw.isBlank()) {
            return emptyList()
        }

        return runCatching {
            val array = JSONArray(raw)

            buildList {
                for (
                index in 0 until array.length()
                ) {
                    val item =
                        array.optJSONObject(index)
                            ?: continue

                    val id =
                        item.optString("id")

                    val name =
                        item.optString("name")

                    val isEnabled =
                        item.optBoolean(
                            "isEnabled",
                            true
                        )

                    when (
                        item.optString("type")
                    ) {
                        "xtream" -> {
                            add(
                                PlaylistSource.XtreamCodes(
                                    id = id,
                                    name = name,
                                    isEnabled = isEnabled,
                                    serverUrl =
                                        item.optString(
                                            "serverUrl"
                                        ),
                                    username =
                                        item.optString(
                                            "username"
                                        ),
                                    password =
                                        item.optString(
                                            "password"
                                        )
                                )
                            )
                        }

                        "m3u" -> {
                            add(
                                PlaylistSource.M3u(
                                    id = id,
                                    name = name,
                                    isEnabled = isEnabled,
                                    playlistUrl =
                                        item.optString(
                                            "playlistUrl"
                                        )
                                )
                            )
                        }
                    }
                }
            }
        }.getOrElse {
            emptyList()
        }
    }
}
// IPTV_PORTAL_PRODUCTION_V1

// IPTV_SUBTITLE_LAYOUT_PORTAL_LOAD_V1

// IPTV_LIST_LOADING_AND_PLAYER_INPUT_V1
