﻿[CmdletBinding()]
param(
    [Alias('Tv')][string]$Serial = '',
    [string]$Adb = "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe",
    [string]$Saida = "$env:USERPROFILE\Downloads\IPTV-desempenho-r16.txt",
    [switch]$AoVivo
)
$ErrorActionPreference = 'Stop'
if (!(Test-Path -LiteralPath $Adb -PathType Leaf)) { throw "ADB nao encontrado: $Adb" }
function Ler-Adb([string[]]$Argumentos) {
    $anterior=$ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        $linhas=@(& $Adb @Argumentos 2>&1)
        $codigo=$LASTEXITCODE
    } finally { $ErrorActionPreference=$anterior }
    if($codigo -ne 0){throw 'Falha ao consultar o ADB.'}
    $linhas | ForEach-Object { "$_" }
}
$conectados=@(Ler-Adb -Argumentos @('devices','-l') | ForEach-Object {
    if($_ -match '^(\S+)\s+device(?:\s+(.*))?$') {[PSCustomObject]@{Serial=$Matches[1];Detalhes=[string]$Matches[2]}}
})
if([string]::IsNullOrWhiteSpace($Serial)) {
    $tv=@($conectados | Where-Object {$_.Detalhes -match '(?:^|\s)(?:model:Smart_TV_Pro|product:G08_4K_GB|device:G08)(?:\s|$)'})
    if($tv.Count -eq 1){$Serial=$tv[0].Serial}
    elseif($tv.Count -eq 0 -and $conectados.Count -eq 1){$Serial=$conectados[0].Serial}
    else{throw 'Nao foi possivel escolher uma unica TV autorizada. Confira adb devices -l ou informe -Serial.'}
}
if($Serial -notmatch '^[A-Za-z0-9._:-]+$' -or @($conectados | Where-Object {$_.Serial -eq $Serial}).Count -ne 1){throw 'TV nao conectada/autorizada.'}

function Testar-Desempenho([string]$Linha) {
    $Linha -cmatch '^kind=MOVIES stage=data remote=(?:true|false) roomMs=[0-9]+ remoteMs=[0-9]+$' -or
    $Linha -cmatch '^kind=MOVIES stage=artwork ready=(?:true|false) elapsedMs=[0-9]+$' -or
    $Linha -cmatch '^kind=SERIES stage=data ready=(?:true|false) episodes=[0-9]+ elapsedMs=[0-9]+$' -or
    $Linha -cmatch '^phase=(?:before|after) source=(?:android|estimate) appBytes=[0-9]+ dataBytes=[0-9]+ cacheIncludedBytes=[0-9]+ managedCacheBytes=[0-9]+ totalBytes=[0-9]+ targetBytes=400000000 overTargetBytes=[0-9]+ apkBytes=[0-9]+ nativeBytes=[0-9]+ cacheAllowanceBytes=[0-9]+$' -or
    $Linha -cmatch '^phase=(?:before|after) databases=[0-9]+ files=[0-9]+ preferences=[0-9]+ no_backup=[0-9]+ cache_total=[0-9]+ code_cache=[0-9]+ posters=[0-9]+ details_home=[0-9]+ updates=[0-9]+ subtitles=[0-9]+$' -or
    $Linha -cmatch '^phase=(?:before|after) db_main=[0-9]+ db_wal=[0-9]+ db_pages=[0-9]+ db_free_pages=[0-9]+ db_page_size=[0-9]+ generations_active=[0-9]+ generations_ready=[0-9]+ generations_stale=[0-9]+ generations_importing=[0-9]+$' -or
    $Linha -cmatch '^endpoint=get_vod_info escopo=(?:completo|categoria) httpMs=-?[0-9]+ parsingMs=-?[0-9]+ totalMs=[0-9]+ fase=(?:http|parsing) status=(?:OK|FALHA|CANCELADO) erro=[A-Za-z0-9_$]+$' -or
    $Linha -cmatch '^phase=waiting reason=(?:opening|import|media|grace|user_activity|eligible) opening=(?:true|false) importing=(?:true|false) mediaBusy=(?:true|false) userIdle=(?:true|false) foreground=(?:true|false) graceMs=[0-9]+$' -or
    $Linha -cmatch '^durationMs=[0-9]+ beforeBytes=[0-9]+ afterBytes=[0-9]+ totalDeltaBytes=-?[0-9]+ managedCacheDeltaBytes=-?[0-9]+ cacheAllowanceBytes=[0-9]+ restoredCacheAllowanceBytes=[0-9]+ targetBytes=400000000$'
}
function Salvar-Ram {
    $ram=@(Ler-Adb -Argumentos @('-s',$Serial,'shell','dumpsys','meminfo','br.com.flaviotorres.iptvpremium'))
    foreach($linha in $ram) {
        if($linha -match '^\s*(TOTAL PSS|TOTAL RSS|TOTAL SWAP PSS|Native Heap|Java Heap|Graphics):\s*([0-9]+)(?:\s.*)?$') {
            $campo=$Matches[1].ToLowerInvariant().Replace(' ','_')
            Add-Content -LiteralPath $Saida -Value "ram_${campo}_kb=$($Matches[2])" -Encoding UTF8
        } elseif($linha -match '^\s*TOTAL\s+([0-9]+)\s+[0-9]+\s+[0-9]+(?:\s.*)?$') {
            Add-Content -LiteralPath $Saida -Value "ram_total_pss_legacy_kb=$($Matches[1])" -Encoding UTF8
        }
    }
}
Set-Content -LiteralPath $Saida -Value 'diagnostico=r16 unidade_disco=bytes unidade_ram=kb' -Encoding UTF8
Salvar-Ram
$argumentos=@('-s',$Serial,'logcat','-v','raw','-s','ContentOpeningPerf:I','XtreamEndpointPerf:I','IPTVStorage:I','AppStoragePerf:I','StorageMaintenancePerf:I','StorageCleanupPerf:I','*:S')
if(!$AoVivo){$argumentos=@('-s',$Serial,'logcat','-d','-v','raw','-s','ContentOpeningPerf:I','XtreamEndpointPerf:I','IPTVStorage:I','AppStoragePerf:I','StorageMaintenancePerf:I','StorageCleanupPerf:I','*:S')}
if($AoVivo){Write-Host 'Coleta ativa. Abra filmes e series; depois volte a Home e deixe 90 segundos sem navegar. Ctrl+C encerra.'}
try {
    & $Adb @argumentos 2>$null | ForEach-Object {
        $linha="$_"
        if(Testar-Desempenho $linha){Add-Content -LiteralPath $Saida -Value $linha -Encoding UTF8;if($AoVivo){Write-Host $linha}}
    }
    if($LASTEXITCODE -ne 0){throw 'Falha ao consultar logcat.'}
} finally {
    Write-Host "Diagnostico salvo em: $Saida"
}
