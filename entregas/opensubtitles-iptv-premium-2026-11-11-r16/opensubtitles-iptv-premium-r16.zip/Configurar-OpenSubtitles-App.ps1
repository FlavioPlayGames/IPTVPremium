[CmdletBinding()]
param(
    [string]$Projeto="$env:USERPROFILE\AndroidStudioProjects\IPTVPremium",
    [string]$UserAgent='IPTVPremium v1.13'
)
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Seguranca.ps1"
$Projeto=Projeto-Valido $Projeto
if($UserAgent.Length -lt 3 -or $UserAgent.Length -gt 200 -or @($UserAgent.ToCharArray() | Where-Object {[char]::IsControl($_)}).Count -gt 0){throw 'User-Agent invalido. Use o valor registrado para seu aplicativo.'}
$relativo='app/src/desempenho/res/values/opensubtitles-private.xml'
$destino=Caminho-Seguro $Projeto $relativo
if((Test-Path -LiteralPath $destino) -and !(Test-Path -LiteralPath $destino -PathType Leaf)){throw 'Destino privado inesperado.'}
$ignore=Caminho-Seguro $Projeto '.gitignore'
if((Test-Path -LiteralPath $ignore) -and !(Test-Path -LiteralPath $ignore -PathType Leaf)){throw 'Destino .gitignore inesperado.'}
$regra='/app/src/*/res/values/opensubtitles-private.xml*'
$texto=if(Test-Path -LiteralPath $ignore){[IO.File]::ReadAllText($ignore)}else{''}
if($texto.Split([char]10) -notcontains $regra){[IO.File]::AppendAllText($ignore,[Environment]::NewLine+$regra+[Environment]::NewLine,(New-Object Text.UTF8Encoding($false)))}
$segura=Read-Host 'Cole a chave TECNICA do API Consumer OpenSubtitles (entrada oculta)' -AsSecureString
$ponteiro=[IntPtr]::Zero
$temporario=$null
try {
    $ponteiro=[Runtime.InteropServices.Marshal]::SecureStringToBSTR($segura)
    $chave=[Runtime.InteropServices.Marshal]::PtrToStringBSTR($ponteiro)
    if($chave.Length -lt 8 -or $chave.Length -gt 512 -or @($chave.ToCharArray() | Where-Object {[char]::IsWhiteSpace($_) -or [char]::IsControl($_)}).Count -gt 0 -or $chave -in @('CHAVE_DO_APLICATIVO','SUA_CHAVE_AQUI','OPENSUBTITLES_API_KEY')){throw 'Chave tecnica incompleta ou invalida. Nenhuma configuracao privada foi gravada.'}
    if(Test-Path -LiteralPath $destino -PathType Leaf) {
        $settings=New-Object Xml.XmlReaderSettings
        $settings.DtdProcessing=[Xml.DtdProcessing]::Prohibit
        $settings.XmlResolver=$null
        $reader=[Xml.XmlReader]::Create($destino,$settings)
        try {$documento=New-Object Xml.XmlDocument;$documento.XmlResolver=$null;$documento.Load($reader)} finally {$reader.Dispose()}
        $keyNode=$documento.SelectSingleNode("/resources/string[@name='opensubtitles_api_key']")
        $agentNode=$documento.SelectSingleNode("/resources/string[@name='opensubtitles_user_agent']")
        if($keyNode.InnerText -ceq $chave -and $agentNode.InnerText -ceq $UserAgent){Write-Host 'Configuracao privada ja corresponde aos valores informados.';return}
        throw 'Ja existe uma configuracao privada diferente. Ela foi preservada. Confira o arquivo localmente antes de substituir.'
    }
    New-Item -ItemType Directory -Path (Split-Path $destino) -Force | Out-Null
    $temporario=Caminho-Seguro $Projeto ($relativo+'.'+[Guid]::NewGuid().ToString('N')+'.tmp')
    $settings=New-Object Xml.XmlWriterSettings
    $settings.Encoding=New-Object Text.UTF8Encoding($false)
    $settings.Indent=$true
    $writer=[Xml.XmlWriter]::Create($temporario,$settings)
    try {
        $writer.WriteStartDocument();$writer.WriteStartElement('resources')
        foreach($item in @(@('opensubtitles_api_key',$chave),@('opensubtitles_user_agent',$UserAgent))) {
            $writer.WriteStartElement('string');$writer.WriteAttributeString('name',[string]$item[0]);$writer.WriteAttributeString('translatable','false');$writer.WriteString([string]$item[1]);$writer.WriteEndElement()
        }
        $writer.WriteEndElement();$writer.WriteEndDocument()
    } finally {$writer.Dispose()}
    [IO.File]::Move($temporario,$destino)
    $temporario=$null
    Write-Host 'Configuracao privada criada para a variante desempenho e excluida pelo .gitignore.'
    Write-Host 'Este comando nao valida a chave no servico nem configura o servidor. Use a mesma chave e User-Agent nos segredos Cloudflare; depois compile/instale o app.'
} finally {
    if($temporario -and (Test-Path -LiteralPath $temporario -PathType Leaf)){Remove-Item -LiteralPath $temporario -Force}
    if($ponteiro -ne [IntPtr]::Zero){[Runtime.InteropServices.Marshal]::ZeroFreeBSTR($ponteiro)}
    $chave=$null
    if($null -ne $segura){$segura.Dispose()}
}
