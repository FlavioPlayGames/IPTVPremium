package br.com.flaviotorres.iptvpremium.core.player
import org.json.JSONObject
private class SessionAccounts:OpenSubtitleAccounts {
 var stored:OpenSubtitleSession?=null;var seq=0L
 override fun generation()=seq
 override fun read()=stored
 override fun save(token:String,base:String,expiresAt:Long,appFingerprint:String,expectedGeneration:Long,accountScope:String):Boolean {
  if(expectedGeneration!=seq)return false
  stored=OpenSubtitleSession(token,base,accountScope,expiresAt,appFingerprint);seq++;return true
 }
 override fun disconnect(expectedToken:String?):Boolean {stored=null;seq++;return true}
}
fun main(args:Array<String>) {
 val data=JSONObject(java.io.File(args[0]).readText())
 val accounts=SessionAccounts();val open=OpenSubtitlesClient({OpenSubtitleAppConfig("test-open-application-key","IPTVPremium v1.13")},accounts)
 val original=SubtitleProviderUpdates.revision.value
 receiveSession(open,data)
 check(open.connected()&&SubtitleProviderUpdates.revision.value==original+1)
 val accepted=accounts.stored
 for(invalid in listOf(JSONObject(data.toString()).put("provider","other"),JSONObject(data.toString()).put("appFingerprint","f".repeat(64)))) {
  check(runCatching{receiveSession(open,invalid)}.isFailure)
  check(SubtitleProviderUpdates.revision.value==original+1&&accounts.stored===accepted)
 }
 println("PASS: actual portal-session handler saves valid session before publishing provider update; rejected sessions do not notify or change saved account")
}
