"""Test current server in memory, then current app protocol against its fake delivery. No production API or TV writes."""
from pathlib import Path
import argparse,os,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--projeto',type=Path,required=True);p.add_argument('--site',type=Path,required=True);p.add_argument('--tools',type=Path,required=True);p.add_argument('--java',default='java');a=p.parse_args()
r=a.projeto/'app/src/main/java/br/com/flaviotorres/iptvpremium';f=Path(__file__).parent
ns=['kotlin-compiler-embeddable-2.2.10.jar','kotlin-stdlib-2.2.10.jar','kotlin-script-runtime-2.2.10.jar','kotlin-reflect-1.6.10.jar','kotlin-daemon-embeddable-2.2.10.jar','kotlinx-coroutines-core-jvm-1.8.0.jar','annotations-13.0.jar','json-20250517.jar'];cp=os.pathsep.join(str(a.tools/n)for n in ns)
with tempfile.TemporaryDirectory(prefix='iptv-open-test-')as td:
 w=Path(td);fixture=w/'delivery.json'
 subprocess.run(['node',str(f/'Testar-Servidor.mjs'),str(a.site),str(fixture)],check=True)
 (w/'Verify.kt').write_text((f/'Verify.kt').read_text().replace('/workspace/legendas-duas-etapas/server-session-fixture.json',fixture.as_posix()))
 text=(r/'core/device/DevicePortalSync.kt').read_text();start=text.index('''                        "subtitle_session" -> {''');end=text.index('''                        "subtitle_key" -> {''',start);body=text[start:end];body=body[body.index('{')+1:body.rindex('}')]
 (w/'Receiver.kt').write_text('package br.com.flaviotorres.iptvpremium.core.player\nimport org.json.JSONObject\ninternal fun receiveSession(open:OpenSubtitlesClient,data:JSONObject){'+body+'\n}')
 files=[r/'core/navigation/player'/n for n in ['OpenSubtitlesProtocol.kt','OpenSubtitlesClient.kt','SubtitleProviderUpdates.kt']]+[w/'Verify.kt',w/'Receiver.kt',f/'Notificacao.kt'];jar=w/'protocol.jar'
 subprocess.run([a.java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',str(jar),*map(str,files)],check=True)
 for main in ['VerifyKt','NotificacaoKt']:subprocess.run([a.java,'-cp',str(jar)+os.pathsep+cp,'br.com.flaviotorres.iptvpremium.core.player.'+main,str(fixture)],check=True)
