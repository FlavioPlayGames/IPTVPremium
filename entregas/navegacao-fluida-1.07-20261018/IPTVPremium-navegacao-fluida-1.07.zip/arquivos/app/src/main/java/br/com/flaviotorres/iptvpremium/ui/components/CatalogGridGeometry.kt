package br.com.flaviotorres.iptvpremium.ui.components

/** Largest natural 2:3 poster that fits four cells and two complete rows. */
internal fun catalogTwoRowPosterWidth(width: Float, height: Float, columns: Int,
    spacing: Float, metadata: Float): Float {
    if (width <= 0 || height <= 0 || columns <= 0) return 0f
    val cellWidth = ((width - 16f - spacing * (columns - 1)) / columns).coerceAtLeast(0f)
    val posterHeight = ((height - 18f - spacing) / 2f - metadata).coerceAtLeast(0f)
    return minOf(cellWidth, posterHeight * (2f / 3f))
}
