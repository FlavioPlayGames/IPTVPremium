package br.com.flaviotorres.iptvpremium.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.input.key.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import br.com.flaviotorres.iptvpremium.data.cache.CatalogVerticalIntent
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first

/** Width belongs to the poster itself; surplus space is distributed between cells. */
internal val LocalCatalogPosterWidth = staticCompositionLocalOf { androidx.compose.ui.unit.Dp.Unspecified }
internal val LocalCatalogMetadataHeight = staticCompositionLocalOf { 34.dp }

/** One pending destination for repeated DPAD commands, including not-yet-composed rows. */
internal class CatalogGridNavigator(private val grid: LazyGridState, private val scope: CoroutineScope,
    private val columns: Int, private val count: () -> Int, private val load: (Int) -> Unit,
    private val manual: () -> Unit, private val onExitUp: (() -> Unit)? = null,
    private val onExitLeft: (() -> Unit)? = null) {
    private val requesters = mutableMapOf<Int, FocusRequester>()
    private val revision = MutableStateFlow(0L)
    private val intent = CatalogVerticalIntent(columns)
    private var job: Job? = null
    private var movementJob: Job? = null
    val host = FocusRequester()
    private var currentIndex = 0
    private var lastCount = -1
    private var transferring = false
    private var hostHasFocus = false
    var hasFocus by mutableStateOf(false)
        private set
    fun focusTreeChanged(containsFocus: Boolean) { hasFocus = containsFocus }
    fun hostFocusChanged(focused: Boolean) {
        hostHasFocus = focused
        if (!focused || transferring || job?.isActive == true || count() == 0) return
        val target = currentIndex.coerceIn(0, count() - 1)
        movementJob = null
        job = scope.launch {
            load(target)
            val ready = withTimeoutOrNull(2_500L) { revision.first { requesters[target] != null } }
            if (ready != null) {
                withFrameNanos { }
                ensureActive()
                if (hostHasFocus && currentIndex == target) requesters[target]?.requestFocus()
            }
        }
    }
    fun attach(index: Int, requester: FocusRequester) {
        requesters[index] = requester; revision.value++
        if (hostHasFocus) hostFocusChanged(true)
    }
    fun detach(index: Int, requester: FocusRequester) { if (requesters[index] === requester) requesters.remove(index) }
    fun focused(index: Int) {
        // A late focus event from a previous row cannot replace the current command.
        if (intent.desired == null || intent.desired == index) currentIndex = index
        intent.focused(index)
    }
    fun cancel() { job?.cancel(); job = null; movementJob = null; intent.clear(); revision.value++ }
    fun leave() { cancel(); manual() }
    fun hostKey(event: KeyEvent): Boolean = key(currentIndex, event)
    fun key(index: Int, event: KeyEvent): Boolean {
        val direction = event.key
        val arrow = direction == Key.DirectionDown || direction == Key.DirectionUp ||
            direction == Key.DirectionLeft || direction == Key.DirectionRight
        if (!arrow) return job?.isActive == true && (direction == Key.DirectionCenter || direction == Key.Enter)
        val total = count()
        if (lastCount != total) { currentIndex = currentIndex.coerceIn(0, (total - 1).coerceAtLeast(0)); lastCount = total }
        val anchor = (intent.desired ?: currentIndex).coerceIn(0, (total - 1).coerceAtLeast(0))
        // Top-row UP and first-column LEFT have explicit, stable destinations.
        if (direction == Key.DirectionUp && anchor < columns && onExitUp != null) {
            if (event.type == KeyEventType.KeyDown) { leave(); onExitUp.invoke() }
            return true
        }
        if (direction == Key.DirectionLeft && anchor % columns == 0) {
            if (event.type == KeyEventType.KeyDown) { leave(); onExitLeft?.invoke() }
            return onExitLeft != null
        }
        if (event.type != KeyEventType.KeyDown) return true
        if (total == 0) return true
        manual()
        val target = when (direction) {
            Key.DirectionDown -> intent.request(anchor, total, true)
            Key.DirectionUp -> intent.request(anchor, total, false)
            Key.DirectionLeft -> (anchor - 1).also { intent.clear() }
            Key.DirectionRight -> if (anchor % columns < columns - 1 && anchor + 1 < total) (anchor + 1).also { intent.clear() } else null
            else -> null
        } ?: return true
        currentIndex = target
        load(target)
        val visible = grid.layoutInfo.visibleItemsInfo.firstOrNull { it.index == target }
        val fullyVisible = visible != null && visible.offset.y >= grid.layoutInfo.viewportStartOffset &&
            visible.offset.y + visible.size.height <= grid.layoutInfo.viewportEndOffset
        if (fullyVisible && requesters[target] != null) {
            // The usual arrow press stays on the actual cards: no host transfer or frame delay.
            job?.cancel(); job = null; movementJob = null
            if (runCatching { requesters[target]?.requestFocus() == true }.getOrDefault(false)) return true
        }
        revision.value++
        if (job === movementJob && job?.isActive == true) return true // Only movement jobs follow a new destination.
        job?.cancel() // Initial host restoration targets one card; a manual command replaces it.
        transferring = true
        try { runCatching { host.requestFocus() } } finally { transferring = false }
        job = scope.launch(start = CoroutineStart.LAZY) {
            while (isActive) {
                val destination = currentIndex
                if (destination !in 0 until count()) { intent.clear(); return@launch }
                load(destination)
                val layout = grid.layoutInfo
                val items = layout.visibleItemsInfo
                val item = items.firstOrNull { it.index == destination }
                val inView = item != null && item.offset.y >= layout.viewportStartOffset &&
                    item.offset.y + item.size.height <= layout.viewportEndOffset
                if (!inView) {
                    val rows = items.filter { it.offset.y >= layout.viewportStartOffset &&
                        it.offset.y + it.size.height <= layout.viewportEndOffset }.map { it.index / columns }.distinct().size.coerceAtLeast(1)
                    val firstRow = (items.firstOrNull()?.index ?: destination) / columns
                    val row = destination / columns
                    grid.scrollToItem((if (row >= firstRow) (row - rows + 1).coerceAtLeast(0) else row) * columns)
                }
                if (currentIndex != destination) continue
                val ready = withTimeoutOrNull(2_500L) {
                    revision.first { currentIndex != destination || requesters[destination] != null }
                }
                if (currentIndex != destination) continue
                if (ready == null) { intent.clear(); return@launch }
                ensureActive()
                if (runCatching { requesters[destination]?.requestFocus() == true }.getOrDefault(false)) return@launch
                withFrameNanos { }
                ensureActive()
                if (currentIndex != destination) continue
                if (runCatching { requesters[destination]?.requestFocus() == true }.getOrDefault(false)) return@launch
                intent.clear(); return@launch
            }
        }
        movementJob = job
        job?.start()
        return true
    }
}

/** Parent remains composed even when a held key moves beyond the loaded rows. */
internal fun Modifier.catalogGridHost(navigator: CatalogGridNavigator): Modifier =
    this.focusRequester(navigator.host).onFocusChanged { navigator.focusTreeChanged(it.hasFocus); navigator.hostFocusChanged(it.isFocused) }.onPreviewKeyEvent { navigator.hostKey(it) }.focusable()

internal fun Modifier.catalogGridNavigation(navigator: CatalogGridNavigator?, index: Int, requester: FocusRequester): Modifier =
    this.then(if (navigator == null) Modifier else Modifier.onPreviewKeyEvent { navigator.key(index, it) })

@Composable
internal fun BindCatalogFocus(navigator: CatalogGridNavigator?, index: Int, requester: FocusRequester) {
    DisposableEffect(navigator, index, requester) {
        navigator?.attach(index, requester)
        onDispose { navigator?.detach(index, requester) }
    }
}

@Composable
internal fun CatalogPosterPlaceholder(aspect: Float) {
    val width = LocalCatalogPosterWidth.current
    val metadata = LocalCatalogMetadataHeight.current
    Column(Modifier.fillMaxWidth().then(if (width.value.isFinite())
        Modifier.wrapContentWidth(Alignment.CenterHorizontally).width(width) else Modifier)) {
        Box(Modifier.fillMaxWidth().aspectRatio(aspect).background(Color(0xFF0B1020)))
        Spacer(Modifier.height(if (width.value.isFinite()) metadata else 34.dp))
    }
}
