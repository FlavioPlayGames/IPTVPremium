package androidx.compose.foundation.lazy.grid
data class Coord(val y:Int) { val height:Int get()=y }
data class Item(val index:Int,val offset:Coord,val size:Coord)
class Info { var visibleItemsInfo=emptyList<Item>();val viewportStartOffset=0;val viewportEndOffset=180 }
class LazyGridState {
 val layoutInfo=Info();var onScroll:(Int)->Unit={};var scrollCalls=0
 suspend fun scrollToItem(index:Int){ scrollCalls++;kotlinx.coroutines.delay(5);onScroll(index) }
}
