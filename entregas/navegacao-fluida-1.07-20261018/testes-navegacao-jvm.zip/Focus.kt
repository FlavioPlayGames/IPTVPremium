package androidx.compose.ui.focus
class FocusRequester { var onRequest:()->Boolean={false}; fun requestFocus()=onRequest() }
