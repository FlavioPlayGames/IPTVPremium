package androidx.compose.ui.input.key
enum class Key { DirectionDown,DirectionUp,DirectionLeft,DirectionRight,DirectionCenter,Enter,Back }
enum class KeyEventType { KeyDown,KeyUp }
data class KeyEvent(val key:Key,val type:KeyEventType)
