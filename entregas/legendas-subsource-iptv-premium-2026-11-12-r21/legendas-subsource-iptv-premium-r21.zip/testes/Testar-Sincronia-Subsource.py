"""Real subtitle protocol/clock/parser and bounded preference policy, with API/Android adapters."""
from pathlib import Path
import argparse,os,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--projeto',type=Path,required=True);p.add_argument('--tools',type=Path,required=True);p.add_argument('--java',default='java');a=p.parse_args()
r=a.projeto/'app/src/main/java/br/com/flaviotorres/iptvpremium/core/navigation/player';f=Path(__file__).parent;cp=os.pathsep.join(str(x)for x in a.tools.glob('*.jar'))
with tempfile.TemporaryDirectory(prefix='iptv-r19-protocol-')as td:
 w=Path(td);repo=(r/'ExternalSubtitleRepositor.kt').read_text();start=repo.index('    private fun parseSubtitle(');end=repo.index('    private fun digest(',start)
 cue=next(x for x in repo.splitlines()if x.startswith('data class ExternalSubtitleCue('))
 (w/'TimingParser.kt').write_text('package br.com.flaviotorres.iptvpremium.core.player\n'+cue+'\ninternal object TimingParser {\n'+repo[start:end].replace('private fun parseSubtitle','fun parseSubtitle')+'\n}\n')
 decl=repo[repo.index('data class ExternalSubtitleOption('):repo.index(') {',repo.index('data class ExternalSubtitleOption('))+1]
 key=repo[repo.index('    private fun downloadedOptionKey('):repo.index('    /** Apenas as opções',repo.index('    private fun downloadedOptionKey('))]
 decode=repo[repo.index('    private fun decodeOptions('):repo.index('    private fun ',repo.index('    private fun decodeOptions(')+10)]
 (w/'StorageAdapter.kt').write_text('package br.com.flaviotorres.iptvpremium.core.player\nimport org.json.*\n'+decl+'\ninternal object StorageAdapter {\n'+key.replace('private fun','fun')+decode.replace('private fun','fun')+'\nprivate fun digest(value:String)=openSubtitleDigest(value)\n}\n')
 files=[r/x for x in ['OpenSubtitlesProtocol.kt','OpenSubtitlesClient.kt','SubsourceClient.kt','SubsourceEpisodePolicy.kt','SubsourceArchive.kt','ExternalSubtitleSync.kt','ExternalSubtitleSyncStore.kt','SubtitleMenuPolicy.kt']]+[r.parents[2]/'data/repository/CatalogMetadataIdentity.kt',w/'TimingParser.kt',w/'StorageAdapter.kt',f/'Context.kt',f/'SyncVerify.kt',f/'SubsourceVerify.kt']
 jar=w/'verify.jar';subprocess.run([a.java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',str(jar),*map(str,files)],check=True)
 for main in ['SyncVerifyKt','SubsourceVerifyKt']:subprocess.run([a.java,'-cp',str(jar)+os.pathsep+cp,'br.com.flaviotorres.iptvpremium.core.player.'+main],check=True)
