package br.com.flaviotorres.iptvpremium.core.player
import kotlinx.coroutines.*
import org.json.*
private class Wire:OpenSubtitleTransport {
 val urls=mutableListOf<String>()
 override suspend fun request(url:String,method:String,headers:Map<String,String>,body:String?,limit:Int):OpenSubtitleResponse {
  urls+=url
  val rows=if("/movies/search?" in url)JSONArray().put(JSONObject().put("movieId",1).put("title","Show").put("type","tvseries").put("season",5))else JSONArray().apply {
   for((id,lang)in listOf(1 to "brazillian-portuguese",2 to "brazilian-portuguese",3 to "english",4 to "spanish",5 to "portuguese"))put(JSONObject().put("subtitleId",id).put("language",lang).put("releaseInfo",JSONArray().put("Show.S05E06")))
  }
  return OpenSubtitleResponse(200,JSONObject().put("success",true).put("data",rows).toString().toByteArray())
 }
}
fun main()=runBlocking {
 val wire=Wire();val trace=mutableListOf<String>();val client=SubsourceClient({"fake-personal-key"},wire,{trace+=it},0)
 val result=client.search(SubsourceQuery("Show",null,null,5,6)).second
 check(wire.urls.size==2){"must request work and only Brazilian Portuguese"}
 check(wire.urls.last().contains("language=brazillian-portuguese"))
 check(wire.urls.none{"language=english" in it||"language=spanish" in it})
 check(result.map{it.id}==listOf("1","2")){"reject English, Spanish and generic Portuguese even in mixed response"}
 check(result.all{it.language=="pt-BR"})
 check(trace.any{"stage=subsource_results language=pt-BR" in it})
 println("6 SubSource Brazilian-Portuguese checks passed; simulated API.")
}
