package br.com.flaviotorres.iptvpremium.data.history

import android.content.Context
import br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import br.com.flaviotorres.iptvpremium.data.repository.SeriesEpisodeInfo
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONArray
import org.json.JSONObject

/** Device-local identity links. No server requests, video URLs, passwords or catalogue copies. */
class SharedLibraryStore private constructor(context: Context) {
    private val app = context.applicationContext
    private val prefs = app.getSharedPreferences("iptvpremium_shared_library_v1", Context.MODE_PRIVATE)
    private val lock = Any()
    private val reconcileLock = Mutex()
    val changes = MutableStateFlow(0L)
    private data class Record(val key: String, val playlist: String, val id: String,
        val identity: ContentIdentity, val tracked: Boolean, val favorite: Boolean?, val changed: Long,
        val hiddenUntil: Long = 0L)
    private data class Link(val id: String, val title: String, val poster: String?)
    private var records = readRecords()
    private var linkedPlaylist: String? = null
    private var linkedGeneration: String? = null
    private var linkedSignature = ""
    private var links = emptyMap<String, Link>()
    private val episodeMaps = mutableMapOf<String, Map<Pair<Int, Int>, SeriesEpisodeInfo>>()

    private fun key(playlist: String, kind: String, id: String) = "${playlist.length}:$playlist:$kind:$id"
    private fun identity(row: SharedCatalogIdentity, kind: String) = ContentIdentity(kind, row.title, row.year, row.imdb, row.tmdb)
    private fun changed() { changes.value = changes.value + 1L }
    private fun readRecords(): MutableMap<String, Record> = synchronized(lock) {
        val result = linkedMapOf<String, Record>()
        val array = try { JSONArray(prefs.getString("identities", "[]")) } catch (_: Exception) { JSONArray() }
        for (i in 0 until array.length()) {
            val o = array.optJSONObject(i) ?: continue
            val kind = o.optString("kind"); if (kind !in listOf("movies", "series")) continue
            val playlist = o.optString("playlist"); val id = o.optString("id")
            if (playlist.isBlank() || id.isBlank()) continue
            val k = key(playlist, kind, id)
            result[k] = Record(k, playlist, id, ContentIdentity(kind, o.optString("title"),
                o.optInt("year").takeIf { it > 0 }, o.optString("imdb"), o.optString("tmdb")),
                o.optBoolean("tracked"), if (o.has("favorite")) o.optBoolean("favorite") else null,
                o.optLong("changed"), o.optLong("hiddenUntil"))
        }
        result
    }
    private fun persist() {
        val a = JSONArray()
        records.values.forEach { r -> a.put(JSONObject().apply {
            put("playlist", r.playlist); put("id", r.id); put("kind", r.identity.kind)
            put("title", r.identity.title); put("year", r.identity.year ?: 0)
            put("imdb", r.identity.imdb ?: ""); put("tmdb", r.identity.tmdb ?: "")
            put("tracked", r.tracked); r.favorite?.let { put("favorite", it) }
            put("changed", r.changed); put("hiddenUntil", r.hiddenUntil)
        }) }
        // Keep only small identity records, never the catalogue or playback addresses.
        if (!prefs.edit().putString("identities", a.toString()).commit()) {
            records = readRecords()
            error("Falha ao salvar vínculos locais")
        }
    }
    private suspend fun ensureRecord(dao: PlaylistCacheDao, playlist: String, kind: String, id: String,
        fallback: ContentIdentity? = null): Record? {
        val k = key(playlist, kind, id)
        synchronized(lock) { records[k]?.takeIf { it.tracked }?.let { return it } }
        val basic = if (kind == "movies") dao.getActiveMovieById(playlist, id)?.let {
            ContentIdentity(kind, it.name, it.year)
        } else dao.getActiveGeneration(playlist)?.let { g ->
            dao.getParentalSeriesById(playlist, g.generationId, id)?.let {
                ContentIdentity(kind, it.name, it.year, it.imdbId, it.tmdbId)
            }
        }
        return synchronized(lock) {
            val previous = records[k]
            val value = previous?.identity ?: basic ?: fallback ?: return@synchronized null
            val record = previous?.copy(tracked = true) ?: Record(k, playlist, id, value, true, null, 0)
            records[k] = record
            record
        }
    }
    suspend fun setFavorite(dao: PlaylistCacheDao, playlist: String, kind: String, id: String, favorite: Boolean) {
        ensureRecord(dao, playlist, kind, id) ?: return
        synchronized(lock) {
            val k = key(playlist, kind, id); val r = records[k] ?: return
            val stamp = maxOf(System.currentTimeMillis(), records.values.maxOfOrNull { it.changed }?.plus(1) ?: 0)
            records[k] = r.copy(favorite = favorite, changed = stamp)
            persist(); changed()
        }
    }
    /** Called only for details the person actually opens; does not fetch metadata in bulk. */
    fun rememberExternal(playlist: String, id: String, value: ContentIdentity) = synchronized(lock) {
        if (playlist.isBlank() || id.isBlank()) return@synchronized
        val k = key(playlist, value.kind, id); val old = records[k]
        val merged = value.copy(imdb = value.imdbKey ?: old?.identity?.imdbKey,
            tmdb = value.tmdbKey ?: old?.identity?.tmdbKey, year = value.year ?: old?.identity?.year)
        if (old?.identity == merged) return@synchronized
        // Non-tracked detail hints have a bounded lifetime; favorites/history are never evicted here.
        if (old == null && records.values.count { !it.tracked } >= 512) {
            records.entries.firstOrNull { !it.value.tracked }?.key?.let { records.remove(it) }
        }
        records[k] = old?.copy(identity = merged) ?: Record(k, playlist, id, merged, false, null, 0)
        persist(); changed()
    }
    suspend fun reconcile(dao: PlaylistCacheDao, playlist: String, history: List<WatchHistoryEntry>) = reconcileLock.withLock {
        val generation = dao.getActiveGeneration(playlist)?.generationId ?: return@withLock
        val favoritePrefs = app.getSharedPreferences("iptvpremium_favorites_v1", Context.MODE_PRIVATE)
        // Existing 1.05 favorites are imported as timestamp-zero facts, never overwrite an explicit removal.
        favoritePrefs.all.forEach { (name, raw) ->
            val kind = when { name.startsWith("movies_") -> "movies"; name.startsWith("series_") -> "series"; else -> return@forEach }
            val source = name.removePrefix("${kind}_")
            (raw as? Set<*>)?.filterIsInstance<String>()?.forEach { id ->
                currentCoroutineContext().ensureActive()
                val r = ensureRecord(dao, source, kind, id) ?: return@forEach
                synchronized(lock) { val latest = records[r.key]!!
                    if (latest.favorite == null) records[r.key] = latest.copy(favorite = true) }
            }
        }
        history.forEach { h ->
            val kind = if (h.contentType == PlaybackContentType.MOVIE) "movies" else if (h.contentType == PlaybackContentType.EPISODE) "series" else return@forEach
            val id = if (kind == "series") h.seriesId ?: return@forEach else h.contentId
            ensureRecord(dao, h.playlistId, kind, id, ContentIdentity(kind, if (kind == "series") h.seriesTitle.orEmpty() else h.title))
        }
        val snapshot = synchronized(lock) { persist(); records.values.toList() }
        val tracked = snapshot.filter { it.tracked }
        val signature = snapshot.joinToString("\n") { "${it.key}:${it.identity}:${it.tracked}" }
        if (synchronized(lock) { linkedPlaylist == playlist && linkedGeneration == generation && linkedSignature == signature }) return@withLock
        val result = mutableMapOf<String, Link>()
        for (kind in listOf("movies", "series")) {
            val wanted = tracked.filter { it.identity.kind == kind }
            if (wanted.isEmpty()) continue
            val ownIds = wanted.filter { it.playlist == playlist }.associateBy { it.id }
            val byName = wanted.groupBy { it.identity.normalizedTitle }
            val byImdb = wanted.filter { it.identity.imdbKey != null }.groupBy { it.identity.imdbKey }
            val byTmdb = wanted.filter { it.identity.tmdbKey != null }.groupBy { it.identity.tmdbKey }
            val best = mutableMapOf<String, Pair<Int, MutableList<Link>>>()
            val overrides = snapshot.filter { it.playlist == playlist && it.identity.kind == kind }.associateBy { it.id }
            var after = ""
            while (true) {
                currentCoroutineContext().ensureActive()
                val page = if (kind == "movies") dao.sharedMoviePage(playlist, generation, after) else dao.sharedSeriesPage(playlist, generation, after)
                if (page.isEmpty()) break
                for (row in page) {
                    val candidate = overrides[row.contentId]?.identity ?: identity(row, kind)
                    val possible = (byName[candidate.normalizedTitle].orEmpty() + byImdb[candidate.imdbKey].orEmpty() + byTmdb[candidate.tmdbKey].orEmpty()).distinctBy { it.key }
                    for (r in possible) {
                        // Same-playlist IDs always keep the original local data, regardless of duplicate names.
                        if (r.playlist == playlist) continue
                        val score = r.identity.confidence(candidate)
                        if (score == 0) continue
                        val previous = best[r.key]
                        if (previous == null || score > previous.first) best[r.key] = score to mutableListOf(Link(row.contentId, row.title, row.poster))
                        else if (score == previous.first && previous.second.size < 2) previous.second.add(Link(row.contentId, row.title, row.poster))
                    }
                    ownIds[row.contentId]?.let {
                        result[it.key] = Link(row.contentId, row.title, row.poster)
                    }
                }
                after = page.last().contentId
            }
            // Even fallback names are accepted only when unique in the target catalogue.
            best.forEach { (k, match) -> if (match.second.size == 1) result[k] = match.second.single() }
        }
        if (dao.getActiveGeneration(playlist)?.generationId != generation) return@withLock
        synchronized(lock) {
            if (linkedPlaylist != playlist || linkedGeneration != generation) episodeMaps.clear()
            linkedPlaylist = playlist; linkedGeneration = generation; linkedSignature = signature; links = result
        }
    }
    fun favorites(playlist: String, kind: String, existing: Set<String>): Set<String> = synchronized(lock) {
        if (linkedPlaylist != playlist) return@synchronized existing
        val events = records.values.filter { it.identity.kind == kind && it.favorite != null }
            .mapNotNull { r -> links[r.key]?.let { it.id to r } }.groupBy({ it.first }, { it.second })
        existing.toMutableSet().apply {
            events.forEach { (id, choices) ->
                if (choices.maxBy { it.changed }.favorite == true) add(id) else remove(id)
            }
        }.toSet()
    }
    fun registerEpisodes(playlist: String, series: String, episodes: List<SeriesEpisodeInfo>) = synchronized(lock) {
        if (playlist != linkedPlaylist) return@synchronized
        episodeMaps[series] = episodes.filter { it.seasonNumber >= 0 && it.episodeNumber > 0 }
            .groupBy { it.seasonNumber to it.episodeNumber }.filterValues { it.size == 1 }.mapValues { it.value.single() }
    }
    fun projectHistory(playlist: String, raw: List<WatchHistoryEntry>): List<WatchHistoryEntry> = synchronized(lock) {
        if (playlist != linkedPlaylist) return@synchronized raw.filter { it.playlistId == playlist }
        val mapped = raw.mapNotNull { h ->
            val kind = if (h.contentType == PlaybackContentType.MOVIE) "movies" else if (h.contentType == PlaybackContentType.EPISODE) "series" else return@mapNotNull null
            val id = if (kind == "series") h.seriesId ?: return@mapNotNull null else h.contentId
            val r = records[key(h.playlistId, kind, id)]
            val link = r?.let { links[it.key] }
            val hidden = if (link != null) records.values.filter { it.identity.kind == kind && links[it.key]?.id == link.id }.maxOfOrNull { it.hiddenUntil } ?: 0 else r?.hiddenUntil ?: 0
            if (h.updatedAtMs <= hidden) return@mapNotNull null
            if (h.playlistId == playlist) return@mapNotNull h
            if (link == null) return@mapNotNull null
            if (kind == "movies") h.copy(playlistId = playlist, contentId = link.id, title = link.title,
                posterUrl = link.poster, sharedFromPlaylist = h.playlistId)
            else {
                val episode = episodeMaps[link.id]?.get(h.seasonNumber to h.episodeNumber)
                if (episode == null && !h.inProgress) return@mapNotNull null
                h.copy(playlistId = playlist, seriesId = link.id, seriesTitle = link.title, seriesPosterUrl = link.poster,
                    contentId = episode?.id ?: "series-only:${link.id}", title = episode?.title ?: link.title,
                    positionMs = if (episode != null) h.positionMs else 0,
                    durationMs = if (episode != null) h.durationMs else null,
                    seasonNumber = if (episode != null) h.seasonNumber else null,
                    episodeNumber = if (episode != null) h.episodeNumber else null,
                    seriesOnly = episode == null, sharedFromPlaylist = h.playlistId)
            }
        }
        mapped.sortedByDescending { it.updatedAtMs }.distinctBy { it.contentType to it.contentId }
    }
    fun hide(playlist: String, type: PlaybackContentType, contentId: String, raw: List<WatchHistoryEntry>) = synchronized(lock) {
        val entry = projectHistory(playlist, raw).firstOrNull { it.contentType == type && it.contentId == contentId } ?: return@synchronized
        val kind = if (type == PlaybackContentType.MOVIE) "movies" else "series"
        val id = if (kind == "movies") entry.contentId else entry.seriesId ?: return@synchronized
        val until = System.currentTimeMillis()
        records.replaceAll { _, r -> if (r.identity.kind == kind &&
            ((r.playlist == playlist && r.id == id) || (linkedPlaylist == playlist && links[r.key]?.id == id))) r.copy(hiddenUntil = until) else r }
        persist(); changed()
    }
    companion object {
        fun resumePosition(entry: WatchHistoryEntry?, position: Long, duration: Long?): Long {
            if (entry?.seriesOnly == true) return 0L
            if (entry?.sharedFromPlaylist != null && duration != null && duration > 0 &&
                (position >= duration || (entry.durationMs != null &&
                kotlin.math.abs(entry.durationMs - duration) > maxOf(90_000L, duration / 10)))) return 0L
            return position.coerceAtLeast(0L)
        }
        @Volatile private var instance: SharedLibraryStore? = null
        fun get(context: Context): SharedLibraryStore = instance ?: synchronized(this) {
            instance ?: SharedLibraryStore(context).also { instance = it }
        }
    }
}
