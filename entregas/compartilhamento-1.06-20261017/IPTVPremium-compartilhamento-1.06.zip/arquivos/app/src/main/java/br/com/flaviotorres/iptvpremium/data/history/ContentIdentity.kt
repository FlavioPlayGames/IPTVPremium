package br.com.flaviotorres.iptvpremium.data.history

import java.text.Normalizer
import java.util.Locale

/** Provider IDs are scoped to their playlist, never treated as external identifiers. */
data class ContentIdentity(
    val kind: String,
    val title: String,
    val year: Int? = null,
    val imdb: String? = null,
    val tmdb: String? = null
) {
    val normalizedTitle: String get() = normalizeTitle(title, normalizedYear)
    val normalizedYear: Int? get() = year?.takeIf { it in 1888..2100 }
        ?: Regex("(?:\\(|\\[|\\s)((?:19|20)\\d{2})(?:\\)|\\]|\\s*$)").find(title)?.groupValues?.get(1)?.toIntOrNull()
    val imdbKey: String? get() = imdb?.trim()?.lowercase(Locale.ROOT)?.takeIf { it.matches(Regex("tt\\d{5,12}")) }
    val tmdbKey: String? get() = tmdb?.trim()?.toLongOrNull()?.takeIf { it > 0 }?.toString()

    fun confidence(other: ContentIdentity): Int {
        if (kind != other.kind) return 0
        if (imdbKey != null && other.imdbKey != null && imdbKey != other.imdbKey) return 0
        if (tmdbKey != null && other.tmdbKey != null && tmdbKey != other.tmdbKey) return 0
        if ((imdbKey != null && imdbKey == other.imdbKey) || (tmdbKey != null && tmdbKey == other.tmdbKey)) return 2
        if (normalizedTitle.isBlank() || normalizedTitle != other.normalizedTitle) return 0
        if (normalizedYear != null && other.normalizedYear != null) return if (normalizedYear == other.normalizedYear) 1 else 0
        // A unique exact series name can supply a series-only shortcut. Films require a year.
        return if (kind == "series") 1 else 0
    }
    companion object {
        fun normalizeTitle(raw: String, releaseYear: Int? = null): String {
            var title = raw.lowercase(Locale.ROOT)
            title = title.replace(Regex("\\[(?:4k|uhd|fhd|hd|sd|dv|hdr|hdr10|l|dub|leg|dublado|legendado)\\]"), " ")
            title = title.replace(Regex("\\b(?:4k|2160p|1080p|720p|uhd|fhd|hdr10|hdr|dublado|legendado)\\b"), " ")
            if (releaseYear != null) {
                title = title.replace(Regex("(?:\\(|\\[)$releaseYear(?:\\)|\\])"), " ")
                    .replace(Regex("\\s+$releaseYear\\s*$"), " ")
            }
            return Normalizer.normalize(title, Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
                .replace(Regex("[^\\p{L}\\p{N}]+"), " ").trim().replace(Regex("\\s+"), " ")
        }
    }
}

/** Lightweight Room projection: deliberately excludes stream URLs and credentials. */
data class SharedCatalogIdentity(
    val contentId: String, val title: String, val year: Int?,
    val imdb: String?, val tmdb: String?, val poster: String?
)
