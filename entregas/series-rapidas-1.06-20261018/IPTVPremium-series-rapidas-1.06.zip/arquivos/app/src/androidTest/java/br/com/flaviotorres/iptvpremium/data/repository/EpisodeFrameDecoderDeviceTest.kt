package br.com.flaviotorres.iptvpremium.data.repository

import androidx.test.platform.app.InstrumentationRegistry
import org.junit.Assert.*
import org.junit.Test
import java.net.ServerSocket
import java.util.concurrent.atomic.AtomicLong
import kotlin.concurrent.thread

/** Teste NATIVO separado do APK distribuido. Nao depende de playlist/credenciais. */
class EpisodeFrameDecoderDeviceTest {
    @Test fun extractsMp4FrameUsingRealAndroidDecoder() = checkFrame("frame-test.mp4")
    @Test fun extractsMatroskaFrameUsingRealAndroidDecoder() = checkFrame("frame-test.mkv")

    private fun checkFrame(asset: String) {
        val data = InstrumentationRegistry.getInstrumentation().context.assets.open(asset).use { it.readBytes() }
        val socket = ServerSocket(0, 2, java.net.InetAddress.getByName("127.0.0.1"))
        val received = AtomicLong(0)
        val worker = thread(isDaemon = true, name = "FrameFixtureHttp") {
            while (!socket.isClosed) {
                try {
                    socket.accept().use { client ->
                        client.soTimeout = 3000
                        val reader = client.getInputStream().bufferedReader()
                        reader.readLine()
                        var range: String? = null
                        while (true) {
                            val header = reader.readLine() ?: break
                            if (header.isEmpty()) break
                            if (header.startsWith("Range:", true)) range = header.substringAfter(':').trim()
                        }
                        val parts = range?.substringAfter("bytes=")?.split('-')
                        val start = parts?.getOrNull(0)?.toIntOrNull() ?: 0
                        val end = minOf(parts?.getOrNull(1)?.toIntOrNull() ?: data.lastIndex, data.lastIndex)
                        if (start > end) {
                            client.getOutputStream().write("HTTP/1.1 416 Range Not Satisfiable\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
                        } else {
                            val count = end - start + 1
                            val header = "HTTP/1.1 206 Partial Content\r\nContent-Range: bytes $start-$end/${data.size}\r\nContent-Length: $count\r\nConnection: close\r\n\r\n"
                            client.getOutputStream().apply { write(header.toByteArray()); write(data, start, count); flush() }
                            received.addAndGet(count.toLong())
                        }
                    }
                } catch (_: java.io.IOException) { if (socket.isClosed) break }
            }
        }
        try {
            val bitmap = Media3EpisodeFrameDecoder.extract("http://127.0.0.1:${socket.localPort}/$asset", 320, 180, null)
            assertNotNull("Media3/MediaCodec nao extraiu frame de $asset; veja EpisodePreview", bitmap)
            bitmap!!
            try {
                assertTrue(bitmap.width <= 640 && bitmap.height <= 360)
                val pixel = bitmap.getPixel(bitmap.width / 2, bitmap.height / 2)
                assertTrue("Frame deve conter a cor azul real da fixture", (pixel and 255) > 180 && ((pixel shr 16) and 255) < 80)
                assertTrue(received.get() <= 6L * 1024 * 1024)
            } finally { bitmap.recycle() }
        } finally { socket.close(); worker.join(3000) }
    }
}
