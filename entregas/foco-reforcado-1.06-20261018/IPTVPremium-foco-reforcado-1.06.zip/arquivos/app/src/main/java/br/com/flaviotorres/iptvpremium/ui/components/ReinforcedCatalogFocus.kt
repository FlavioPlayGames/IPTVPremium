package br.com.flaviotorres.iptvpremium.ui.components

import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors

/** Static, cached strokes: works on API 28 without blur layers or animated shaders. */
fun Modifier.reinforcedCatalogFocus(enabled: Boolean, roundedDp: Float = 12f): Modifier =
    if (!enabled) this else drawWithCache {
        val accent = ThemeColors.borderColor(0xFFD6A32E)
        val highlight = ThemeColors.borderColor(0xFFFFF5CD)
        val metal = Brush.linearGradient(
            0f to accent, .12f to highlight, .22f to accent,
            .67f to accent, .78f to highlight, 1f to accent,
            start = Offset.Zero, end = Offset(size.width, size.height)
        )
        val radius = CornerRadius(roundedDp.dp.toPx())
        val rim = 4.dp.toPx()
        val inset = rim / 2
        val innerInset = 5.dp.toPx()
        onDrawWithContent {
            drawContent()
            // Short halo stays inside the card bounds, so adjacent covers remain clear.
            drawRoundRect(accent.copy(alpha = .15f), cornerRadius = radius,
                style = Stroke(12.dp.toPx()))
            drawRoundRect(accent.copy(alpha = .24f), cornerRadius = radius,
                style = Stroke(8.dp.toPx()))
            drawRoundRect(metal, topLeft = Offset(inset, inset),
                size = Size(size.width - rim, size.height - rim),
                cornerRadius = CornerRadius((radius.x - inset).coerceAtLeast(0f)),
                style = Stroke(rim))
            if (size.width > innerInset * 2 && size.height > innerInset * 2) {
                drawRoundRect(Color(0xE6000000), topLeft = Offset(innerInset, innerInset),
                    size = Size(size.width - innerInset * 2, size.height - innerInset * 2),
                    cornerRadius = CornerRadius((radius.x - innerInset).coerceAtLeast(0f)),
                    style = Stroke(1.dp.toPx()))
            }
        }
    }

/** Constant slot height prevents layout jumps when the focused title changes. */
fun Modifier.catalogFocusUnderline(enabled: Boolean): Modifier = drawWithCache {
    val color = ThemeColors.borderColor(0xFFD6A32E)
    onDrawBehind {
        if (enabled) drawRoundRect(color, cornerRadius = CornerRadius(2.dp.toPx()))
    }
}
