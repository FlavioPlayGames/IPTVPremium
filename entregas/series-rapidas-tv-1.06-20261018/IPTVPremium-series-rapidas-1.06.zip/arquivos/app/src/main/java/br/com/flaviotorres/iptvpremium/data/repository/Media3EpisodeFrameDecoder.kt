package br.com.flaviotorres.iptvpremium.data.repository

import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaDataSource
import android.media.MediaFormat
import android.os.SystemClock
import android.util.Log
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.inspector.MediaExtractorCompat
import kotlinx.coroutines.Job
import kotlinx.coroutines.ensureActive

/** Extrai uma imagem com os demuxers Media3, sem abrir outro player/audio. */
@OptIn(UnstableApi::class)
internal object Media3EpisodeFrameDecoder {
    fun extract(url: String, width: Int, height: Int, job: Job?): Bitmap? {
        val end = SystemClock.elapsedRealtime() + 12_000L
        var stage = "abrir_container"
        fun unavailable(reason: String): Bitmap? { Log.d("EpisodePreview", "frame_indisponivel via=media3 motivo=$reason"); return null }
        fun active() { job?.ensureActive(); check(SystemClock.elapsedRealtime() < end) { "Prazo do frame" } }
        try {
            BoundedVideoReader(url, active = { job?.isActive != false }, timeoutMs = 10_000).use { reader ->
                val source = object : MediaDataSource() {
                    override fun getSize() = reader.size()
                    override fun readAt(p: Long, b: ByteArray, o: Int, n: Int) = reader.readAt(p, b, o, n)
                    override fun close() = reader.close()
                }
                val extractor = MediaExtractorCompat(androidx.media3.extractor.DefaultExtractorsFactory(),
                    androidx.media3.datasource.DataSource.Factory { error("Usa apenas MediaDataSource") })
                try {
                    extractor.setDataSource(source)
                    active()
                    val track = (0 until extractor.trackCount).firstOrNull {
                        extractor.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/") == true
                    } ?: return unavailable("sem_video")
                    val format = extractor.getTrackFormat(track)
                    val mime = format.getString(MediaFormat.KEY_MIME) ?: return unavailable("sem_mime")
                    val videoWidth = format.getInteger(MediaFormat.KEY_WIDTH)
                    val videoHeight = format.getInteger(MediaFormat.KEY_HEIGHT)
                    if (videoWidth <= 0 || videoHeight <= 0 || videoWidth.toLong() * videoHeight > 3840L * 2160) return unavailable("limite_resolucao")
                    val rotation = if (format.containsKey(MediaFormat.KEY_ROTATION)) format.getInteger(MediaFormat.KEY_ROTATION) else 0
                    extractor.selectTrack(track)
                    // Primeira imagem decodificavel: evita buscar 5s/cauda desnecessariamente.
                    format.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatYUV420Flexible)
                    format.setInteger(MediaFormat.KEY_ROTATION, 0)
                    stage = "iniciar_codec"
                    val codec = MediaCodec.createDecoderByType(mime)
                    var started = false
                    try {
                        codec.configure(format, null, null, 0)
                        codec.start(); started = true
                        val info = MediaCodec.BufferInfo()
                        var inputEnded = false
                        stage = "decodificar"
                        while (SystemClock.elapsedRealtime() < end) {
                            active()
                            if (!inputEnded) {
                                val input = codec.dequeueInputBuffer(10_000)
                                if (input >= 0) {
                                    val buffer = codec.getInputBuffer(input) ?: return unavailable("buffer_entrada")
                                    val sample = extractor.readSampleData(buffer, 0)
                                    if (sample < 0) {
                                        codec.queueInputBuffer(input, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                        inputEnded = true
                                    } else {
                                        // Nao tenta decodificar amostras protegidas.
                                        if (extractor.sampleFlags and 2 != 0) return unavailable("amostra_protegida")
                                        codec.queueInputBuffer(input, 0, sample, extractor.sampleTime.coerceAtLeast(0), 0)
                                        extractor.advance()
                                    }
                                }
                            }
                            val output = codec.dequeueOutputBuffer(info, 10_000)
                            if (output >= 0) {
                                try {
                                    if (info.size > 0) {
                                        codec.getOutputImage(output)?.use { image ->
                                            if (image.format != ImageFormat.YUV_420_888) return unavailable("formato_yuv_${image.format}")
                                            val crop = image.cropRect
                                            val rotated = rotation % 180 != 0
                                            val targetW = if (rotated) minOf(height.coerceIn(90, 360), 360) else width.coerceIn(160, 640)
                                            val targetH = if (rotated) minOf(width.coerceIn(160, 640), 360) else height.coerceIn(90, 360)
                                            val scale = minOf(targetW.toFloat() / crop.width(), targetH.toFloat() / crop.height())
                                            val w = (crop.width() * scale).toInt().coerceIn(1, 640)
                                            val h = (crop.height() * scale).toInt().coerceIn(1, 360)
                                            val planes = image.planes.map { YuvPreviewPixels.Plane(it.buffer, it.rowStride, it.pixelStride) }
                                            val pixels = YuvPreviewPixels.argb(planes[0], planes[1], planes[2], crop.left, crop.top, crop.width(), crop.height(), w, h)
                                            val bitmap = Bitmap.createBitmap(pixels, w, h, Bitmap.Config.ARGB_8888)
                                            if (rotation % 360 == 0) return bitmap
                                            return try {
                                                Bitmap.createBitmap(bitmap, 0, 0, w, h, Matrix().apply { postRotate(rotation.toFloat()) }, true)
                                            } finally { bitmap.recycle() }
                                        }
                                    }
                                } finally { codec.releaseOutputBuffer(output, false) }
                                if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                            }
                        }
                    } finally {
                        try { if (started) codec.stop() } finally { codec.release() }
                    }
                } finally { extractor.release() }
            }
        } catch (cancelled: kotlinx.coroutines.CancellationException) { throw cancelled }
        catch (error: Exception) {
            Log.d("EpisodePreview", "extracao_falhou via=media3 etapa=$stage tipo=${error.javaClass.simpleName}")
        }
        return unavailable("sem_frame_decodificado")
    }
}
