package br.com.flaviotorres.iptvpremium.data.repository

import java.nio.ByteBuffer

/** Amostra apenas o tamanho final; nunca cria um Bitmap 4K intermediario. */
internal object YuvPreviewPixels {
    data class Plane(val data: ByteBuffer, val rowStride: Int, val pixelStride: Int)
    fun argb(y: Plane, u: Plane, v: Plane, left: Int, top: Int,
        sourceWidth: Int, sourceHeight: Int, width: Int, height: Int): IntArray {
        require(sourceWidth > 0 && sourceHeight > 0 && left >= 0 && top >= 0)
        require(width in 1..640 && height in 1..360)
        fun sample(p: Plane, x: Int, row: Int): Int =
            p.data.get(p.data.position() + row * p.rowStride + x * p.pixelStride).toInt() and 255
        return IntArray(width * height) { i ->
            val sx = left + (i % width).toLong().times(sourceWidth).div(width).toInt()
            val sy = top + (i / width).toLong().times(sourceHeight).div(height).toInt()
            val yy = (sample(y, sx, sy) - 16).coerceAtLeast(0)
            val uu = sample(u, sx / 2, sy / 2) - 128
            val vv = sample(v, sx / 2, sy / 2) - 128
            val red = ((298 * yy + 409 * vv + 128) shr 8).coerceIn(0, 255)
            val green = ((298 * yy - 100 * uu - 208 * vv + 128) shr 8).coerceIn(0, 255)
            val blue = ((298 * yy + 516 * uu + 128) shr 8).coerceIn(0, 255)
            (255 shl 24) or (red shl 16) or (green shl 8) or blue
        }
    }
}
