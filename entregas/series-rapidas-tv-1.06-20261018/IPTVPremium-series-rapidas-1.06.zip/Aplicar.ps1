﻿param([string]$Projeto = $PSScriptRoot, [switch]$Verificar)
$ErrorActionPreference = 'Stop'
$Projeto = [System.IO.Path]::GetFullPath($Projeto)
$payload = Join-Path $PSScriptRoot 'arquivos'
$manifest = Get-Content -LiteralPath (Join-Path $PSScriptRoot 'manifest.json') -Raw -Encoding UTF8 | ConvertFrom-Json
if (-not (Test-Path -LiteralPath (Join-Path $Projeto 'settings.gradle.kts'))) { throw 'Extraia o pacote na raiz do projeto, ou informe -Projeto com a pasta correta.' }
function Hash-File([string]$path) {
    if (Test-Path -LiteralPath $path -PathType Leaf) { return (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant() }
    return $null
}
$pending = [System.Collections.Generic.List[object]]::new()
# Check every payload and target before changing anything.
foreach ($entry in $manifest.files) {
    $destination = Join-Path $Projeto $entry.file
    if (Test-Path -LiteralPath $destination -PathType Container) { throw ('Existe uma pasta no lugar do arquivo: ' + $entry.file + '. Nada foi alterado.') }
    $choices = @($entry)
    if ($entry.alternatives) { $choices += @($entry.alternatives) }
    foreach ($choice in $choices) {
        if ((Hash-File (Join-Path $payload $choice.payload)) -ne $choice.after) { throw ('Pacote incompleto ou alterado: ' + $choice.payload) }
    }
    $current = Hash-File $destination
    $already = @($choices | Where-Object { $_.after -eq $current })
    if ($already.Count -gt 0) { continue }
    $accepted = @($choices | Where-Object { @($_.before) -contains $current })
    if ($accepted.Count -ne 1) { throw ('Versao diferente em ' + $entry.file + '. Nada foi alterado. Envie o arquivo atual para adaptar o pacote sem perder suas alteracoes.') }
    $choice = $accepted[0]
    $pending.Add([pscustomobject]@{ file = $entry.file; before = $current; after = $choice.after; source = $choice.payload })
}
if ($Verificar) { Write-Host ('Verificacao concluida: ' + $pending.Count + ' arquivo(s) a aplicar. Nada foi alterado.'); exit 0 }
if ($pending.Count -eq 0) { Write-Host 'Este pacote ja esta aplicado. Nada foi alterado.'; exit 0 }
$backup = Join-Path $Projeto ('.iptv-backups\series-rapidas-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [guid]::NewGuid().ToString('N').Substring(0,8))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
# Back up all existing targets before beginning installation.
foreach ($entry in $pending) {
    if ($null -ne $entry.before) {
        $saved = Join-Path $backup $entry.file
        New-Item -ItemType Directory -Path (Split-Path -Parent $saved) -Force | Out-Null
        Copy-Item -LiteralPath (Join-Path $Projeto $entry.file) -Destination $saved
    }
}
$attempted = [System.Collections.Generic.List[object]]::new()
try {
    foreach ($entry in $pending) {
        $destination = Join-Path $Projeto $entry.file
        New-Item -ItemType Directory -Path (Split-Path -Parent $destination) -Force | Out-Null
        $attempted.Add($entry)
        Copy-Item -LiteralPath (Join-Path $payload $entry.source) -Destination $destination -Force
        if ((Hash-File $destination) -ne $entry.after) { throw ('Falha na verificacao de ' + $entry.file) }
    }
} catch {
    $reason = $_.Exception.Message
    foreach ($entry in $attempted) {
        $destination = Join-Path $Projeto $entry.file
        if ($null -ne $entry.before) { Copy-Item -LiteralPath (Join-Path $backup $entry.file) -Destination $destination -Force }
        elseif (Test-Path -LiteralPath $destination -PathType Leaf) { Remove-Item -LiteralPath $destination -Force }
    }
    throw ('Aplicacao interrompida; arquivos anteriores restaurados. Motivo: ' + $reason)
}
Write-Host ('Concluido: ' + $pending.Count + ' arquivo(s). Backup: ' + $backup)
Write-Host 'Configuracoes locais e dados foram preservados.'
Write-Host 'Cache de temporadas e extracao Media3 preparados. Compile os APKs e teste no aparelho antes de publicar.'
