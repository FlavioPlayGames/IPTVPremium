from pathlib import Path
import os,subprocess,time
w=Path('/workspace/series-capas-temporada');o=Path('/workspace/outputs/series-capas-temporada');pw='/workspace/storage-toolchain/powershell/pwsh'
env=dict(os.environ,XDG_CACHE_HOME='/workspace/storage-toolchain/xdg-cache',XDG_DATA_HOME='/workspace/storage-toolchain/xdg-data',XDG_CONFIG_HOME='/workspace/storage-toolchain/xdg-config')
for p in o.glob('*.ps1'):
 command="$err=$null;$tokens=$null;[System.Management.Automation.Language.Parser]::ParseFile('"+str(p)+"',[ref]$tokens,[ref]$err)|Out-Null;if($err.Count){$err|Out-String|Write-Output;exit 1}"
 r=subprocess.run([pw,'-NoProfile','-Command',command],capture_output=True,text=True,env=env);assert r.returncode==0,(p,r.stdout,r.stderr)
print('PASS all PowerShell scripts parse')
fake=w/'fake-adb';fake.write_text('''#!/usr/bin/env python3
import sys,time
if 'devices' in sys.argv:print('List of devices attached\\nTV:5555 device')
elif '-d' in sys.argv:print('SeriesPosterPerf: stage=identity status=OK source=CACHE workHash=aaaaaaaaaaaa tmdbId=1')
else:
 print('SeriesPosterPerf: stage=identity status=OK source=CACHE workHash=aaaaaaaaaaaa tmdbId=1',flush=True)
 print('SeriesPosterPerf: stage=identity status=OK source=REMOTE workHash=abcdef123456 tmdbId=69478 url=https://secret.example password=secret title=secret',flush=True)
 print('SeriesPosterPerf: stage=image status=READY workHash=abcdef123456 tmdbId=69478',flush=True)
 print('OtherTag: password=secret',flush=True)
 time.sleep(30)
''');fake.chmod(0o755)
out=w/'collector-test';out.mkdir(exist_ok=True)
p=subprocess.Popen([pw,'-NoProfile','-File',str(o/'Coletar-Capas.ps1'),'-AdbPath',str(fake),'-PastaSaida',str(out)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,env=env)
time.sleep(3);stdout,stderr=p.communicate('\n',timeout=15);assert p.returncode==0,(stdout,stderr)
reports=list(out.glob('*.txt'));assert reports;body=max(reports,key=lambda p:p.stat().st_mtime).read_text(encoding='utf-8-sig')
assert 'source=REMOTE' in body and 'status=READY' in body and '69478' in body
assert all(x not in body for x in ['secret','password','https:','aaaaaaaaaaaa','OtherTag'])
print('PASS collector captures new cover metrics, excludes historical replay and strips titles, URLs and credentials')
