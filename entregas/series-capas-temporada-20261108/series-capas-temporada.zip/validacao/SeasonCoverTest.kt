package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.repository.*
import br.com.flaviotorres.iptvpremium.data.history.*
import br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType
import kotlinx.coroutines.*
import org.json.*

private fun episode(series:String,season:Int?,updated:Long,finished:Boolean=false,only:Boolean=false)=WatchHistoryEntry(
    playlistId="playlist",contentType=PlaybackContentType.EPISODE,contentId="episode-$series-$updated",seriesId=series,
    title="Episode",seasonNumber=season,episodeNumber=1,positionMs=15_000,durationMs=60_000,updatedAtMs=updated,finished=finished,seriesOnly=only)
private fun season(number:Int,path:String?)=JSONObject().put("season_number",number).put("poster_path",path)
private fun show(id:Int,name:String,poster:String?="/general-$id.jpg",vararg seasons:JSONObject)=JSONObject().put("id",id).put("name",name)
    .put("original_name",name).put("first_air_date","2020-01-01").put("poster_path",poster).put("seasons",JSONArray(seasons.toList()))
fun main()=runBlocking {
    fun pass(s:String)=println("PASS $s")
    val initial=episode("a",1,1)
    check(watchedSeriesSeasons(emptyList()).isEmpty());pass("unstarted series have no seasonal preference")
    check(watchedSeriesSeasons(listOf(initial,episode("a",2,2)))["a"]==2);pass("saved episode moving to another season updates its series cover")
    check(watchedSeriesSeasons(listOf(initial,episode("a",3,3,finished=true)))["a"]==3);pass("finishing an episode keeps its latest season instead of resurrecting an older unfinished season")
    check(watchedSeriesSeasons(listOf(episode("a",5,1),episode("a",1,2)))["a"]==1);pass("rewatching an earlier season follows recency instead of greatest season number")
    check(watchedSeriesSeasons(listOf(initial,episode("a",8,4,only=true)))["a"]==1);pass("series-only metadata does not replace an actual episode season")
    check(watchedSeriesSeasons(listOf(episode("a",0,10)))["a"]==0);pass("specials season zero is valid")
    check(watchedSeriesSeasons(listOf(episode("a",-1,10),episode("b",null,10))).isEmpty());pass("invalid or absent season numbers do not request artwork")
    check(watchedSeriesSeasons(listOf(episode("12",2,1),episode("m3u:series:34",4,1)))==mapOf("12" to 2,"m3u:series:34" to 4));pass("Xtream and M3U IDs use the same independent series rule")
    val normal=watchedSeriesSeasons(listOf(episode("same-series",1,1)))
    val kids=watchedSeriesSeasons(listOf(episode("same-series",3,1)))
    check(normal["same-series"]==1&&kids["same-series"]==3);pass("independent profile histories can select different seasons for the same cached artwork identity")
    val root=show(80001,"Season Cover Work","/general.jpg",season(0,"/special.jpg"),season(1,"/first.jpg"),season(2,"/second.jpg"),season(3,null),season(4,"https://wrong.example/episode.jpg"))
    var count=0
    val get:suspend(String,Map<String,String>)->String={path,_->count++;when(path){"/search/tv"->JSONObject().put("results",JSONArray().put(root)).toString();"/tv/80001"->root.toString();else->error("No season or episode request should be necessary: $path")}}
    val general=SeriesCatalogPosterResolver.resolve("Season Cover Work",2020,null,null,get)
    check(general?.url=="https://image.tmdb.org/t/p/w500/general.jpg");pass("series with no saved season uses its verified general poster")
    val first=SeriesCatalogPosterResolver.resolve("Season Cover Work",2020,null,null,get,1)
    val second=SeriesCatalogPosterResolver.resolve("Season Cover Work",2020,null,null,get,2)
    check(first?.url?.endsWith("/first.jpg")==true&&second?.url?.endsWith("/second.jpg")==true&&count==2)
    check(first?.fallbackUrl==general?.url&&second?.fallbackUrl==general?.url);pass("season change uses validated season posters from one metadata request and retains general download fallback")
    check(SeriesCatalogPosterResolver.peek("Season Cover Work",2020,null,null,1)?.url==first?.url)
    check(SeriesCatalogPosterResolver.peek("Season Cover Work",2020,null,null,2)?.url==second?.url)
    check(SeriesCatalogPosterResolver.peek("Season Cover Work",2020,null,null)?.url==general?.url);pass("initial RAM painting selects requested season without contaminating another profile or general artwork")
    for(n in listOf(3,4,99,-1))check(SeriesCatalogPosterResolver.resolve("Season Cover Work",2020,null,null,get,n)?.url==general?.url)
    pass("missing, unsafe or nonexistent season poster falls back to the verified general series poster")
    check(SeriesCatalogPosterResolver.resolve("Season Cover Work",2020,null,null,get,0)?.url?.endsWith("/special.jpg")==true);pass("specials use their own official poster")
    val seasonOnly=show(80002,"Only Season Poster Work",null,season(2,"/only-season.jpg"))
    val getOnly:suspend(String,Map<String,String>)->String={path,_->if(path=="/search/tv")JSONObject().put("results",JSONArray().put(seasonOnly)).toString()else seasonOnly.toString()}
    check(SeriesCatalogPosterResolver.resolve("Only Season Poster Work",2020,null,null,getOnly)==null)
    check(SeriesCatalogPosterResolver.resolve("Only Season Poster Work",2020,null,null,getOnly,2)?.url?.endsWith("/only-season.jpg")==true);pass("valid seasonal artwork can be used even if the verified series has no general poster")
    val poisonedKey="series_catalog_poster_v1:old work|2020||"
    CatalogMetadataCache.load(poisonedKey){JSONObject().put("id",1).put("poster_path","/old.jpg")}
    val updated=show(80003,"Old Work","/new.jpg",season(2,"/new-season.jpg"))
    check(SeriesCatalogPosterResolver.resolve("Old Work",2020,null,null,{path,_->if(path=="/search/tv")JSONObject().put("results",JSONArray().put(updated)).toString()else updated.toString()},2)?.url?.endsWith("/new-season.jpg")==true)
    pass("older cache without season metadata cannot prevent this revision from finding season posters")
    check(catalogMetadataTtlMillis(SERIES_CATALOG_POSTER_PREFIX+"work")==30L*24*60*60*1000);pass("season maps reuse the existing thirty-day bounded metadata cache")
    Unit
}
