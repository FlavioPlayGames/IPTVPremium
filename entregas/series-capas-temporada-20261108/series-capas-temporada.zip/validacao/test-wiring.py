from pathlib import Path
b=Path('/workspace/backup-reviewed-build/app/src/main/java/br/com/flaviotorres/iptvpremium')
for name in ['ui/components/UnifiedMediaCatalog.kt','ui/kids/KidsMediaCatalog.kt']:
 s=(b/name).read_text()
 assert 'watchedSeriesSeasons(history)'in s
 assert 'artworkSeason=if(series)watchedSeasons[entry.id]else null'in s
 assert s.count('entry.imdbId, entry.artworkSeason, epoch')==2
 assert 'peekCatalogPoster(entry.url,kind,entry.name,entry.year,entry.tmdbId,entry.imdbId,entry.artworkSeason)'in s
 assert 'loadCatalogPoster(context, entry.url, kind, entry.name, entry.year, entry.tmdbId, entry.imdbId, entry.artworkSeason)'in s
 print('PASS catalog/continue/favorites share history-driven seasonal cover and recreate bitmap state on season changes: '+name)
s=(b/'core/navigation/player/PlaybackCatalogBrowser.kt').read_text()
assert s.count('media.seasonNumber?:watchedSeasons[')==3
assert s.count('artworkImdbId,artworkSeason)')==3
print('PASS all three player series entry paths prefer the current playing episode season and pass it to initial and async artwork')
s=(b/'ui/movies/CatalogPosterFallback.kt').read_text()
assert 'if(kind!=PosterKind.SERIES)return MoviePosterLoader.loadWithRetry(context,url,kind)'in s
assert 'it.fallbackUrl?.let' in s and 'TmdbClientProvider.client::get,season'in s
print('PASS movies preserve old loading; failed seasonal image downloads may use verified general series artwork')
s=(b/'core/navigation/AppNavigation.kt').read_text()
assert 'WatchHistoryStore(context.applicationContext,activeHistoryKids)'in s and 'watchHistoryStore.all(playlist)'in s
print('PASS screen history remains scoped to the selected playlist and Kids/normal store at navigation boundary')
# Import/network/schema not touched by this revision.
w=Path('/workspace/series-capas-temporada/before')
assert all(not (w/name).exists()for name in ['data/cache/PlaylistCacheDatabase.kt','data/sync/M3uSourceSynchronizer.kt','data/cache/importer/M3uCacheImporter.kt'])
print('PASS this stage does not change import, Xtream fallback or database sources')
