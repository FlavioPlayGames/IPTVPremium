package br.com.flaviotorres.iptvpremium.data.history

/** Presentation only: never changes checkpoints or filters out a finished last episode. */
internal fun watchedSeriesSeasons(history:List<WatchHistoryEntry>):Map<String,Int> =
    latestHistorySeries(history.filter{!it.seriesOnly && it.seasonNumber!=null && it.seasonNumber>=0})
        .associate{it.seriesId!! to it.seasonNumber!!}
