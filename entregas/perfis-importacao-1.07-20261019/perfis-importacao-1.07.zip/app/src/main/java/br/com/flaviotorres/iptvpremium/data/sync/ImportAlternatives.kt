package br.com.flaviotorres.iptvpremium.data.sync

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

/** An alternative is lazy: it is never executed after a successful primary import. */
internal object ImportAlternatives {
    suspend fun <T> run(
        primary: suspend () -> T,
        alternative: (suspend () -> T)?,
        eligible: (Exception) -> Boolean = { true },
        onFallback: (Exception) -> Unit = {}
    ): T {
        val failed = try { return primary() }
        catch (cancelled: CancellationException) { throw cancelled }
        catch (error: Exception) { error }
        currentCoroutineContext().ensureActive()
        if (alternative == null || !eligible(failed)) throw failed
        onFallback(failed)
        currentCoroutineContext().ensureActive()
        try { return alternative() }
        catch (cancelled: CancellationException) { throw cancelled }
        catch (error: Exception) { if (error !== failed) error.addSuppressed(failed); throw error }
    }
}
