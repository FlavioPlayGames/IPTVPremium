package br.com.flaviotorres.iptvpremium.domain.model

sealed interface PlaylistSource {

    val id: String
    val name: String
    val isEnabled: Boolean

    data class XtreamCodes(
        override val id: String,
        override val name: String,
        override val isEnabled: Boolean = true,
        val serverUrl: String,
        val username: String,
        val password: String,
        val fallbackM3uUrl: String? = null
    ) : PlaylistSource

    data class M3u(
        override val id: String,
        override val name: String,
        override val isEnabled: Boolean = true,
        val playlistUrl: String
    ) : PlaylistSource
}