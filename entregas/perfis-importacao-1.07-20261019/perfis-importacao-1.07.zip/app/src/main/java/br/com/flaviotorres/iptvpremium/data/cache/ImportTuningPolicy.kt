package br.com.flaviotorres.iptvpremium.data.cache

/** Diagnostic profiles; release always uses ATUAL. No full-catalog materialization. */
internal enum class ImportProfile(val forceWal: Boolean, val normal: Boolean, val batchSize: Int, val batchCharacters: Int) {
    ATUAL(false, false, 250, 256 * 1024),
    WAL(true, false, 250, 256 * 1024),
    NORMAL(true, true, 250, 256 * 1024),
    LOTES(true, true, 2000, 2 * 1024 * 1024);
    companion object {
        fun stored(value: String?, debug: Boolean): ImportProfile =
            if (debug) entries.firstOrNull { it.name == value } ?: ATUAL else ATUAL
        fun requested(value: String): ImportProfile = entries.firstOrNull { it.name == value }
            ?: throw IllegalArgumentException("Perfil de importacao invalido.")
    }
}
internal object ImportTuningState {
    @Volatile var profile: ImportProfile = ImportProfile.ATUAL
}
