package br.com.flaviotorres.iptvpremium.data.cache
import android.content.Context
import android.os.Bundle
import android.os.SystemClock
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.platform.app.InstrumentationRegistry
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.parser.DefaultXtreamParser
import br.com.flaviotorres.iptvpremium.data.parser.XtreamArrayStream
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import br.com.flaviotorres.iptvpremium.data.sync.*
import br.com.flaviotorres.iptvpremium.domain.model.*
import br.com.flaviotorres.iptvpremium.domain.repository.PlaylistRepository
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
import java.io.StringReader
import java.util.UUID
class ImportTuningDeviceTest {
 private val context get()=ApplicationProvider.getApplicationContext<Context>()
 private fun report(message:String){InstrumentationRegistry.getInstrumentation().sendStatus(2,Bundle().apply{putString("stream",message+"\n")})}
 @Test fun configureProfile(){val id=InstrumentationRegistry.getArguments().getString("perfil")?:return;val profile=ImportProfile.requested(id);ImportTuning.saveForDebug(context,profile);assertEquals(profile,ImportTuning.load(context));report("PERFIL_CONFIGURADO=${profile.name}")}
 @Test fun allProfilesImportRollbackAndReopenBothFormats()=runBlocking(Dispatchers.IO){
  val original=ImportTuningState.profile
  try{for(round in 1..2)for(profile in if(round==1)ImportProfile.entries else ImportProfile.entries.reversed())for(format in if(round==1)listOf("XTREAM","M3U")else listOf("M3U","XTREAM")){
   ImportTuningState.profile=profile
   val name="bench-import-${UUID.randomUUID()}.db"
   fun open()=ImportTuning.configure(Room.databaseBuilder(context,PlaylistCacheDatabase::class.java,name),profile).build()
   var db=open()
   try{
    val sql=db.openHelper.writableDatabase
    val settings=ImportTuning.writerSettings(sql)
    val journal=settings.first;val syncValue=settings.second.toString()
    if(profile.forceWal)assertEquals("wal",journal.lowercase())
    if(profile.normal)assertEquals("1",syncValue)
    val dao=db.playlistCacheDao();val manager=PlaylistCacheGenerationManager(dao)
    var failure:Exception?=null
    val json=(1..5000).joinToString(",","[","]"){"{\"stream_id\":$it,\"name\":\"Fixture $it\",\"category_id\":\"1\",\"container_extension\":\"mp4\"}"}
    val provider=object:PlaylistRepository,ProgressiveXtreamRepository{
     override suspend fun loadContent(source:PlaylistSource):PlaylistContent=error("Streaming required")
     override suspend fun importXtream(source:PlaylistSource.XtreamCodes,sink:XtreamCatalogSink){XtreamArrayStream.read(StringReader(json),"get_vod_streams"){chunk,_->sink.append("get_vod_streams",DefaultXtreamParser().parseCatalogBatch("get_vod_streams",chunk))};failure?.let{throw it}}
    }
    val client=object:PlaylistHttpClient{
     override suspend fun get(url:String):String=error("Streaming required")
     override suspend fun readLines(url:String,onLine:suspend(String)->Unit){onLine("#EXTM3U");for(i in 1..5000){onLine("#EXTINF:-1 group-title=\"Movies\",Fixture $i");onLine("https://example.invalid/movie/fixture/fixture/$i.mp4")};failure?.let{throw it}}
    }
    val synchronizer=M3uSourceSynchronizer(provider,M3uCacheImporter(client,dao,manager),dao,manager)
    suspend fun import():String=if(format=="XTREAM")synchronizer.sync(PlaylistSource.XtreamCodes("fixture","Fixture",true,"https://example.invalid","fixture","fixture"))else synchronizer.sync(PlaylistSource.M3u("fixture","Fixture",playlistUrl="https://example.invalid/list.m3u"))
    val started=SystemClock.elapsedRealtime();val ready=import();val duration=SystemClock.elapsedRealtime()-started
    assertEquals(5000,dao.getMovieCount("fixture",ready));manager.activateReadyGenerationOnStartup("fixture")
    if(round==2)for(error in listOf(IOException("fixture"),CancellationException("fixture"))){failure=error;try{import();fail("Must fail")}catch(expected:Exception){assertSame(error,expected)};assertEquals(ready,dao.getActiveGeneration("fixture")!!.generationId);assertNull(dao.getReadyGeneration("fixture"));assertEquals(5000,dao.getMovieCount("fixture",ready))}
    report("BENCH_IMPORT rodada=$round perfil=${profile.name} formato=$format itens=5000 totalMs=$duration journal=$journal synchronous=$syncValue lote=${profile.batchSize}")
    db.close();db=open();assertEquals(ready,db.playlistCacheDao().getActiveGeneration("fixture")!!.generationId);assertEquals(5000,db.playlistCacheDao().getMovieCount("fixture",ready))
   }finally{db.close();context.deleteDatabase(name)}
  }}finally{ImportTuningState.profile=original}
 }
}
