package br.com.flaviotorres.iptvpremium.data.sync
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import br.com.flaviotorres.iptvpremium.domain.model.*
import br.com.flaviotorres.iptvpremium.domain.repository.PlaylistRepository
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
class ImportAlternativesRoomDeviceTest {
 private class Provider: PlaylistRepository, ProgressiveXtreamRepository {
  var failure: Exception?=null
  override suspend fun loadContent(source:PlaylistSource):PlaylistContent=error("Must stream")
  override suspend fun importXtream(source:PlaylistSource.XtreamCodes,sink:XtreamCatalogSink){
   sink.append("get_vod_streams",PlaylistContent(movies=listOf(Movie("xtream-only","Fixture",null,null,null,"https://example.invalid/movie.mp4",null,null,null))))
   failure?.let{throw it}
  }
 }
 private class Client: PlaylistHttpClient {
  var calls=0; var failure=false
  override suspend fun get(url:String):String=error("Must stream")
  override suspend fun readLines(url:String,onLine:suspend(String)->Unit){calls++;if(failure)throw IOException();listOf("#EXTM3U","#EXTINF:-1 group-title=\"Movies\",Alternative","https://example.invalid/movie/u/p/101.mp4").forEach{onLine(it)}}
 }
 private fun fixture(check:suspend(Provider,Client,M3uSourceSynchronizer,PlaylistCacheGenerationManager,br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao)->Unit)=runBlocking {
  val db=Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(),PlaylistCacheDatabase::class.java).build()
  try { val dao=db.playlistCacheDao();val manager=PlaylistCacheGenerationManager(dao);val provider=Provider();val client=Client();val sync=M3uSourceSynchronizer(provider,M3uCacheImporter(client,dao,manager),dao,manager);check(provider,client,sync,manager,dao) }finally{db.close()}
 }
 private val source=PlaylistSource.XtreamCodes("fixture","One list",true,"https://example.invalid","fixture","fixture","https://example.invalid/list.m3u")
 @Test fun completeXtreamNeverDownloadsM3u()=fixture{_,client,sync,manager,dao->val gen=sync.sync(source);assertEquals(0,client.calls);assertEquals(gen,dao.getReadyGeneration(source.id)!!.generationId);manager.activateReadyGenerationOnStartup(source.id);assertEquals(1,dao.getMovieCount(source.id,gen))}
 @Test fun partialXtreamIsDiscardedBeforeM3uReplacesCatalog()=fixture{provider,client,sync,manager,dao->val old=sync.sync(source);manager.activateReadyGenerationOnStartup(source.id);provider.failure=IOException();val next=sync.sync(source);assertEquals(1,client.calls);assertEquals(old,dao.getActiveGeneration(source.id)!!.generationId);assertEquals(1,dao.getMovieCount(source.id,next));manager.activateReadyGenerationOnStartup(source.id);assertNull(dao.getActiveMovieById(source.id,"xtream-only"));assertEquals(next,dao.getActiveGeneration(source.id)!!.generationId)}
 @Test fun bothFailuresPreserveActiveCatalog()=fixture{provider,client,sync,manager,dao->val old=sync.sync(source);manager.activateReadyGenerationOnStartup(source.id);provider.failure=IOException();client.failure=true;try{sync.sync(source);fail()}catch(expected:IOException){};assertEquals(1,client.calls);assertEquals(old,dao.getActiveGeneration(source.id)!!.generationId);assertNull(dao.getReadyGeneration(source.id))}
 @Test fun cancellationAndStorageFailureDoNotStartM3u()=fixture{provider,client,sync,_,dao->for(error in listOf(CancellationException(),XtreamCatalogWriteException(IOException()))){provider.failure=error;try{sync.sync(source);fail()}catch(expected:Exception){assertSame(error,expected)};assertEquals(0,client.calls);assertNull(dao.getReadyGeneration(source.id))}}
}
