package br.com.flaviotorres.iptvpremium.core.device
import androidx.datastore.preferences.core.PreferenceDataStoreFactory
import br.com.flaviotorres.iptvpremium.data.storage.PlaylistStorage
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.first
import org.junit.Assert.*
import org.junit.Test
import java.io.File
import java.util.UUID
class AlternativeStorageDeviceTest {
 @Test fun suppliedAlternativeSurvivesLocalStorageAndSnapshot()=runBlocking {
  val root=androidx.test.core.app.ApplicationProvider.getApplicationContext<android.content.Context>().cacheDir
  val file=File(root,"alternative-${UUID.randomUUID()}.preferences_pb");val scope=CoroutineScope(SupervisorJob()+Dispatchers.IO)
  val store=PreferenceDataStoreFactory.create(scope=scope,produceFile={file})
  try{val storage=PlaylistStorage(store);val source=PlaylistSource.XtreamCodes("same-id","Same list",true,"https://example.invalid","fixture","fixture","https://example.invalid/list.m3u");storage.applyPortalOperation(source.id,source);assertEquals(listOf(source),PlaylistStorage(store).playlists.first());assertEquals(listOf(source),decodePortalLists(encodePortalLists(PlaylistStorage(store).playlists.first())))}finally{scope.coroutineContext[Job]!!.cancelAndJoin();file.delete()}
 }
}
