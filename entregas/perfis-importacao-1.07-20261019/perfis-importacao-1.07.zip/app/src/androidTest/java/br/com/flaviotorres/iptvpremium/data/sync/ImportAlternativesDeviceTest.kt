package br.com.flaviotorres.iptvpremium.data.sync
import kotlinx.coroutines.*
import org.junit.Assert.*
import org.junit.Test
import java.io.IOException
class ImportAlternativesDeviceTest {
 @Test fun successfulPrimaryNeverCallsAlternative() = runBlocking { var calls=0; assertEquals("xtream", ImportAlternatives.run({"xtream"}, {calls++; "m3u"})); assertEquals(0,calls) }
 @Test fun failureWaitsForPrimaryCleanup() = runBlocking { val events=mutableListOf<String>(); val value=ImportAlternatives.run({try {events.add("primary"); throw IOException()} finally {events.add("cleanup")}}, {events.add("m3u"); "ok"}); assertEquals("ok",value); assertEquals(listOf("primary","cleanup","m3u"),events) }
 @Test fun bothFailuresKeepOriginalAsSuppressed() = runBlocking { val primary=IOException("first"); val alternative=IOException("second"); try {ImportAlternatives.run({throw primary},{throw alternative}); fail()} catch(e:IOException){assertSame(alternative,e); assertSame(primary,e.suppressed.single())} }
 @Test fun missingAlternativePreservesFailure() = runBlocking { val primary=IOException(); try {ImportAlternatives.run({throw primary},null); fail()} catch(e:IOException){assertSame(primary,e)} }
 @Test fun cancellationNeverStartsAlternative() = runBlocking { var calls=0; try {ImportAlternatives.run({throw CancellationException()},{calls++; "bad"}); fail()} catch(e:CancellationException){}; assertEquals(0,calls) }
 @Test fun cancelledCoroutineCannotStartAlternativeEvenAfterIoFailure() = runBlocking { var calls=0; val task=launch(start=CoroutineStart.UNDISPATCHED) { ImportAlternatives.run({currentCoroutineContext().cancel(); throw IOException()},{calls++; "bad"}) }; task.join(); assertTrue(task.isCancelled); assertEquals(0,calls) }
 @Test fun localStorageFailureDoesNotDownloadAgain() = runBlocking {var calls=0; val error=IllegalStateException(); try {ImportAlternatives.run({throw error},{calls++;"bad"},eligible={false});fail()}catch(e:IllegalStateException){assertSame(error,e)};assertEquals(0,calls)}
 @Test fun fatalErrorsAreNotRetried() = runBlocking {var calls=0; val error=AssertionError();try {ImportAlternatives.run({throw error},{calls++;"bad"});fail()}catch(e:AssertionError){assertSame(error,e)};assertEquals(0,calls)}
}
