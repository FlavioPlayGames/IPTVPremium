package br.com.flaviotorres.iptvpremium.core.device
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import org.junit.Assert.*
import org.junit.Test
class PortalPlaylistCodecDeviceTest {
 private val source=PlaylistSource.XtreamCodes("same-id","Same list",true,"https://example.invalid","fixture-user","fixture-password","https://example.invalid/get.php?username=fixture-user&password=fixture-password&type=m3u_plus")
 @Test fun alternativeSurvivesPortalSnapshotRoundTrip(){ assertEquals(listOf(source),decodePortalLists(encodePortalLists(listOf(source)))) }
 @Test fun oldXtreamAndNativeM3uStayCompatible(){val old=source.copy(fallbackM3uUrl=null);val m3u=PlaylistSource.M3u("m3u","Native",playlistUrl="https://example.invalid/list.m3u");assertEquals(listOf(old,m3u),decodePortalLists(encodePortalLists(listOf(old,m3u))))}
 @Test fun unsafeAlternativeIsRejected(){val array=encodePortalLists(listOf(source));array.getJSONObject(0).put("fallbackM3uUrl","file:///bad");try{decodePortalLists(array);fail()}catch(expected:IllegalArgumentException){}}
}
