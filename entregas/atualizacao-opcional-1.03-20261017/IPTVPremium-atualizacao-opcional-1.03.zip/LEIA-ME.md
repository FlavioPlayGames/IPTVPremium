# Aplicativo 1.03 / número interno 5

Aplica cinco arquivos de atualização opcional; não altera favoritos, histórico, listas, banco de catálogo, temas ou teclado.
Mantém a assinatura e configurações locais; o APK deve ser compilado no computador original.
O aviso oferece Mais tarde (também Voltar), preserva a navegação e lembra a escolha para aquela versão.
Para retomar, Configurações > Atualização > Verificar atualização.
A publicação de uma versão posterior pode abrir um novo aviso.
Os APKs continuam sendo selecionados pelas ABIs suportadas pelo Android.
O Android ainda exige autorização para instalar de fora da loja e confirmação da instalação.

O preparador cria backup, confere os hashes antes de alterar fontes e prepara exatamente 1.03/code5.
Se o projeto já estiver acima de code5, aborta para não rebaixar a versão.
Preserva os bytes de todas as demais propriedades locais. Detecta o Java do Android Studio para compilar.
Nenhum APK gerado na nuvem está incluído neste pacote.

TESTE PRIMEIRO: instalar por cima da 1.02, com adb install -r ou pelo Android Studio, sem desinstalar ou limpar dados.
Comparar favoritos e continuar assistindo de filmes e séries; fechar e reabrir e comparar novamente.
A preservação na atualização real ainda depende desse teste no aparelho.
O script não instala nem publica automaticamente.

O painel opcional é entregue separadamente. Aplicativos antigos recebem update:null do novo Worker
porque não conseguem exibir o botão Mais tarde; precisam instalar uma vez a nova versão manualmente.
Depois disso, publicações seguintes podem ser adiadas dentro do aplicativo.

Validação: compilação Android, políticas/ABI, ciclo do gerenciador com serviços Android simulados,
Worker, sincronização autenticada de comandos criptografados e navegador real.
Esses testes não substituem o teste de instalação e navegação por controle remoto.
