package br.com.flaviotorres.iptvpremium.core.update

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.R
import br.com.flaviotorres.iptvpremium.core.device.PortalOutlineButton
import kotlinx.coroutines.launch

@Composable
internal fun AppUpdateScreen() {
    val state by AppUpdateManager.state.collectAsState()
    val policy = state.policy ?: return
    val busy = state.stage in listOf("downloading", "verifying")
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var refreshing by remember { mutableStateOf(false) }
    var permissionMessage by remember { mutableStateOf<String?>(null) }
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        if (context.packageManager.canRequestPackageInstalls() && AppUpdateManager.state.value.showPrompt && AppUpdateManager.state.value.policy == policy) scope.launch { AppUpdateManager.install(context) }
        else permissionMessage = "Autorize a instalação de atualizações deste aplicativo nas configurações do Android."
    }
    val laterFocus = remember { FocusRequester() }
    Dialog(onDismissRequest = { AppUpdateManager.defer() }, properties = DialogProperties(
        usePlatformDefaultWidth = false, dismissOnClickOutside = false
    )) {
    LaunchedEffect(policy.versionCode) { laterFocus.requestFocus() }
    Box(Modifier.fillMaxSize().background(Color(0xFF08090B)).padding(20.dp), contentAlignment = Alignment.Center) {
        Column(Modifier.widthIn(max = 620.dp).verticalScroll(rememberScrollState())
            .background(Color(0x60111419), RoundedCornerShape(18.dp))
            .border(1.dp, Brush.linearGradient(listOf(br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFF7A5215), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE6A0), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFD6A32E), br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFF5CD))), RoundedCornerShape(18.dp))
            .padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("ATUALIZAÇÃO DISPONÍVEL", color = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE6A0), fontSize = 22.sp, fontFamily = FontFamily(Font(R.font.cinzel_semibold)))
            Text("Versão ${policy.versionName}", color = Color.White, fontSize = 18.sp)
            Text("Há uma nova versão disponível. Você pode atualizar agora ou continuar usando o aplicativo.", color = Color(0xFFF2F2F2), fontSize = 16.sp)
            if (policy.notes.isNotBlank()) Text(policy.notes, color = Color(0xFFF2F2F2), fontSize = 15.sp)
            if (state.stage == "downloading") {
                Text("Baixando… ${(state.progress * 100).toInt()}%", color = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE6A0), fontSize = 15.sp)
                Box(Modifier.fillMaxWidth().height(3.dp).background(Color(0xFF292A2D))) {
                    Box(Modifier.fillMaxWidth(state.progress.coerceIn(0f, 1f)).fillMaxHeight().background(br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE6A0)))
                }
            }
            if (state.stage == "verifying") Text("Verificando atualização…", color = br.com.flaviotorres.iptvpremium.ui.theme.ThemeColors.color(0xFFFFE6A0), fontSize = 15.sp)
            state.message?.let { Text(it, color = Color(0xFFF2F2F2), fontSize = 14.sp) }
            permissionMessage?.let { Text(it, color = Color(0xFFF2F2F2), fontSize = 14.sp) }
            PortalOutlineButton(label = when (state.stage) { "downloading" -> "Baixando atualização…"; "verifying" -> "Verificando atualização…"; "ready" -> if (context.packageManager.canRequestPackageInstalls()) "Instalar atualização" else "Autorizar instalação"; "error" -> "Tentar novamente"; else -> "Atualizar agora" }, enabled = !busy) {
                permissionMessage = null
                if (state.stage == "ready") {
                    if (context.packageManager.canRequestPackageInstalls()) scope.launch { AppUpdateManager.install(context) }
                    else runCatching { permission.launch(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:" + context.packageName))) }
                        .onFailure { permissionMessage = "Abra as configurações do Android e autorize instalações deste aplicativo." }
                } else AppUpdateManager.download()
            }
            PortalOutlineButton(if (refreshing) "Consultando…" else "Verificar novamente", enabled = !refreshing && !busy) {
                scope.launch {
                    refreshing = true
                    try { AppUpdateManager.refresh() } catch (_: Exception) { AppUpdateManager.reportRefreshFailure() }
                    finally { refreshing = false }
                }
            }
            PortalOutlineButton("Mais tarde", modifier = Modifier.fillMaxWidth().focusRequester(laterFocus)) { AppUpdateManager.defer() }
            Text("O Android pedirá sua confirmação para instalar.", color = Color(0xFFF2F2F2), fontSize = 13.sp)
        }
    }
}
}
