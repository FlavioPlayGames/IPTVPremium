# IPTV Premium — r5: janela móvel de capas

Atualização incremental sobre a r4. O aplicador altera oito arquivos Kotlin (um novo), confere os hashes da base e do pacote, cria backup e permite desfazer. Não contém APK, lista M3U, credenciais ou recursos grandes.

## Regra implementada

A regra compartilhada vale para Filmes e Séries, tanto Xtream quanto M3U, nos catálogos normal e Kids. Também é usada nas categorias, Favoritos, pesquisas e Continuar desses catálogos.

- Até **30 itens na janela ativa**, incluindo os visíveis: normalmente 10 visíveis, até 15 adiante e até 5 atrás.
- Com 8 visíveis, a janela tem até 28 itens. Nas extremidades da lista, pode ter menos; não busca posições inexistentes. Se mais itens estiverem parcialmente visíveis, reduz a reserva para continuar dentro de 30.
- Ao subir, a prioridade se inverte: até 15 acima e 5 abaixo. A fileira mais próxima na direção do movimento é preparada em grupos de até 5.
- Só a fileira mais próxima fora da tela é decodificada antecipadamente. As demais são antecipadas como arquivos comprimidos no cache de disco existente. Capas já decodificadas podem ser reaproveitadas enquanto estiverem na janela e couberem no LRU de RAM existente.
- A janela retém o trabalho que continua útil durante uma mudança normal de fileira. Cancela o que ficou fora da nova janela. Na navegação rápida, pausa a antecipação, cancela trabalhos ativos opcionais e retoma a janela da posição final, sem terminar uma fila de posições abandonadas.
- Mantém os intervalos existentes de estabilização: 200 ms após cessar a rolagem e a pausa de navegação rápida de 900 ms. As capas visíveis continuam com seu carregamento próprio e prioridade de rede.
- Apenas dois trabalhadores de antecipação. Não aumenta a concorrência de download nem de decodificação existente.

A antecipação agora recebe título, ano e IDs disponíveis, além da URL. Assim, uma série M3U cuja foto de episódio foi rejeitada também pode ter sua capa verificada preparada ANTES de aparecer. As capas válidas do provedor continuam preferidas. Não realiza busca de todos os títulos ou download de outro catálogo remoto.

A leitura antecipada é uma consulta local limitada a 30 registros no banco, sem avançar/descarregar as páginas visíveis. Preserva os filtros de categoria, favoritos, ordem e controle parental do repositório existente. Títulos sem identificação segura continuam com capa genérica.

## Armazenamento e rotatividade preservados

A meta informada continua sendo 400 MB para o aplicativo completo. Esta revisão não amplia cotas nem cria um cache paralelo.

Os limites existentes do cache descartável são **100 MB no total e 75 MB para imagens**, com **125 arquivos de capas por tipo**. Os arquivos que definem esses limites e o algoritmo de rotação não foram modificados.

Quando uma nova reserva excederia a cota, o mecanismo existente remove um lote de arquivos antigos elegíveis para liberar espaço. Preserva leitores/gravações ativos; contabiliza as reservas dos temporários; recusa a gravação quando não consegue espaço. Sair da janela de 30 libera referências do cache RAM pertencentes à janela antiga, preservando as que também atendem outra janela ativa ou a Home. Os arquivos em disco seguem a rotação existente, sem apagar toda a categoria ao navegar.

O teto do cache não mede sozinho o tamanho completo instalado: recursos do aplicativo, bancos e dados persistentes também participam da meta de 400 MB. A ocupação total no aparelho não foi medida remotamente nesta revisão.

## Aplicar e instalar na TV

Baixe `continuacao-iptv-premium-r5.zip` em Downloads e execute no PowerShell:

```powershell
$projeto = "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium"
$pasta = "$env:USERPROFILE\Downloads\continuacao-iptv-premium-r5"
Unblock-File -LiteralPath "$pasta.zip"
Expand-Archive -LiteralPath "$pasta.zip" -DestinationPath $pasta -Force
Set-Location $pasta
powershell -ExecutionPolicy Bypass -File .\Aplicar.ps1 -Projeto "$projeto"
if ($LASTEXITCODE -eq 0) {
    powershell -ExecutionPolicy Bypass -File .\Instalar-TV.ps1 -Projeto "$projeto"
} else {
    throw "A aplicacao falhou. Confira a mensagem antes de compilar/instalar."
}
```

O instalador está na pasta extraída em Downloads. Compila assembleDesempenho com os arquivos/assinatura locais, escolhe a ABI da TV e instala com `adb install -r`. Não desinstala nem limpa dados. Se o aplicador recusar a base, não force a substituição.

Não precisa reimportar a lista nem limpar o cache para ativar a janela nova. A aplicação mostra o caminho do backup e o comando para desfazer.

## Conferência na TV

Teste Filmes e Séries de cada formato. Desça uma fileira, aguarde, desça de novo; depois suba e faça uma sequência rápida, parando em outra fileira. Confira também Favoritos, pesquisa, Continuar e Kids, preservando o bloqueio parental.

Para registrar a janela e os tempos enquanto navega, execute na pasta extraída:

```powershell
powershell -ExecutionPolicy Bypass -File .\Coletar-Diagnostico.ps1 -AoVivo
```

Ctrl+C encerra. Saída: `Downloads\IPTV-tempos-capas-r5.txt`. Os novos registros PosterWindowPerf informam posição, direção, visíveis, reserva à frente/atrás, limite e trabalhadores ativos. `ready` conta arquivos comprimidos obtidos, não confirma pixels exibidos na TV. O coletor exporta somente formatos permitidos de contagens, tempos e IDs públicos, sem URLs ou credenciais. Não apaga o buffer da TV; a amostra pode incluir registros anteriores à coleta.

Os testes locais confirmam a regra e os limites. A primeira visita ainda depende da rede; não há promessa de imagem instantânea ou ganho já medido na TV. Veja VALIDACAO.md.
