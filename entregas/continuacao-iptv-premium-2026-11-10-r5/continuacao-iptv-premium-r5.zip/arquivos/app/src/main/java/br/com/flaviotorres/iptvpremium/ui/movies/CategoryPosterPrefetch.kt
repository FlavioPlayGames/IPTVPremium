package br.com.flaviotorres.iptvpremium.ui.movies

import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.paging.LoadState
import androidx.paging.compose.LazyPagingItems
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.ui.settings.ParentalPolicy
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

private data class PosterViewport(val first: Int, val last: Int, val posters: Map<Int, PosterCandidate>,
    val busy: Boolean, val scrolling: Boolean, val total: Int)

/** One bounded moving window for both provider formats, normal/Kids, catalogue/favourites/history. */
@Composable
internal fun <T : Any> CategoryPosterPrefetch(kind: PosterKind, category: String,
    grid: LazyGridState, paging: LazyPagingItems<T>?, poster: (T) -> PosterCandidate, blocked: Boolean,
    page: (suspend (Int) -> PosterPage)?, navigationActivity: StateFlow<Long>? = null,
    history: List<PosterCandidate>? = null, decorate: (PosterCandidate) -> PosterCandidate = { it }) {
    val context = LocalContext.current.applicationContext
    val access by ParentalPolicy.accessFlow.collectAsState(initial = ParentalPolicy.access())
    val blockedNow by rememberUpdatedState(blocked)
    val readPage by rememberUpdatedState(page)
    val getPoster by rememberUpdatedState(poster)
    val readHistory by rememberUpdatedState(history)
    val decoratePoster by rememberUpdatedState(decorate)
    DisposableEffect(kind) { onDispose { MoviePosterLoader.releaseVisible(context, kind) } }
    LaunchedEffect(paging, category, kind, access, navigationActivity, history != null) {
        val items = paging
        if (items == null && readHistory == null) return@LaunchedEffect
        if (items != null && readHistory == null) launch {
            recoverCatalogViewport(snapshotFlow {
                val visible = grid.layoutInfo.visibleItemsInfo
                val state = items.loadState
                CatalogViewportSnapshot(
                    visible.minOfOrNull { it.index } ?: -1,
                    visible.maxOfOrNull { it.index } ?: -1,
                    visible.count { it.index in 0 until items.itemCount && items.peek(it.index) != null },
                    items.itemCount,
                    listOf(state.refresh, state.prepend, state.append).any { it is LoadState.Loading },
                    listOf(state.refresh, state.prepend, state.append).any { it is LoadState.Error })
            }) { viewport ->
                android.util.Log.i("CatalogViewportPerf", "kind=${kind.name} recovery=${if (viewport.error) "retry" else "refresh"} " +
                    "first=${viewport.first} last=${viewport.last} present=0 total=${viewport.total}")
                for (index in (viewport.first..viewport.last).take(30)) {
                    if (index in 0 until items.itemCount) items[index]
                }
                if (viewport.error) items.retry() else items.refresh()
            }
        }
        val plan = PosterWindowPlan()
        val reserve = PosterWindowQueue(this,
            fetch = { candidate -> prefetchCatalogPoster(context, kind, candidate) },
            prepare = { urls -> MoviePosterLoader.prepareNearestCategoryRow(context, kind, urls) },
            retain = { urls -> MoviePosterLoader.retainWindow(kind, urls) },
            report = { target, ready, active -> android.util.Log.d("PosterWindowPerf", "kind=${kind.name} target=$target ready=$ready active=$active") })
        var previousCandidates = emptyMap<Int, PosterCandidate>()
        val pace = PosterNavigationPace(this)
        launch { navigationActivity?.drop(1)?.collect { pace.activity() } }
        val viewports = snapshotFlow {
            val visible = grid.layoutInfo.visibleItemsInfo.sortedBy { it.index }
            val local = readHistory
            val total = local?.size ?: items?.itemCount ?: 0
            val candidates = visible.mapNotNull { v ->
                val candidate = local?.getOrNull(v.index) ?: if (local == null && v.index in 0 until total)
                    items?.peek(v.index)?.let(getPoster) else null
                candidate?.let { v.index to it }
            }.toMap()
            PosterViewport(visible.firstOrNull()?.index ?: -1, visible.lastOrNull()?.index ?: -1, candidates,
                blockedNow || visible.isEmpty() || (local == null && items?.loadState?.refresh is LoadState.Loading),
                grid.isScrollInProgress, total)
        }
        combine(viewports, CatalogMemoryPolicy.pressured, MediaOpeningPriority.busy, CatalogImportPriority.busy, pace.rapid) { viewport, pressure, selectedMedia, importing, rapid ->
            viewport.copy(busy = viewport.busy || pressure || selectedMedia || importing || rapid)
        }.distinctUntilChanged().collectLatest { viewport ->
            val window = plan.window(viewport.first, viewport.last, viewport.total)
            if (readHistory == null && items != null && viewport.first >= 0 &&
                viewport.posters.size < window.visible.size && items.itemCount > 0) {
                withFrameNanos { }
                requestMissingCatalogItems(grid.layoutInfo.visibleItemsInfo.map { it.index },
                    { items.itemCount }, { items.peek(it) }, { items[it] })
            }
            MoviePosterLoader.updateVisible(context, kind, viewport.posters.values.map { it.url })
            if (viewport.busy) { reserve.pause(); return@collectLatest }
            // Cancel obsolete targets as soon as the row changes, before waiting for new local data.
            val keep = window.priority.toSet()
            previousCandidates = previousCandidates.filterKeys { it in keep } + viewport.posters
            reserve.update(window.priority.mapNotNull { previousCandidates[it] }, window.nearest.mapNotNull { previousCandidates[it] })
            if (viewport.scrolling) return@collectLatest
            delay(200L)
            val indices = window.priority
            if (indices.isEmpty()) return@collectLatest
            val first = indices.minOrNull()!!
            val count = indices.maxOrNull()!! - first + 1
            val local = readHistory
            val candidates = previousCandidates.toMutableMap()
            if (local != null) {
                indices.forEach { index -> local.getOrNull(index)?.let { candidates[index] = it } }
            } else {
                // Local Room query only, at most 30 rows; never requests another provider catalogue.
                try {
                    readPage?.invoke(first)?.posters?.take(count)?.forEachIndexed { offset, candidate ->
                        candidates[first + offset] = decoratePoster(candidate)
                    }
                } catch (cancelled: CancellationException) { throw cancelled }
                catch (error: Exception) {
                    android.util.Log.d("PosterQueuePerf", "stage=ahead_deferred type=${error.javaClass.simpleName}")
                }
                // Prefer exact rendered records, including any nullable artwork identity.
                candidates.putAll(viewport.posters)
            }
            previousCandidates = candidates.filterKeys { it in keep }
            val priority = indices.mapNotNull { candidates[it] }
            reserve.update(priority, window.nearest.mapNotNull { candidates[it] })
            android.util.Log.i("PosterWindowPerf", "kind=${kind.name} first=${viewport.first} last=${viewport.last} " +
                "direction=${if(window.descending)"DOWN"else"UP"} visible=${window.visible.size} ahead=${window.ahead.size} behind=${window.behind.size} target=${priority.size} limit=${PosterWindow.CAPACITY}")
        }
    }
}
