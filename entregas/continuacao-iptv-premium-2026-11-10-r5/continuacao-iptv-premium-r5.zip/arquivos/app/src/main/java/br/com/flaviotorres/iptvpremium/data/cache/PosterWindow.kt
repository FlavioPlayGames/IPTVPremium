package br.com.flaviotorres.iptvpremium.data.cache

import kotlinx.coroutines.*

/** Item count is independent of the configured number of columns (normally 8 or 10 visible). */
internal data class PosterWindow(val visible: List<Int>, val ahead: List<Int>, val behind: List<Int>, val descending: Boolean = true) {
    val priority: List<Int> get() = visible + ahead + behind
    val nearest: List<Int> get() = ahead.take(PosterCategoryPolicy.GROUP)
    companion object { const val CAPACITY = 30; const val AHEAD = 15; const val BEHIND = 5 }
}
internal class PosterWindowPlan {
    private var previousFirst: Int? = null
    private var descending = true
    fun window(first: Int, last: Int, total: Int): PosterWindow {
        if (total <= 0 || first < 0 || last < first) return PosterWindow(emptyList(), emptyList(), emptyList())
        val start = first.coerceAtMost(total - 1)
        val end = last.coerceIn(start, minOf(total.toLong() - 1, start.toLong() + PosterWindow.CAPACITY - 1).toInt())
        previousFirst?.let { if (start != it) descending = start > it }
        previousFirst = start
        val visible = (start..end).toList()
        val spare = PosterWindow.CAPACITY - visible.size
        val trailing = minOf(PosterWindow.BEHIND, spare)
        val forward = minOf(PosterWindow.AHEAD, spare - trailing)
        val below = ((end.toLong() + 1)..minOf(total.toLong() - 1, end.toLong() + if (descending) forward else trailing)).map { it.toInt() }
        val above = (maxOf(0, start - if (descending) trailing else forward) until start).reversed().toList()
        return if (descending) PosterWindow(visible, below, above, true) else PosterWindow(visible, above, below, false)
    }
}

/** One current viewport, two workers; overlapping work survives a normal row move. Main-context confined. */
internal class PosterWindowQueue(
    private val scope: CoroutineScope,
    private val fetch: suspend (PosterCandidate) -> String?,
    private val prepare: suspend (List<String>) -> Unit,
    private val retain: (List<String>) -> Unit = {},
    private val report: (Int, Int, Int) -> Unit = { _, _, _ -> }
) {
    private var targets = emptyList<PosterCandidate>()
    private var nearest = emptySet<PosterCandidate>()
    private val ready = linkedMapOf<PosterCandidate, String>()
    private val failed = mutableSetOf<PosterCandidate>()
    private val active = linkedMapOf<PosterCandidate, Job>()
    private var enabled = false
    private var prepareJob: Job? = null
    fun pause() {
        enabled = false
        active.values.toList().forEach { it.cancel() }
        prepareJob?.cancel()
    }
    fun update(priority: List<PosterCandidate>, prepareNext: List<PosterCandidate>) {
        enabled = true
        targets = priority.distinct().take(PosterWindow.CAPACITY)
        nearest = prepareNext.filter { it in targets }.take(PosterCategoryPolicy.GROUP).toSet()
        val keep = targets.toSet()
        ready.keys.retainAll(keep); failed.retainAll(keep)
        active.filterKeys { it !in keep }.values.toList().forEach { it.cancel() }
        prepareJob?.cancel()
        prepareJob = scope.launch { prepare(nearest.mapNotNull { ready[it] }) }
        retainCurrent()
        pump()
        status()
    }
    private fun retainCurrent() = retain((targets.mapNotNull { it.url } + ready.values).distinct())
    private fun status() = report(targets.size, ready.size, active.size)
    private fun pump() {
        if (!enabled || !scope.isActive) return
        while (active.size < PosterNetworkBudget.BACKGROUND_REQUESTS) {
            val item = targets.firstOrNull { it !in ready && it !in failed && it !in active } ?: return
            val job = scope.launch(start = CoroutineStart.LAZY) {
                try {
                    val url = fetch(item)
                    currentCoroutineContext().ensureActive()
                    if (item in targets) {
                        if (url != null) {
                            ready[item] = url
                            retainCurrent()
                            if (item in nearest) prepare(listOf(url))
                        } else failed += item
                    }
                } catch (cancelled: CancellationException) { throw cancelled }
                catch (_: Exception) { if (item in targets) failed += item }
            }
            active[item] = job
            // Also runs when canceled before the coroutine body ever starts.
            job.invokeOnCompletion { active.remove(item); pump(); status() }
            job.start()
        }
    }
}
