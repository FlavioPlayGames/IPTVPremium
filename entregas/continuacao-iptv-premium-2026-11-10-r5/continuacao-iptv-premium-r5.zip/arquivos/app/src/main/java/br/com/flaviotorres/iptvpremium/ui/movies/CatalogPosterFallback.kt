package br.com.flaviotorres.iptvpremium.ui.movies

import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.remote.TmdbClientProvider
import br.com.flaviotorres.iptvpremium.data.repository.SeriesCatalogPosterResolver
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit

private val verifiedPosterSlots=Semaphore(2)
internal val SeasonPosterRevision=MutableStateFlow(0L)
internal fun peekCatalogPoster(url:String?,kind:PosterKind,name:String,year:Int?,tmdbId:String?,imdbId:String?,season:Int?=null):ImageBitmap? {
    val missingProvider= !GenericPosterPolicy.hasSource(url)
    val seasonal=if(kind==PosterKind.SERIES&&(season!=null||missingProvider))SeriesCatalogPosterResolver.peek(name,year,tmdbId,imdbId,season)?.takeIf{missingProvider||it.isSeason}else null
    return seasonal?.let{MoviePosterLoader.peekBitmap(it.url)}?:MoviePosterLoader.peekBitmap(url)
}

/** Valid provider covers stay first. Only visible missing/rejected covers get a verified fallback. */
internal suspend fun loadCatalogPoster(context:Context,url:String?,kind:PosterKind,name:String,year:Int?,tmdbId:String?,imdbId:String?,season:Int?=null,onProviderReady:(ImageBitmap)->Unit={}):ImageBitmap? {
    if(kind!=PosterKind.SERIES)return MoviePosterLoader.loadWithRetry(context,url,kind)
    if(!GenericPosterPolicy.hasSource(url)) {
        val prepared=SeriesCatalogPosterResolver.cached(name,year,tmdbId,imdbId,season)
        prepared?.let{MoviePosterLoader.loadWithRetry(context,it.url,kind)}?.let{return it}
        MediaOpeningPriority.awaitIdle();CatalogImportPriority.busy.first{!it}
        try {
            val queuedAt=System.nanoTime()
            val verified=verifiedPosterSlots.withPermit {
                android.util.Log.i("SeriesPosterPerf","stage=lookup_queue elapsedMs=${(System.nanoTime()-queuedAt)/1_000_000}")
                withTimeoutOrNull(15_000L) {
                    SeriesCatalogPosterResolver.resolve(name,year,tmdbId,imdbId,TmdbClientProvider.client::get,season)
                }
            } ?: return null
            // Image downloads and decoding have their own budgets; release the lookup slot first.
            return MoviePosterLoader.loadWithRetry(context,verified.url,kind)
        }catch(cancelled:CancellationException){throw cancelled}
        catch(_:Exception){return null}
    }
    if(season==null)return MoviePosterLoader.loadWithRetry(context,url,kind)
    val prepared=SeriesCatalogPosterResolver.cached(name,year,tmdbId,imdbId,season)?.takeIf{it.isSeason}
    prepared?.let{MoviePosterLoader.loadCached(context,it.url)}?.let{return it}
    val provider=MoviePosterLoader.loadWithRetry(context,url,kind)
    provider?.let(onProviderReady)
    // A stored public metadata lookup is local IO, not a search or a details request.
    return prepared?.let{MoviePosterLoader.loadWithRetry(context,it.url,kind)}?:provider
}

/** Called after an episode starts playing, never from an unvisited catalogue row. */
internal suspend fun warmPlayingSeasonPoster(context:Context,name:String,year:Int?,tmdbId:String?,imdbId:String?,season:Int) {
    if(season<0)return
    MediaOpeningPriority.awaitIdle();CatalogImportPriority.busy.first{!it}
    try {
        val poster=verifiedPosterSlots.withPermit {
            withTimeoutOrNull(15_000L){
                SeriesCatalogPosterResolver.resolve(name,year,tmdbId,imdbId,TmdbClientProvider.client::get,season)?.takeIf{it.isSeason}
            }
        } ?: return
        if(MoviePosterLoader.loadWithRetry(context,poster.url,PosterKind.SERIES)!=null)SeasonPosterRevision.update{it+1}
    }catch(cancelled:CancellationException){throw cancelled}
    catch(_:Exception){ /* Optional artwork must never fail playback. */ }
}

/** Bounded off-screen anticipation uses compressed files, never decoded bitmaps for the full window. */
internal suspend fun prefetchCatalogPoster(context:Context,kind:PosterKind,item:PosterCandidate):String? {
    MediaOpeningPriority.awaitIdle();CatalogImportPriority.busy.first{!it}
    val missing = !GenericPosterPolicy.hasSource(item.url)
    val cached = if(kind==PosterKind.SERIES && (missing || item.season!=null))
        SeriesCatalogPosterResolver.cached(item.name,item.year,item.tmdbId,item.imdbId,item.season)
            ?.takeIf{missing || it.isSeason} else null
    val url = cached?.url ?: if(kind==PosterKind.SERIES && missing && item.name.isNotBlank()) {
        verifiedPosterSlots.withPermit {
            withTimeoutOrNull(15_000L) {
                SeriesCatalogPosterResolver.resolve(item.name,item.year,item.tmdbId,item.imdbId,TmdbClientProvider.client::get,item.season)?.url
            }
        }
    } else item.url
    if(url.isNullOrBlank())return null
    return if(MoviePosterLoader.prefetch(context,url,kind=kind,duringNavigation=true))url else null
}
