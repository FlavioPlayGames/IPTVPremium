package br.com.flaviotorres.iptvpremium.data.cache
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicInteger

fun main()=runBlocking {
 val plan=PosterWindowPlan()
 val initial=plan.window(5,14,100)
 check(initial.visible==(5..14).toList() && initial.ahead==(15..29).toList() && initial.behind==(0..4).reversed().toList())
 check(initial.priority.size==30 && initial.nearest==(15..19).toList())
 val down=plan.window(20,29,100)
 check(down.ahead==(30..44).toList() && down.behind==(15..19).reversed().toList())
 val up=plan.window(15,24,100)
 check(up.ahead==(0..14).reversed().toList() && up.behind==(25..29).toList())
 val eight=PosterWindowPlan().window(20,27,100)
 check(eight.visible.size==8 && eight.ahead.size==15 && eight.behind.size==5 && eight.priority.size==28)
 val edge=PosterWindowPlan().window(0,9,100)
 check(edge.priority.size==25 && edge.ahead==(10..24).toList())
 check(PosterWindowPlan().window(5,14,12).priority.toSet()==(0..11).toSet())
 check(PosterWindowPlan().window(-1,-1,0).priority.isEmpty())
 val random=kotlin.random.Random(27)
 repeat(10_000) {
  val total=random.nextInt(1,2000);val first=random.nextInt(total);val last=minOf(total-1,first+random.nextInt(1,16))
  val w=plan.window(first,last,total)
  check(w.priority.size<=30 && w.priority.distinct().size==w.priority.size && w.priority.all{it in 0 until total})
  check(w.nearest.size<=5 && w.ahead.size<=15 && w.behind.size<=5)
 }
 println("PASS: 8/10 visible, direction reversal, 5-nearest, 15-ahead/5-behind, end/empty and 10000 random windows stay within 30")
 val started=mutableListOf<Int>();val canceled=mutableSetOf<Int>();val gates=mutableMapOf<Int,CompletableDeferred<Unit>>()
 val active=AtomicInteger();val peak=AtomicInteger();var targetCount=0
 val queue=PosterWindowQueue(this, fetch={p->
  val id=p.id.toInt();started+=id;val n=active.incrementAndGet();peak.updateAndGet{maxOf(it,n)}
  try{gates.getOrPut(id){CompletableDeferred()}.await();p.url}
  catch(e:CancellationException){canceled+=id;throw e}finally{active.decrementAndGet()}
 },prepare={},report={target,_,_->targetCount=target})
 fun candidate(id:Int)=PosterCandidate("https://provider.example/$id.jpg",id=id.toString())
 queue.update((0..29).map(::candidate),(10..14).map(::candidate));yield()
 check(started==listOf(0,1))
 // One retained item must keep its existing job while stale items are canceled.
 queue.update(listOf(candidate(1))+(100..128).map(::candidate),listOf(candidate(100)));yield();yield()
 check(started.count{it==1}==1 && 0 in canceled && 100 in started)
 // Rapid skips keep only the final row/window, not a backlog of the intermediate catalogue.
 queue.update((500..529).map(::candidate),(510..514).map(::candidate));yield();yield()
 check(started.takeLast(2)==listOf(500,501))
 check((2..29).none{it in started} && (101..128).none{it in started})
 gates.getValue(500).complete(Unit);gates.getValue(501).complete(Unit);yield();yield()
 check(started.takeLast(2)==listOf(502,503) && peak.get()<=2 && targetCount==30)
 queue.pause();yield();yield();val paused=started.size
 delay(20);check(started.size==paused && active.get()==0)
 queue.update((800..829).map(::candidate),(810..814).map(::candidate));yield();check(started.takeLast(2)==listOf(800,801))
 queue.pause();yield();yield()
 println("PASS: two workers, overlap retained, obsolete work canceled, latest stopped window resumes, never queues abandoned rows")
 val instantStarts=mutableListOf<Int>()
 val immediate=PosterWindowQueue(this, fetch={item->instantStarts+=item.id.toInt();awaitCancellation()},prepare={})
 immediate.update((0..29).map(::candidate),emptyList())
 // No yield: cancel both scheduled workers before either body enters its try/finally.
 immediate.update((900..929).map(::candidate),emptyList())
 yield();yield()
 check(instantStarts==listOf(900,901)) {"Canceled-before-start workers must not occupy queue slots"}
 immediate.pause();yield();yield()
 immediate.update((950..979).map(::candidate),emptyList());immediate.pause()
 immediate.update((980..1009).map(::candidate),emptyList());yield();yield()
 check(instantStarts.takeLast(2)==listOf(980,981))
 immediate.pause();yield();yield()
 println("PASS: cancellation before coroutine start releases slots; repeated immediate pause/resume never stalls the final row")
 Unit
}
