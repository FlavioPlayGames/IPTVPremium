# Validação — r5

## Avaliação da regra anterior

CategoryPosterPrefetch usava PosterReservePlan: iniciava com 15 itens adiante e podia crescer até 25, além dos visíveis; não reservava uma fileira atrás. A reserva recebia apenas URLs, portanto uma série M3U sem URL válida não podia ter sua identidade/capa preparada fora da tela. Continuar não participava da antecipação. A rotação em lotes por bytes e o LRU por quantidade já existiam.

## Mudanças verificadas

- Novo plano inclui os visíveis no teto de 30 e mantém direção: até 15 à frente/5 atrás, com cinco próximos preparados. Com 8 visíveis, até 28; nas bordas, menos.
- Fila mantém interseções úteis, limita trabalhadores opcionais a dois, cancela alvos obsoletos e retoma a última posição após a pausa existente de navegação rápida.
- Dados públicos de identificação acompanham a consulta local de até 30 registros. Filmes e Séries Xtream/M3U usam o mesmo caminho após a importação; não há uma nova consulta de catálogo ao provedor.
- Normal e Kids usam o mesmo controlador, incluindo Continuar e Favoritos. Metadados nulos de identidade de arte do histórico permanecem separados dos metadados exibidos.
- Antecipação de séries sem capa usa o resolvedor verificado da r4 e o cache já existente. Somente a fileira próxima é decodificada antecipadamente.
- RAM antiga da janela pode ser liberada sem apagar os arquivos em disco. Download/compressão continuam em MoviePosterLoader.prefetch/ensureFile/download, com as reservas de armazenamento existentes.

## Testes JVM executados

Fontes reais com adaptadores de Context/DAO/rede/bitmap onde necessário:

- 10 visíveis: 15 adiante + 5 atrás, teto 30. Com 8 visíveis: teto efetivo 28. Inversão ao subir, início/fim/coleção vazia e 10.000 janelas aleatórias sem índices inválidos ou excesso de itens: passaram.
- Dois trabalhadores; preservação de uma requisição útil ao deslocar a janela; cancelamento das antigas; salto para outra janela sem executar as posições intermediárias; pausa e retomada, incluindo cancelamento antes de o corpo da coroutine iniciar: passaram.
- Série M3U sem URL: identificação verificada simulada e arquivo comprimido antecipado, sem bitmap para a janela inteira; card visível reaproveita a identidade, sem nova consulta. Filmes e Séries com URL do provedor não iniciam busca de identidade: passaram.
- Regressões da r4: e/&, nomes de franquias distintos, ambiguidade, ano/ID conflitante, provedor primeiro, cache de temporada, perfis, metadados nulos do histórico, prioridades de vídeo/importação e separação entre busca e download: passaram.
- Histórico: casos de reconciliação, metadados de favoritos, mais de 400 fatos, compactação de 2200 fatos, conclusões e sucessores: passaram.
- Persistência de metadados entre processos JVM e seleção de imagens M3U estáveis/episódios/paisagem: passaram. Não houve mudança no parser e não foi reprocessada a lista completa nesta revisão.

## Armazenamento

Comparação byte a byte com os fontes originais: CacheStorageBudget.kt, AppCacheStorage.kt, ImageDiskBudget.kt e PosterFileLru.kt permanecem iguais. PosterCategoryPolicy.CAPACITY permanece 125; somente o DTO da página foi ampliado nesse arquivo.

Teste com os algoritmos reais de armazenamento e cotas pequenas: passou rotação em lote ao exceder a cota, preservação de leitor ativo, contabilização de reserva temporária e recusa de reserva excessiva. Teste de LRU por quantidade preservou o leitor ativo e a capa visível, removendo a mais antiga elegível. As constantes reais continuam 100.000.000 bytes de cache descartável e 75.000.000 bytes para imagens.

Isso verifica a preservação das regras de cache, não uma medição de ocupação total do aplicativo instalado contra a meta de 400 MB.

## Aplicador, coleta e Android

Aplicação/reversão e coletor passaram em PowerShell 7, com comportamento de arrays JSON do Windows PowerShell 5.1 também simulado. Conferidos hashes, reaplicação, reversão incluindo remoção do arquivo novo, recusa de base diferente e proteção de edições posteriores. Coletor ADB simulado passou nos modos buffer/ao vivo: reteve os tempos da amostra da TV e os novos contadores de janela, rejeitando URLs e campos extras. Não executado em Windows ou com a TV física nesta revisão.

`:app:compileDesempenhoKotlin :app:lintDesempenho` concluídos com BUILD SUCCESSFUL na compilação final dos fontes estáveis. Lint: zero erros, 178 avisos e 6 sugestões; a mesma contagem da r4. Configuração desempenho existente, sem alteração de versão/assinatura.

Para repetir os testes portáveis:

```powershell
python .\testes\Testar-Host.py --projeto "$env:USERPROFILE\AndroidStudioProjects\IPTVPremium" --tools "PASTA_DOS_JARS"
```

--tools é opcional; sem cache, baixa dependências Maven. Os adaptadores de rede/bitmap são simulados: estes testes não comprovam a aparência final, a velocidade da conexão nem o tamanho instalado da TV. Não foi publicado APK, alterada assinatura, instalado remotamente ou medido ganho de navegação no aparelho.
