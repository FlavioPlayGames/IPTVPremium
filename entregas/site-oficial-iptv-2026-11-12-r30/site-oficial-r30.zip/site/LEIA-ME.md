# Site IPTV — pasta oficial

Pasta oficial no PC: `C:\Users\flavi\AndroidStudioProjects\Site IPTV`.
Todas as próximas edições, testes e publicações devem partir desta pasta. Downloads serve apenas para receber entregas. O projeto Android continua separado.

## Rotina

1. Editar os fontes nesta pasta. Nunca editar `.worker-preview`, que é gerada pelo Wrangler.
2. Executar `powershell -ExecutionPolicy Bypass -File .\Testar-Site.ps1`.
3. Para publicar, executar `powershell -ExecutionPolicy Bypass -File .\Publicar-Site.ps1`. A rotina testa, gera um pacote dos fontes, prepara o bucket privado de legendas e publica com Wrangler. Só registra sucesso após retorno zero. Requer login Cloudflare na conta existente e Node.js 22 recente ou superior.
4. Para enviar os fontes atualizados a outra conversa: `powershell -ExecutionPolicy Bypass -File .\manutencao-iptv\Manter-Site.ps1 -Acao Pacote`. O ZIP fica em `manutencao-iptv\pacotes`. Revise antes de compartilhar: não colocar credenciais em código nem em wrangler.jsonc.

O publicador registra em manutencao-iptv/relatorios os horários, hash do Worker, hash da configuração, pacote anterior à publicação e saída do Wrangler. Uma falha de rede pode ocorrer depois de uma publicação aceita pelo servidor; nesse caso confira o painel Cloudflare antes de repetir. Guardar uma cópia não torna o código sincronizado automaticamente: toda edição precisa ocorrer nesta pasta ou ser aplicada nela.

## Recursos preservados

Mesmo Worker central-iptv-premium, domínio, DB, assets, cron, envio direto de listas M3U/Xtream e provedores SubDL/SubSource/OpenSubtitles. Inclui envio manual SRT/ZIP, QR e confirmação pela TV. O R2 MANUAL_SUBTITLES é privado, com expiração de objetos temporários em manual/ após um dia. Preparar-R2.ps1 faz operações reais ao ser executado. Não há migração D1 ou criação de outro Worker.

Secrets continuam no Cloudflare: não recriar APP_KEY ou os secrets OpenSubtitles. APP_KEY mantém a leitura dos dados existentes. A antiga pasta Downloads/site-identidade-aprovada não é removida nem alterada pelo instalador. A instalação local não publica.

## Verificação

Testes de servidor e navegador usam DB, R2, API e TV simulados. O teste físico celular → site → TV → player e o deploy real continuam necessários. Consulte validacao/ORIGEM-R30.md e validacao/VALIDACAO.md. O teste de navegador opcional exige Playwright, conforme sua documentação.

## Continuidade

Ao iniciar outra conversa, informe esta pasta, envie o pacote atualizado produzido pela rotina e descreva a última alteração. Não envie node_modules, .wrangler, .worker-preview, arquivos .env, .dev.vars ou credenciais. Os relatórios e pacotes são locais e não devem ser publicados no GitHub. Mantenha cópia externa do projeto e dos pacotes importantes.
