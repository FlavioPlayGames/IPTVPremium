﻿[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
Push-Location -LiteralPath $PSScriptRoot
function Executar-Npm([string[]]$Argumentos) {
 $previous=$ErrorActionPreference
 try{$ErrorActionPreference='Continue';& npm.cmd @Argumentos 2>&1|ForEach-Object {Write-Host "$_"};$code=$LASTEXITCODE}
 finally{$ErrorActionPreference=$previous}
 if($code -ne 0){throw "Falha no npm ($($Argumentos -join ' ')). Nenhum deploy foi executado."}
}
try {
 if(!(Get-Command node -ErrorAction SilentlyContinue)){throw 'Instale Node.js 22 recente ou superior.'}
 $version=& node --version
 if([int]$version.TrimStart('v').Split('.')[0] -lt 22){throw 'Use Node.js 22 recente ou superior.'}
 if(!(Test-Path -LiteralPath "$PSScriptRoot\node_modules\wrangler\bin\wrangler.js" -PathType Leaf)){Executar-Npm @('ci','--no-audit','--no-fund')}
 Executar-Npm @('test')
 Executar-Npm @('run','check')
 Write-Host 'Servidor e empacotamento dry-run verificados. Nenhum deploy ou migracao foi executado.'
} finally {Pop-Location}
