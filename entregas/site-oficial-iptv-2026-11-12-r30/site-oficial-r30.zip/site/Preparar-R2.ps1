﻿[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$bucket='iptv-premium-manual-subtitles'
$rule='manual-expira-1dia'
$wrangler=Join-Path $PSScriptRoot 'node_modules\wrangler\bin\wrangler.js'
if(!(Test-Path -LiteralPath $wrangler -PathType Leaf)){throw 'Execute Testar-Site.ps1 antes de preparar o R2.'}
$config=Get-Content -LiteralPath (Join-Path $PSScriptRoot 'wrangler.jsonc') -Raw
if($config -notmatch '"binding"\s*:\s*"MANUAL_SUBTITLES"\s*,\s*"bucket_name"\s*:\s*"iptv-premium-manual-subtitles"'){throw 'O binding manual nao corresponde ao pacote. Confira a configuracao antes de criar recursos.'}
function Executar-WranglerSeguro([string[]]$Argumentos) {
 $previous=$ErrorActionPreference
 try{$ErrorActionPreference='Continue';$lines=@(& node $wrangler @Argumentos 2>&1|ForEach-Object {"$_"});$code=$LASTEXITCODE}
 finally{$ErrorActionPreference=$previous}
 $lines|ForEach-Object {Write-Host $_}
 if($code -ne 0){throw "Wrangler falhou em $($Argumentos -join ' '). Nenhum deploy foi feito."}
 return ([regex]::Replace(($lines -join "`n"),([string][char]27+'\[[0-9;]*[A-Za-z]'),'')).Replace("`r",'')
}
function Regra([string]$Lista){return [regex]::Match($Lista,'(?ms)^\s*name:\s*manual-expira-1dia\s*$.*?(?=^\s*name:|\z)').Value}
function Regra-Correta([string]$Bloco){return $Bloco -match '(?m)^\s*enabled:\s*Yes\s*$' -and $Bloco -match '(?m)^\s*prefix:\s*manual/\s*$' -and $Bloco -match 'Expire objects after 1 days'}
Push-Location -LiteralPath $PSScriptRoot
try {
 $null=Executar-WranglerSeguro @('whoami')
 $list=Executar-WranglerSeguro @('r2','bucket','list')
 if($list -notmatch '(?m)^\s*name:\s*iptv-premium-manual-subtitles\s*$'){$null=Executar-WranglerSeguro @('r2','bucket','create',$bucket)}
 $rules=Executar-WranglerSeguro @('r2','bucket','lifecycle','list',$bucket);$existing=Regra $rules
 if($existing) {
  if(!(Regra-Correta $existing)){throw 'A regra manual existente tem outra configuracao. Confira o painel; ela nao foi substituida.'}
 }else{$null=Executar-WranglerSeguro @('r2','bucket','lifecycle','add',$bucket,$rule,'manual/','--expire-days','1','--force')}
 $verified=Regra (Executar-WranglerSeguro @('r2','bucket','lifecycle','list',$bucket))
 if(!(Regra-Correta $verified)){throw 'Nao foi possivel confirmar a regra de exclusao do prefixo manual/.'}
 Write-Host 'R2 privado preparado: prefixo manual/ expira em 1 dia. Nao habilitamos acesso publico.'
 Write-Host 'Nenhum deploy ou comando D1 foi executado. Para publicar o site, execute npx wrangler deploy separadamente.'
} finally {Pop-Location}
