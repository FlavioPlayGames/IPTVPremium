﻿[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
$site=$PSScriptRoot
Push-Location -LiteralPath $site
try {
    & "$site\Testar-Site.ps1"
    & "$site\manutencao-iptv\Manter-Site.ps1" -Acao Pacote -Projeto $site
    & "$site\Preparar-R2.ps1"
    $reports=Join-Path $site 'manutencao-iptv\relatorios'
    New-Item -ItemType Directory -Path $reports -Force|Out-Null
    $stamp=Get-Date -Format 'yyyyMMdd-HHmmss-fff'
    $log=Join-Path $reports "publicacao-$stamp.log"
    $packages=Join-Path $site 'manutencao-iptv\pacotes'
    $package=Get-ChildItem -LiteralPath $packages -Filter '*.zip' -File|Sort-Object LastWriteTime -Descending|Select-Object -First 1
    $workerHash=(Get-FileHash -LiteralPath "$site\worker-atualizacao-abi.js" -Algorithm SHA256).Hash
    $configHash=(Get-FileHash -LiteralPath "$site\wrangler.jsonc" -Algorithm SHA256).Hash
    $previous=$ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        & node "$site\node_modules\wrangler\bin\wrangler.js" deploy 2>&1|Tee-Object -FilePath $log
        $code=$LASTEXITCODE
    } finally {$ErrorActionPreference=$previous}
    if($code -ne 0){throw "Wrangler retornou $code. Confira o log: $log"}
    [PSCustomObject]@{concluidaEmUtc=[DateTime]::UtcNow.ToString('o');projeto=$site;workerSHA256=$workerHash;configSHA256=$configHash;pacote=$package.FullName;log=$log}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $reports "publicacao-$stamp.json") -Encoding UTF8
    Write-Host 'Publicacao concluida. Fontes oficiais nesta pasta; comprovante em manutencao-iptv\relatorios.'
} finally {Pop-Location}
