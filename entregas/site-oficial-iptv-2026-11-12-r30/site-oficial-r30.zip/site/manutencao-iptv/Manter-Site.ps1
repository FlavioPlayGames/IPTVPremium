﻿[CmdletBinding()]
param(
    [ValidateSet('Inventario','Verificar','Pacote')][string]$Acao='Inventario',
    [string]$Projeto=(Split-Path -Parent $PSScriptRoot)
)
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($Projeto).TrimEnd('\','/')
if(!(Test-Path -LiteralPath (Join-Path $root 'package.json') -PathType Leaf)){throw 'package.json nao encontrado na pasta do projeto.'}
$man=Join-Path $root 'manutencao-iptv'
$reports=Join-Path $man 'relatorios'
New-Item -ItemType Directory -Path $reports -Force|Out-Null
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss-fff'
function Relativo([string]$Path){return $Path.Substring($root.Length).TrimStart('\','/').Replace('\','/')}
function Fontes {
    $extensions=@('.js','.mjs','.cjs','.ts','.tsx','.json','.jsonc','.toml','.md','.ps1','.html','.css','.svg','.png','.jpg','.jpeg','.webp','.ico','.ttf','.woff','.woff2','.txt')
    $rootNames=@('package.json','package-lock.json','wrangler.jsonc','wrangler.toml','wrangler.json','tsconfig.json','jsconfig.json','.gitignore')
    $files=New-Object System.Collections.Generic.List[string]
    foreach($f in @(Get-ChildItem -LiteralPath $root -File -Force)) {
        if($f.Name -in $rootNames -or $f.Extension -in @('.js','.mjs','.cjs','.ts','.md','.ps1')){$files.Add($f.FullName)}
    }
    foreach($name in @('public','src','validacao','manutencao-iptv')) {
        $dir=Join-Path $root $name
        if(!(Test-Path -LiteralPath $dir -PathType Container)){continue}
        $found=if($name -eq 'manutencao-iptv'){@(Get-ChildItem -LiteralPath $dir -File -Force)}else{@(Get-ChildItem -LiteralPath $dir -File -Recurse -Force)}
        foreach($f in $found){if($name -eq 'public' -or $f.Extension -in $extensions -or $f.Name -eq '.gitignore'){$files.Add($f.FullName)}}
    }
    $files | Sort-Object -Unique | Where-Object {
        $rel=Relativo $_
        $rel -notmatch '(?i)(?:^|/)(?:node_modules|\.git|\.wrangler|\.worker-preview|pacotes|relatorios|backups)(?:/|$)' -and
        $rel -notmatch '(?i)(?:^|/)(?:\.env(?:\..*)?|\.dev\.vars(?:\..*)?)$' -and
        $rel -notmatch '(?i)(?:service[-_]?account|recovery[-_]?codes|private[-_.]|\.backup|\.antes-publicacao)' -and
        $rel -notmatch '(?i)^validacao/.*\.(?:txt|log)$' -and
        $rel -notmatch '(?i)(?:^|/)(?:INVENTARIO-SITE\.json|SHA256SUMS\.txt)$'
    }
}
function Executar-Local([string]$Programa,[string[]]$Argumentos,[string]$Log) {
    Get-Command $Programa -ErrorAction Stop|Out-Null
    $previous=$ErrorActionPreference
    try {
        $ErrorActionPreference='Continue'
        & $Programa @Argumentos 2>&1|Out-File -LiteralPath $Log -Append -Encoding UTF8
        return [int]$LASTEXITCODE
    } finally {$ErrorActionPreference=$previous}
}
$checks=New-Object System.Collections.Generic.List[object]
if($Acao -eq 'Verificar') {
    if(!(Get-Command node -ErrorAction SilentlyContinue)){throw 'Instale Node.js 22 recente ou superior para executar a verificacao.'}
    $log=Join-Path $reports ("verificacao-$stamp.log")
    Push-Location -LiteralPath $root
    try {
        foreach($file in @(Fontes | Where-Object {[IO.Path]::GetExtension($_) -in @('.js','.mjs','.cjs')})) {
            $code=Executar-Local 'node' @('--check',$file) $log
            $checks.Add([PSCustomObject]@{teste='sintaxe';arquivo=(Relativo $file);codigo=$code})
        }
        $pkg=Get-Content -LiteralPath (Join-Path $root 'package.json') -Raw|ConvertFrom-Json
        foreach($name in @('test','check')) {
            $prop=$pkg.scripts.PSObject.Properties[$name]
            if($null -eq $prop){continue}
            $cmd=[string]$prop.Value
            if($cmd -match '(?i)--remote|\bwrangler\s+d1\b|\bwrangler\s+deploy(?![^;&]*--dry-run)'){
                $checks.Add([PSCustomObject]@{teste="npm:$name";codigo=-1;motivo='Comando de publicacao ou banco remoto recusado pela rotina de verificacao.'});continue
            }
            $code=Executar-Local 'npm.cmd' @('run',$name) $log
            $checks.Add([PSCustomObject]@{teste="npm:$name";codigo=$code})
        }
    } finally {Pop-Location}
    Write-Host "Log local: $log"
}
$config=New-Object System.Collections.Generic.List[object]
foreach($name in @('wrangler.jsonc','wrangler.toml','wrangler.json')) {
    $p=Join-Path $root $name
    if(Test-Path -LiteralPath $p -PathType Leaf) {
        $s=Get-Content -LiteralPath $p -Raw
        $values=@{}
        foreach($key in @('name','main','directory','binding','database_name')) {
            $pat='"'+$key+'"\s*:\s*"([^"\r\n]+)"|(?m)^\s*'+$key+'\s*=\s*"([^"\r\n]+)"'
            $values[$key]=@([regex]::Matches($s,$pat)|ForEach-Object {if($_.Groups[1].Success){$_.Groups[1].Value}else{$_.Groups[2].Value}})
        }
        $config.Add([PSCustomObject]@{arquivo=$name;camposPublicos=$values})
    }
}
$rows=@(foreach($file in @(Fontes)) {
    $f=Get-Item -LiteralPath $file -Force
    [PSCustomObject]@{arquivo=(Relativo $file);bytes=$f.Length;sha256=(Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()}
})
$hasher=[Security.Cryptography.SHA256]::Create()
try {
    $fingerprintText=($rows|ForEach-Object {"$($_.arquivo):$($_.sha256)"}) -join "`n"
    $fingerprint=([BitConverter]::ToString($hasher.ComputeHash([Text.Encoding]::UTF8.GetBytes($fingerprintText)))).Replace('-','').ToLowerInvariant()
} finally {$hasher.Dispose()}
$lastFile=Join-Path $reports 'ultima-verificacao.json'
if($Acao -eq 'Verificar') {
    [PSCustomObject]@{geradoEm=(Get-Date).ToString('o');fontesSha256=$fingerprint;verificacoes=$checks.ToArray();log=[IO.Path]::GetFileName($log)}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath $lastFile -Encoding UTF8
}
$lastCheck=$null
if(Test-Path -LiteralPath $lastFile -PathType Leaf) {
    $last=Get-Content -LiteralPath $lastFile -Raw|ConvertFrom-Json
    $lastCheck=[PSCustomObject]@{geradoEm=$last.geradoEm;correspondeAosFontesAtuais=($last.fontesSha256 -eq $fingerprint);verificacoes=$last.verificacoes;log=$last.log}
}
$state=[PSCustomObject]@{geradoEm=(Get-Date).ToString('o');projeto=$root;acao=$Acao;fontesSha256=$fingerprint;ultimaVerificacao=$lastCheck;configuracao=$config.ToArray();verificacoes=$checks.ToArray();arquivos=$rows}
$inventory=Join-Path $reports 'inventario-atual.json'
$state|ConvertTo-Json -Depth 10|Set-Content -LiteralPath $inventory -Encoding UTF8
Write-Host "Inventario: $inventory"
if($Acao -eq 'Pacote') {
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $packs=Join-Path $man 'pacotes';New-Item -ItemType Directory -Path $packs -Force|Out-Null
    $zipPath=Join-Path $packs ("site-fontes-$stamp.zip")
    $sum=($rows|Measure-Object -Property bytes -Sum).Sum
    if($sum -gt 30MB){throw 'Os fontes selecionados passam de 30 MiB. Confira o inventario para identificar arquivos grandes antes de empacotar.'}
    $zip=[IO.Compression.ZipFile]::Open($zipPath,[IO.Compression.ZipArchiveMode]::Create)
    try {
        foreach($row in $rows){[IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,(Join-Path $root $row.arquivo),$row.arquivo,[IO.Compression.CompressionLevel]::Optimal)|Out-Null}
        [IO.Compression.ZipFileExtensions]::CreateEntryFromFile($zip,$inventory,'INVENTARIO-SITE.json',[IO.Compression.CompressionLevel]::Optimal)|Out-Null
    } finally {$zip.Dispose()}
    $digest=(Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
    [PSCustomObject]@{pacote=$zipPath;sha256=$digest;bytes=(Get-Item -LiteralPath $zipPath).Length}|ConvertTo-Json|Set-Content -LiteralPath (Join-Path $reports 'ultimo-pacote.json') -Encoding UTF8
    Write-Host "Pacote atual: $zipPath"
    Write-Host 'Pacote criado somente no PC. Inclui configuracao e fontes: confira se nao ha credenciais escritas diretamente nesses arquivos antes de compartilhar.'
}
$failed=@($checks|Where-Object {$_.codigo -ne 0})
if($failed.Count){Write-Host "Verificacao com $($failed.Count) falha(s). Consulte o log; nenhum deploy foi solicitado por esta rotina.";exit 1}
if($Acao -eq 'Verificar'){Write-Host 'Verificacoes configuradas concluiram sem falhas. Testes de navegador opcionais devem ser executados separadamente.'}
