Reconstrução r30

O JavaScript colado pelo usuário corresponde exatamente ao bundle dos módulos da base recebida, removendo somente linhas de comentários (caminhos e sourceMappingURL). Nenhuma diferença executável encontrada.

SHA256 do texto recebido: e1831757b9c9129865a19c8dc739a3087656c1aec4739cc0d2bc95f949eca7f0

Base modular: 7c7d33be76f1c1bc3a2ccb84cf1be2b08d28d0f1c1a63d459f2b236e0cdb1628. Sobre ela foram incorporadas as alterações r29 já verificadas para envio manual de legendas, isolamento de destino e cartão SubSource administrativo. Nenhum backup antigo foi restaurado.
