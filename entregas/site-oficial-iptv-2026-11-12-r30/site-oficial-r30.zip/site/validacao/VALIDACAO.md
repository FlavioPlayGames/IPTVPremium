# Validação real executada nesta revisão r29

- npm test: PASS. 24 verificações do servidor existente, usando SQLite em memória e provedor simulado. Fluxo manual executado pelo Worker modular atual com DB/R2 simulados: autenticação, CSRF, isolamento, QR, upload/download, SHA256, confirmação, rejeição/reenvio, substituição, cancelamento, concorrência, expiração e limite efetivo de 8 MiB.
- npm run check: PASS, Wrangler 4.151.1. Sintaxe JavaScript e dry-run reconheceram DB, ASSETS e MANUAL_SUBTITLES. Nenhum recurso foi criado e nenhum deploy foi realizado.
- node validacao/browser.test.mjs: PASS, 224 verificações, Chromium local, larguras 360/390/768/1440. APIs e TV simuladas. Testes atualizados para envio direto, não apenas troca de seletores. Mocks Xtream retornam a playlist M3U preparada que o formulário espera. Administração tem o mesmo cartão SubSource. Uma validação atrasada não envia lista após mudança de TV. Envio manual pendente não é mostrado como confirmação da TV. Refresh e submissão duplicada durante upload bloqueados.
- Sintaxe do módulo SubSource e sua implementação foram preservadas byte a byte; os avanços não foram substituídos pelo portal antigo da r27.
- Testes de Preparar-R2.ps1 com CLI simulada: criação inicial, reutilização, recusa de regra diferente e falha de CLI passaram. Sem chamadas reais à conta Cloudflare. Sintaxe/flags conferidas no Wrangler fixado no lockfile.

A instalação, reaplicação e restauração são verificadas separadamente nos fixtures do pacote. A documentação do pacote contém o resultado final desses testes.

Não executado: TV física, R2 real, deploy, serviços de legenda reais ou o runtime Android. A cópia Kotlin recebida foi preservada isoladamente; nela o fundo r28 é estático e as classes manuais estão presentes. Nenhuma compilação Android nova é reivindicada por esta entrega do site.
