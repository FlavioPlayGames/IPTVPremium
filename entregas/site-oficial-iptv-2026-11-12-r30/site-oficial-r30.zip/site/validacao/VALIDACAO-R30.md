# Validação r30 — 12/11/2026

- Bundle colado pelo usuário e bundle da base modular comparados: nenhum código executável diferente; somente comentários de caminhos/source map.
- 24 verificações existentes de servidor e cenários adicionais do envio manual passaram, com DB/R2/provedores simulados.
- 224 verificações de navegador passaram: 360, 390, 768 e 1440 px, API/TV simuladas.
- npm run check passou: sintaxe e Wrangler 4.151.1 deploy --dry-run, DB/ASSETS/MANUAL_SUBTITLES reconhecidos.
- Scripts analisados e executados em PowerShell 7 Linux: instalação, repetição, recusa de edição divergente; pacote real de fontes; publicador com Wrangler/R2 simulados, sucesso registrado apenas após código zero. Compatibilidade de sintaxe visada para Windows PowerShell 5.1; execução real no Windows ainda necessária.
- Nenhuma publicação Cloudflare, mudança em D1, criação de R2 ou instalação na TV feita neste ambiente.

Fontes da aplicação iguais aos testados em site-manual-r29; esta entrega completa adiciona instalação em pasta oficial e rotinas locais de manutenção/publicação. A pasta antiga permanece intacta.
