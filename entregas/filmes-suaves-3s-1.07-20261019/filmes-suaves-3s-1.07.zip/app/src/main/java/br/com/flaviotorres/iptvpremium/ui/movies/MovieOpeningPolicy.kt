package br.com.flaviotorres.iptvpremium.ui.movies

/** One budget for metadata and decoded principal images, reserving the final animation. */
internal object MovieOpeningPolicy {
    const val preparationMs = 3_500L
    const val remoteMs = 2_500L
    const val minimumLoadingMs = 3_000L
    const val rotationCardsPerSecond = 1.5f
    const val alignNanos = 1_100_000_000L
    const val pressNanos = 260_000_000L
    const val expandNanos = 600_000_000L
    fun remainingMs(elapsedMs: Long): Long = (preparationMs - elapsedMs.coerceAtLeast(0L)).coerceAtLeast(0L)
    // Artwork readiness never shortens the mandatory three-second loading stage.
    @Suppress("UNUSED_PARAMETER")
    fun minimumWaitMs(elapsedMs: Long, artworkReady: Boolean): Long =
        (minimumLoadingMs - elapsedMs.coerceAtLeast(0L)).coerceAtLeast(0L)
}
