﻿param(
    [Parameter(Mandatory=$true)][string]$Serial,
    [Parameter(Mandatory=$true)][string]$PastaApks,
    [string]$Adb = "$env:LOCALAPPDATA\Android\Sdk\platform-tools\adb.exe"
)
$ErrorActionPreference = 'Stop'
if (!(Test-Path -LiteralPath $Adb -PathType Leaf)) { throw "ADB nao encontrado: $Adb" }
$estado = & $Adb -s $Serial get-state 2>&1
if ($LASTEXITCODE -ne 0 -or "$estado".Trim() -ne 'device') { throw 'Aparelho indisponivel. Confira adb devices -l e o pareamento.' }
$arquiteturas = (& $Adb -s $Serial shell getprop ro.product.cpu.abilist).Trim()
if ($LASTEXITCODE -ne 0) { throw 'Nao foi possivel consultar a arquitetura.' }
$arquivos = @(Get-ChildItem -LiteralPath $PastaApks -Filter '*.apk' -File)
$apk = $null
foreach ($abi in $arquiteturas.Split(',')) {
    if ($abi -notin @('armeabi-v7a','arm64-v8a','x86','x86_64')) { continue }
    $candidatos = @($arquivos | Where-Object { $_.Name -match ('-' + [regex]::Escape($abi) + '-desempenho\.apk$') })
    if ($candidatos.Count -eq 1) { $apk = $candidatos[0]; break }
    if ($candidatos.Count -gt 1) { throw 'Mais de um APK compativel. Use uma pasta contendo apenas o build a testar.' }
}
if ($null -eq $apk) {
    $universais = @($arquivos | Where-Object { $_.Name -match '-universal-desempenho\.apk$' })
    if ($universais.Count -ne 1) { throw "APK desempenho compativel nao encontrado. ABIs: $arquiteturas" }
    $apk = $universais[0]
}
Write-Host "Instalando $($apk.Name). ABIs da TV: $arquiteturas"
& $Adb -s $Serial install -r $apk.FullName
if ($LASTEXITCODE -ne 0) { throw 'Instalacao recusada. Confira assinatura e versao. Nao desinstale o aplicativo para contornar o erro.' }
Write-Host 'Instalacao concluida com preservacao dos dados existentes.'
