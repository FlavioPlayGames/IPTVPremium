# Legendas — estado comprovado por inspeção dos arquivos recebidos

A integração completa não foi declarada concluída nem ativada. Não houve publicação de Worker, alteração de D1 ou chamada real aos provedores de legendas.

No aplicativo existem clientes SubDL/OpenSubtitles, configuração pelo portal, persistência local e pesquisa/download separados. O player pesquisa ao abrir o menu e baixa a opção após escolha. Os arquivos externos são convertidos em cues e desenhados pelo próprio PlaybackScreen sobre o vídeo; esse caminho é compartilhado pelos mecanismos Exo e VLC. Isso é análise de código, não prova de exibição real.

## Comunicação existente

- O aparelho se registra por `/api/device/register` e mantém um segredo privado local.
- A sincronização usa o caminho de pull escolhido por `portalPullPath`, preservando os comandos separados de listas/legendas.
- O SubDL chega por `subtitle_key` e o OpenSubtitles por `subtitle_session`. A remoção usa o comando de chave nula do provedor.
- O aplicativo registra o resultado de cada comando antes de enviar `/api/device/ack`, incluindo o estado dos provedores.
- `/api/device/qr-login` retorna link e `expires`. A tela apresenta 15 minutos e usa a expiração retornada para renovar a apresentação. A validade e a autorização reais no servidor precisam ser verificadas nos fontes do Worker e em teste de integração.
- Não foi alterado o protocolo, o segredo do aparelho, APP_KEY, FCM ou o formato do QR.

## OpenSubtitles

O recurso `opensubtitles_api_key` está vazio nos arquivos enviados. O cliente do app lê essa configuração e exige uma chave técnica válida para considerar a integração disponível; a conta pessoal é outra parte do fluxo. Esse achado ajuda a explicar a indisponibilidade no aparelho, mas não comprova como o servidor publicado está configurado.

É necessário conferir o API Consumer do projeto e a configuração segura do Worker e do app. Não enviar a chave, senha ou token pelo chat. Nenhuma chave de terceiros foi usada. A configuração Firebase recebida ficou apenas no ambiente de compilação e não integra o pacote de entrega.

## Fontes ainda necessários para concluir o site

Enviar o pacote atual do site, sem `.dev.vars`, `.env`, tokens, senhas nem conta de serviço. Arquivos esperados segundo o histórico, a confirmar no pacote real:

- Worker principal, `opensubtitles.js`, `playlist-validation.js` e os módulos importados.
- `public/app.js`, `public/subtitles.js`, HTML/CSS e demais assets atuais.
- Configuração Wrangler, `package.json`/lockfile e migrações D1.

Sem esses arquivos, não é possível concluir a validação do celular → servidor → aparelho nem conferir isolamento, expiração, chave técnica ou estado publicado. A sessão Wrangler do Windows não existe automaticamente nesta máquina.

Continuam pendentes os testes reais de API, limites vigentes, credenciais inválidas, download/aplicação de SRT/VTT/ZIP nos dois mecanismos, troca/desativação, reconexão e isolamento entre aparelhos. A futura promoção desempenho → oficial também permanece para depois da estabilização, com sua assinatura original.
