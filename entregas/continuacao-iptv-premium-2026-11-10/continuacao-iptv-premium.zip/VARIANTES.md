# Variantes recebidas — inspeção da configuração

Pacote comum: `br.com.flaviotorres.iptvpremium`. Versão recebida: 1.13. O versionCode é `maxOf(15, APP_VERSION_CODE)`; nas propriedades fornecidas, o resultado é 15. Nada disso foi alterado pelo pacote.

| Aspecto | debug | release | desempenho |
|---|---|---|---|
| Base | build type debug | build type release | `initWith(release)` |
| Depuração | configuração debug | configuração release | explicitamente desativada |
| Otimização explícita | não declarada no trecho debug | AndroidX, Kotlin e kotlinx | inclui também os pacotes do app |
| Assinatura | debug local | não explicitada no trecho recebido | herda a assinatura debug configurada |
| Regras adicionais | — | — | tv-performance-rules.pro, sem ofuscação e com preservação do VLC |
| UiStallMonitor na MainActivity | instalado | não instalado por essa condição | instalado, mesmo com debuggable=false |
| Pausa experimental do histórico compartilhado | opt-in por propriedade Gradle | false | false |

`M3U_IMPORT_PROFILE` é declarado no `defaultConfig` pelo script, com G8 como padrão. Não encontrei leitura desse campo nos fontes Kotlin recebidos. A simples presença dessa constante não comprova uma otimização ativa da importação.

O manifesto específico de desempenho enviado está vazio além da declaração de namespace XML. As correções desta entrega ficam nos fontes comuns, disponíveis às variantes que compilarem esses mesmos arquivos.

Esta inspeção não é uma comparação de velocidade na TV. Não houve promoção para release, mudança de assinatura ou publicação. Para a promoção futura, separar o efeito das otimizações do R8, o código comum e a instrumentação de diagnóstico; testar atualização com a chave original, preservar os dados e escolher versionCode/versionName adequados naquele momento.
