"""Testes JVM isolados. Nao substituem compilacao Android, Room real ou TV."""
from pathlib import Path
import argparse, os, subprocess, tempfile, shutil, urllib.request

cli = argparse.ArgumentParser(description=__doc__)
cli.add_argument('--projeto', required=True, type=Path)
cli.add_argument('--lista', type=Path, help='ZIP do M3U completo, opcional')
cli.add_argument('--tools', type=Path, help='Cache de JARs Maven')
cli.add_argument('--java', default='java')
a = cli.parse_args()
root = a.projeto.resolve() / 'app/src/main/java/br/com/flaviotorres/iptvpremium'
fixtures = Path(__file__).resolve().parent / 'host'
tools = a.tools or Path(__file__).resolve().parent / '.tools'
tools.mkdir(exist_ok=True, parents=True)
artifacts = [
 ('org.jetbrains.kotlin','kotlin-compiler-embeddable','2.2.10'),
 ('org.jetbrains.kotlin','kotlin-stdlib','2.2.10'),
 ('org.jetbrains.kotlin','kotlin-script-runtime','2.2.10'),
 ('org.jetbrains.kotlin','kotlin-reflect','1.6.10'),
 ('org.jetbrains.kotlin','kotlin-daemon-embeddable','2.2.10'),
 ('org.jetbrains.kotlinx','kotlinx-coroutines-core-jvm','1.8.0'),
 ('org.jetbrains','annotations','13.0'), ('org.json','json','20250517')
]
jars=[]
for group, artifact, version in artifacts:
 name=f'{artifact}-{version}.jar'; dest=tools/name
 if not dest.exists():
  url=f'https://repo.maven.apache.org/maven2/{group.replace(".","/")}/{artifact}/{version}/{name}'
  temporary=dest.with_suffix('.download')
  with urllib.request.urlopen(url, timeout=120) as response, temporary.open('wb') as output:
   shutil.copyfileobj(response,output)
  temporary.replace(dest)
 jars.append(str(dest.resolve()))
cp = os.pathsep.join(jars)

def run(*args): subprocess.run(list(map(str,args)),check=True)
with tempfile.TemporaryDirectory(prefix='iptv-host-') as temp:
 work=Path(temp)
 for p in fixtures.glob('*.kt'):shutil.copyfile(p,work/p.name)
 # Extract the actual presentation functions from the project under test.
 for path,model,fn in [('ui/components/UnifiedMediaCatalog.kt','CatalogPoster','catalogContinuePosters'),('ui/kids/KidsMediaCatalog.kt','KidsPoster','kidsContinuePosters')]:
  text=(root/path).read_text(encoding='utf-8-sig');start=text.index('internal data class '+model+'(');end=text.index('\n\n',start)
  fstart=text.index('internal fun '+fn+'(');fend=text.index('\n}',fstart)+2
  (work/(model+'.kt')).write_text('package host\nimport br.com.flaviotorres.iptvpremium.data.history.WatchHistoryEntry\nimport br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType\n'+text[start:end]+'\n'+text[fstart:fend],encoding='utf-8')
 def compile(name, production, fake):
  jar=work/(name+'.jar')
  run(a.java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',jar,*[root/f for f in production],*[work/f for f in fake])
  return str(jar)+os.pathsep+cp
 parser=compile('parser',[
  'data/m3u/M3uCatalogParser.kt','data/m3u/M3uCatalogFormat.kt','data/m3u/M3uSeriesPosterSelection.kt',
  'data/cache/importer/M3uEntryClassifier.kt','data/cache/importer/M3uEntryMetadata.kt',
  'data/m3uepisodes/M3uEpisodeSource.kt','data/cache/entity/CachedEpisodeEntity.kt'
 ],['Room.kt','Log.kt','Epg.kt','ParserMain.kt','SelectionMain.kt'])
 run(a.java,'-cp',parser,'br.com.flaviotorres.iptvpremium.data.m3u.SelectionMainKt')
 if a.lista:
  run(a.java,'-Xmx768m','-cp',parser,'br.com.flaviotorres.iptvpremium.data.m3u.ParserMainKt',a.lista.resolve(),work/'m3u')
 history=compile('history',[
  'data/history/WatchHistoryStore.kt','data/history/HistoryProfile.kt',
  'data/history/ContentIdentity.kt','data/history/HistoryWorkPolicy.kt'
 ],['Context.kt','Playback.kt','Shared.kt','Episode.kt','CatalogPoster.kt','KidsPoster.kt','HistoryMain.kt'])
 run(a.java,'-cp',history,'host.HistoryMainKt')
 cache=compile('cache',[
  'data/repository/CatalogMetadataCache.kt','data/repository/CatalogMetadataDiskCache.kt','data/repository/CatalogMetadataIdentity.kt',
  'data/repository/SeriesCatalogPosterResolver.kt','data/repository/SeriesArtworkIdentityResolver.kt',
  'data/cache/PosterRequestLocks.kt','data/m3u/M3uSeriesPosterSelection.kt'
 ],['Context.kt','Budget.kt','Log.kt','CacheMain.kt'])
 for mode in ('write','read'):
  run(a.java,'-cp',cache,'br.com.flaviotorres.iptvpremium.data.repository.CacheMainKt',mode,work/'cache-disco')
print('Testes host concluidos. Android, Room e TV exigem validacao separada.')
