package br.com.flaviotorres.iptvpremium.data.m3u
fun main(){
 val p=M3uSeriesPosterSelection();val a=M3uSeriesPosterSelection.Candidates();val b=M3uSeriesPosterSelection.Candidates()
 val shared="https://image.tmdb.org/t/p/w500/shared.jpg"
 p.series(a,"A",shared);p.series(a,"A","https://image.tmdb.org/t/p/w500/a.jpg")
 p.series(b,"B",shared);p.series(b,"B","https://image.tmdb.org/t/p/w500/b.jpg")
 check(p.select(a)==shared) // shared series art alone is not evidence of a movie placeholder.
 p.movie("https://image.tmdb.org/t/p/original/shared.jpg") // movie may occur later in the input.
 check(p.select(a)!!.endsWith("/a.jpg") && p.select(b)!!.endsWith("/b.jpg"))
 val c=M3uSeriesPosterSelection.Candidates();p.series(c,"C",shared);check(p.select(c)==null)
 val d=M3uSeriesPosterSelection.Candidates();p.series(d,"D","https://cdn.example/only.jpg");p.movie("https://cdn.example/only.jpg")
 check(p.select(d)=="https://cdn.example/only.jpg") // no cross-series evidence: preserve provider.
 println("PASS: image sizes, input order, conservative selection, provider alternatives and missing-cover fallback")
}
