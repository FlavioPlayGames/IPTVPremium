package host
import br.com.flaviotorres.iptvpremium.data.history.WatchHistoryEntry
import br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType
internal data class CatalogPoster(val id: String, val name: String, val url: String?,
    val categoryId: String? = null, val rating: Double? = null, val progress: Float? = null, val year: Int? = null, val tmdbId: String? = null, val imdbId: String? = null, val artworkSeason:Int? = null)
private data class CatalogMenuRow(val key: String, val label: String, val count: Int, val categoryId: String? = null)
internal fun catalogContinuePosters(history: List<WatchHistoryEntry>, series: Boolean): List<CatalogPoster> {
        val sorted = history.sortedByDescending { it.updatedAtMs }
        return if (series) br.com.flaviotorres.iptvpremium.data.history.latestHistorySeries(sorted).filter{it.inProgress}.map { CatalogPoster(it.seriesId!!, it.seriesTitle?.takeIf { title -> title.isNotBlank() } ?: it.title, it.seriesPosterUrl?.takeIf { url -> url.isNotBlank() }, rating=it.catalogRating,year=it.year,tmdbId=it.tmdbId,imdbId=it.catalogImdbId,artworkSeason=it.seasonNumber) }
        else sorted.filter { it.contentType == PlaybackContentType.MOVIE && it.inProgress }
            .map { CatalogPoster(it.contentId, it.title, it.posterUrl, rating=it.catalogRating,progress=it.fraction,year=it.year) }
}