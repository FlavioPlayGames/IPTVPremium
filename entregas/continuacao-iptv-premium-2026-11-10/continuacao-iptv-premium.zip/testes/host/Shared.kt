package br.com.flaviotorres.iptvpremium.data.history
import android.content.Context
import br.com.flaviotorres.iptvpremium.core.player.*
object HistoryProfileMigration { fun run(context:Context){} }
class SharedLibraryStore {
 companion object {fun get(context:Context,kids:Boolean)=SharedLibraryStore()}
 fun effectiveHistory(raw:List<WatchHistoryEntry>)=raw
 fun projectHistory(playlist:String,raw:List<WatchHistoryEntry>)=raw.filter{it.playlistId==playlist}
 fun allowLegacyResume(playlist:String,media:PlaybackMedia,raw:List<WatchHistoryEntry>)=true
 fun resumeEntry(playlist:String,media:PlaybackMedia,raw:List<WatchHistoryEntry>)=raw.firstOrNull{it.playlistId==playlist && it.contentId==media.id && it.contentType==media.type}
 fun hide(playlist:String,type:PlaybackContentType,id:String,raw:List<WatchHistoryEntry>){}
 fun compactHistory(raw:List<WatchHistoryEntry>)=raw
}
