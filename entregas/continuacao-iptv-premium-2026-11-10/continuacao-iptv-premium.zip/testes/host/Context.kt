package android.content
open class Context(val cacheDir:java.io.File=java.io.File("/tmp/iptv-cache-host")) {
 companion object { const val MODE_PRIVATE=0 }
 val applicationContext get()=this
 private val stores=mutableMapOf<String,Prefs>()
 fun getSharedPreferences(name:String,mode:Int)=stores.getOrPut(name){Prefs()}
}
class Prefs {
 val all=mutableMapOf<String,Any?>()
 fun getString(k:String,d:String?):String?=all[k] as? String ?: d
 fun getBoolean(k:String,d:Boolean)=all[k] as? Boolean ?: d
 fun getLong(k:String,d:Long)=all[k] as? Long ?: d
 fun edit()=Editor(this)
}
class Editor(val prefs:Prefs) {
 private val values=mutableMapOf<String,Any?>();private var clear=false
 fun putString(k:String,v:String?)=apply{values[k]=v}
 fun putBoolean(k:String,v:Boolean)=apply{values[k]=v}
 fun clear()=apply{clear=true}
 fun commit():Boolean {if(clear)prefs.all.clear();prefs.all.putAll(values);return true}
 fun apply(){commit()}
}
