param([string]$Projeto = $PSScriptRoot)
$ErrorActionPreference = 'Stop'
$Projeto = (Resolve-Path -LiteralPath $Projeto).Path
$gradle = Join-Path $Projeto 'gradlew.bat'
if (-not (Test-Path -LiteralPath $gradle -PathType Leaf)) {
    throw "Nao encontrei gradlew.bat em $Projeto. Selecione a raiz do projeto extraido."
}
if (-not $env:JAVA_HOME) {
    $jbr = Join-Path $env:ProgramFiles 'Android\Android Studio\jbr'
    if (Test-Path -LiteralPath (Join-Path $jbr 'bin\java.exe')) { $env:JAVA_HOME = $jbr }
}
Push-Location -LiteralPath $Projeto
try {
    & $gradle :app:assembleDebug :app:testDebugUnitTest --console=plain
    if ($LASTEXITCODE -ne 0) { throw "O Gradle terminou com codigo $LASTEXITCODE. O motivo aparece acima; nenhum aplicativo foi instalado." }
    $apk = Join-Path $Projeto 'app\build\outputs\apk\debug\app-debug.apk'
    if (-not (Test-Path -LiteralPath $apk)) { throw 'O Gradle nao informou erro, mas o APK esperado nao foi encontrado.' }
    Write-Host "APK gerado: $apk" -ForegroundColor Green
    Write-Host 'Para atualizar uma instalacao existente, confira se a assinatura e a mesma do aplicativo anterior.'
}
finally { Pop-Location }
