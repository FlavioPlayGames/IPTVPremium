# Animes Quest — projeto reconstruído

Esta é uma pasta de projeto Android Studio editável, reconstruída sobre os fontes enviados e os recursos originais do APK avançado. Não é o código-fonte original decompilado nem uma simples troca de imagens no APK. Os ZIPs e o APK originais foram preservados.

## Abrir e gerar

1. Extraia a pasta `AnimesQuest-Reconstruido` em um novo local. Guarde o projeto anterior como backup.
2. No Android Studio, use **Open** e selecione esta pasta, que contém `settings.gradle.kts`.
3. Use o JDK 21 do Android Studio e instale o SDK Android 37 e Build Tools 37.0.0 se solicitado. Deixe a sincronização Gradle terminar. O Android Studio cria `local.properties` para o computador atual.
4. Para gerar o APK de desenvolvimento, execute na raiz:

```powershell
.\gradlew.bat :app:assembleDebug
```

Saída: `app\build\outputs\apk\debug\app-debug.apk`.

Para conferir as regras e o projeto:

```powershell
.\gradlew.bat :app:testDebugUnitTest :app:lintDebug
```

Os testes de interface precisam de celular/emulador conectado e de uma instalação de teste com idioma inicial português:

```powershell
.\gradlew.bat :app:connectedDebugAndroidTest
```

Não é necessário copiar caches, pastas `build`, `.gradle` ou o `local.properties` do computador anterior.

## O que foi reconstruído

- Home com a arte original `home_animes_quest_art_v2.png`, botão JOGAR original e botões menores com a base original. Não há um segundo texto desenhado sobre o JOGAR.
- Logo recriado em desenho nativo no estilo neon da referência. Os fontes originais do logo não estavam no ZIP de código.
- Seleção ilustrada de 22 avatares, equipe de 2 a 8 jogadores e nomes editáveis.
- Preparação manual com escolha de armadilha e adversário; o botão LET’S GO inicia a pergunta.
- Perguntas, feedback, placar entre rodadas, tela de vencedor e histórico local de vencedores.
- 3.200 perguntas recuperadas do APK, sem perguntas duplicadas e com quatro alternativas e resposta válida. Lite usa as primeiras 500.
- 10 técnicas e 9 armadilhas identificadas no APK; três de cada são sorteadas por jogador. Uma habilidade por turno, sem reutilização na partida.
- Pontuação por tempo, piso zero, vitória a partir de 20 pontos e bloqueio de técnicas a partir de 17 pontos.
- Música MP3 original de abertura, efeitos, narrador Android e endpoint opcional de voz externa. O cronômetro aguarda a narração, com proteção contra espera indefinida.
- Oito opções de idioma. Tradução automática local com ML Kit para os idiomas estrangeiros; os modelos precisam de internet na primeira utilização. Durante falha/download, o texto original continua disponível. A voz depende dos idiomas instalados no mecanismo TTS do celular; a voz externa depende do serviço configurado.
- Estrutura Google Sign-In, Billing, anúncios Lite e acesso Premium do projeto enviado. Validação de compra continua dependendo do backend; a reconstrução não libera compras sem validação.
- Identidade do launcher Lite/Premium conforme o acesso, com os nomes de aliases usados no APK.

## Configurações do dono do aplicativo

Este pacote não contém senhas, chaves privadas, keystores, tokens ou configurações de produção extraídas do APK. As integrações precisam dos valores legítimos já usados pelo dono:

- `premiumApiUrl`
- `googleWebClientId`
- `premiumSubscriptionId`
- `admobAppId`
- `admobInterstitialId`

Consulte `PREMIUM_LITE_SETUP.md` e a pasta `backend`. Guarde os valores em configuração local do Gradle, sem publicá-los. Debug utiliza IDs de teste do AdMob. Release é bloqueado se faltar configuração obrigatória; isso não bloqueia a sincronização nem a compilação debug.

O endpoint opcional do narrador é informado na própria tela de narração. Chaves do serviço ficam no servidor, não no aplicativo.

## Instalação como atualização

O package permanece `com.example.animeverso`; versionCode passou a 3 e versionName é `1.0.1-reconstruido`. Para atualizar o aplicativo instalado sem apagar dados, a assinatura deve ser a mesma. Use o keystore legítimo do projeto/aplicativo anterior. Gerar debug em outro computador normalmente usa outra assinatura; não desinstale o app com dados importantes para contornar isso.

O histórico novo usa armazenamento próprio: não foi afirmada migração automática do histórico privado do APK anterior, cujo formato de dados não estava nos fontes enviados.

## Fidelidade e limites

As artes e a música foram recuperadas sem edição. As telas, o logo, a organização das regras e o código de comportamento foram reconstruídos; não há garantia de equivalência de cada detalhe interno com os fontes perdidos. A preparação mostra as armadilhas recebidas na própria tela. As traduções são automáticas e podem precisar de revisão.

A compilação, os testes de regras e a análise estática foram executados. Ainda falta validar no celular as proporções das telas, áudio/TTS, download dos modelos, compras/conta, anúncios e interrupções reais. Não houve publicação em loja, instalação no seu aparelho ou alteração de backend em produção.

Para ver as telas no Android Studio, abra `RecoveredPreviews.kt` em modo **Split/Design**. São previews Compose do código reconstruído, não capturas do APK antigo.

Leia `VALIDACAO.md` para os resultados e `PROVENIENCIA-RECURSOS.json` para os hashes dos recursos recuperados.
