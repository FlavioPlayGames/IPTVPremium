# Animes Quest

Projeto Android reconstruído, com Kotlin e Jetpack Compose. Comece por [LEIA-ME-PRIMEIRO.md](LEIA-ME-PRIMEIRO.md).

A Home antiga com emojis foi substituída pela composição com os recursos originais do APK avançado. O botão JOGAR usa a imagem sem texto duplicado. As regras e telas foram reconstruídas; leia os limites de equivalência e a validação antes de distribuir.

Código das telas: `app/src/main/java/com/example/animeverso/ui/`.
Código das regras: `app/src/main/java/com/example/animeverso/game/`.
Áudio e narrador: `app/src/main/java/com/example/animeverso/audio/`.

Não inclua credenciais ou keystores no repositório. O backend e as contas de publicação continuam sendo responsabilidade e propriedade do dono do aplicativo.
