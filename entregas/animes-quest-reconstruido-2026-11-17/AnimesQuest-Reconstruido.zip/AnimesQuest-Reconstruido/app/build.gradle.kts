plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.example.animeverso"
    compileSdk = 37
    buildToolsVersion = "37.0.0"
    val premiumApiUrl = providers.gradleProperty("premiumApiUrl").orElse("").get()
    val googleWebClientId = providers.gradleProperty("googleWebClientId").orElse("").get()
    val premiumSubscriptionId = providers.gradleProperty("premiumSubscriptionId").orElse("animes_quest_premium_monthly").get()
    val admobAppId = providers.gradleProperty("admobAppId").orElse("").get()
    val admobInterstitialId = providers.gradleProperty("admobInterstitialId").orElse("").get()

    defaultConfig {
        applicationId = "com.example.animeverso"
        minSdk = 28
        targetSdk = 37
        versionCode = 3
        versionName = "1.0.1-reconstruido"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        buildConfigField("String", "PREMIUM_API_URL", "\"$premiumApiUrl\"")
        buildConfigField("String", "GOOGLE_WEB_CLIENT_ID", "\"$googleWebClientId\"")
        buildConfigField("String", "PREMIUM_SUBSCRIPTION_ID", "\"$premiumSubscriptionId\"")
        buildConfigField("String", "ADMOB_APP_ID", "\"$admobAppId\"")
        buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"$admobInterstitialId\"")
    }

    buildTypes {
        debug {
            buildConfigField("String", "ADMOB_APP_ID", "\"ca-app-pub-3940256099942544~3347511713\"")
            buildConfigField("String", "ADMOB_INTERSTITIAL_ID", "\"ca-app-pub-3940256099942544/1033173712\"")
            manifestPlaceholders["admobAppId"] = "ca-app-pub-3940256099942544~3347511713"
        }
        release {
            manifestPlaceholders["admobAppId"] = admobAppId
            optimization {
                enable = true
                packageScope = setOf("androidx.**", "kotlin.**", "kotlinx.**")
            }
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation("com.google.mlkit:translate:17.0.3")
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.credentials)
    implementation(libs.androidx.credentials.play.services.auth)
    implementation(libs.googleid)
    implementation(libs.google.play.billing)
    implementation(libs.google.mobile.ads.nextgen)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    testImplementation(libs.junit)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
    debugImplementation(libs.androidx.compose.ui.tooling)
}

// Validate publication configuration only for release packaging.
val validateReleaseConfig = tasks.register("validateReleaseConfig") {
    doLast {
        val required = listOf("premiumApiUrl", "googleWebClientId", "admobAppId", "admobInterstitialId")
        val missing = required.filter { providers.gradleProperty(it).orNull.isNullOrBlank() }
        check(missing.isEmpty()) { "Release bloqueado: configure " + missing.joinToString() }
    }
}
tasks.configureEach {
    if (name == "preReleaseBuild") dependsOn(validateReleaseConfig)
}
