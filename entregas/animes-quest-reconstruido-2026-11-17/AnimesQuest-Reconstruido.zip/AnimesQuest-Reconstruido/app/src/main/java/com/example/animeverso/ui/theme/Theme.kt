package com.example.animeverso.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = Color(0xFFFFD166),
    secondary = Color(0xFF51E4FF),
    tertiary = Color(0xFFFF4FD8),
    background = Color(0xFF090A1C),
    surface = Color(0xFF171A3B),
    onPrimary = Color(0xFF11132C),
    onSecondary = Color(0xFF11132C),
    onTertiary = Color(0xFF11132C),
    onBackground = Color.White,
    onSurface = Color.White,
)

@Composable
fun AnimeVersoTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
