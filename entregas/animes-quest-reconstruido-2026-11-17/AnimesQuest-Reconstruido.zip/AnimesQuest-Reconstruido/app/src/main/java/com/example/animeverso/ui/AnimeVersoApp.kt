package com.example.animeverso.ui

import android.content.Context
import android.app.Activity
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.systemBars
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.semantics.Role
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import com.example.animeverso.ui.QuestText as Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.offset
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException
import com.example.animeverso.BuildConfig
import com.example.animeverso.game.AccessState
import com.example.animeverso.game.ProductTier
import com.example.animeverso.premium.PremiumAccessClient
import com.example.animeverso.premium.PlaySubscriptionManager
import com.example.animeverso.premium.LiteRoundAds
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected as selectedSemantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.animeverso.audio.AnimeAudioManager
import com.example.animeverso.audio.AnimeNarrator
import com.example.animeverso.game.AppScreen
import com.example.animeverso.game.GameItem
import com.example.animeverso.game.GameViewModel
import com.example.animeverso.game.Player
import kotlinx.coroutines.delay

private val Ink = Color(0xFF090A1C)
private val Panel = Color(0xFF171A3B)
private val Cyan = Color(0xFF51E4FF)
private val Pink = Color(0xFFFF4FD8)
private val Gold = Color(0xFFFFD166)
private val Green = Color(0xFF76F7B2)
private val Red = Color(0xFFFF697D)
private val muted = Color(0xFFB5BBDF)
private val avatars = listOf("🍥", "🐉", "🎋", "🏴‍☠️", "⚡", "🌸", "🌀", "🗡️")

@Composable
internal fun AnimeVersoAppContent(viewModel: GameViewModel) {
    val state = viewModel.ui
    androidx.activity.compose.BackHandler(enabled = state.screen != AppScreen.INTRO) { viewModel.returnHome() }
    val context = LocalContext.current
    val preferences = remember { context.getSharedPreferences("animeverso", Context.MODE_PRIVATE) }
    val accessPreferences = remember { context.getSharedPreferences("animes_quest_access", Context.MODE_PRIVATE) }
    val lifecycleOwner = context as? LifecycleOwner
    var appInForeground by remember { mutableStateOf(lifecycleOwner?.lifecycle?.currentState?.isAtLeast(Lifecycle.State.STARTED) ?: true) }
    var homeLanguageKey by rememberSaveable { mutableStateOf(preferences.getString("home_language", HomeLanguage.PORTUGUESE_BRAZIL.name) ?: HomeLanguage.PORTUGUESE_BRAZIL.name) }
    val homeLanguage = HomeLanguage.entries.firstOrNull { it.name == homeLanguageKey } ?: HomeLanguage.PORTUGUESE_BRAZIL
    var endpoint by rememberSaveable { mutableStateOf(preferences.getString("voice_endpoint", "") ?: "") }
    var showVoiceSettings by remember { mutableStateOf(false) }
    var showAccessPanel by remember { mutableStateOf(false) }
    var accessMessage by remember { mutableStateOf("") }
    var homePanel by rememberSaveable { mutableStateOf("") }
    var googleIdToken by remember { mutableStateOf<String?>(null) }
    var isSigningIn by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val accessClient = remember { PremiumAccessClient() }
    val roundAds = remember(context) {
        (context as? Activity)?.let { LiteRoundAds(context, it, BuildConfig.ADMOB_APP_ID, BuildConfig.ADMOB_INTERSTITIAL_ID) }
    }
    val billing = remember(context) {
        (context as? Activity)?.let { activity ->
            PlaySubscriptionManager(
                activity = activity,
                accessClient = accessClient,
                currentGoogleIdToken = { googleIdToken },
                onAccessVerified = { access ->
                    viewModel.setAccessState(access)
                    accessPreferences.edit()
                        .putBoolean("server_verified", true)
                        .putString("tier", access.tier.name)
                        .putLong("trial_ends_at", access.trialEndsAtEpochMs)
                        .putLong("premium_ends_at", access.premiumEndsAtEpochMs ?: 0L)
                        .putString("account_email", access.accountEmail)
                        .apply()
                    accessMessage = access.statusMessage
                },
                onMessage = { accessMessage = it },
            )
        }
    }
    val localization = LocalQuestLocalization.current
    LaunchedEffect(homeLanguage) { localization.select(homeLanguage.translationCode) }
    val narrator = remember(context) { AnimeNarrator(context.applicationContext) }
    LaunchedEffect(homeLanguage, localization.ready) { narrator.setLanguage(if(localization.ready) homeLanguage.voiceTag else "pt-BR") }
    LaunchedEffect(state.soundEnabled, state.screen, state.isPaused) {
        if(!state.soundEnabled || state.isPaused || state.screen in setOf(AppScreen.INTRO, AppScreen.RULES, AppScreen.SETUP, AppScreen.ROUND_RESULTS)) narrator.stop()
    }
    val audio = remember(context) { AnimeAudioManager(context.applicationContext) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_START -> appInForeground = true
                Lifecycle.Event.ON_STOP -> {
                    viewModel.pauseMatch()
                    appInForeground = false
                    narrator.stop()
                    audio.stopOpeningMusic()
                }
                else -> Unit
            }
        }
        lifecycleOwner?.lifecycle?.addObserver(observer)
        onDispose { lifecycleOwner?.lifecycle?.removeObserver(observer) }
    }

    LaunchedEffect(state.soundEnabled) { audio.setEnabled(state.soundEnabled) }

    LaunchedEffect(state.access.trialEndsAtEpochMs, state.access.isVerifiedByServer) {
        while (true) {
            viewModel.expireTrialIfNeeded(System.currentTimeMillis())
            delay(30_000)
        }
    }

    LaunchedEffect(state.access.isPremium) {
        com.example.animeverso.LauncherIdentity.update(context.applicationContext, state.access.isPremium)
        if (!state.access.isPremium) roundAds?.initializeIfConfigured()
    }

    LaunchedEffect(accessClient.isConfigured, state.access.isVerifiedByServer) {
        if (accessClient.isConfigured && !state.access.isVerifiedByServer) showAccessPanel = true
    }

    DisposableEffect(showAccessPanel, billing) {
        if (showAccessPanel) billing?.connectAndLoad()
        onDispose { }
    }

    DisposableEffect(Unit) { onDispose { narrator.close(); audio.close(); billing?.close() } }

    LaunchedEffect(state.soundEnabled, state.screen, appInForeground, state.isPaused) {
        if (appInForeground && !state.isPaused && state.soundEnabled && state.screen in setOf(AppScreen.INTRO, AppScreen.RULES, AppScreen.SETUP)) audio.startOpeningMusic()
        else audio.stopOpeningMusic()
    }
    LaunchedEffect(state.handoffSerial, state.screen, appInForeground, state.isPaused) {
        if (appInForeground && !state.isPaused && state.screen == AppScreen.HANDOFF) {
            val roundEnded = !state.access.isPremium && state.players.isNotEmpty() && state.cardNumber > 0 && state.cardNumber % state.players.size == 0
            if (roundEnded) roundAds?.showAtRoundBoundary()
            audio.playTransition()
            if(state.soundEnabled) narrator.speak(localization.translate(viewModel.handoffSpeech()), endpoint)

        }
    }
    LaunchedEffect(state.questionSerial, state.screen, appInForeground, state.isPaused) {
        if (appInForeground && !state.isPaused && state.screen == AppScreen.GAME) {
            var finished = false
            if (state.soundEnabled) state.question?.let { narrator.speak(localization.translate(it.text), endpoint) { finished = true } } else finished = true
            var waited = 0
            while(!finished && waited < 20_000) { delay(100); waited += 100 }
            viewModel.startQuestionTimer()
            while(viewModel.ui.screen == AppScreen.GAME) {
                delay(1_000)
                viewModel.tickQuestion()
                if(viewModel.ui.soundEnabled && viewModel.ui.secondsLeft <= 5) audio.playTick()
            }
        }
    }
    LaunchedEffect(state.feedbackSerial, state.screen, appInForeground, state.isPaused) {
        if (appInForeground && !state.isPaused && state.screen == AppScreen.FEEDBACK) {
            if (viewModel.ui.soundEnabled) audio.playAnswer(viewModel.ui.answerWasCorrect)
            var finished = false
            if(state.soundEnabled) narrator.speak(localization.translate(viewModel.ui.feedbackSpeech), endpoint) { finished = true } else { delay(1_000); finished = true }
            var elapsed = 0
            while (!finished && elapsed < 8_000) { delay(100); elapsed += 100 }
            viewModel.finishFeedback()
        }
    }
    LaunchedEffect(state.screen, state.winnerName, appInForeground, state.isPaused) {
        if (appInForeground && !state.isPaused && state.soundEnabled && state.screen == AppScreen.FINISHED) {
            val name = state.winnerName
            narrator.speak(if (name != null) "Parabéns, $name! Você venceu o torneio do Animeverso!" else "O torneio terminou!", endpoint)
        }
    }

    Box(Modifier.fillMaxSize().background(Ink)) {
    if (state.screen != AppScreen.INTRO) QuestBackground()
    Column(
        Modifier.fillMaxSize()

            .windowInsetsPadding(WindowInsets.safeDrawing)
            .imePadding()
            .padding(horizontal = if(state.screen == AppScreen.INTRO) 0.dp else 16.dp, vertical = if(state.screen == AppScreen.INTRO) 0.dp else 10.dp),
    ) {
        if(localization.downloading) androidx.compose.material3.Text("Baixando idioma para uso no aparelho…", color = Cyan, fontSize = 11.sp)
        if(localization.error.isNotBlank()) androidx.compose.material3.Text(localization.error, color = Gold, fontSize = 11.sp)
        if (state.screen != AppScreen.INTRO) {
            Header(soundOn = state.soundEnabled, onSound = { viewModel.toggleSound() })
            Spacer(Modifier.height(12.dp))
        }
        Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (state.screen) {
                AppScreen.INTRO -> IntroScreen(
                    state.access,
                    soundOn = state.soundEnabled,
                    onSound = viewModel::toggleSound,
                    selectedLanguage = homeLanguage,
                    onLanguageSelected = { language ->
                        homeLanguageKey = language.name
                        preferences.edit().putString("home_language", language.name).apply()
                    },
                    onStart = {
                        if (accessClient.isConfigured && !viewModel.ui.access.isVerifiedByServer) showAccessPanel = true
                        else viewModel.openRules()
                    },
                    onRules = viewModel::openRules,
                    onAbilities = { homePanel = "abilities" },
                    onRanking = { homePanel = "ranking" },
                    onVoice = { showVoiceSettings = true },
                    onAccess = { showAccessPanel = true },
                )
                AppScreen.RULES -> RulesScreen(onHome = viewModel::returnHome, onContinue = viewModel::openSetup, questionCount = viewModel.availableQuestions().size, isPremium = state.access.isPremium)
                AppScreen.SETUP -> SetupScreen(viewModel, onStart = { viewModel.startMatch() })
                AppScreen.HANDOFF -> QuestPreparation(viewModel)
                AppScreen.GAME, AppScreen.FEEDBACK -> QuestGame(viewModel)
                AppScreen.ROUND_RESULTS -> QuestRoundResults(viewModel)
                AppScreen.FINISHED -> ResultScreen(state.winnerName, viewModel.rankedPlayers(), onHome = viewModel::returnHome, onAgain = viewModel::openSetup)
            }
        }
    }
    }

    if (state.isPaused && appInForeground) {
        AlertDialog(
            onDismissRequest = { },
            containerColor = Panel,
            title = { Text("Partida pausada", color = Cyan, fontWeight = FontWeight.Black) },
            text = { Text("A partida e a narração estão pausadas.", color = Color.White) },
            confirmButton = { TextButton(onClick = viewModel::resumeMatch) { Text("Retomar", color = Cyan) } },
            dismissButton = {
                TextButton(onClick = {
                    narrator.stop()
                    viewModel.returnHome()
                }) { Text("Encerrar partida", color = muted) }
            },
        )
    }

    if (showAccessPanel) {
        AlertDialog(
            onDismissRequest = { showAccessPanel = false },
            containerColor = Panel,
            title = { Text(if (state.access.isPremium) "ANIMES QUEST PREMIUM" else "ANIMES QUEST LITE", color = Cyan, fontWeight = FontWeight.Black) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text(state.access.statusMessage.ifBlank { "Período Premium gratuito de 24 horas." }, color = Color.White)
                    if (state.access.accountEmail != null) Text("Conta: ${state.access.accountEmail}", color = Gold, fontSize = 13.sp)
                    Text("Premium: banco completo, todas as técnicas, armadilhas e avatares. Lite: 500 perguntas, 4 técnicas, 3 armadilhas, metade dos avatares, ranking, sons e anúncios por rodada.", color = muted, fontSize = 12.sp)
                    Text("O teste de 24 horas não inicia uma cobrança. A assinatura mensal só começa se você confirmar a compra no Google Play; o cancelamento é gerenciado pela loja.", color = Color.White, fontSize = 12.sp)
                    if (accessMessage.isNotBlank()) Text(accessMessage, color = if (state.access.isPremium) Green else Gold, fontSize = 12.sp)
                    if (!accessClient.isConfigured) Text("Configuração pendente: publique o backend HTTPS e informe premiumApiUrl e googleWebClientId em gradle.properties. Sem isso, conta e compras ainda não podem ser validadas.", color = Red, fontSize = 12.sp)
                }
            },
            confirmButton = {
                Column(horizontalAlignment = Alignment.End) {
                    TextButton(enabled = !isSigningIn && BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank() && accessClient.isConfigured, onClick = {
                        scope.launch {
                            isSigningIn = true
                            accessMessage = ""
                            try {
                                val activity = context as? Activity ?: error("Atividade Android indisponível")
                                val option = GetGoogleIdOption.Builder()
                                    .setFilterByAuthorizedAccounts(false)
                                    .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
                                    .build()
                                val request = GetCredentialRequest.Builder().addCredentialOption(option).build()
                                val credential = CredentialManager.create(context).getCredential(activity, request).credential
                                val custom = credential as? CustomCredential ?: error("Tipo de conta Google inesperado")
                                if (custom.type != GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) error("A conta não retornou um token Google válido")
                                val idToken = GoogleIdTokenCredential.createFrom(custom.data).idToken
                                googleIdToken = idToken
                                val firstOpenedAt = accessPreferences.getLong("trial_started_at", System.currentTimeMillis())
                                val access = accessClient.refreshAccess(idToken, firstOpenedAt)
                                viewModel.setAccessState(access)
                                accessPreferences.edit()
                                    .putBoolean("server_verified", true)
                                    .putString("tier", access.tier.name)
                                    .putLong("trial_ends_at", access.trialEndsAtEpochMs)
                                    .putLong("premium_ends_at", access.premiumEndsAtEpochMs ?: 0L)
                                    .putString("account_email", access.accountEmail)
                                    .apply()
                                accessMessage = access.statusMessage
                                billing?.connectAndLoad()
                            } catch (error: GoogleIdTokenParsingException) {
                                accessMessage = "Não foi possível ler o token da conta Google."
                            } catch (error: Exception) {
                                accessMessage = error.message ?: "Falha ao validar a conta no servidor."
                            } finally { isSigningIn = false }
                        }
                    }) { Text(if (isSigningIn) "Validando…" else "Entrar com Google", color = Cyan) }
                    TextButton(enabled = googleIdToken != null && accessClient.isConfigured, onClick = { billing?.launchMonthlyPurchase() }) {
                        Text("Assinar Premium · R$ 10/mês", color = Gold)
                    }
                }
            },
            dismissButton = { TextButton(onClick = { showAccessPanel = false }) { Text("Fechar", color = muted) } },
        )
    }

    if (homePanel.isNotBlank()) {
        AlertDialog(
            onDismissRequest = { homePanel = "" },
            containerColor = Panel,
            title = { Text(if (homePanel == "abilities") "HABILIDADES" else "RANKING", color = Cyan, fontWeight = FontWeight.Black) },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (homePanel == "abilities") {
                        GameItem.entries.forEach { item ->
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Image(painterResource(item.art), null, Modifier.size(46.dp), contentScale = ContentScale.Crop)
                                Column { Text(item.label, color = Gold, fontWeight = FontWeight.Bold); Text(item.description, color = Cyan, fontSize = 12.sp) }
                            }
                        }
                    } else {
                        val ranked = viewModel.rankedPlayers()
                        viewModel.winnerRecords().forEach { Text("🏆 ${it.name} · ${it.score} pontos", color = Gold) }
                        if (ranked.isEmpty() && viewModel.winnerRecords().isEmpty()) Text("A classificação da partida aparecerá aqui após o torneio.", color = Color.White)
                        else ranked.forEachIndexed { index, player -> Text("${index + 1}. ${player.name} · ${player.score} pts", color = Color.White) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { homePanel = "" }) { Text("Fechar", color = Cyan) } },
        )
    }

    if (showVoiceSettings) {
        AlertDialog(
            onDismissRequest = { showVoiceSettings = false },
            containerColor = Panel,
            title = { Text("Narração do torneio", color = Cyan, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Use o endereço HTTPS do proxy ElevenLabs. A chave fica no servidor e não deve ser colocada no app.", color = Color.White)
                    OutlinedTextField(value = endpoint, onValueChange = { endpoint = it }, label = { Text("Endpoint HTTPS (opcional)") }, placeholder = { Text("https://seu-dominio/api/voice/generate") }, singleLine = true)
                    Text("Voz: Narrador Animeverso · Herói Shōnen BR", color = Gold, fontSize = 13.sp)
                }
            },
            confirmButton = { TextButton(onClick = {
                val cleaned = endpoint.trim()
                if (cleaned.isEmpty() || cleaned.startsWith("https://", true)) {
                    endpoint = cleaned
                    preferences.edit().putString("voice_endpoint", cleaned).apply()
                    showVoiceSettings = false
                }
            }) { Text("Salvar", color = Cyan) } },
            dismissButton = { TextButton(onClick = { showVoiceSettings = false }) { Text("Cancelar", color = muted) } },
        )
    }
}

@Composable
private fun Header(soundOn: Boolean, onSound: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Column(Modifier.weight(1f)) {
            AppBrandLogo(Modifier.fillMaxWidth(0.82f).height(52.dp))
            Text("BATALHA DOS OTAKUS", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 2.sp)
        }
        OutlinedButton(onClick = onSound, shape = CircleShape) { Text(if(soundOn) "🔊" else "🔇") }
    }
}

@Composable
internal fun HomeImageButton(type: HomeButtonType, language: HomeLanguage, onClick: () -> Unit, modifier: Modifier) {
    val label = when (type) {
        HomeButtonType.PLAY -> language.accessibilityName + ": PLAY"
        HomeButtonType.RULES -> language.accessibilityName + ": RULES"
        HomeButtonType.ABILITIES -> language.accessibilityName + ": ABILITIES"
        HomeButtonType.RANKING -> language.accessibilityName + ": RANKING"
    }
    key(language, type) {
        Image(
            painter = painterResource(language.buttonResource(type)),
            contentDescription = label,
            modifier = modifier.clickable(role = Role.Button, onClick = onClick),
            contentScale = ContentScale.Fit,
        )
    }
}

@Composable
internal fun LanguageSelector(selected: HomeLanguage, onSelect: (HomeLanguage) -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Text(selected.selectorTitle, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Black, letterSpacing = 0.5.sp, textAlign = TextAlign.Center)
        HomeLanguage.entries.chunked(4).forEach { rowLanguages ->
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                rowLanguages.forEach { language ->
                    Box(
                        Modifier.size(38.dp)
                            .background(if (language == selected) Color(0xFF233B5C) else Color(0xDD10132E), CircleShape)
                            .then(if (language == selected) Modifier.border(1.5.dp, Cyan, CircleShape) else Modifier)
                            .clickable(role = Role.RadioButton, onClick = { onSelect(language) }),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(language.flag, fontSize = 23.sp, modifier = Modifier.semantics { contentDescription = language.accessibilityName; selectedSemantics = language == selected })
                    }
                }
            }
        }
    }
}

@Composable
private fun RulesScreen(onHome: () -> Unit, onContinue: () -> Unit, questionCount: Int, isPremium: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("REGRAS DA BATALHA", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
        RuleCard("Objetivo", listOf("De 2 a 8 jogadores. Vence quem chegar a 20 pontos.", "Cada jogador recebe 3 técnicas e 3 armadilhas sorteadas."))
        RuleCard("Tempo e pontuação", listOf("30 segundos após a narração da pergunta.", "Acertos: 21–30 segundos = 3 pontos; 11–20 = 2; até 10 = 1.", "Erro ou tempo esgotado: −1 ponto, mínimo zero.", "A partir de 17 pontos, perguntas avançadas e técnicas bloqueadas; armadilhas continuam disponíveis."))
        RuleCard("Habilidades", listOf("Armadilhas: use na preparação, escolhendo o adversário.", "Técnicas: use durante a pergunta.", "No máximo uma habilidade por turno; cada habilidade só pode ser usada uma vez por partida."))
        RuleCard("Perguntas", listOf("$questionCount perguntas disponíveis nesta modalidade.", if(isPremium) "Premium: banco completo e todos os avatares." else "Lite: 500 perguntas e seleção reduzida de habilidades e avatares."))
        PrimaryButton("SELECIONAR PERSONAGENS", onContinue)
        OutlinedButton(onClick = onHome, modifier = Modifier.fillMaxWidth()) { Text("← INÍCIO", color = Color.White) }
    }
}

@Composable
private fun SetupScreen(vm: GameViewModel, onStart: () -> Unit) = QuestSetup(vm, onStart)

@Composable
private fun ResultScreen(winner: String?, players: List<Player>, onHome: () -> Unit, onAgain: () -> Unit) {
    GameCard {
        Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Image(painterResource(com.example.animeverso.R.drawable.victory_crest), null, Modifier.size(110.dp), contentScale = ContentScale.Fit)
            Text("CAMPEÃO DA BATALHA!", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black, textAlign = TextAlign.Center)
            Text(winner.orEmpty(), color = Cyan, fontWeight = FontWeight.Black, fontSize = 24.sp)
            players.forEachIndexed { i, p ->
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    AvatarArt(p.avatar, Modifier.size(44.dp)); Text("${i+1}. ${p.name} · ${p.score} pontos", color = Color.White)
                }
            }
            PrimaryButton("JOGAR NOVAMENTE", onAgain)
            OutlinedButton(onClick = onHome) { Text("VOLTAR AO INÍCIO", color = Color.White) }
        }
    }
}

@Composable
private fun RuleCard(title: String, lines: List<String>) {
    GameCard {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(title, color = Cyan, fontWeight = FontWeight.Bold)
            lines.forEach { Text("•  $it", color = Color.White, fontSize = 13.sp) }
        }
    }
}

@Composable
private fun GameCard(content: @Composable () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)) { content() }
}

@Composable
private fun PrimaryButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Button(onClick = onClick, modifier = modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink), shape = RoundedCornerShape(13.dp)) {
        Text(text, fontWeight = FontWeight.Black, modifier = Modifier.padding(vertical = 4.dp))
    }
}

