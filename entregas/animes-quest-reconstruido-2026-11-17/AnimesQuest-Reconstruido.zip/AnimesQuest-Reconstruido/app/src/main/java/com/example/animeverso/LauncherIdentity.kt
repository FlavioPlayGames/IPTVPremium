package com.example.animeverso

import android.content.ComponentName
import android.content.Context
import android.content.pm.PackageManager

/** Uses the original APK's alias names; never kills the foreground game. */
object LauncherIdentity {
    fun update(context: Context, premium: Boolean) {
        val pm = context.packageManager
        val enabled = if(premium) "PremiumLauncher" else "LiteLauncher"
        val disabled = if(premium) "LiteLauncher" else "PremiumLauncher"
        fun change(name: String, state: Int) {
            val component = ComponentName(context.packageName, context.packageName + "." + name)
            if(pm.getComponentEnabledSetting(component) != state) pm.setComponentEnabledSetting(component, state, PackageManager.DONT_KILL_APP)
        }
        change(enabled, PackageManager.COMPONENT_ENABLED_STATE_ENABLED)
        change(disabled, PackageManager.COMPONENT_ENABLED_STATE_DISABLED)
    }
}
