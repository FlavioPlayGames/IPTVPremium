package com.example.animeverso.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import java.util.concurrent.Executors
import kotlin.math.PI
import kotlin.math.sin

class AnimeAudioManager(private val context: android.content.Context) {
    private var openingPlayer: android.media.MediaPlayer? = null
    @Volatile private var enabled = true
    @Volatile private var musicRunning = false
    private var musicThread: Thread? = null
    private val effects = Executors.newSingleThreadExecutor()
    private val sampleRate = 22_050

    fun setEnabled(value: Boolean) { enabled = value; if (!value) stopOpeningMusic() }

    fun startOpeningMusic() {
        if(!enabled || openingPlayer?.isPlaying == true) return
        if(openingPlayer == null) openingPlayer = android.media.MediaPlayer.create(context, com.example.animeverso.R.raw.animes_quest_opening)?.apply {
            isLooping = true
            setVolume(0.28f, 0.28f)
        }
        runCatching { openingPlayer?.start() }
    }

    fun stopOpeningMusic() { runCatching { openingPlayer?.pause() } }

    fun playTransition() = sequence(listOf(392.0, 523.0, 659.0, 784.0), 125, 0.18f)
    fun playTick() = sequence(listOf(128.0, 850.0), 70, 0.24f)
    fun playAnswer(correct: Boolean) = if (correct) sequence(listOf(523.0, 659.0, 784.0, 1046.0), 150, 0.22f) else sequence(listOf(260.0, 185.0, 115.0), 180, 0.22f)
    fun playItem() = sequence(listOf(440.0, 660.0, 880.0), 110, 0.18f)

    private fun sequence(notes: List<Double>, durationMs: Int, volume: Float) {
        if (!enabled) return
        effects.execute {
            for (frequency in notes) {
                if (!enabled) break
                playTone(frequency, durationMs, volume, 0.12)
                try { Thread.sleep(18) } catch (_: InterruptedException) { break }
            }
        }
    }

    private fun playTone(frequency: Double, durationMs: Int, volume: Float, shape: Double) {
        val count = (sampleRate * durationMs / 1000.0).toInt().coerceAtLeast(1)
        val samples = ShortArray(count) { index ->
            val time = index.toDouble() / sampleRate
            val fadeIn = (index / (sampleRate * 0.018)).coerceIn(0.0, 1.0)
            val fadeOut = ((count - index).toDouble() / (sampleRate * 0.06)).coerceIn(0.0, 1.0)
            val envelope = minOf(fadeIn, fadeOut)
            val fundamental = sin(2.0 * PI * frequency * time)
            val harmonic = sin(2.0 * PI * frequency * 2.01 * time) * shape
            ((fundamental + harmonic) * 0.5 * envelope * volume * Short.MAX_VALUE).toInt().toShort()
        }
        val format = AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
        val attributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
        val track = AudioTrack.Builder().setAudioAttributes(attributes).setAudioFormat(format).setBufferSizeInBytes(samples.size * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        try {
            track.write(samples, 0, samples.size)
            track.play()
            Thread.sleep(durationMs.toLong())
        } catch (_: InterruptedException) {
            Thread.currentThread().interrupt()
        } catch (_: IllegalStateException) {
            // Audio can be interrupted while the app is leaving a screen.
        } finally {
            if (track.state == AudioTrack.STATE_INITIALIZED) {
                try { track.stop() } catch (_: IllegalStateException) { }
            }
            track.release()
        }
    }

    fun close() {
        stopOpeningMusic()
        openingPlayer?.release()
        openingPlayer = null
        effects.shutdownNow()
    }

    private fun Double.pow(exponent: Double): Double = Math.pow(this, exponent)
}
