package com.example.animeverso

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.animeverso.game.GameViewModel
import com.example.animeverso.game.QuestionRepository
import com.example.animeverso.game.AccessState
import com.example.animeverso.game.ProductTier
import com.example.animeverso.ui.AnimeVersoApp
import com.example.animeverso.ui.theme.AnimeVersoTheme
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        lifecycleScope.launch {
            val questions = withContext(Dispatchers.IO) { QuestionRepository.load(applicationContext) }
            val factory = GameViewModelFactory(questions, com.example.animeverso.game.WinnerHistoryRepository(applicationContext))
            val gameViewModel = ViewModelProvider(this@MainActivity, factory)[GameViewModel::class.java]
            val accessPrefs = getSharedPreferences("animes_quest_access", MODE_PRIVATE)
            val now = System.currentTimeMillis()
            val trialStarted = accessPrefs.getLong("trial_started_at", 0L).takeIf { it > 0L } ?: now.also {
                accessPrefs.edit().putLong("trial_started_at", it).apply()
            }
            val trialEndsAt = trialStarted + 24L * 60L * 60L * 1000L
            val savedPremiumUntil = accessPrefs.getLong("premium_ends_at", 0L)
            val savedVerified = accessPrefs.getBoolean("server_verified", false)
            val savedTrialEndsAt = accessPrefs.getLong("trial_ends_at", trialEndsAt)
            val savedTier = accessPrefs.getString("tier", "")
            val isPremium = if (savedVerified) {
                savedTier == ProductTier.PREMIUM.name && (savedPremiumUntil > now || savedTrialEndsAt > now)
            } else now < trialEndsAt
            gameViewModel.setAccessState(
                AccessState(
                    tier = if (isPremium) ProductTier.PREMIUM else ProductTier.LITE,
                    trialEndsAtEpochMs = if (savedVerified) savedTrialEndsAt else trialEndsAt,
                    premiumEndsAtEpochMs = savedPremiumUntil.takeIf { it > now },
                    accountEmail = accessPrefs.getString("account_email", null),
                    isVerifiedByServer = savedVerified,
                    statusMessage = if (isPremium && savedVerified && savedPremiumUntil > now) "Assinatura validada." else if (isPremium) "Período Premium de 24 horas." else "Versão Lite ativa.",
                ),
            )
            setContent { AnimeVersoTheme { AnimeVersoApp(gameViewModel) } }
        }
    }
}

private class GameViewModelFactory(private val questions: List<com.example.animeverso.game.QuizQuestion>, private val history: com.example.animeverso.game.WinnerHistoryRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T = GameViewModel(questions, history) as T
}
