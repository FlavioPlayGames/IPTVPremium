package com.example.animeverso.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import com.example.animeverso.game.GameViewModel
import com.google.android.gms.tasks.Task
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

internal suspend fun <T> Task<T>.awaitQuest(): T = suspendCancellableCoroutine { c ->
    addOnSuccessListener { if(c.isActive) c.resume(it) }
    addOnFailureListener { if(c.isActive) c.resumeWithException(it) }
    addOnCanceledListener { c.cancel() }
}

internal class QuestLocalization {
    var code by mutableStateOf("pt"); private set
    var ready by mutableStateOf(true); private set
    var downloading by mutableStateOf(false); private set
    var error by mutableStateOf(""); private set
    private var translator: Translator? = null
    private val cache = mutableStateMapOf<String, String>()
    suspend fun select(language: String) {
        if(code == language && ready) return
        translator?.close(); translator = null; cache.clear()
        code = language; error = ""; ready = language == "pt"; downloading = !ready
        if(ready) return
        val target = Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(TranslateLanguage.PORTUGUESE).setTargetLanguage(language).build())
        translator = target
        try {
            target.downloadModelIfNeeded().awaitQuest()
            if(translator === target) ready = true
        } catch(e: kotlinx.coroutines.CancellationException) { throw e }
        catch(e: Exception) { if(translator === target) error = "Não foi possível baixar o idioma. O texto original continua disponível." }
        finally { if(translator === target) downloading = false }
    }
    suspend fun translate(text: String): String {
        val active = translator
        if(code == "pt" || !ready || active == null || text.isBlank() || text == "ANIMES QUEST" || text.none { it.isLetter() }) return text
        cache[text]?.let { return it }
        return try {
            val translated = active.translate(text).awaitQuest()
            if(active === translator) { if(cache.size > 2500) cache.clear(); cache[text] = translated }
            translated
        } catch(e: kotlinx.coroutines.CancellationException) { throw e }
        catch(e: Exception) { text }
    }
    fun close() { translator?.close(); translator = null }
}
internal val LocalQuestLocalization = staticCompositionLocalOf<QuestLocalization> { error("Localization unavailable") }

@Composable
fun AnimeVersoApp(viewModel: GameViewModel) {
    val localization = remember { QuestLocalization() }
    DisposableEffect(localization) { onDispose { localization.close() } }
    CompositionLocalProvider(LocalQuestLocalization provides localization) { AnimeVersoAppContent(viewModel) }
}

@Composable
internal fun QuestText(
    text: String, modifier: Modifier = Modifier, color: Color = Color.Unspecified,
    fontSize: TextUnit = TextUnit.Unspecified, fontWeight: FontWeight? = null,
    fontStyle: FontStyle? = null, letterSpacing: TextUnit = TextUnit.Unspecified,
    textAlign: TextAlign? = null,
) {
    val manager = LocalQuestLocalization.current
    var displayed by remember(text, manager.code) { mutableStateOf(text) }
    LaunchedEffect(text, manager.code, manager.ready) { displayed = manager.translate(text) }
    androidx.compose.material3.Text(displayed, modifier, color = color, fontSize = fontSize, fontWeight = fontWeight, fontStyle = fontStyle, letterSpacing = letterSpacing, textAlign = textAlign, style = MaterialTheme.typography.bodyLarge)
}

internal val HomeLanguage.translationCode: String get() = when(this) {
    HomeLanguage.PORTUGUESE_BRAZIL, HomeLanguage.PORTUGUESE_PORTUGAL -> "pt"
    HomeLanguage.ENGLISH_US, HomeLanguage.ENGLISH_UK -> "en"
    HomeLanguage.FRENCH -> "fr"; HomeLanguage.GERMAN -> "de"; HomeLanguage.SPANISH -> "es"; HomeLanguage.ITALIAN -> "it"
}
internal val HomeLanguage.voiceTag: String get() = when(this) {
    HomeLanguage.PORTUGUESE_BRAZIL -> "pt-BR"; HomeLanguage.PORTUGUESE_PORTUGAL -> "pt-PT"
    HomeLanguage.ENGLISH_US -> "en-US"; HomeLanguage.ENGLISH_UK -> "en-GB"
    HomeLanguage.FRENCH -> "fr-FR"; HomeLanguage.GERMAN -> "de-DE"; HomeLanguage.SPANISH -> "es-ES"; HomeLanguage.ITALIAN -> "it-IT"
}
