package com.example.animeverso.game

data class QuizQuestion(
    val id: Int,
    val category: String,
    val text: String,
    val answer: String,
    val options: List<String>,
    val advanced: Boolean,
)

data class Player(
    val name: String,
    val avatar: String,
    val colorIndex: Int,
    val score: Int = 0,
    val position: Int = 0,
    val eliminated: Boolean = false,
    val usedItems: Set<GameItem> = emptySet(),
    val shortTimer: Boolean = false,
    val blockItems: Boolean = false,
    val blockTechniques: Boolean = false,
    val shield: Boolean = false,
    val finalChallenge: Boolean = false,
    val availableTechniques: Set<GameItem> = emptySet(),
    val availableTraps: Set<GameItem> = emptySet(),
    val timerPenalty: Int = 0,
    val forceAdvanced: Boolean = false,
    val noPoints: Boolean = false,
    val protectedErrors: Int = 0,
    val retry: Boolean = false,
    val bonus: Int = 0,
    val pendingTrap: String = "",

)

enum class AppScreen { INTRO, RULES, SETUP, HANDOFF, GAME, FEEDBACK, ROUND_RESULTS, FINISHED }

enum class ProductTier { LITE, PREMIUM }

data class AccessState(
    val tier: ProductTier = ProductTier.PREMIUM,
    val trialEndsAtEpochMs: Long = 0L,
    val premiumEndsAtEpochMs: Long? = null,
    val accountEmail: String? = null,
    val isVerifiedByServer: Boolean = false,
    val statusMessage: String = "",
) {
    val isPremium: Boolean get() = tier == ProductTier.PREMIUM
}

enum class GameItem(val icon: String, val label: String, val description: String, val art: Int, val isTrap: Boolean) {
    SENZU("⚔️", "Lâmina Astral", "+10 segundos", com.example.animeverso.R.drawable.tech_aether_blade, false),
    SHARINGAN("🔶", "Cristal da Previsão", "Remove 2 opções erradas", com.example.animeverso.R.drawable.tech_foresight_crystal, false),
    INSTINCT("💠", "Aura Ascendente", "Remove até 3 opções erradas", com.example.animeverso.R.drawable.tech_ascendant_aura, false),
    BARRIER("🛡️", "Campo de Égide", "Absorve uma armadilha recebida", com.example.animeverso.R.drawable.tech_aegis_field, false),
    VORTEX("🔵", "Orbe Turbilhão", "Acertando, ganha +2 pontos", com.example.animeverso.R.drawable.tech_vortex_orb, false),
    WAVE("🔷", "Onda Celeste", "+8 segundos", com.example.animeverso.R.drawable.tech_azure_wave, false),
    OVERDRIVE("👊", "Punho Overdrive", "+5 segundos e protege 1 erro", com.example.animeverso.R.drawable.tech_overclock_fist, false),
    MIRAGE("🌀", "Portal da Miragem", "Troca a pergunta sem reiniciar o tempo", com.example.animeverso.R.drawable.tech_mirage_gate, false),
    DECOY("🌫️", "Eco Espectral", "Permite uma segunda tentativa após errar", com.example.animeverso.R.drawable.tech_phantom_decoy, false),
    ARMOR("🛡️", "Armadura Astral", "Protege contra perda de pontos nos próximos 2 erros", com.example.animeverso.R.drawable.tech_astral_armor, false),
    CLONE("📜", "Talismã Rúnico", "Próxima pergunta começa com 15 segundos", com.example.animeverso.R.drawable.trap_hex_talisman, true),
    SEAL("🔹", "Dardo Noturno", "Bloqueia habilidades no próximo turno", com.example.animeverso.R.drawable.trap_night_dart, true),
    DRAIN("🐺", "Lobo Espectral", "Transfere até 3 pontos", com.example.animeverso.R.drawable.trap_spirit_wolf, true),
    EMBER("🔥", "Marca de Brasa", "Alvo começa com 10 segundos a menos", com.example.animeverso.R.drawable.trap_ember_mark, true),
    MIRROR("🪞", "Fenda do Espelho", "Força uma pergunta avançada no próximo turno", com.example.animeverso.R.drawable.trap_mirror_rift, true),
    VOID("🟣", "Vórtice do Vazio", "Transfere até 2 pontos do alvo", com.example.animeverso.R.drawable.trap_void_well, true),
    SIPHON("🌀", "Dreno de Energia", "Bloqueia técnicas no próximo turno", com.example.animeverso.R.drawable.trap_energy_siphon, true),
    ARC("⚡", "Arco Negro", "Transfere 3 pontos a um jogador aleatório", com.example.animeverso.R.drawable.trap_black_arc, true),
    STASIS("🔒", "Cristal de Estase", "Alvo não ganha pontos na próxima resposta correta", com.example.animeverso.R.drawable.trap_stasis_crystal, true);
}

data class GameUiState(
    val screen: AppScreen = AppScreen.INTRO,
    val playerCount: Int = 4,
    val playerNames: List<String> = (1..4).map { "Competidor $it" },
    val avatars: List<String> = (0 until 8).map { it.toString() },
    val players: List<Player> = emptyList(),
    val currentPlayerIndex: Int = 0,
    val question: QuizQuestion? = null,
    val answerOptions: List<String> = emptyList(),
    val correctOptionIndex: Int = -1,
    val eliminatedOptions: Set<Int> = emptySet(),
    val selectedOptionIndex: Int = -1,
    val secondsLeft: Int = 30,
    val handoffSeconds: Int = 10,
    val handoffIsFirst: Boolean = false,
    val handoffSerial: Int = 0,
    val questionSerial: Int = 0,
    val feedbackSerial: Int = 0,
    val feedbackText: String = "",
    val feedbackSpeech: String = "",
    val answerWasCorrect: Boolean = false,
    val timedOut: Boolean = false,
    val cardNumber: Int = 0,
    val hasUsedItemThisTurn: Boolean = false,
    val winnerName: String? = null,
    val banner: String = "",
    val soundEnabled: Boolean = true,
    val isPaused: Boolean = false,
    val round: Int = 1,
    val isListening: Boolean = false,
    val access: AccessState = AccessState(),
)
