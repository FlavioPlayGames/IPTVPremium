package com.example.animeverso.premium

import android.app.Activity
import android.content.Context
import com.google.android.libraries.ads.mobile.sdk.MobileAds
import com.google.android.libraries.ads.mobile.sdk.common.AdLoadCallback
import com.google.android.libraries.ads.mobile.sdk.common.AdRequest
import com.google.android.libraries.ads.mobile.sdk.initialization.InitializationConfig
import com.google.android.libraries.ads.mobile.sdk.common.LoadAdError
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAd
import com.google.android.libraries.ads.mobile.sdk.interstitial.InterstitialAdEventCallback
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.withTimeoutOrNull

/** Lite interstitials are only offered at the pause between complete player cycles. */
class LiteRoundAds(context: Context, private val activity: Activity, private val appId: String, private val adUnitId: String) {
    private val appContext = context.applicationContext
    @Volatile private var initialized = false
    @Volatile private var ad: InterstitialAd? = null
    private val initializationScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun initializeIfConfigured() {
        if (initialized || appId.isBlank() || adUnitId.isBlank()) return
        initialized = true
        initializationScope.launch {
            MobileAds.initialize(appContext, InitializationConfig.Builder(appId).build()) {
                initializationScope.launch(Dispatchers.Main) { loadNext() }
            }
        }
    }

    private fun loadNext() {
        if (!initialized || adUnitId.isBlank()) return
        InterstitialAd.load(AdRequest.Builder(adUnitId).build(), object : AdLoadCallback<InterstitialAd> {
            override fun onAdLoaded(loaded: InterstitialAd) { ad = loaded }
            override fun onAdFailedToLoad(error: LoadAdError) { ad = null }
        })
    }

    suspend fun showAtRoundBoundary(): Boolean {
        initializeIfConfigured()
        val current = ad ?: return false
        ad = null
        val dismissed = CompletableDeferred<Boolean>()
        current.adEventCallback = object : InterstitialAdEventCallback {
            override fun onAdDismissedFullScreenContent() { dismissed.complete(true); loadNext() }
            override fun onAdFailedToShowFullScreenContent(error: com.google.android.libraries.ads.mobile.sdk.common.FullScreenContentError) {
                dismissed.complete(false)
                loadNext()
            }
        }
        runCatching { current.show(activity) }.onFailure { dismissed.complete(false); loadNext() }
        return withTimeoutOrNull(60_000) { dismissed.await() } ?: false
    }
}
