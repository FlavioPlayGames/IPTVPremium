package com.example.animeverso.ui

import com.example.animeverso.R

internal enum class HomeButtonType { PLAY, RULES, ABILITIES, RANKING }

internal enum class HomeLanguage(
    val flag: String,
    val accessibilityName: String,
) {
    PORTUGUESE_BRAZIL("🇧🇷", "Português (Brasil)"),
    PORTUGUESE_PORTUGAL("🇵🇹", "Português (Portugal)"),
    ENGLISH_US("🇺🇸", "English (United States)"),
    ENGLISH_UK("🇬🇧", "English (United Kingdom)"),
    FRENCH("🇫🇷", "Français"),
    GERMAN("🇩🇪", "Deutsch"),
    SPANISH("🇪🇸", "Español"),
    ITALIAN("🇮🇹", "Italiano");

    val selectorTitle: String
        get() = when (this) {
            PORTUGUESE_BRAZIL -> "ESCOLHA SEU IDIOMA"
            PORTUGUESE_PORTUGAL -> "ESCOLHA O SEU IDIOMA"
            ENGLISH_US, ENGLISH_UK -> "CHOOSE YOUR LANGUAGE"
            FRENCH -> "CHOISISSEZ VOTRE LANGUE"
            GERMAN -> "SPRACHE WÄHLEN"
            SPANISH -> "ELIGE TU IDIOMA"
            ITALIAN -> "SCEGLI LA TUA LINGUA"
        }

    fun buttonResource(type: HomeButtonType): Int = when (this) {
        PORTUGUESE_BRAZIL -> when (type) {
            HomeButtonType.PLAY -> R.drawable.home_play_pt_br
            HomeButtonType.RULES -> R.drawable.home_rules_pt_br
            HomeButtonType.ABILITIES -> R.drawable.home_abilities_pt_br
            HomeButtonType.RANKING -> R.drawable.home_ranking_pt_br
        }
        PORTUGUESE_PORTUGAL -> when (type) {
            HomeButtonType.PLAY -> R.drawable.home_play_pt_pt
            HomeButtonType.RULES -> R.drawable.home_rules_pt_pt
            HomeButtonType.ABILITIES -> R.drawable.home_abilities_pt_pt
            HomeButtonType.RANKING -> R.drawable.home_ranking_pt_pt
        }
        ENGLISH_US -> when (type) {
            HomeButtonType.PLAY -> R.drawable.home_play_en_us
            HomeButtonType.RULES -> R.drawable.home_rules_en_us
            HomeButtonType.ABILITIES -> R.drawable.home_abilities_en_us
            HomeButtonType.RANKING -> R.drawable.home_ranking_en_us
        }
        ENGLISH_UK -> when (type) {
            HomeButtonType.PLAY -> R.drawable.home_play_en_gb
            HomeButtonType.RULES -> R.drawable.home_rules_en_gb
            HomeButtonType.ABILITIES -> R.drawable.home_abilities_en_gb
            HomeButtonType.RANKING -> R.drawable.home_ranking_en_gb
        }
        FRENCH -> when (type) {
            HomeButtonType.PLAY -> R.drawable.home_play_fr
            HomeButtonType.RULES -> R.drawable.home_rules_fr
            HomeButtonType.ABILITIES -> R.drawable.home_abilities_fr
            HomeButtonType.RANKING -> R.drawable.home_ranking_fr
        }
        GERMAN -> when (type) {
            HomeButtonType.PLAY -> R.drawable.home_play_de
            HomeButtonType.RULES -> R.drawable.home_rules_de
            HomeButtonType.ABILITIES -> R.drawable.home_abilities_de
            HomeButtonType.RANKING -> R.drawable.home_ranking_de
        }
        SPANISH -> when (type) {
            HomeButtonType.PLAY -> R.drawable.home_play_es
            HomeButtonType.RULES -> R.drawable.home_rules_es
            HomeButtonType.ABILITIES -> R.drawable.home_abilities_es
            HomeButtonType.RANKING -> R.drawable.home_ranking_es
        }
        ITALIAN -> when (type) {
            HomeButtonType.PLAY -> R.drawable.home_play_it
            HomeButtonType.RULES -> R.drawable.home_rules_it
            HomeButtonType.ABILITIES -> R.drawable.home_abilities_it
            HomeButtonType.RANKING -> R.drawable.home_ranking_it
        }
    }
}
