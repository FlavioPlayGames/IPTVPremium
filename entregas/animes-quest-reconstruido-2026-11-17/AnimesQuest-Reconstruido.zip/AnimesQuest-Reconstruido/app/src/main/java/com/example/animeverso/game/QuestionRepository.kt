package com.example.animeverso.game

import android.content.Context
import org.json.JSONArray

object QuestionRepository {
    fun load(context: Context): List<QuizQuestion> {
        val raw = context.assets.open("anime_questions.json").bufferedReader(Charsets.UTF_8).use { it.readText() }
        val json = JSONArray(raw)
        val questions = ArrayList<QuizQuestion>(json.length())
        val seen = HashSet<String>()
        for (index in 0 until json.length()) {
            val row = json.getJSONObject(index)
            val text = row.getString("pergunta")
            val normalized = text.lowercase().filter(Char::isLetterOrDigit)
            if (!seen.add(normalized)) continue
            val values = row.getJSONArray("alternativas")
            val options = (0 until values.length()).map(values::getString)
            questions += QuizQuestion(
                id = row.getInt("id"),
                category = row.getString("categoria"),
                text = text,
                answer = row.getString("respostaCorreta"),
                options = options,
                advanced = row.getBoolean("avancada"),
            )
        }
        return questions
    }
}
