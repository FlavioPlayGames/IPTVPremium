package com.example.animeverso.premium

import com.example.animeverso.BuildConfig
import com.example.animeverso.game.AccessState
import com.example.animeverso.game.ProductTier
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Sends Google ID tokens to the trusted access server. The app never decides purchases are valid. */
class PremiumAccessClient(private val baseUrl: String = BuildConfig.PREMIUM_API_URL) {
    val isConfigured: Boolean get() = baseUrl.startsWith("https://", ignoreCase = true)

    suspend fun refreshAccess(googleIdToken: String, firstOpenedAtEpochMs: Long): AccessState = withContext(Dispatchers.IO) {
        check(isConfigured) { "O servidor Premium ainda não foi configurado." }
        val connection = URL("${baseUrl.trimEnd('/')}/v1/access").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 10_000
            connection.readTimeout = 15_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("Accept", "application/json")
            connection.outputStream.use { it.write(JSONObject().put("googleIdToken", googleIdToken).put("firstOpenedAt", firstOpenedAtEpochMs).toString().toByteArray()) }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            check(code in 200..299) { runCatching { JSONObject(body).optString("error") }.getOrNull() ?: "Não foi possível validar o acesso." }
            val json = JSONObject(body)
            AccessState(
                tier = if (json.optString("tier") == "PREMIUM") ProductTier.PREMIUM else ProductTier.LITE,
                trialEndsAtEpochMs = json.optLong("trialEndsAt", 0L),
                premiumEndsAtEpochMs = json.optLong("premiumEndsAt", 0L).takeIf { it > 0 },
                accountEmail = json.optString("email").takeIf { it.isNotBlank() },
                isVerifiedByServer = true,
                statusMessage = json.optString("message"),
            )
        } finally { connection.disconnect() }
    }

    suspend fun verifySubscription(googleIdToken: String, purchaseToken: String, productId: String): AccessState = withContext(Dispatchers.IO) {
        check(isConfigured) { "O servidor Premium ainda não foi configurado." }
        val connection = URL("${baseUrl.trimEnd('/')}/v1/billing/verify").openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 10_000
            connection.readTimeout = 20_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.outputStream.use {
                it.write(JSONObject().put("googleIdToken", googleIdToken).put("purchaseToken", purchaseToken).put("productId", productId).toString().toByteArray())
            }
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
            check(code in 200..299) { runCatching { JSONObject(body).optString("error") }.getOrNull() ?: "A assinatura não foi validada." }
            val json = JSONObject(body)
            AccessState(
                tier = if (json.optString("tier") == "PREMIUM") ProductTier.PREMIUM else ProductTier.LITE,
                trialEndsAtEpochMs = json.optLong("trialEndsAt", 0L),
                premiumEndsAtEpochMs = json.optLong("premiumEndsAt", 0L).takeIf { it > 0 },
                accountEmail = json.optString("email").takeIf { it.isNotBlank() },
                isVerifiedByServer = true,
                statusMessage = json.optString("message"),
            )
        } finally { connection.disconnect() }
    }
}
