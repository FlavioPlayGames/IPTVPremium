package com.example.animeverso.game

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class WinnerRecord(val name: String, val avatar: String, val score: Int, val time: Long)

class WinnerHistoryRepository(context: Context) {
    private val prefs = context.getSharedPreferences("quest_winner_history_reconstructed", Context.MODE_PRIVATE)
    fun records(): List<WinnerRecord> = runCatching {
        val a = JSONArray(prefs.getString("records", "[]"))
        (0 until a.length()).map { a.getJSONObject(it) }.map { WinnerRecord(it.getString("name"), it.getString("avatar"), it.getInt("score"), it.getLong("time")) }
    }.getOrDefault(emptyList())
    fun add(player: Player) {
        val records = (listOf(WinnerRecord(player.name, player.avatar, player.score, System.currentTimeMillis())) + records()).take(50)
        val a = JSONArray()
        records.forEach { a.put(JSONObject().put("name", it.name).put("avatar", it.avatar).put("score", it.score).put("time", it.time)) }
        prefs.edit().putString("records", a.toString()).apply()
    }
}
