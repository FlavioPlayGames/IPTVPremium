package com.example.animeverso.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import com.example.animeverso.ui.QuestText as Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.animeverso.R
import com.example.animeverso.game.*

private val QInk = Color(0xFF090A1C)
private val QPanel = Color(0xEE14152E)
private val QCyan = Color(0xFF50DAF0)
private val QPink = Color(0xFFFF43CB)
private val QGold = Color(0xFFFFD46C)
private val edge = Brush.linearGradient(listOf(QCyan, QPink, QGold))

/** Native text paths, not a screenshot: scales cleanly at any display density. */
@Composable
fun AppBrandLogo(modifier: Modifier = Modifier) {
    Canvas(modifier.semantics { contentDescription = "ANIMES QUEST" }) {
        val c = drawContext.canvas.nativeCanvas
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD_ITALIC)
            textSize = 100f
        }
        val words = listOf("ANIMES", "QUEST")
        val width = words.sumOf { paint.measureText(it).toDouble() }.toFloat() + 12f
        val scale = minOf(size.width / (width + 32f), size.height / 132f)
        c.save(); c.translate((size.width - width * scale)/2f, (size.height - 132f * scale)/2f); c.scale(scale, scale)
        var x = 0f
        words.forEachIndexed { i, word ->
            val color = if(i == 0) 0xFFFF6AB8.toInt() else 0xFF36DAFF.toInt()
            val fill = if(i == 0) intArrayOf(0xFFFFF17D.toInt(), 0xFFFF735F.toInt()) else intArrayOf(0xFF8AF3FF.toInt(), 0xFF31A3E9.toInt())
            paint.shader = null; paint.style = Paint.Style.STROKE; paint.strokeJoin = Paint.Join.ROUND
            for ((stroke, alpha) in listOf(28f to 24, 20f to 45, 12f to 255)) {
                paint.strokeWidth = stroke; paint.color = color; paint.alpha = alpha; c.drawText(word, x, 105f, paint)
            }
            paint.alpha = 255; paint.strokeWidth = 8f; paint.color = 0xFF101020.toInt(); c.drawText(word, x, 105f, paint)
            paint.strokeWidth = 2f; paint.color = 0xFFE9F4F8.toInt(); c.drawText(word, x, 105f, paint)
            paint.style = Paint.Style.FILL
            paint.shader = android.graphics.LinearGradient(0f, 25f, 0f, 110f, fill, null, android.graphics.Shader.TileMode.CLAMP)
            c.drawText(word, x, 105f, paint); x += paint.measureText(word) + 12f
        }
        c.restore()
    }
}

@Composable
internal fun QuestBackground() {
    Box(Modifier.fillMaxSize()) {
        Image(painterResource(R.drawable.animes_quest_background), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop, alpha = 0.19f)
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(QInk.copy(alpha=.55f), QInk.copy(alpha=.2f), QInk.copy(alpha=.75f)))))
        Canvas(Modifier.fillMaxSize()) {
            drawLine(QCyan.copy(alpha=.3f), androidx.compose.ui.geometry.Offset.Zero, androidx.compose.ui.geometry.Offset(size.width, size.height), 1.5.dp.toPx())
            drawLine(QPink.copy(alpha=.25f), androidx.compose.ui.geometry.Offset(size.width, 0f), androidx.compose.ui.geometry.Offset(0f, size.height), 1.5.dp.toPx())
        }
    }
}

@Composable
internal fun IntroScreen(
    access: AccessState, soundOn: Boolean, onSound: () -> Unit,
    selectedLanguage: HomeLanguage, onLanguageSelected: (HomeLanguage) -> Unit,
    onStart: () -> Unit, onRules: () -> Unit, onAbilities: () -> Unit,
    onRanking: () -> Unit, onVoice: () -> Unit, onAccess: () -> Unit,
) {
    Column(Modifier.fillMaxWidth().background(QInk), horizontalAlignment = Alignment.CenterHorizontally) {
        Spacer(Modifier.height(16.dp))
        AppBrandLogo(Modifier.fillMaxWidth().padding(horizontal = 14.dp).aspectRatio(4.1f))
        Box(Modifier.fillMaxWidth(.56f).height(1.dp).background(QGold.copy(alpha=.7f)))
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val artHeight = maxWidth * 1.56f
            Image(painterResource(R.drawable.home_animes_quest_art_v2), null, Modifier.fillMaxWidth().height(artHeight), contentScale = ContentScale.Crop)
            // The recovered PNG already contains JOGAR. Do not draw a second label.
            Image(painterResource(if(selectedLanguage == HomeLanguage.PORTUGUESE_BRAZIL || selectedLanguage == HomeLanguage.PORTUGUESE_PORTUGAL) R.drawable.home_button_play else selectedLanguage.buttonResource(HomeButtonType.PLAY)),
                contentDescription = selectedLanguage.accessibilityName + ": Jogar",
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth(.9f).height(maxWidth * .36f).clickable(role = Role.Button, onClick = onStart), contentScale = ContentScale.Fit)
            TextButton(onClick = onSound, modifier = Modifier.align(Alignment.TopEnd).padding(4.dp)) { Text(if(soundOn) "🔊" else "🔇", color = Color.White) }
        }
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            HomeSmallButton(HomeButtonType.RULES, selectedLanguage, onRules, Modifier.weight(1f).height(70.dp))
            HomeSmallButton(HomeButtonType.ABILITIES, selectedLanguage, onAbilities, Modifier.weight(1f).height(70.dp))
            HomeSmallButton(HomeButtonType.RANKING, selectedLanguage, onRanking, Modifier.weight(1f).height(70.dp))
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.Top) {
            val remaining = ((maxOf(access.premiumEndsAtEpochMs ?: 0L, access.trialEndsAtEpochMs) - System.currentTimeMillis()).coerceAtLeast(0) / 60_000)
            Box(Modifier.weight(1f).border(1.dp, edge, CircleShape).clickable(role = Role.Button, onClick = onAccess).padding(horizontal = 10.dp, vertical = 17.dp), contentAlignment = Alignment.Center) {
                Text(if(access.isPremium) "PREMIUM · ${remaining / 60}h ${remaining % 60}min" else "LITE · Conta", color = QGold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
            Box(Modifier.weight(1.25f)) { LanguageSelector(selectedLanguage, onLanguageSelected) }
        }
        TextButton(onClick = onVoice) { Text("CONFIGURAR NARRAÇÃO", color = QCyan, fontSize = 11.sp) }
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
private fun HomeSmallButton(type: HomeButtonType, language: HomeLanguage, onClick: () -> Unit, modifier: Modifier) {
    val index = when(type) { HomeButtonType.RULES -> 0; HomeButtonType.ABILITIES -> 1; else -> 2 }
    val labels = when(language) {
        HomeLanguage.PORTUGUESE_BRAZIL, HomeLanguage.PORTUGUESE_PORTUGAL -> listOf("REGRAS", "HABILIDADES", "RANKING")
        HomeLanguage.ENGLISH_US, HomeLanguage.ENGLISH_UK -> listOf("RULES", "ABILITIES", "RANKING")
        HomeLanguage.FRENCH -> listOf("RÈGLES", "POUVOIRS", "CLASSEMENT")
        HomeLanguage.GERMAN -> listOf("REGELN", "FÄHIGKEITEN", "RANGLISTE")
        HomeLanguage.SPANISH -> listOf("REGLAS", "HABILIDADES", "RANKING")
        HomeLanguage.ITALIAN -> listOf("REGOLE", "ABILITÀ", "CLASSIFICA")
    }
    Box(modifier.clickable(role = Role.Button, onClick = onClick), contentAlignment = Alignment.Center) {
        Image(painterResource(R.drawable.home_button_small_base), labels[index], Modifier.fillMaxSize(), contentScale = ContentScale.FillBounds)
        Text(labels[index], color = Color.Black, fontWeight = FontWeight.Black, fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, fontSize = 12.sp)
    }
}

internal val questAvatars = listOf(
    R.drawable.avatar_male_01, R.drawable.avatar_female_01, R.drawable.avatar_male_02, R.drawable.avatar_female_02,
    R.drawable.avatar_male_03, R.drawable.avatar_female_03, R.drawable.avatar_male_04, R.drawable.avatar_female_04,
    R.drawable.avatar_male_05, R.drawable.avatar_female_05, R.drawable.avatar_male_06, R.drawable.avatar_female_06,
    R.drawable.avatar_male_07, R.drawable.avatar_female_07, R.drawable.avatar_male_08, R.drawable.avatar_female_08,
    R.drawable.avatar_male_09, R.drawable.avatar_female_09, R.drawable.avatar_male_10, R.drawable.avatar_female_10,
    R.drawable.avatar_male_11, R.drawable.avatar_female_11,
)

@Composable
internal fun AvatarArt(avatar: String, modifier: Modifier = Modifier) {
    Image(painterResource(questAvatars[(avatar.toIntOrNull() ?: 0).coerceIn(questAvatars.indices)]), "Avatar", modifier.clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
}

@Composable
private fun NeonPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().border(1.dp, edge, RoundedCornerShape(20.dp)).background(QPanel, RoundedCornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
}

@Composable
private fun BattleButton(label: String, onClick: () -> Unit) {
    Button(onClick, Modifier.fillMaxWidth().heightIn(min = 50.dp).border(1.5.dp, edge, RoundedCornerShape(14.dp)), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFED1751)), shape = RoundedCornerShape(14.dp)) {
        Text(label, fontWeight = FontWeight.Black, color = Color.White, fontSize = 16.sp)
    }
}

@Composable
internal fun QuestSetup(vm: GameViewModel, onStart: () -> Unit) {
    val state = vm.ui
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("SELECIONE SEU PERSONAGEM", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
        Text("ESCOLHA UM AVATAR PARA CADA JOGADOR", color = QCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        NeonPanel {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("TAMANHO DA EQUIPE", color = QGold, fontWeight = FontWeight.Bold)
                Text("${state.playerCount} JOGADORES", color = Color.White, fontSize = 12.sp)
            }
            Slider(state.playerCount.toFloat(), { vm.setPlayerCount(kotlin.math.round(it).toInt()) }, valueRange = 2f..8f, steps = 5, colors = SliderDefaults.colors(thumbColor = QGold, activeTrackColor = QPink, inactiveTrackColor = QCyan.copy(alpha=.4f)))
            repeat(state.playerCount) { i ->
                Column(Modifier.fillMaxWidth().border(1.dp, edge, RoundedCornerShape(18.dp)).padding(9.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        AvatarArt(state.avatars[i], Modifier.size(46.dp))
                        Text("JOGADOR ${i+1}", color = if(i % 2 == 0) QCyan else QPink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    }
                    OutlinedTextField(state.playerNames[i], { vm.setPlayerName(i, it) }, Modifier.fillMaxWidth(), label = { Text("Nome do jogador") }, singleLine = true, shape = RoundedCornerShape(15.dp), colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, unfocusedBorderColor = QCyan.copy(alpha=.5f), focusedBorderColor = QGold))
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                        vm.availableAvatarIndices().forEach { a ->
                            AvatarArt(a.toString(), Modifier.size(52.dp).border(if(state.avatars[i] == a.toString()) 2.dp else 0.dp, if(state.avatars[i] == a.toString()) QGold else Color.Transparent, RoundedCornerShape(12.dp)).clickable(role = Role.RadioButton) { vm.selectAvatar(i, a) })
                        }
                    }
                }
            }
        }
        BattleButton("⚡ COMEÇAR A BATALHA ⚡", onStart)
        OutlinedButton(vm::openRules, Modifier.fillMaxWidth()) { Text("← VOLTAR ÀS REGRAS", color = Color.White) }
    }
}

@Composable
private fun AbilityRow(item: GameItem, enabled: Boolean, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).clickable(enabled = enabled, role = Role.Button, onClick = onClick).background(QPanel.copy(alpha=.7f)).padding(9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Image(painterResource(item.art), null, Modifier.size(48.dp).clip(CircleShape), contentScale = ContentScale.Crop, alpha = if(enabled) 1f else .4f)
        Column(Modifier.weight(1f)) {
            Text(item.label, color = if(enabled) Color.White else Color.Gray, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(item.description, color = QCyan, fontSize = 11.sp)
        }
        Text(if(enabled) "+" else "✓", color = QGold, fontSize = 28.sp)
    }
}

@Composable
internal fun QuestPreparation(vm: GameViewModel) {
    val s = vm.ui; val p = s.players.getOrNull(s.currentPlayerIndex) ?: return
    var selectedTrap by remember(s.handoffSerial) { mutableStateOf<GameItem?>(null) }
    var notice by remember(s.handoffSerial) { mutableStateOf("") }
    Spacer(Modifier.height(24.dp))
    NeonPanel {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            AvatarArt(p.avatar, Modifier.size(86.dp))
            Text("TELA DE PREPARAÇÃO", color = QCyan, fontSize = 18.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp)
            Text(if(s.handoffIsFirst) "PRIMEIRO DESAFIO" else "RODADA ${s.round}", color = QGold, fontWeight = FontWeight.Bold)
            Text(p.name, color = Color.White, fontWeight = FontWeight.Black, fontSize = 24.sp)
            Text(vm.playerHandoffPhrase(s.currentPlayerIndex), color = Color.LightGray)
            if(p.pendingTrap.isNotBlank()) Text(p.pendingTrap, color = QGold, textAlign = TextAlign.Center)
        }
        Text("ARMADILHAS · escolha um alvo antes da pergunta", color = QPink, fontWeight = FontWeight.Bold, fontSize = 12.sp)
        p.availableTraps.filter { it in vm.availableItems() }.forEach { item -> AbilityRow(item, !s.hasUsedItemThisTurn && !p.blockItems && item !in p.usedItems) { selectedTrap = item } }
        if(notice.isNotBlank()) Text(notice, color = QGold, fontSize = 12.sp)
        Text("Use no máximo uma habilidade neste turno.", color = Color.LightGray, fontSize = 11.sp)
        BattleButton("LET’S GO  ▶", vm::beginQuestion)
    }
    selectedTrap?.let { item ->
        AlertDialog(onDismissRequest = { selectedTrap = null }, containerColor = QPanel, title = { Text("Escolha o alvo", color = QGold) }, text = {
            Column { s.players.forEachIndexed { index, player -> if(index != s.currentPlayerIndex) TextButton(onClick = { notice = vm.useItem(item, index); selectedTrap = null }) { Text(player.name, color = QCyan) } } }
        }, confirmButton = {}, dismissButton = { TextButton({ selectedTrap = null }) { Text("Cancelar") } })
    }
}

@Composable
internal fun QuestGame(vm: GameViewModel) {
    val s = vm.ui; val p = s.players.getOrNull(s.currentPlayerIndex) ?: return
    val feedback = s.screen == AppScreen.FEEDBACK
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            AvatarArt(p.avatar, Modifier.size(44.dp))
            Text("Vez de ${p.name}", color = QGold, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), fontSize = 18.sp)
            TextButton(onClick = vm::repeatNarration, enabled = !feedback) { Text(if(s.isListening) "▶ OUVINDO" else "${s.secondsLeft}s", color = QCyan, fontSize = if(s.isListening) 11.sp else 20.sp, fontWeight = FontWeight.Black) }
        }
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            OutlinedButton(vm::returnHome) { Text("⌂ INÍCIO", color = Color.White) }
            Text("RODADA ${s.round} · ${p.score}/20 PONTOS", color = QGold, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
        if(s.banner.isNotBlank()) Text(s.banner, color = QGold, fontSize = 12.sp)
        NeonPanel {
            Text("🎴 ${s.question?.category.orEmpty()} · PERGUNTA ${s.cardNumber}", color = QCyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(s.question?.text.orEmpty(), color = QGold, fontWeight = FontWeight.Bold, fontSize = 21.sp)
            s.answerOptions.forEachIndexed { index, option ->
                val disabled = feedback || index in s.eliminatedOptions
                val color = when { feedback && index == s.correctOptionIndex -> Color(0xFF237C60); feedback && index == s.selectedOptionIndex -> Color(0xFFAC3155); else -> Color(0xFF262749) }
                Button({ vm.answer(index) }, Modifier.fillMaxWidth().heightIn(min=48.dp), enabled = !disabled, shape = RoundedCornerShape(13.dp), colors = ButtonDefaults.buttonColors(containerColor = color, disabledContainerColor = color.copy(alpha = if(index in s.eliminatedOptions) .25f else 1f), contentColor = Color.White, disabledContentColor = Color.White)) {
                    Text(option, Modifier.fillMaxWidth(), fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
                }
            }
        }
        Text("✦ TÉCNICAS ESPECIAIS", color = QCyan, fontWeight = FontWeight.Black, fontSize = 18.sp)
        p.availableTechniques.filter { it in vm.availableItems() }.forEach { item ->
            AbilityRow(item, !feedback && !s.hasUsedItemThisTurn && p.score < 17 && !p.blockItems && !p.blockTechniques && item !in p.usedItems) { vm.useItem(item) }
        }
        if(p.score >= 17) Text("A partir de 17 pontos, as técnicas ficam bloqueadas.", color = QGold, fontSize = 12.sp)
    }
}

@Composable
internal fun QuestRoundResults(vm: GameViewModel) {
    NeonPanel {
        Text("RESULTADO DA RODADA ${vm.ui.round}", color = QGold, fontSize = 22.sp, fontWeight = FontWeight.Black)
        vm.rankedPlayers().forEachIndexed { i, p ->
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AvatarArt(p.avatar, Modifier.size(50.dp)); Text("${i+1}. ${p.name} · ${p.score} pontos", color = Color.White)
            }
        }
        BattleButton("PRÓXIMA RODADA ▶", vm::startNextRound)
    }
}
