package com.example.animeverso.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.animeverso.game.*
import com.example.animeverso.ui.theme.AnimeVersoTheme

/** These are actual Compose previews of the rebuilt screens, not reference images. */
@Preview(name = "01 · Home recuperada", widthDp = 360, heightDp = 800)
@Composable
private fun HomePreview() = PreviewFrame {
    IntroScreen(AccessState(trialEndsAtEpochMs = System.currentTimeMillis() + 24*60*60*1000), true, {}, HomeLanguage.PORTUGUESE_BRAZIL, {}, {}, {}, {}, {}, {}, {})
}

@Preview(name = "02 · Personagens", widthDp = 360, heightDp = 800)
@Composable
private fun SetupPreview() = PreviewFrame {
    val vm = previewGame()
    QuestSetup(vm) {}
}

@Preview(name = "03 · Preparação", widthDp = 360, heightDp = 800)
@Composable
private fun PreparationPreview() = PreviewFrame {
    val vm = previewGame()
    QuestPreparation(vm)
}

@Preview(name = "04 · Pergunta", widthDp = 360, heightDp = 800)
@Composable
private fun QuestionPreview() = PreviewFrame {
    val vm = previewGame(true)
    QuestGame(vm)
}

@Composable
private fun previewGame(question: Boolean = false): GameViewModel = remember {
    GameViewModel(listOf(QuizQuestion(1, "Death Note", "Que fruta Ryuk costuma comer no mundo humano?", "Maçã", listOf("Laranja", "Pera", "Maçã", "Banana"), false))).apply { startMatch(); if(question) { beginQuestion(); startQuestionTimer() } }
}

@Composable
private fun PreviewFrame(content: @Composable ColumnScope.() -> Unit) {
    AnimeVersoTheme {
        CompositionLocalProvider(LocalQuestLocalization provides remember { QuestLocalization() }) {
            Box(Modifier.fillMaxSize().background(Color(0xFF090A1C))) {
                QuestBackground()
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(8.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
            }
        }
    }
}
