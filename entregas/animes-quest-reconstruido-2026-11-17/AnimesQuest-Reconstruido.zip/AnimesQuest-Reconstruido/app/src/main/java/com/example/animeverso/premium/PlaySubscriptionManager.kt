package com.example.animeverso.premium

import android.app.Activity
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.android.billingclient.api.Purchase
import com.example.animeverso.BuildConfig
import com.example.animeverso.game.AccessState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

/** Play purchases are granted only after PremiumAccessClient verifies the token with the backend. */
class PlaySubscriptionManager(
    private val activity: Activity,
    private val accessClient: PremiumAccessClient,
    private val currentGoogleIdToken: () -> String?,
    private val onAccessVerified: (AccessState) -> Unit,
    private val onMessage: (String) -> Unit,
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val productId = BuildConfig.PREMIUM_SUBSCRIPTION_ID
    private var productDetails: ProductDetails? = null
    private var offerToken: String? = null
    private var connecting = false
    private val billingClient = BillingClient.newBuilder(activity)
        .setListener { result, purchases -> handlePurchases(result, purchases.orEmpty()) }
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()

    fun connectAndLoad() {
        if (!accessClient.isConfigured) { onMessage("Configure o servidor seguro de acesso antes de vender assinaturas."); return }
        if (billingClient.isReady) { loadProductAndExistingPurchases(); return }
        if (connecting) return
        connecting = true
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) {
                connecting = false
                if (result.responseCode != BillingClient.BillingResponseCode.OK) { onMessage("Google Play indisponível: ${result.debugMessage}"); return }
                loadProductAndExistingPurchases()
            }
            override fun onBillingServiceDisconnected() { connecting = false; onMessage("Conexão com Google Play interrompida. Tente novamente.") }
        })
    }

    private fun loadProductAndExistingPurchases() {
        val product = QueryProductDetailsParams.Product.newBuilder().setProductId(productId).setProductType(BillingClient.ProductType.SUBS).build()
        billingClient.queryProductDetailsAsync(QueryProductDetailsParams.newBuilder().setProductList(listOf(product)).build()) { queryResult, response ->
            productDetails = response.productDetailsList.firstOrNull()
            offerToken = productDetails?.subscriptionOfferDetails?.firstOrNull()?.offerToken
            if (queryResult.responseCode != BillingClient.BillingResponseCode.OK || productDetails == null || offerToken == null) {
                onMessage("Plano mensal indisponível. Confira o produto e a oferta-base no Play Console.")
            }
        }
        val purchasesQuery = QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build()
        billingClient.queryPurchasesAsync(purchasesQuery) { purchasesResult, purchases -> handlePurchases(purchasesResult, purchases) }
    }

    fun launchMonthlyPurchase() {
        val token = currentGoogleIdToken()
        val details = productDetails
        val offer = offerToken
        if (token.isNullOrBlank()) { onMessage("Entre com sua conta Google antes de assinar."); return }
        if (details == null || offer == null || !billingClient.isReady) { connectAndLoad(); onMessage("Carregando o plano mensal do Google Play."); return }
        val params = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(details).setOfferToken(offer).build()
        val result = billingClient.launchBillingFlow(activity, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(params)).build())
        if (result.responseCode != BillingClient.BillingResponseCode.OK) onMessage("Não foi possível abrir a compra: ${result.debugMessage}")
    }

    private fun handlePurchases(result: BillingResult, purchases: List<Purchase>) {
        if (result.responseCode != BillingClient.BillingResponseCode.OK) { onMessage("Compra não concluída: ${result.debugMessage}"); return }
        purchases.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED && productId in it.products }.forEach { purchase ->
            val idToken = currentGoogleIdToken()
            if (idToken.isNullOrBlank()) { onMessage("Entre novamente na conta Google para validar a compra."); return@forEach }
            scope.launch {
                runCatching { accessClient.verifySubscription(idToken, purchase.purchaseToken, productId) }
                    .onSuccess { access ->
                        onAccessVerified(access)
                        if (!purchase.isAcknowledged) {
                            billingClient.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()) { ack ->
                                if (ack.responseCode != BillingClient.BillingResponseCode.OK) onMessage("Acesso validado; o Google Play ainda está confirmando a compra.")
                            }
                        }
                    }
                    .onFailure { onMessage("O servidor não validou a assinatura: ${it.message ?: "tente novamente"}") }
            }
        }
    }

    fun close() { scope.coroutineContext[kotlinx.coroutines.Job]?.cancel(); if (billingClient.isReady) billingClient.endConnection() }
}
