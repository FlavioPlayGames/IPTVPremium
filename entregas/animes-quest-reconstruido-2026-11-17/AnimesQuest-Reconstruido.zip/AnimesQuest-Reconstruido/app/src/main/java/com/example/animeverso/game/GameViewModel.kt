package com.example.animeverso.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel

/** Reconstructed from observable rules and labels in the supplied advanced APK. */
class GameViewModel(private val questions: List<QuizQuestion>, private val history: WinnerHistoryRepository? = null) : ViewModel() {
    var ui by mutableStateOf(GameUiState())
        private set
    private var regularDeck = mutableListOf<QuizQuestion>()
    private var advancedDeck = mutableListOf<QuizQuestion>()
    private var completedRanking = emptyList<Player>()
    private val liteTech = setOf(GameItem.SENZU, GameItem.SHARINGAN, GameItem.BARRIER, GameItem.VORTEX)
    private val liteTraps = setOf(GameItem.CLONE, GameItem.SEAL, GameItem.EMBER)
    private val phrases = listOf("Bora com tudo!", "Mostra teu poder!", "Confia no instinto!", "Hora de brilhar!", "Ativa o modo herói!", "Pensa rápido e vai!", "Foco total, campeão!", "Manda bem nessa!")
    fun setAccessState(access: AccessState) { regularDeck.clear(); advancedDeck.clear(); ui = ui.copy(access = access) }
    fun expireTrialIfNeeded(nowEpochMs: Long) {
        val end = maxOf(ui.access.premiumEndsAtEpochMs ?: 0L, ui.access.trialEndsAtEpochMs)
        if (ui.access.isPremium && end > 0 && nowEpochMs >= end) setAccessState(ui.access.copy(tier = ProductTier.LITE, statusMessage = "A experiência Premium terminou. A partida continua no modo Lite."))
    }
    fun availableQuestions() = if (ui.access.isPremium) questions else questions.take(500)
    fun availableItems() = GameItem.entries.filter { ui.access.isPremium || it in liteTech || it in liteTraps }
    fun isItemAvailableInLite(item: GameItem) = item in liteTech || item in liteTraps
    fun availableAvatarIndices() = if (ui.access.isPremium) (0..21).toList() else listOf(0, 1, 4, 5, 8, 9, 12, 13, 18, 19, 20)
    fun setPlayerCount(count: Int) { val n = count.coerceIn(2, 8); ui = ui.copy(playerCount = n, playerNames = (0 until n).map { ui.playerNames.getOrNull(it) ?: "Competidor ${it + 1}" }) }
    fun setPlayerName(index: Int, name: String) { if(index in 0 until ui.playerCount) ui = ui.copy(playerNames = ui.playerNames.toMutableList().also { it[index] = name.take(24) }) }
    fun selectAvatar(index: Int, avatar: Int) { if(index in 0 until ui.playerCount && avatar in availableAvatarIndices()) ui = ui.copy(avatars = ui.avatars.toMutableList().also { it[index] = avatar.toString() }) }
    fun rotateAvatar(index: Int) { val choices = availableAvatarIndices(); selectAvatar(index, choices[(choices.indexOf(ui.avatars[index].toIntOrNull() ?: 0) + 1) % choices.size]) }
    fun openRules() { ui = ui.copy(screen = AppScreen.RULES) }
    fun openSetup() { ui = ui.copy(screen = AppScreen.SETUP) }
    fun startMatch() {
        regularDeck.clear(); advancedDeck.clear()
        val tech = availableItems().filterNot { it.isTrap }; val traps = availableItems().filter { it.isTrap }
        val players = (0 until ui.playerCount).map { i -> Player(ui.playerNames[i].trim().ifBlank { "Competidor ${i+1}" }, ui.avatars[i], i, availableTechniques = tech.shuffled().take(3).toSet(), availableTraps = traps.shuffled().take(3).toSet()) }
        ui = ui.copy(players = players, round = 1, cardNumber = 0, currentPlayerIndex = 0, winnerName = null, isPaused = false)
        prepare(0)
    }
    private fun prepare(index: Int) { ui = ui.copy(screen = AppScreen.HANDOFF, currentPlayerIndex = index, handoffIsFirst = ui.round == 1, handoffSerial = ui.handoffSerial + 1, hasUsedItemThisTurn = false, selectedOptionIndex = -1, banner = "") }
    fun handoffSpeech() = "${if(ui.handoffIsFirst) "Primeiro desafio" else "Sua vez"}, ${ui.players.getOrNull(ui.currentPlayerIndex)?.name.orEmpty()}! ${playerHandoffPhrase(ui.currentPlayerIndex)}"
    fun playerHandoffPhrase(index: Int) = phrases[(index + ui.round - 1) % phrases.size]
    // Preparation is manual, as in the reference; it never advances behind the user's back.
    fun tickHandoff() = Unit
    fun beginQuestion() {
        if(ui.screen != AppScreen.HANDOFF || ui.isPaused) return
        val p = ui.players[ui.currentPlayerIndex]; val q = drawQuestion(p.forceAdvanced || p.score >= 17)
        val seconds = (if(p.shortTimer) 15 else 30) - p.timerPenalty
        val notice = p.pendingTrap
        updatePlayer(ui.currentPlayerIndex, p.copy(shortTimer = false, timerPenalty = 0, forceAdvanced = false, pendingTrap = ""))
        ui = ui.copy(screen = AppScreen.GAME, isListening = true, question = q, answerOptions = q.options.shuffled(), secondsLeft = seconds.coerceAtLeast(5), questionSerial = ui.questionSerial + 1, cardNumber = ui.cardNumber + 1, eliminatedOptions = emptySet(), correctOptionIndex = -1, banner = notice)
        ui = ui.copy(correctOptionIndex = ui.answerOptions.indexOf(q.answer))
    }
    private fun drawQuestion(advanced: Boolean): QuizQuestion {
        val pool = availableQuestions(); require(pool.isNotEmpty()) { "Banco de perguntas vazio" }
        val deck = if(advanced) advancedDeck else regularDeck
        if(deck.isEmpty()) deck.addAll(pool.filter { it.advanced == advanced }.ifEmpty { pool }.shuffled())
        return deck.removeAt(deck.lastIndex)
    }
    fun startQuestionTimer() { if(ui.screen == AppScreen.GAME) ui = ui.copy(isListening = false) }
    fun repeatNarration() { if(ui.screen == AppScreen.GAME) ui = ui.copy(isListening = true, questionSerial = ui.questionSerial + 1) }
    fun tickQuestion() { if(ui.screen != AppScreen.GAME || ui.isPaused || ui.isListening) return; if(ui.secondsLeft <= 1) answer(-1, true) else ui = ui.copy(secondsLeft = ui.secondsLeft - 1) }
    fun answer(optionIndex: Int, timeout: Boolean = false) {
        if(ui.screen != AppScreen.GAME || ui.isPaused) return
        val p = ui.players[ui.currentPlayerIndex]; val correct = !timeout && optionIndex == ui.correctOptionIndex
        if(!correct && !timeout && p.retry) { updatePlayer(ui.currentPlayerIndex, p.copy(retry = false)); ui = ui.copy(eliminatedOptions = ui.eliminatedOptions + optionIndex, banner = "Eco Espectral! Tente outra alternativa."); return }
        val points = if(correct && !p.noPoints) (if(ui.secondsLeft >= 21) 3 else if(ui.secondsLeft >= 11) 2 else 1) + p.bonus else 0
        val score = if(correct) p.score + points else (p.score - if(p.protectedErrors > 0) 0 else 1).coerceAtLeast(0)
        val updated = p.copy(score = score, position = score, protectedErrors = (p.protectedErrors - if(correct) 0 else 1).coerceAtLeast(0), noPoints = if(correct) false else p.noPoints, bonus = 0, retry = false, blockItems = false, blockTechniques = false, finalChallenge = score >= 17)
        updatePlayer(ui.currentPlayerIndex, updated)
        val text = if(correct) if(p.noPoints) "Cristal de Estase: acerto sem pontos." else "Resposta certa! +$points ponto(s)." else if(timeout) "Tempo esgotado." else "Resposta errada."
        ui = ui.copy(screen = AppScreen.FEEDBACK, selectedOptionIndex = optionIndex, answerWasCorrect = correct, timedOut = timeout, feedbackSerial = ui.feedbackSerial + 1, feedbackText = text, feedbackSpeech = "${p.name}, $text", banner = text, winnerName = if(score >= 20) p.name else null)
    }
    fun finishFeedback() {
        if(ui.screen != AppScreen.FEEDBACK || ui.isPaused) return
        if(ui.winnerName != null) { ui.players.firstOrNull { it.name == ui.winnerName }?.let { history?.add(it) }; completedRanking = rankedPlayers(); ui = ui.copy(screen = AppScreen.FINISHED); return }
        if(ui.currentPlayerIndex == ui.players.lastIndex) ui = ui.copy(screen = AppScreen.ROUND_RESULTS) else prepare(ui.currentPlayerIndex + 1)
    }
    fun startNextRound() { if(ui.screen == AppScreen.ROUND_RESULTS) { ui = ui.copy(round = ui.round + 1); prepare(0) } }
    private fun updatePlayer(index: Int, player: Player) { ui = ui.copy(players = ui.players.toMutableList().also { it[index] = player }) }
    fun useItem(item: GameItem, targetIndex: Int? = null): String {
        if(ui.isPaused || ui.hasUsedItemThisTurn) return "Use apenas uma técnica ou armadilha por turno."
        val preparation = ui.screen == AppScreen.HANDOFF
        if(item.isTrap != preparation || ui.screen !in setOf(AppScreen.HANDOFF, AppScreen.GAME)) return "Armadilhas são usadas na preparação; técnicas, durante a pergunta."
        var p = ui.players[ui.currentPlayerIndex]
        if(item !in availableItems() || item !in (if(preparation) p.availableTraps else p.availableTechniques) || item in p.usedItems || p.blockItems || (!preparation && p.blockTechniques) || (!preparation && p.score >= 17)) return "Esta habilidade está bloqueada ou já foi usada."
        var message = item.label + " ativado."
        if(preparation) {
            val index = targetIndex ?: return "Escolha um adversário."
            if(index !in ui.players.indices || index == ui.currentPlayerIndex) return "Escolha um adversário diferente de você."
            var t = ui.players[index]
            if(t.shield) { t = t.copy(shield = false); message = "O Campo de Égide bloqueou a armadilha." }
            else {
                when(item) {
                    GameItem.CLONE -> t = t.copy(shortTimer = true)
                    GameItem.SEAL -> t = t.copy(blockItems = true)
                    GameItem.SIPHON -> t = t.copy(blockTechniques = true)
                    GameItem.EMBER -> t = t.copy(timerPenalty = t.timerPenalty + 10)
                    GameItem.MIRROR -> t = t.copy(forceAdvanced = true)
                    GameItem.STASIS -> t = t.copy(noPoints = true)
                    GameItem.DRAIN, GameItem.VOID, GameItem.ARC -> {
                        val amount = minOf(t.score, if(item == GameItem.VOID) 2 else 3)
                        t = t.copy(score = t.score - amount, position = t.score - amount)
                        if(item == GameItem.ARC) {
                            val receiver = ui.players.indices.filter { it != index }.random()
                            if(receiver == ui.currentPlayerIndex) p = p.copy(score = p.score + amount, position = p.score + amount)
                            else { val r = ui.players[receiver]; updatePlayer(receiver, r.copy(score = r.score + amount, position = r.score + amount)) }
                        } else p = p.copy(score = p.score + amount, position = p.score + amount)
                    }
                    else -> Unit
                }
                t = t.copy(pendingTrap = "${p.name}: ${item.label}. ${item.description}")
            }
            updatePlayer(index, t)
        } else {
            when(item) {
                GameItem.SENZU -> ui = ui.copy(secondsLeft = ui.secondsLeft + 10)
                GameItem.WAVE -> ui = ui.copy(secondsLeft = ui.secondsLeft + 8)
                GameItem.OVERDRIVE -> { ui = ui.copy(secondsLeft = ui.secondsLeft + 5); p = p.copy(protectedErrors = p.protectedErrors + 1) }
                GameItem.SHARINGAN, GameItem.INSTINCT -> { val n = if(item == GameItem.SHARINGAN) 2 else 3; ui = ui.copy(eliminatedOptions = ui.eliminatedOptions + ui.answerOptions.indices.filter { it != ui.correctOptionIndex && it !in ui.eliminatedOptions }.shuffled().take(n)) }
                GameItem.BARRIER -> p = p.copy(shield = true)
                GameItem.VORTEX -> p = p.copy(bonus = 2)
                GameItem.ARMOR -> p = p.copy(protectedErrors = p.protectedErrors + 2)
                GameItem.DECOY -> p = p.copy(retry = true)
                GameItem.MIRAGE -> { val q = drawQuestion(p.score >= 17); val options = q.options.shuffled(); ui = ui.copy(question = q, answerOptions = options, correctOptionIndex = options.indexOf(q.answer), eliminatedOptions = emptySet(), questionSerial = ui.questionSerial + 1) }
                else -> Unit
            }
        }
        updatePlayer(ui.currentPlayerIndex, p.copy(usedItems = p.usedItems + item))
        ui = ui.copy(hasUsedItemThisTurn = true, banner = message)
        return message
    }
    fun winnerRecords() = history?.records().orEmpty()
    fun rankedPlayers() = ui.players.ifEmpty { completedRanking }.sortedWith(compareByDescending<Player> { it.score }.thenBy { it.name })
    fun returnHome() { ui = ui.copy(screen = AppScreen.INTRO, isPaused = false) }
    fun toggleSound() { ui = ui.copy(soundEnabled = !ui.soundEnabled) }
    fun pauseMatch() { if(ui.screen in setOf(AppScreen.HANDOFF, AppScreen.GAME, AppScreen.FEEDBACK)) ui = ui.copy(isPaused = true) }
    fun resumeMatch() { ui = ui.copy(isPaused = false) }
}
