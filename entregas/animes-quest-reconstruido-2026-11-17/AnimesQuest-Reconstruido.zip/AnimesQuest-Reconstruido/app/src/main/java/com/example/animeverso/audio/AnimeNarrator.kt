package com.example.animeverso.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors

/** The proxy owns the ElevenLabs key. This app stores only its public HTTPS URL. */
class AnimeNarrator(private val context: Context) : TextToSpeech.OnInitListener {
    private val main = Handler(Looper.getMainLooper())
    private val network = Executors.newSingleThreadExecutor()
    private val tts = TextToSpeech(context, this)
    @Volatile private var ready = false
    @Volatile private var initFinished = false
    private var locale = Locale.forLanguageTag("pt-BR")
    fun setLanguage(tag: String) { locale = Locale.forLanguageTag(tag); if(ready) tts.language = locale }
    @Volatile private var requestId = 0
    private var player: MediaPlayer? = null
    private var pendingLocal: Pending? = null

    private data class Pending(val id: Int, val text: String, val done: () -> Unit)

    override fun onInit(status: Int) {
        initFinished = true
        ready = status == TextToSpeech.SUCCESS
        if(!ready) main.post { pendingLocal?.let { complete(it.id, it.done) } }
        if (ready) {
            tts.language = locale
            tts.setSpeechRate(1.04f)
            tts.setPitch(1.02f)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) = Unit
                override fun onDone(utteranceId: String?) { utteranceId?.toIntOrNull()?.let { id -> main.post { complete(id, pendingLocal?.takeIf { it.id == id }?.done) } } }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { utteranceId?.toIntOrNull()?.let { id -> main.post { complete(id, pendingLocal?.takeIf { it.id == id }?.done) } } }
            })
            main.post { pendingLocal?.let { speakLocal(it) } }
        }
    }

    fun speak(text: String, endpoint: String, done: () -> Unit = {}) {
        stop()
        val id = requestId
        val url = endpoint.trim()
        if (!url.startsWith("https://", ignoreCase = true)) {
            speakLocal(Pending(id, text, done))
            return
        }
        network.execute {
            val audio = runCatching { requestSpeech(url, text) }.getOrNull()
            main.post {
                if (id != requestId) return@post
                if (audio == null) speakLocal(Pending(id, text, done)) else playRemote(id, audio, text, done)
            }
        }
    }

    private fun requestSpeech(endpoint: String, text: String): ByteArray? {
        val connection = URL(endpoint).openConnection() as HttpURLConnection
        return try {
            connection.requestMethod = "POST"
            connection.connectTimeout = 8_000
            connection.readTimeout = 20_000
            connection.doOutput = true
            connection.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            connection.setRequestProperty("Accept", "audio/mpeg")
            connection.setRequestProperty("Origin", "https://appassets.androidplatform.net")
            val payload = JSONObject().put("text", text).toString().toByteArray(Charsets.UTF_8)
            connection.outputStream.use { it.write(payload) }
            if (connection.responseCode != HttpURLConnection.HTTP_OK) return null
            connection.inputStream.use { stream ->
                val bytes = stream.readBytes()
                bytes.takeIf { it.isNotEmpty() && it.size <= 2 * 1024 * 1024 }
            }
        } finally { connection.disconnect() }
    }

    private fun speakLocal(pending: Pending) {
        if (pending.id != requestId) return
        if (!ready) { if(initFinished) complete(pending.id, pending.done) else pendingLocal = pending; return }
        pendingLocal = pending
        val params = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 0.9f) }
        if(tts.speak(pending.text, TextToSpeech.QUEUE_FLUSH, params, pending.id.toString()) == TextToSpeech.ERROR) complete(pending.id, pending.done)
    }

    private fun playRemote(id: Int, bytes: ByteArray, fallback: String, done: () -> Unit) {
        val file = runCatching {
            File.createTempFile("animeverso-voice-", ".mp3", context.cacheDir).apply { writeBytes(bytes) }
        }.getOrNull()
        if (file == null) { speakLocal(Pending(id, fallback, done)); return }
        pendingLocal = Pending(id, fallback, done)
        val media = MediaPlayer()
        player = media
        media.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
        runCatching { media.setDataSource(file.absolutePath) }.onFailure {
            file.delete()
            media.release()
            player = null
            speakLocal(Pending(id, fallback, done))
            return
        }
        media.setOnPreparedListener { if (id == requestId) it.start() }
        media.setOnCompletionListener { file.delete(); it.release(); if(player === it) player = null; complete(id, done) }
        media.setOnErrorListener { failed, _, _ -> file.delete(); failed.release(); player = null; speakLocal(Pending(id, fallback, done)); true }
        media.prepareAsync()
    }

    private fun complete(id: Int, done: (() -> Unit)?) {
        if (id != requestId) return
        pendingLocal = null
        done?.invoke()
    }

    fun stop() {
        requestId += 1
        pendingLocal = null
        val stopPlayback: () -> Unit = {
            runCatching { player?.stop() }
            player?.release()
            player = null
            runCatching { tts.stop() }
            Unit
        }
        if (Looper.myLooper() == main.looper) stopPlayback() else main.post(stopPlayback)
    }

    fun close() {
        stop()
        network.shutdownNow()
        main.post { tts.shutdown() }
    }
}
