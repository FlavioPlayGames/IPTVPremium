package com.example.animeverso.game

import org.junit.Assert.*
import org.junit.Test

class GameViewModelTest {
    private val questions = listOf(
        QuizQuestion(1, "Naruto", "Pergunta comum?", "Resposta", listOf("Resposta", "A", "B", "C"), false),
        QuizQuestion(2, "Anime", "Pergunta avançada?", "Avançada", listOf("Avançada", "A", "B", "C"), true),
    )
    private fun game() = GameViewModel(questions).apply { setPlayerCount(2); startMatch() }
    private fun correct(g: GameViewModel) { g.beginQuestion(); g.startQuestionTimer(); g.answer(g.ui.correctOptionIndex); g.finishFeedback() }

    @Test fun preparationRequiresExplicitStart() {
        val g = game(); repeat(60) { g.tickHandoff() }
        assertEquals(AppScreen.HANDOFF, g.ui.screen)
        g.beginQuestion(); g.startQuestionTimer(); assertEquals(AppScreen.GAME, g.ui.screen)
    }
    @Test fun narrationDoesNotConsumeQuestionTime() {
        val g = game(); g.beginQuestion(); repeat(15) { g.tickQuestion() }
        assertEquals(30, g.ui.secondsLeft)
        g.startQuestionTimer(); g.tickQuestion(); assertEquals(29, g.ui.secondsLeft)
    }
    @Test fun scoreBoundariesAreThreeTwoAndOne() {
        for((elapsed, expected) in listOf(0 to 3, 9 to 3, 10 to 2, 19 to 2, 20 to 1)) {
            val g = game(); g.beginQuestion(); g.startQuestionTimer(); repeat(elapsed) { g.tickQuestion() }; g.answer(g.ui.correctOptionIndex)
            assertEquals("elapsed=$elapsed", expected, g.ui.players[0].score)
        }
    }
    @Test fun timeoutDoesNotMakeScoreNegative() {
        val g = game(); g.beginQuestion(); g.startQuestionTimer(); repeat(30) { g.tickQuestion() }
        assertEquals(0, g.ui.players[0].score); assertTrue(g.ui.timedOut)
    }
    @Test fun aRoundWaitsForEveryPlayerAndForContinue() {
        val g = game(); correct(g)
        assertEquals(1, g.ui.currentPlayerIndex); assertEquals(AppScreen.HANDOFF, g.ui.screen)
        correct(g); assertEquals(AppScreen.ROUND_RESULTS, g.ui.screen)
        g.startNextRound(); assertEquals(2, g.ui.round); assertEquals(0, g.ui.currentPlayerIndex)
    }
    @Test fun pausedQuestionAndPreparationDoNotAdvance() {
        val g = game(); g.pauseMatch(); g.beginQuestion(); g.startQuestionTimer(); assertEquals(AppScreen.HANDOFF, g.ui.screen)
        g.resumeMatch(); g.beginQuestion(); g.startQuestionTimer(); g.pauseMatch(); repeat(20) { g.tickQuestion() }
        assertEquals(30, g.ui.secondsLeft)
    }
    @Test fun invalidTargetDoesNotConsumeTrap() {
        val g = game(); val trap = g.ui.players[0].availableTraps.first()
        g.useItem(trap, 0); assertFalse(g.ui.hasUsedItemThisTurn)
        assertFalse(trap in g.ui.players[0].usedItems)
    }
    @Test fun onlyOneAbilityPerTurnAndUsedAbilityIsRemembered() {
        val g = game(); val trap = g.ui.players[0].availableTraps.first()
        g.useItem(trap, 1); assertTrue(g.ui.hasUsedItemThisTurn)
        g.beginQuestion(); g.startQuestionTimer(); val tech = g.ui.players[0].availableTechniques.first()
        g.useItem(tech); assertFalse(tech in g.ui.players[0].usedItems)
        assertTrue(trap in g.ui.players[0].usedItems)
    }
    @Test fun liteHasFourTechniquesThreeTrapsAndElevenAvatars() {
        val g = game(); g.setAccessState(AccessState(tier = ProductTier.LITE))
        assertEquals(4, g.availableItems().count { !it.isTrap })
        assertEquals(3, g.availableItems().count { it.isTrap })
        assertEquals(11, g.availableAvatarIndices().size)
    }
    @Test fun twentyPointsEndsTheMatch() {
        val g = game()
        repeat(6) { correct(g); correct(g); g.startNextRound() }
        assertEquals(18, g.ui.players[0].score)
        correct(g); assertEquals(AppScreen.FINISHED, g.ui.screen)
        assertEquals(g.ui.players[0].name, g.ui.winnerName)
    }
    @Test fun premiumExpiryKeepsTheCurrentMatch() {
        val g = game(); g.setAccessState(AccessState(trialEndsAtEpochMs = 10L))
        g.beginQuestion(); g.startQuestionTimer(); g.expireTrialIfNeeded(11L)
        assertEquals(ProductTier.LITE, g.ui.access.tier); assertEquals(AppScreen.GAME, g.ui.screen)
    }
}
