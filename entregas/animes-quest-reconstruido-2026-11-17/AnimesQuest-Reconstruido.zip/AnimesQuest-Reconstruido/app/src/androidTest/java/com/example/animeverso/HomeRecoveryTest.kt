package com.example.animeverso

import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createAndroidComposeRule
import androidx.compose.ui.test.onNodeWithContentDescription
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performClick
import org.junit.Rule
import org.junit.Test

/** Run on a device/emulator with connectedDebugAndroidTest. Not a simulated screenshot. */
class HomeRecoveryTest {
    @get:Rule val compose = createAndroidComposeRule<MainActivity>()

    @Test fun recoveredPlayImageHasNoDuplicateTextAndOpensCharacterSetup() {
        compose.waitUntil(15_000) {
            compose.onAllNodes(androidx.compose.ui.test.hasContentDescription("Português (Brasil): Jogar")).fetchSemanticsNodes().isNotEmpty()
        }
        compose.onNodeWithText("JOGAR").assertDoesNotExist()
        compose.onNodeWithContentDescription("Português (Brasil): Jogar").performScrollTo().performClick()
        compose.onNodeWithText("REGRAS DA BATALHA").assertIsDisplayed()
        compose.onNodeWithText("SELECIONAR PERSONAGENS").performScrollTo().performClick()
        compose.onNodeWithText("SELECIONE SEU PERSONAGEM").assertIsDisplayed()
    }
}
