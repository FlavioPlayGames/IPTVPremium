import express from 'express';
import { OAuth2Client, GoogleAuth } from 'google-auth-library';
import { google } from 'googleapis';
import pg from 'pg';

const { Pool } = pg;
const required = ['DATABASE_URL', 'GOOGLE_WEB_CLIENT_ID', 'ANDROID_PACKAGE_NAME', 'PLAY_SERVICE_ACCOUNT_JSON'];
for (const name of required) if (!process.env[name]) throw new Error(`Missing environment variable: ${name}`);

const db = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.PGSSLMODE === 'disable' ? false : { rejectUnauthorized: true } });
const googleClient = new OAuth2Client(process.env.GOOGLE_WEB_CLIENT_ID);
const playAuth = new GoogleAuth({ keyFile: process.env.PLAY_SERVICE_ACCOUNT_JSON, scopes: ['https://www.googleapis.com/auth/androidpublisher'] });
const publisher = google.androidpublisher({ version: 'v3', auth: playAuth });
const productId = process.env.PREMIUM_SUBSCRIPTION_ID || 'animes_quest_premium_monthly';
const app = express();
app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(express.json({ limit: '16kb' }));

await db.query(`
  CREATE TABLE IF NOT EXISTS app_users (
    google_sub TEXT PRIMARY KEY,
    email TEXT,
    trial_started_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE TABLE IF NOT EXISTS subscriptions (
    purchase_token TEXT PRIMARY KEY,
    google_sub TEXT NOT NULL REFERENCES app_users(google_sub),
    product_id TEXT NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
  );
  CREATE INDEX IF NOT EXISTS subscriptions_user_expiry_idx ON subscriptions(google_sub, expires_at DESC);
`);

app.use((req, res, next) => {
  if (req.get('x-forwarded-proto') !== 'https' && !['localhost', '127.0.0.1'].includes(req.hostname)) return res.status(400).json({ error: 'HTTPS_REQUIRED' });
  next();
});

async function requireGoogleUser(req, res) {
  const token = req.body?.googleIdToken;
  if (typeof token !== 'string' || token.length < 100 || token.length > 10000) {
    res.status(401).json({ error: 'GOOGLE_SIGN_IN_REQUIRED' });
    return null;
  }
  try {
    const ticket = await googleClient.verifyIdToken({ idToken: token, audience: process.env.GOOGLE_WEB_CLIENT_ID });
    const payload = ticket.getPayload();
    if (!payload?.sub || !payload.email_verified) throw new Error('Email must be verified');
    const firstOpenedAt = Number(req.body?.firstOpenedAt);
    const claimedStart = Number.isSafeInteger(firstOpenedAt) && firstOpenedAt > 0
      ? new Date(Math.min(firstOpenedAt, Date.now()))
      : new Date();
    await db.query(`INSERT INTO app_users(google_sub, email, trial_started_at) VALUES($1,$2,$3)
      ON CONFLICT(google_sub) DO UPDATE SET email=EXCLUDED.email`, [payload.sub, payload.email || null, claimedStart]);
    return { sub: payload.sub, email: payload.email || null };
  } catch {
    res.status(401).json({ error: 'INVALID_GOOGLE_ID_TOKEN' });
    return null;
  }
}

async function accessFor(user) {
  const { rows } = await db.query(`SELECT trial_started_at FROM app_users WHERE google_sub=$1`, [user.sub]);
  const trialEnd = new Date(new Date(rows[0].trial_started_at).getTime() + 24 * 60 * 60 * 1000);
  const { rows: tokens } = await db.query(`SELECT purchase_token FROM subscriptions WHERE google_sub=$1 AND expires_at>NOW()`, [user.sub]);
  for (const { purchase_token: purchaseToken } of tokens) {
    try {
      const live = (await publisher.purchases.subscriptionsv2.get({ packageName: process.env.ANDROID_PACKAGE_NAME, token: purchaseToken })).data;
      const item = live.lineItems?.find(line => line.productId === productId);
      const expiry = item?.expiryTime ? new Date(item.expiryTime) : null;
      const validState = new Set(['SUBSCRIPTION_STATE_ACTIVE', 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD', 'SUBSCRIPTION_STATE_CANCELED']).has(live.subscriptionState);
      await db.query(`UPDATE subscriptions SET expires_at=$2, updated_at=NOW() WHERE purchase_token=$1`, [purchaseToken, expiry && validState ? expiry : new Date(0)]);
    } catch (error) {
      if ([404, 410].includes(error?.code) || [404, 410].includes(error?.response?.status)) {
        await db.query(`UPDATE subscriptions SET expires_at=NOW(), updated_at=NOW() WHERE purchase_token=$1`, [purchaseToken]);
      } else {
        throw error;
      }
    }
  }
  const { rows: paid } = await db.query(`SELECT MAX(expires_at) AS expires_at FROM subscriptions WHERE google_sub=$1 AND expires_at>NOW()`, [user.sub]);
  const premiumEnd = paid[0].expires_at ? new Date(paid[0].expires_at) : null;
  const isPremium = Boolean(premiumEnd) || trialEnd.getTime() > Date.now();
  return {
    tier: isPremium ? 'PREMIUM' : 'LITE',
    trialEndsAt: trialEnd.getTime(),
    premiumEndsAt: premiumEnd?.getTime() || null,
    email: user.email || '',
    message: premiumEnd ? 'Assinatura mensal validada pelo Google Play.' : isPremium ? 'Período Premium de 24 horas, sem cobrança automática.' : 'Período de teste encerrado. Versão Lite ativa.'
  };
}

app.post('/v1/access', async (req, res) => {
  const user = await requireGoogleUser(req, res);
  if (!user) return;
  try { res.json(await accessFor(user)); }
  catch (error) { console.error('access lookup failed', error); res.status(503).json({ error: 'ACCESS_TEMPORARILY_UNAVAILABLE' }); }
});

app.post('/v1/billing/verify', async (req, res) => {
  const user = await requireGoogleUser(req, res);
  if (!user) return;
  const { purchaseToken, productId: requestedProduct } = req.body || {};
  if (typeof purchaseToken !== 'string' || purchaseToken.length > 4096 || requestedProduct !== productId) return res.status(400).json({ error: 'INVALID_PURCHASE' });
  try {
    const prior = await db.query('SELECT google_sub FROM subscriptions WHERE purchase_token=$1', [purchaseToken]);
    if (prior.rows[0] && prior.rows[0].google_sub !== user.sub) return res.status(409).json({ error: 'PURCHASE_ALREADY_LINKED_TO_ANOTHER_ACCOUNT' });
    const response = await publisher.purchases.subscriptionsv2.get({ packageName: process.env.ANDROID_PACKAGE_NAME, token: purchaseToken });
    const purchase = response.data;
    const item = purchase.lineItems?.find(line => line.productId === productId);
    const expiresAt = item?.expiryTime ? new Date(item.expiryTime) : null;
    const permittedStates = new Set(['SUBSCRIPTION_STATE_ACTIVE', 'SUBSCRIPTION_STATE_IN_GRACE_PERIOD', 'SUBSCRIPTION_STATE_CANCELED']);
    if (!permittedStates.has(purchase.subscriptionState)) return res.status(402).json({ error: 'SUBSCRIPTION_NOT_ACTIVE' });
    if (!expiresAt || expiresAt.getTime() <= Date.now()) return res.status(402).json({ error: 'SUBSCRIPTION_EXPIRED' });
    await db.query(`INSERT INTO subscriptions(purchase_token, google_sub, product_id, expires_at)
      VALUES($1,$2,$3,$4) ON CONFLICT(purchase_token) DO UPDATE SET expires_at=EXCLUDED.expires_at, updated_at=NOW()
      WHERE subscriptions.google_sub=EXCLUDED.google_sub`, [purchaseToken, user.sub, productId, expiresAt]);
    res.json(await accessFor(user));
  } catch (error) {
    console.error('purchase verification failed', error?.message || error);
    res.status(503).json({ error: 'PURCHASE_VERIFICATION_FAILED' });
  }
});

app.get('/health', (_req, res) => res.json({ ok: true }));
const port = Number(process.env.PORT || 8080);
app.listen(port, '0.0.0.0', () => console.log(`Animes Quest Premium API listening on ${port}`));
