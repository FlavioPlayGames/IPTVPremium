param(
    [string]$ProjectRoot = (Split-Path -Parent $PSScriptRoot)
)

$ErrorActionPreference = 'Stop'
$sourcePath = Join-Path $ProjectRoot 'artwork\approved_button_sheet.png'
$outputDirectory = Join-Path $ProjectRoot 'app\src\main\res\drawable-nodpi'
if (-not (Test-Path -LiteralPath $sourcePath -PathType Leaf)) {
    throw "Approved button sheet not found: $sourcePath"
}
New-Item -ItemType Directory -Force -Path $outputDirectory | Out-Null

Add-Type -AssemblyName System.Drawing
$source = [System.Drawing.Bitmap]::FromFile($sourcePath)
try {
    if ($source.Width -ne 1774 -or $source.Height -ne 887) {
        throw "Unexpected approved sheet dimensions $($source.Width)x$($source.Height); expected 1774x887."
    }

    $locales = @('pt_br', 'pt_pt', 'en_us', 'en_gb', 'fr', 'de', 'es', 'it')
    $rows = @(
        @(0, 136), @(140, 261), @(265, 376), @(380, 481),
        @(490, 586), @(590, 686), @(690, 786), @(790, 887)
    )
    $buttons = @(
        @{ name = 'play'; left = 150; right = 520 },
        @{ name = 'rules'; left = 525; right = 932 },
        @{ name = 'abilities'; left = 936; right = 1362 },
        @{ name = 'ranking'; left = 1366; right = 1774 }
    )
    $backupDirectory = Join-Path $ProjectRoot ('backup\home-buttons-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
    $created = 0

    for ($row = 0; $row -lt $locales.Count; $row++) {
        $top = $rows[$row][0]
        $bottom = $rows[$row][1]
        foreach ($button in $buttons) {
            $fileName = "home_$($button.name)_$($locales[$row]).png"
            $destination = Join-Path $outputDirectory $fileName
            if (Test-Path -LiteralPath $destination) {
                New-Item -ItemType Directory -Force -Path $backupDirectory | Out-Null
                Copy-Item -LiteralPath $destination -Destination (Join-Path $backupDirectory $fileName)
            }
            $rectangle = New-Object System.Drawing.Rectangle($button.left, $top, ($button.right - $button.left), ($bottom - $top))
            $crop = $source.Clone($rectangle, [System.Drawing.Imaging.PixelFormat]::Format32bppArgb)
            try { $crop.Save($destination, [System.Drawing.Imaging.ImageFormat]::Png) }
            finally { $crop.Dispose() }
            $created++
        }
    }
    Write-Output "Created or refreshed $created localized button images in $outputDirectory"
    if (Test-Path -LiteralPath $backupDirectory) { Write-Output "Previous assets backed up to $backupDirectory" }
}
finally { $source.Dispose() }
