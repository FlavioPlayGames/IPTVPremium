# Validação — 17/11/2026

Executado com JDK 21, Gradle 9.6.0, AGP 9.4.0, SDK 37 e Build Tools 37.0.0.

Comando concluído com **BUILD SUCCESSFUL**:

```text
:app:assembleDebug :app:testDebugUnitTest :app:lintDebug :app:compileDebugAndroidTestKotlin
```

- APK debug gerado a partir do projeto reconstruído.
- 11 testes de regras passaram, com zero falhas: preparação manual, início do cronômetro após narração, faixas de pontuação, tempo esgotado, rodadas, pausa, alvo inválido, limite de habilidade, Lite, vitória e expiração do acesso.
- O teste de exemplo herdado também passou; não é contado entre os 11 testes das regras.
- Lint: 0 erros, 34 avisos. Os avisos abrangem recursos reservados sem uso, sugestões KTX/catálogo de versões, ícones, atualizações de bibliotecas e tratamento de credencial. Não foi declarado que o projeto está livre de todos os avisos.
- Teste Compose de interface compilado. **Não executado em aparelho/emulador**.
- Sintaxe do backend: `node --check backend/server.mjs` passou. Backend não publicado nem validado em produção.
- 3.200 perguntas conferidas: nenhuma duplicada, todas com quatro alternativas e resposta correta presente.
- 60 recursos comparados com o APK original por SHA-256: todos idênticos.
- Checksum da distribuição Gradle confere com o wrapper fornecido.

## Ainda requer teste real

1. Abrir Home em celulares com proporções diferentes; conferir JOGAR sem texto sobreposto e navegação/rolagem.
2. Jogar uma partida: avatares, preparação, escolha de alvo, técnicas, armadilhas, placar e vencedor.
3. Conferir música e narrador; pausar, voltar à Home e alternar para outro aplicativo.
4. Selecionar idiomas e testar download dos modelos e voz instalada; conferir traduções das perguntas/alternativas.
5. Com a configuração legítima, testar conta Google, assinatura/recuperação, backend e anúncios Lite.
6. Testar atualização usando a chave original e conservação de dados. O histórico reconstruído usa armazenamento novo e não foi migrado automaticamente.

Não houve instalação em seu celular, acesso a contas, publicação em loja, GitHub ou deploy do backend. O APK de teste gerado neste ambiente não está no ZIP do projeto e não tem a assinatura privada do proprietário.

Detalhes dos testes e avisos: `RESULTADOS-VALIDACAO.json`.
