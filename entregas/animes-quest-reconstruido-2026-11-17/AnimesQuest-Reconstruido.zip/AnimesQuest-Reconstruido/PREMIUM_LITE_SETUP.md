# ANIMES QUEST Premium / Lite

The Android project remains Premium during the 24-hour trial. After expiry it applies the agreed Lite limits: 500 questions, 4 techniques, 3 traps, half the avatar choices, device TTS, and the existing local music and sound effects. The reconstructed project includes a new local winner history. Existing private data from the old APK is not automatically migrated.

## Access and trial

- First app launch records the trial start on-device and gives Premium for 24 hours.
- On Google sign-in, the API creates or finds a database account keyed by Google's stable `sub` claim. The first-open timestamp is used for the initial trial record, so clearing/reinstalling the app does not reset the same Google account's trial.
- The device sends the Google ID token to the HTTPS API. The API validates it with Google and determines the tier. Never grant a paid entitlement based only on a value returned from the APK.
- A Google account is the persistent identity in this implementation. It prevents another trial on the same account, including after reinstall or device change. It cannot establish a real person's legal identity across multiple Google accounts; stronger prevention would require an additional verified identity or risk signal.
- The 24-hour trial is separate from Play Billing and does not create a purchase or automatic charge. Users must explicitly press **Assinar Premium** and confirm in Google Play. The Play subscription then follows its monthly renewal and cancellation rules.

## Backend deployment

Deploy `backend/` as a Node 20+ HTTPS service with PostgreSQL. Put secrets in the hosting provider's secret store; do not commit `.env`, the Play service account JSON, OAuth client secrets, or database credentials. The service initializes its tables on first start. Restrict the Google Play service account to the Android Publisher permissions needed to read subscription purchases, and grant it access to the app in Play Console.

Create an OAuth **Web application** client ID for Google sign-in and a linked Android OAuth client for the final application ID/signing certificate. Set the Web client ID as `GOOGLE_WEB_CLIENT_ID` on the server and as a Gradle property for Android. Configure the Play subscription `animes_quest_premium_monthly` with a monthly base plan priced at R$ 10,00 in Brazil. Do not configure a 24-hour free offer on this SKU: the app grants that trial itself, and it must not trigger billing.

Set these properties in the developer's uncommitted `gradle.properties` (or pass them as Gradle properties):

```properties
premiumApiUrl=https://YOUR_API_HOST
googleWebClientId=YOUR_WEB_CLIENT_ID.apps.googleusercontent.com
premiumSubscriptionId=animes_quest_premium_monthly
admobAppId=ca-app-pub-REPLACE~WITH_REAL_APP_ID
admobInterstitialId=ca-app-pub-REPLACE/WITH_REAL_UNIT_ID
```

The project intentionally has no endpoint, OAuth ID, database URL, service account key, or private API secret checked in. Until those are configured and the API is deployed, sign-in and purchases remain unavailable. In that development state, the local 24-hour trial is not tamper-resistant; do not publish it as a production entitlement gate.

## Ads and ranking notes

Lite now loads an interstitial at the pause between complete player cycles. Debug builds use Google's test AdMob IDs. For release, set `admobAppId` and `admobInterstitialId` Gradle properties to the app's registered IDs, and add an appropriate consent flow and child-directed treatment for the audience. The reconstructed project includes persistent winner history and round standings.

## API routes

- `POST /v1/access`: accepts a Google ID token and the first-open timestamp; returns server-calculated `PREMIUM` or `LITE` state.
- `POST /v1/billing/verify`: validates a Play purchase token through `subscriptionsv2.get`, binds it to the signed-in account, and returns the updated entitlement. The client acknowledges a purchase only after this verification succeeds.
- `GET /health`: deployment health check.

The server uses the Play Developer API as the purchase source of truth. This follows Google's guidance to send purchase tokens to a secure backend and validate with `purchases.subscriptionsv2.get` before granting entitlement: [Play Billing security](https://developer.android.com/google/play/billing/security), [subscription lifecycle](https://developer.android.com/google/play/billing/lifecycle/subscriptions).
