package br.com.flaviotorres.iptvpremium.data.cache

/** Only definitive missing/invalid images warrant a long suppression; never timeouts or priority gates. */
internal fun persistentPosterFailure(outcome:String,httpStatus:Int):Boolean =
    outcome=="http_status"&&httpStatus in listOf(404,410) || outcome=="image_too_large"

/** Short, RAM-only retry delay for a particular failed URL. Never suppress a whole provider. */
internal class PosterTransientFailures(private val now:()->Long=System::currentTimeMillis) {
    private val failed=LinkedHashMap<String,Long>()
    @Synchronized fun cooling(key:String):Boolean {
        val at=failed[key]?:return false
        if(now()-at in 0 until 20_000L)return true
        failed.remove(key);return false
    }
    @Synchronized fun record(key:String,outcome:String,httpStatus:Int) {
        if(outcome=="success")failed.remove(key)
        else if(outcome in setOf("timeout","io_error") || outcome=="http_status"&&httpStatus in 500..599) {
            failed.remove(key);failed[key]=now()
            while(failed.size>512)failed.remove(failed.keys.first())
        }
    }
}
internal fun posterSocketTimeouts(url:String):Pair<Int,Int> =
    if(runCatching{java.net.URI(url).host.equals("image.tmdb.org",true)}.getOrDefault(false)) 4_000 to 6_000
    else 2_000 to 2_000

/** Cancels the provider socket before proceeding to the verified alternative. */
internal suspend fun <T> firstProviderPosterAttempt(operation:suspend()->T):T? =
    kotlinx.coroutines.withTimeoutOrNull(1_500L){operation()}
