"""Exercise the actual provider-attempt method with simulated image I/O; no network/TV access."""
from pathlib import Path
import argparse,os,subprocess,tempfile
p=argparse.ArgumentParser();p.add_argument('--projeto',type=Path,required=True);p.add_argument('--tools',type=Path,required=True);p.add_argument('--java',default='java');a=p.parse_args()
r=a.projeto/'app/src/main/java/br/com/flaviotorres/iptvpremium';f=Path(__file__).parent
cp=os.pathsep.join(str(x)for x in a.tools.glob('*.jar'))
s=(r/'ui/movies/MoviePosterLoader.kt').read_text();start=s.index('    suspend fun loadProvider(');end=s.index('    private suspend fun loadVisiblePoster(',start)
with tempfile.TemporaryDirectory(prefix='iptv-provider-deadline-')as td:
 w=Path(td);source=w/'ActualProvider.kt'
 source.write_text('''package br.com.flaviotorres.iptvpremium.ui.movies
import kotlinx.coroutines.*
import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import br.com.flaviotorres.iptvpremium.data.cache.*
private object ProbeLoader {
 var calls=0;var cached:ImageBitmap?=null;var wait=false;var cancelled=false
 val transientFailures=PosterTransientFailures()
 private fun validUrl(url:String?)=url
 private fun sha256(url:String)=url
 private suspend fun loadCached(c:Context,url:String?,kind:PosterKind)=cached
 private suspend fun loadWithRetry(c:Context,url:String?,kind:PosterKind):ImageBitmap? {
  calls++
  if(wait)try{delay(10000)}finally{cancelled=true}
  return ImageBitmap(url?:"none")
 }
'''+s[start:end]+'''}
fun main()=runBlocking {
 val c=Context()
 ProbeLoader.cached=ImageBitmap("cache")
 check(ProbeLoader.loadProvider(c,"cached",PosterKind.MOVIES)!=null&&ProbeLoader.calls==0)
 ProbeLoader.cached=null
 check(ProbeLoader.loadProvider(c,"fast",PosterKind.MOVIES)!=null&&ProbeLoader.calls==1)
 ProbeLoader.wait=true;val start=System.nanoTime()
 check(ProbeLoader.loadProvider(c,"slow",PosterKind.MOVIES)==null)
 val ms=(System.nanoTime()-start)/1000000
 check(ms in 1400..3000&&ProbeLoader.cancelled&&ProbeLoader.transientFailures.cooling("slow"))
 val child=async{ProbeLoader.loadProvider(c,"outer-cancel",PosterKind.SERIES)}
 yield();child.cancelAndJoin()
 check(child.isCancelled&&!ProbeLoader.transientFailures.cooling("outer-cancel"))
 println("PASS actual loadProvider: cache bypasses network, healthy source wins, slow I/O cancelled in ${ms}ms, retry pause applied, outer cancellation propagates without false miss")
}
''')
 files=[source,r/'data/cache/PosterFailurePolicy.kt',r/'data/cache/PosterSourceUrl.kt',r/'data/cache/PosterCategoryPolicy.kt',f/'shared/Context.kt',f/'common/Log.kt',f/'poster/Bitmap.kt']
 # PosterKind lives with the category policy.
 jar=w/'provider.jar';subprocess.run([a.java,'-cp',cp,'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-classpath',cp,'-d',str(jar),*map(str,files)],check=True)
 subprocess.run([a.java,'-cp',str(jar)+os.pathsep+cp,'br.com.flaviotorres.iptvpremium.ui.movies.ActualProviderKt'],check=True)
