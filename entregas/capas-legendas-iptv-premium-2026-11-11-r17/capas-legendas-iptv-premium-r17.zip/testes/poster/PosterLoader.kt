package br.com.flaviotorres.iptvpremium.ui.movies
import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import br.com.flaviotorres.iptvpremium.data.cache.PosterKind
internal object MoviePosterLoader {
 val requested=java.util.concurrent.ConcurrentLinkedQueue<String>()
 fun clearRam(){bitmaps.clear()}
 val compressed=java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
 suspend fun prefetch(context:Context,url:String?,kind:PosterKind,duringNavigation:Boolean):Boolean {
  if(url==null||url in broken)return false
  compressed.add(url);return true
 }
 var beforeLoad: (suspend (String)->Unit)? = null
 private val bitmaps=java.util.concurrent.ConcurrentHashMap<String,ImageBitmap>()
 fun peekBitmap(url:String?):ImageBitmap?=url?.let{bitmaps[it]}
 val broken=java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
 fun knownMissing(url:String?)=url==null||url in broken
 suspend fun loadCached(context:Context,url:String?,kind:PosterKind=PosterKind.MOVIES):ImageBitmap?=peekBitmap(url)
 suspend fun loadProvider(context:Context,url:String?,kind:PosterKind):ImageBitmap?=br.com.flaviotorres.iptvpremium.data.cache.firstProviderPosterAttempt{loadWithRetry(context,url,kind)}
 suspend fun loadWithRetry(context:Context,url:String?,kind:PosterKind):ImageBitmap? = url?.also{requested.add(it)}?.takeIf{it !in broken && (it.startsWith("https://")||it.startsWith("http://"))}?.let{beforeLoad?.invoke(it);bitmaps.getOrPut(it){ImageBitmap(it)}}
}
