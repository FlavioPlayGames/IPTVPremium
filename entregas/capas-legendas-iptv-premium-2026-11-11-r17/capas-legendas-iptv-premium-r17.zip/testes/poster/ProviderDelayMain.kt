package br.com.flaviotorres.iptvpremium.data.cache
import kotlinx.coroutines.*
fun main()=runBlocking {
 var now=0L;val failures=PosterTransientFailures{now}
 failures.record("a","http_status",502);check(failures.cooling("a"));check(!failures.cooling("other"))
 now=19999;check(failures.cooling("a"));now=20000;check(!failures.cooling("a"))
 failures.record("a","timeout",0);failures.record("a","success",200);check(!failures.cooling("a"))
 for(outcome in listOf("cancelled","priority_busy","priority_interrupted","activity_interrupted","cache_budget")) {
  failures.record("a",outcome,0);check(!failures.cooling("a"))
 }
 repeat(513){failures.record("k$it","timeout",0)};check(!failures.cooling("k0"));check(failures.cooling("k512"))
 check(posterSocketTimeouts("https://provider.example/a.jpg")==2000 to 2000)
 check(posterSocketTimeouts("https://image.tmdb.org/t/p/w342/a.jpg")==4000 to 6000)
 check(posterSocketTimeouts("https://image.tmdb.org.evil.invalid/a.jpg")==2000 to 2000)
 check(firstProviderPosterAttempt {42}==42)
 var disconnected=false;val started=System.nanoTime()
 val result=firstProviderPosterAttempt {
  coroutineScope {
   val interrupt=interruptPosterDownload {disconnected=true}
   try {delay(10000);42}finally{interrupt.cancel()}
  }
 }
 val elapsed=(System.nanoTime()-started)/1000000
 check(result==null&&disconnected&&elapsed in 1400..3000) {"deadline failed: $elapsed, disconnected=$disconnected"}
 val outer=async {firstProviderPosterAttempt {delay(10000);42}};yield();outer.cancelAndJoin();check(outer.isCancelled)
 println("PASS: per-URL bounded RAM cooldown expires, isolates URLs and clears on success; priority cancellation is not a persistent miss")
 println("PASS: provider stage budgets preserve official TMDB; 1500ms deadline cancelled simulated socket in ${elapsed}ms; parent cancellation propagates")
}
