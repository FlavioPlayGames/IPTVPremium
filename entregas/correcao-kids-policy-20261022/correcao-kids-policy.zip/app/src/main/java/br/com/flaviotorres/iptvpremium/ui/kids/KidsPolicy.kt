package br.com.flaviotorres.iptvpremium.ui.kids

import java.text.Normalizer
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow

internal object KidsSession { val active = MutableStateFlow(false) }
internal object KidsContent {
    fun folded(value: String) = Normalizer.normalize(value, Normalizer.Form.NFKD)
        .replace(Regex("\\p{M}+"), "").lowercase(Locale.ROOT)
    private val children = Regex("\\b(?:kids|infantil|infantis|criancas?|desenhos?|cartoons?|children|family|familia|infantojuvenil|infanto[ -]juvenil)\\b")
    // Same name markers as parental classification, without a settings UI dependency.
    private val adult = Regex("""\b(?:adult(?:s|o|os|a|as)?|xxx|porn\w*|playboy|penthouse|hustler|brazzers)\b|\b18\s*\+|\+\s*18\b|\bsexy\s*hot\b|\bsex\s*zone\b""", RegexOption.IGNORE_CASE)
    fun category(name: String): Boolean {
        val normalized = folded(name)
        return children.containsMatchIn(normalized) && !adult.containsMatchIn(normalized)
    }
}
internal object CatalogSections {
    const val SUBTITLED = "__iptv_subtitled__"
    fun subtitled(name: String): Boolean = Regex("(?:^|[^\\p{L}\\p{N}])(?:L|LEG|LEGENDADOS?|LEGENDADAS?)(?:$|[^\\p{L}\\p{N}])",RegexOption.IGNORE_CASE).containsMatchIn(name)
    private val year=Regex("(?:19|20)[0-9]{2}")
    fun orderName(name: String): String = KidsContent.folded(name).trim().removePrefix("🔒 ")
        .replace(Regex("^(?:filmes?|series?|canais|channels?)\\s*[|:–—-]\\s*"), "").trim()
    /** Movie menu: special symbols and restricted/training catalogues always trail. */
    fun moviePriority(name: String): Int {
        val text = orderName(name)
        val adult = Regex("\\b(?:xxx|adultos?|adultas?)\\b|(?:18\\s*\\+|\\+\\s*18)")
        return when {
            text.firstOrNull()?.isLetterOrDigit() == false || adult.containsMatchIn(text) ||
                Regex("\\bcursos?\\b").containsMatchIn(text) -> 4
            "lancamento" in text || Regex("\\breleases?\\b").containsMatchIn(text) -> 0
            subtitled(text) -> 1
            Regex("\\b(?:4k|uhd)\\b").containsMatchIn(text) -> 2
            else -> 3
        }
    }
    /** One stable category order for films, series and channels; never scans media items. */
    fun <T> categoryComparator(name: (T) -> String): Comparator<T> =
        compareBy<T> { moviePriority(name(it)) }
            .thenByDescending { if (moviePriority(name(it)) == 0) year(name(it)) else 0 }
            .thenBy { orderName(name(it)) }
    fun year(name: String): Int = year.findAll(name).maxOfOrNull { it.value.toInt() } ?: 0
}
