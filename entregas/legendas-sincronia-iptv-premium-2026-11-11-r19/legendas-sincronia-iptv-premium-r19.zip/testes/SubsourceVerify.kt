package br.com.flaviotorres.iptvpremium.core.player
import kotlinx.coroutines.*
import org.json.*
private data class Call(val url:String,val headers:Map<String,String>)
private class Fake:OpenSubtitleTransport {
 val calls=mutableListOf<Call>();var handle:(Call)->OpenSubtitleResponse={OpenSubtitleResponse(200,"{\"success\":true,\"data\":[]}".toByteArray())}
 override suspend fun request(url:String,method:String,headers:Map<String,String>,body:String?,limit:Int):OpenSubtitleResponse {
  check(method=="GET"&&body==null);val call=Call(url,headers);calls+=call;return handle(call)
 }
}
private var checks=0
private fun verify(ok:Boolean,label:String){check(ok){label};checks++;println("PASS $label")}
private fun response(data:JSONArray)=OpenSubtitleResponse(200,JSONObject().put("success",true).put("data",data).toString().toByteArray())
private fun work(id:Int=1,title:String="The Handmaid's Tale",type:String="series",year:Int=2017)=JSONObject().put("movieId",id).put("title",title).put("type",type).put("releaseYear",year).put("season",5)
private fun sub(id:Int,lang:String,release:String)=JSONObject().put("subtitleId",id).put("language",lang).put("releaseInfo",JSONArray().put(release))
fun main()=runBlocking {
 var key:String?="fake-personal-subsource-key";val wire=Fake();val trace=mutableListOf<String>()
 val client=SubsourceClient({key},wire,{trace+=it},0)
 wire.handle={c->when {
  "/movies/search?" in c.url->response(JSONArray().put(work()))
  "language=brazillian-portuguese" in c.url->response(JSONArray().put(sub(10,"brazillian-portuguese","Show.S05E06.WEB"))
    .put(sub(11,"brazillian-portuguese","Show.S05E060")) .put(sub(12,"brazillian-portuguese","Show.S05E07"))
    .put(sub(13,"portuguese","Show.S05E06")))
  "language=english" in c.url->response(JSONArray().put(sub(20,"english","Show.S05E06")))
  else->response(JSONArray().put(sub(30,"spanish","Show.S05E06")))
 }}
 val query=SubsourceQuery("The Handmaid's Tale",2017,null,5,6)
 val(scope,hits)=client.search(query)
 verify(hits.map{it.id}==listOf("10","20","30"),"exact episode/languages only; E060, E07 and generic Portuguese rejected")
 verify(hits.map{it.language}==listOf("pt-BR","en","es"),"Brazilian Portuguese before English and Spanish")
 verify(wire.calls.size==4&&wire.calls.none{it.url.endsWith("/download")},"search resolves work and three languages without downloading files")
 verify(wire.calls.all{it.headers["X-API-Key"]==key&&"Authorization" !in it.headers&&it.url.startsWith("https://api.subsource.net/api/v1/")},"personal key stays in official API header, never URL or unrelated host")
 wire.calls.clear();wire.handle={response(JSONArray().put(work()).put(work(2)))}
 verify(client.search(query).second.isEmpty(),"ambiguous work is not selected by popularity")
 wire.handle={response(JSONArray().put(work(title="Other Show")))}
 verify(client.search(query).second.isEmpty(),"unrelated title rejected without IMDb")
 wire.handle={response(JSONArray().put(work(type="movie")))}
 verify(client.search(query).second.isEmpty(),"wrong content type rejected")
 wire.handle={response(JSONArray().put(work(title="Remake",type="movie",year=2020)))}
 verify(client.search(SubsourceQuery("Remake",2000,null)).second.isEmpty(),"name-only search rejects different release year")
 wire.calls.clear();wire.handle={c->if("/movies/search?" in c.url)response(JSONArray().put(work(title="Original Title").put("imdbId","tt1234567")))else response(JSONArray())}
 client.search(query.copy(title="Translated Title",imdb="tt1234567"))
 verify("searchType=imdb" in wire.calls.first().url&&"imdb=tt1234567" in wire.calls.first().url,"verified IMDb is used before text search")
 wire.handle={response(JSONArray().put(work().put("imdbId","tt9999999")))}
 verify(client.search(query.copy(imdb="tt1234567")).second.isEmpty(),"conflicting returned IMDb rejected")
 wire.handle={OpenSubtitleResponse(200,byteArrayOf(80,75,3,4))};wire.calls.clear()
 verify(client.download("10",scope).size==4&&wire.calls.size==1&&wire.calls.single().url.endsWith("/subtitles/10/download"),"one download API GET only after selection")
 wire.handle={OpenSubtitleResponse(302,"https://untrusted.invalid/file.zip".toByteArray())};wire.calls.clear()
 try{client.download("10",scope);error("redirect accepted")}catch(_:SubsourceException){verify(wire.calls.size==1,"authenticated download is not redirected/retried with a personal key")}
 wire.handle={OpenSubtitleResponse(403,byteArrayOf())}
 try{client.search(query);error("403 accepted")}catch(e:SubsourceException){verify("recusada" in e.text,"403 remains authentication error, not cached empty result")}
 wire.handle={OpenSubtitleResponse(200,"{}".toByteArray())}
 try{client.search(query);error("invalid accepted")}catch(e:SubsourceException){verify("incompatível" in e.text,"malformed API data is not an empty search")}
 wire.handle={key="replacement-personal-key";response(JSONArray())}
 try{client.search(query);error("scope accepted")}catch(_:SubsourceException){verify(client.scope()!=scope,"account change discards late search results")}
 key=null;wire.calls.clear()
 try{client.search(query);error("anonymous accepted")}catch(_:SubsourceException){verify(wire.calls.isEmpty(),"unconfigured account performs no anonymous requests")}
 verify(trace.none{it.contains("fake-personal-subsource-key")||it.contains("https://")||it.contains("The Handmaid")},"trace excludes key, URL and title")
 println("$checks SubSource checks passed; simulated API contract, no real account/service access.")
}
