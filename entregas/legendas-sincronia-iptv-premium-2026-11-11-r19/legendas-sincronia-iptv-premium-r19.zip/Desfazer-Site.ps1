[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Backup)
$ErrorActionPreference='Stop'
$state=Get-Content -LiteralPath (Join-Path $Backup 'estado-site.json') -Raw | ConvertFrom-Json
$root=[IO.Path]::GetFullPath([string]$state.site)
function Hash([byte[]]$Bytes){$s=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($s.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()}finally{$s.Dispose()}}
$plan=@()
foreach($item in @($state.files)){
 if([string]$item.path -notin @('worker-atualizacao-abi.js','public/index.html','public/subtitles.js')){throw 'Arquivo fora do escopo do site.'}
 $dest=Join-Path $root ([string]$item.path)
 foreach($path in @($dest,(Join-Path $Backup ([string]$item.path)))){
  $check=Get-Item -LiteralPath $path -Force
  while($null -ne $check){if(($check.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Links de sistema nao sao aceitos.'};$parent=Split-Path -Parent $check.FullName;if([string]::IsNullOrWhiteSpace($parent) -or $parent -eq $check.FullName){break};$check=Get-Item -LiteralPath $parent -Force}
 }
 $current=Hash ([IO.File]::ReadAllBytes($dest))
 if($current -notin @($item.beforeHash,$item.afterHash)){throw 'Fonte do site modificado depois da atualizacao. Restauracao interrompida.'}
 $bytes=[IO.File]::ReadAllBytes((Join-Path $Backup ([string]$item.path)))
 if((Hash $bytes) -ne $item.beforeHash){throw 'Copia de recuperacao invalida.'}
 $plan+=,[PSCustomObject]@{Path=$dest;Bytes=$bytes}
}
foreach($item in $plan){[IO.File]::WriteAllBytes($item.Path,$item.Bytes)}
Write-Host 'Fontes anteriores do site restaurados localmente. Nenhum deploy ou segredo alterado.'
