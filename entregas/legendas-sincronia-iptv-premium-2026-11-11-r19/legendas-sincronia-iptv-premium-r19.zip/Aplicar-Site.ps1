[CmdletBinding()]
param([string]$Site="$env:USERPROFILE\Downloads\site-identidade-aprovada",[string]$Downloads="$env:USERPROFILE\Downloads")
$ErrorActionPreference='Stop'
$root=[IO.Path]::GetFullPath($Site).TrimEnd([IO.Path]::DirectorySeparatorChar)
$backupRoot=[IO.Path]::GetFullPath($Downloads).TrimEnd([IO.Path]::DirectorySeparatorChar)
if($backupRoot -eq $root -or $backupRoot.StartsWith($root+[IO.Path]::DirectorySeparatorChar,[StringComparison]::OrdinalIgnoreCase)){throw 'A recuperacao precisa ficar fora da pasta do site.'}
if(!(Test-Path -LiteralPath $root -PathType Container)){throw 'Pasta do site nao encontrada.'}
function Hash([byte[]]$Bytes){$s=[Security.Cryptography.SHA256]::Create();try{([BitConverter]::ToString($s.ComputeHash($Bytes))).Replace('-','').ToLowerInvariant()}finally{$s.Dispose()}}
function Destino([string]$Rel){
 if($Rel -notin @('worker-atualizacao-abi.js','public/index.html','public/subtitles.js')){throw 'Arquivo fora do escopo do site.'}
 $full=[IO.Path]::GetFullPath((Join-Path $root $Rel))
 $check=Get-Item -LiteralPath $full -Force
 while($null -ne $check){if(($check.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0){throw 'Links de sistema nao sao aceitos.'};if($check.FullName -eq $root){break};$parent=Split-Path -Parent $check.FullName;if([string]::IsNullOrWhiteSpace($parent) -or $parent -eq $check.FullName){break};$check=Get-Item -LiteralPath $parent -Force}
 return $full
}
$items=@((Get-Content -LiteralPath "$PSScriptRoot\site\manifesto-site.json" -Raw | ConvertFrom-Json) | ForEach-Object {$_})
$plan=@()
foreach($item in $items){
 $dest=Destino ([string]$item.path);$before=[IO.File]::ReadAllBytes($dest);$current=Hash $before
 if($current -eq $item.afterHash){continue}
 if($current -ne $item.beforeHash){throw "O site atual diverge da base revisada: $($item.path). Nenhum arquivo alterado. Envie os fontes atuais para revisar, sem credenciais."}
 $stream=New-Object IO.MemoryStream
 try{
  $position=0
  foreach($part in @($item.operations)){
   $offset=[int]$part.offset;$length=[int]$part.length
   if($offset -lt $position -or $length -lt 0 -or $offset+$length -gt $before.Length){throw 'Patch do site invalido.'}
   $stream.Write($before,$position,$offset-$position)
   $insert=[Convert]::FromBase64String([string]$part.data)
   $stream.Write($insert,0,$insert.Length);$position=$offset+$length
  }
  $stream.Write($before,$position,$before.Length-$position)
  [byte[]]$after=$stream.ToArray()
 }finally{$stream.Dispose()}
 if((Hash $after) -ne $item.afterHash){throw 'Integridade do patch do site invalida.'}
 $plan+=,[PSCustomObject]@{Path=[string]$item.path;Destination=$dest;Before=$before;After=$after;BeforeHash=[string]$item.beforeHash;AfterHash=[string]$item.afterHash}
}
if($plan.Count -eq 0){Write-Host 'Site r19 ja aplicado. Nenhuma publicacao foi feita.';exit 0}
$backup=Join-Path $Downloads ('IPTV-site-restauracao-r19-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
$state=@()
foreach($item in $plan){$copy=Join-Path $backup $item.Path;New-Item -ItemType Directory -Path (Split-Path -Parent $copy) -Force | Out-Null;[IO.File]::WriteAllBytes($copy,$item.Before);$state+=,[PSCustomObject]@{path=$item.Path;beforeHash=$item.BeforeHash;afterHash=$item.AfterHash}}
[PSCustomObject]@{site=$root;files=$state} | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $backup 'estado-site.json') -Encoding UTF8
try{foreach($item in $plan){[IO.File]::WriteAllBytes($item.Destination,$item.After)}}
catch{foreach($item in $plan){[IO.File]::WriteAllBytes($item.Destination,$item.Before)};throw}
Write-Host "Site r19 aplicado localmente. Recuperacao: $backup"
Write-Host 'Nao houve deploy. Confira a pasta/conta Cloudflare antes de executar npx wrangler deploy.'
