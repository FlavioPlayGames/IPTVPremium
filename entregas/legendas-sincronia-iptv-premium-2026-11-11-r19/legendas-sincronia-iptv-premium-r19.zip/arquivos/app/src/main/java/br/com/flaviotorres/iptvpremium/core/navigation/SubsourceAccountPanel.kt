package br.com.flaviotorres.iptvpremium.ui.settings

import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.ui.components.SettingsLook
import androidx.compose.ui.platform.LocalContext
import br.com.flaviotorres.iptvpremium.core.player.*
import kotlinx.coroutines.*

@Composable
internal fun SubsourceAccountPanel() {
    val context=LocalContext.current.applicationContext
    val store=remember(context){SubsourceCredentialStore(context)}
    val scope=rememberCoroutineScope()
    var configured by remember{mutableStateOf(store.isConfigured())}
    var input by remember{mutableStateOf("")}
    var busy by remember{mutableStateOf(false)}
    var message by remember{mutableStateOf<String?>(null)}
    Text("SUBSOURCE",color=SettingsLook.text,fontSize=20.sp)
    Text("Gere sua chave pessoal no site oficial subsource.net e cole aqui, ou envie pelo nosso portal.",color=SettingsLook.secondary,fontSize=14.sp)
    Text(if(configured)"Chave salva nesta TV"else"Não configurado",color=SettingsLook.text,fontSize=14.sp)
    Text("Chave de API pessoal",color=SettingsLook.text,fontSize=14.sp)
    BasicTextField(value=input,onValueChange={if(it.length<=512)input=it},singleLine=true,enabled=!busy,
        visualTransformation=PasswordVisualTransformation(),textStyle=TextStyle(color=Color.White,fontSize=17.sp),modifier=Modifier.fillMaxWidth().background(SettingsLook.panel,RoundedCornerShape(8.dp)).padding(12.dp))
    SettingsAction(title=if(busy)"Salvando…"else"Salvar chave SubSource",description="Protege a chave nesta TV; o acesso será confirmado na pesquisa",enabled=!busy&&input.isNotBlank(),onClick={
        busy=true
        scope.launch {
            val ok=withContext(Dispatchers.IO){store.saveKeyFromPortal(input)}
            configured=store.isConfigured()
            if(ok){input="";SubtitleProviderUpdates.changed()}
            message=if(ok)"Chave salva. Abra Legendas no player para pesquisar."else"Não foi possível salvar. Confira o formato da chave."
            busy=false
        }
    })
    if(configured)SettingsAction(title="Desconectar SubSource",description="Mantém suas outras contas e os arquivos baixados",enabled=!busy,onClick={
        busy=true;scope.launch {withContext(Dispatchers.IO){store.disconnect()};configured=false;input="";SubtitleProviderUpdates.changed();busy=false}
    })
    message?.let{Text(it,color=SettingsLook.secondary,fontSize=14.sp)}
}
