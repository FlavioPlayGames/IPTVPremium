package br.com.flaviotorres.iptvpremium.core.player

import android.content.Context

/** User-owned numeric settings; cache rotation must never erase a manually saved adjustment. */
internal class ExternalSubtitleSyncStore(context:Context) {
    private val prefs=context.applicationContext.getSharedPreferences("external_subtitle_sync_v1",Context.MODE_PRIVATE)
    fun load(key:String):Long=prefs.getLong("v:$key",0).coerceIn(-EXTERNAL_SUBTITLE_OFFSET_LIMIT,EXTERNAL_SUBTITLE_OFFSET_LIMIT)
    fun save(key:String,offset:Long) {
        require(key.matches(Regex("[a-f0-9]{64}")))
        synchronized(lock) {
            val edit=prefs.edit()
            if(offset==0L)edit.remove("v:$key").remove("t:$key")
            else edit.putLong("v:$key",offset.coerceIn(-EXTERNAL_SUBTITLE_OFFSET_LIMIT,EXTERNAL_SUBTITLE_OFFSET_LIMIT)).remove("t:$key")
            edit.apply()
        }
    }
    companion object {private val lock=Any()}
}
