package br.com.flaviotorres.iptvpremium.core.player

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Chave individual do SubSource: criptografada pelo Android Keystore, fora do backup. */
internal class SubsourceCredentialStore(context: Context) {
    private val appContext = context.applicationContext
    private val credentialFile = File(appContext.noBackupFilesDir, "iptvpremium_subsource_account_v2.bin")
    private val alias = "iptvpremium_subsource_secret_v2"

    fun isConfigured(): Boolean = readKey() != null

    fun readKey(): String? = synchronized(lock) { runCatching {
        val stored = DataInputStream(android.util.AtomicFile(credentialFile).openRead()).use { input ->
            if (input.readInt() != 1) return@use null
            val iv = ByteArray(12)
            input.readFully(iv)
            val encryptedLength = input.readInt()
            if (encryptedLength !in 17..2048) return@use null
            val encrypted = ByteArray(encryptedLength)
            input.readFully(encrypted)
            iv to encrypted
        } ?: return@runCatching null
        val secret = getOrCreateKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secret, GCMParameterSpec(128, stored.first))
        val decoded = String(cipher.doFinal(stored.second), Charsets.UTF_8).trim()
        decoded.takeIf { it.isNotEmpty() }
    }.getOrNull() }

    private fun saveKey(value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val file=android.util.AtomicFile(credentialFile)
        val stream=file.startWrite()
        try {
            val out=DataOutputStream(stream)
            out.writeInt(1);out.write(cipher.iv);out.writeInt(encrypted.size);out.write(encrypted);out.flush()
            file.finishWrite(stream)
        }catch(error:Exception){file.failWrite(stream);throw error}
    }

    /** Portal delivery stores a personal key without spending provider requests. */
    fun saveKeyFromPortal(raw: String): Boolean = synchronized(lock) {
        val value = raw.trim()
        if (value.length !in 8..512 || value.any { it.isWhitespace() || it.isISOControl() }) return@synchronized false
        runCatching { saveKey(value); readKey() == value }.getOrDefault(false)
    }

    fun disconnect() { synchronized(lock) { android.util.AtomicFile(credentialFile).delete() } }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(false)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    companion object { private val lock=Any() }
}
