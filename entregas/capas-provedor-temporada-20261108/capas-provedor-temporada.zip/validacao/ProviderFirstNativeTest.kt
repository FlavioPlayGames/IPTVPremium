package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.m3u.*
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.*
import java.io.*
import java.nio.file.Files
fun main(){
 val root=Files.createTempDirectory("native-provider-first").toFile()
 fun covers(names:List<String>):List<String?> {
  val g=java.util.UUID.randomUUID().toString();val source=DeferredM3uEpisodes(File(root,g)).begin("p",g);val bytes=ByteArrayOutputStream()
  val input=buildString{appendLine("#EXTM3U");names.forEachIndexed{i,n->appendLine("#EXTINF:-1 group-title=\"Series $i\" tvg-logo=\"http://example.invalid/shared.jpg\",$n S01E01");appendLine("http://example.invalid/series/$i")}}
  M3uCatalogParser.prepare(input.reader().buffered(),DataOutputStream(bytes),"p",g,episodeSource=source);source.finish()
  return DataInputStream(ByteArrayInputStream(bytes.toByteArray())).use{r->check(r.readInt()==0x4D335331);buildList{while(true){val (kind,row)=M3uCatalogParser.read(r)?:break;if(kind==3)add(row[5]as String?)}}}
 }
 try{
  check(covers(listOf("Show (2017)","Show (2020)"))==listOf("http://example.invalid/shared.jpg","http://example.invalid/shared.jpg"));println("PASS provider-first M3U keeps supplied logos even when the provider shares them across different works")
  check(covers(listOf("O Conto da Aia","O Conto da Aia 2017 (2017)"))==listOf("http://example.invalid/shared.jpg","http://example.invalid/shared.jpg"));println("PASS compatible editions of the same work retain their own stable identical provider image")
 }finally{root.deleteRecursively()}
}
