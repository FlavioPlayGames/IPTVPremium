package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.repository.*
import kotlinx.coroutines.runBlocking
import org.json.*
fun main()=runBlocking {
 check(SeriesCatalogPosterResolver.cached("Never Played",2020,null,null,2)==null)
 println("PASS no prepared metadata returns immediately without requiring a TMDB client or remote lookup")
 val root=JSONObject().put("id",86001).put("name","Played Provider Work").put("original_name","Played Provider Work").put("first_air_date","2020-01-01").put("poster_path","/general.jpg")
  .put("seasons",JSONArray().put(JSONObject().put("season_number",2).put("poster_path","/season-two.jpg")))
 var calls=0
 val get:suspend(String,Map<String,String>)->String={p,_->calls++;if(p=="/search/tv")JSONObject().put("results",JSONArray().put(root)).toString()else root.toString()}
 val warmed=SeriesCatalogPosterResolver.resolve("Played Provider Work",2020,null,null,get,2)
 check(warmed?.isSeason==true&&warmed.url.endsWith("/season-two.jpg")&&calls==2)
 val prepared=SeriesCatalogPosterResolver.cached("Played Provider Work",2020,null,null,2)
 check(prepared?.url==warmed.url&&prepared?.isSeason==true&&calls==2)
 println("PASS metadata prepared while playing is reused locally with its exact season poster")
 check(SeriesCatalogPosterResolver.cached("Played Provider Work",2020,null,null,99)?.isSeason==false)
 check(SeriesCatalogPosterResolver.peek("Played Provider Work",2020,null,null)?.isSeason==false)
 println("PASS missing season and general artwork cannot be mistaken for a verified seasonal override")
 Unit
}
