from pathlib import Path
b=Path('/workspace/backup-reviewed-build/app/src/main/java/br/com/flaviotorres/iptvpremium')
s=(b/'ui/movies/CatalogPosterFallback.kt').read_text()
catalog=s.split('internal suspend fun loadCatalogPoster')[1].split('/** Called after')[0]
assert 'SeriesCatalogPosterResolver.resolve('not in catalog and 'TmdbClientProvider'not in catalog
assert 'kind!=PosterKind.SERIES||season==null' in catalog
assert catalog.index('provider?.let(onProviderReady)')<catalog.index('return prepared?.let')
assert '.cached('in catalog and 'it.isSeason'in catalog
print('PASS catalogue never searches TMDB; unseen series use provider directly; watched series retain provider until seasonal image is ready')
for name in ['ui/components/UnifiedMediaCatalog.kt','ui/kids/KidsMediaCatalog.kt','core/navigation/player/PlaybackCatalogBrowser.kt']:
 s=(b/name).read_text();assert 'onProviderReady='in s and 'SeasonPosterRevision.collectAsState()'in s
 print('PASS provider bitmap can paint before seasonal replacement and playback warmup can refresh '+name)
s=(b/'core/navigation/player/PlaybackScreen.kt').read_text()
assert 'if(media.type==PlaybackContentType.EPISODE)'in s and 'it.status==PlaybackStatus.PLAYING && it.media?.id==media.id && it.media.streamUrl==media.streamUrl'in s
assert s.index('delay(1_500L)')<s.index('episodePlayingCallback()')
assert 'catch(cancelled:kotlinx.coroutines.CancellationException){throw cancelled}'in s and 'catch(_:Exception)'in s
print('PASS optional artwork starts only after the matching episode reports PLAYING, with a delay and media-scoped cancellation')
s=(b/'core/navigation/AppNavigation.kt').read_text()
assert 'getSeriesById(currentPlaylistId,watchedSeries)'in s and 'warmPlayingSeasonPoster(context.applicationContext,it.name,it.year,it.tmdbId,it.imdbId,watchedSeason)'in s
print('PASS playback artwork uses actual catalogue identity so subsequent catalogue keys agree')
s=(b/'ui/movies/CategoryPosterPrefetch.kt').read_text();assert 'kind==PosterKind.SERIES'not in s
print('PASS existing bounded provider image prefetch is restored for series')
