package br.com.flaviotorres.iptvpremium.core.storage

import android.content.Context

internal object ImageDiskCache {
    @Volatile private var instance: ImageDiskBudget? = null
    fun get(context: Context): ImageDiskBudget = instance ?: synchronized(this) {
        instance ?: ImageDiskBudget(context.applicationContext.cacheDir).also { instance = it }
    }
}
