Os testes Kotlin foram compilados com o compilador embutido no Gradle 9.6.0 e executados na JVM.

BudgetTest.kt deve ser compilado junto de arquivos/app/src/main/java/br/com/flaviotorres/iptvpremium/core/storage/ImageDiskBudget.kt.

GenerationTest.kt deve ser compilado junto do gerenciador, DAO e entidades reais em arquivos/app/src/main/java/br/com/flaviotorres/iptvpremium/data/cache, dos stubs de anotação/Paging/Log/Clock nesta pasta e do kotlinx-coroutines-core-jvm. Os stubs são exclusivos deste teste JVM e não são instalados no app.

A compilação do aplicativo real também foi executada pelo Gradle, incluindo a geração do Room. Os testes auxiliares não substituem medição de armazenamento e desempenho no aparelho.
