package br.com.flaviotorres.iptvpremium.core.storage

import java.io.File
import java.nio.file.Files
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

private var tests = 0
private fun scenario(name: String, test: (File) -> Unit) {
    val root = Files.createTempDirectory("image-budget-test").toFile()
    try { test(root); tests++; println("PASS $name") } finally { root.deleteRecursively() }
}
private fun image(root: File, dir: String, name: String, size: Int, time: Long = 1): File =
    File(root, "$dir/$name.img").apply { parentFile.mkdirs(); writeBytes(ByteArray(size) { 73 }); setLastModified(time) }
private const val POSTERS = "iptv_movie_posters_session"
private const val DETAILS = "movie_details_images"
fun main() {
    scenario("combined budget and oldest-first across directories") { r ->
        val old = image(r, DETAILS, "old", 60, 1)
        val fresh = image(r, POSTERS, "fresh", 60, 2)
        check(ImageDiskBudget(r, 100).maintain() == 60L)
        check(!old.exists() && fresh.readBytes().all { it == 73.toByte() })
    }
    scenario("multiple readers protect a file until last release") { r ->
        val f = image(r, POSTERS, "busy", 120)
        val budget = ImageDiskBudget(r, 100)
        val a = budget.retain(f); val b = budget.retain(f)
        budget.maintain(); check(f.exists())
        a.close(); a.close(); budget.maintain(); check(f.exists())
        b.close(); budget.maintain(); check(!f.exists())
    }
    scenario("download over budget is trimmed immediately after decode lease") { r ->
        val f = File(r, "$DETAILS/new.img"); f.parentFile.mkdirs()
        val budget = ImageDiskBudget(r, 100)
        budget.retain(f).use {
            f.writeBytes(ByteArray(120)); budget.maintain(); check(f.exists())
        }
        check(!f.exists())
    }
    scenario("partials count but are never deleted by LRU") { r ->
        val f = image(r, DETAILS, "old", 50)
        val partial = File(f.parentFile, "carousel_pending.tmp").apply { writeBytes(ByteArray(80)) }
        ImageDiskBudget(r, 100).maintain()
        check(!f.exists() && partial.length() == 80L)
    }
    scenario("other app data and source artwork are untouched") { r ->
        val data = File(r, "../${r.name}-outside").apply { mkdirs() }
        try {
            val keep = File(data, "catalog.db").apply { writeText("preserve") }
            val unknown = File(r, "$DETAILS/art.webp").apply { parentFile.mkdirs(); writeText("original") }
            image(r, POSTERS, "old", 200)
            ImageDiskBudget(r, 100).maintain()
            check(keep.readText() == "preserve" && unknown.readText() == "original")
        } finally { data.deleteRecursively() }
    }
    scenario("Home preference does not turn into unlimited pinned storage") { r ->
        val home = image(r, POSTERS, "home", 60, 1)
        val other = image(r, DETAILS, "other", 60, 2)
        val budget = ImageDiskBudget(r, 100)
        budget.prefer(setOf(home.name)); budget.maintain()
        check(home.exists() && !other.exists())
        val large = image(r, POSTERS, "home", 150)
        budget.maintain(); check(!large.exists())
    }
    scenario("failed write and exception release a lease") { r ->
        val f = image(r, DETAILS, "failed", 120)
        val budget = ImageDiskBudget(r, 100)
        runCatching { budget.retain(f).use { error("interrupted") } }
        budget.maintain(); check(!f.exists())
    }
    scenario("external deletion recovers accounting") { r ->
        val old = image(r, POSTERS, "old", 60)
        val fresh = image(r, DETAILS, "fresh", 60, 2)
        old.delete(); ImageDiskBudget(r, 100).maintain()
        check(fresh.exists())
    }
    scenario("24 parallel readers and writer leases survive concurrent eviction") { r ->
        val budget = ImageDiskBudget(r, 100)
        val pool = Executors.newFixedThreadPool(8)
        val start = CountDownLatch(1)
        try {
            val futures = (0 until 24).map { i -> pool.submit {
                start.await()
                val f = File(r, "${if (i % 2 == 0) POSTERS else DETAILS}/$i.img")
                f.parentFile.mkdirs()
                budget.retain(f).use {
                    f.writeBytes(ByteArray(30) { i.toByte() })
                    repeat(5) { budget.maintain(); check(f.length() == 30L) }
                }
            } }
            start.countDown(); futures.forEach { it.get(20, TimeUnit.SECONDS) }
            budget.maintain()
            check(r.walkTopDown().filter { it.isFile }.sumOf { it.length() } <= 100L)
        } finally { pool.shutdownNow() }
    }
    scenario("last reader release retries a previously blocked trim") { r ->
        val f = image(r, DETAILS, "busy", 120)
        val budget = ImageDiskBudget(r, 100)
        val a = budget.retain(f); val b = budget.retain(f)
        a.close(); check(f.exists()); b.close(); check(!f.exists())
    }
    scenario("orphan cleanup respects age, exact names and active directories") { r ->
        val dir = File(r, DETAILS).apply { mkdirs() }
        val old = File(dir, "loading_old.tmp").apply { writeText("old"); setLastModified(1) }
        val recent = File(dir, "carousel_recent.tmp").apply { writeText("new"); setLastModified(5000) }
        val unknown = File(dir, "unrecognized.tmp").apply { writeText("keep"); setLastModified(1) }
        val budget = ImageDiskBudget(r, 100)
        budget.retain(File(dir, "busy.img")).use {
            check(budget.cleanupAbandonedTemporaries(2000) == 0 && old.exists())
        }
        check(budget.cleanupAbandonedTemporaries(2000) == 1)
        check(!old.exists() && recent.exists() && unknown.exists())
    }
    println("$tests storage scenarios passed")
}
