param([string]$Serial = '', [string]$AdbPath = '')
$ErrorActionPreference = 'Stop'
if (-not $AdbPath) {
    $AdbPath = Join-Path $env:LOCALAPPDATA 'Android\Sdk\platform-tools\adb.exe'
    if (-not (Test-Path -LiteralPath $AdbPath)) {
        $found = Get-Command adb -ErrorAction SilentlyContinue
        if ($found) { $AdbPath = $found.Source }
    }
}
if (-not (Test-Path -LiteralPath $AdbPath)) { throw 'ADB nao encontrado. Informe -AdbPath com o caminho do adb.exe.' }
$devices = @(& $AdbPath devices | ForEach-Object { if ($_ -match '^(\S+)\s+device$') { $Matches[1] } })
if (-not $Serial) {
    if ($devices.Count -ne 1) { throw ('Conecte um aparelho com depuracao USB autorizada ou informe -Serial. Aparelhos: ' + ($devices -join ', ')) }
    $Serial = $devices[0]
}
if ($Serial -notin $devices) { throw 'Aparelho nao conectado ou depuracao USB nao autorizada.' }
$target = @('-s', $Serial)
$package = 'br.com.flaviotorres.iptvpremium'
$report = [System.Collections.Generic.List[string]]::new()
$report.Add('IPTV Premium - medicao somente de tamanhos (KiB = 1024 bytes)')
$report.Add('Pastas e subpastas se sobrepoem: nao somar todas as linhas.')
# Native stderr differs between Windows PowerShell and PowerShell 7. Capture it without treating it as a script failure.
$prior = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$raw = @(& $AdbPath @target shell run-as $package du -sk databases files shared_prefs no_backup cache code_cache cache/iptv_movie_posters_session cache/movie_details_images cache/updates files/iptv_subtitles_lru_5mb databases/playlist_cache.db databases/playlist_cache.db-wal databases/playlist_cache.db-shm 2>&1)
$ErrorActionPreference = $prior
$rows = @($raw | ForEach-Object { $line = $_.ToString(); if ($line -match '^\s*\d+\s+(databases|files|shared_prefs|no_backup|cache|code_cache)(/[^\s]+)?\s*$') { $line } })
if ($rows.Count) { $report.AddRange([string[]]$rows) }
else { $report.Add('Medicao privada indisponivel (run-as requer APK debug). Use os registros abaixo apos instalar a correcao e abrir o app por pelo menos 30 segundos.') }
$logs = @(& $AdbPath @target logcat -d -s 'IPTVStorage:I' '*:S')
# Only our numeric diagnostics. Never export the general logcat.
$report.Add('Diagnostico do app: valores em bytes; before/after indicam a limpeza de catalogos.')
foreach ($line in $logs) {
    if ($line -match 'IPTVStorage.*phase=(before|after)\s+(databases=|db_main=)') { $report.Add($line.ToString()) }
}
$out = Join-Path $PSScriptRoot ('armazenamento-' + (Get-Date -Format 'yyyyMMdd-HHmmss') + '.txt')
$report | Set-Content -LiteralPath $out -Encoding UTF8
$report | ForEach-Object { Write-Host $_ }
Write-Host ('Relatorio salvo: ' + $out)
Write-Host 'Este script nao limpa dados, nao para o aplicativo e nao modifica o aparelho.'
