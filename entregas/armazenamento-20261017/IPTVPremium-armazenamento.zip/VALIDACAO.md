# Validação da correção de armazenamento

## Testes aprovados

- **11 cenários do orçamento de imagens**, executando o `ImageDiskBudget` real: limite combinado entre pastas, ordem de remoção, múltiplos leitores, liberação após download, contabilização de temporários, preservação de outros dados, preferência limitada da Home, exceções, remoção externa, 24 acessos paralelos, nova tentativa após liberar o último leitor e limpeza de temporários por idade/nome/uso.
- **6 cenários de catálogo**, executando o gerenciador e a interface DAO reais com persistência simulada: remoção de várias gerações/listas, preservação de ACTIVE/READY, proteção de importação ativa mesmo após 48 horas, remoção de importação abandonada, retomada após cancelamento e falha, 16 pedidos simultâneos sem selecionar a mesma geração duas vezes.
- **1 consulta real em SQLite**: a nova consulta seleciona listas distintas com STALE/importações antigas e exclui ACTIVE, READY e importações recentes.
- **5 cenários do instalador**, executando o PowerShell: verificação sem alteração, aplicação com hashes corretos, reaplicação idempotente, rejeição de versão diferente sem mudar fontes e restauração após falha simulada de cópia.
- **1 cenário do relatório**, executando o PowerShell com ADB simulado: coleta tamanhos e diagnósticos numéricos e exclui registros de outros componentes.

Total: 24 cenários. Os testes do gerenciador não substituem testes de integração em um banco Android real. Os scripts foram executados no PowerShell 7.5.4 em Linux, não em Windows nem no aparelho do usuário.

## Compilação

- `:app:compileDebugKotlin`: **aprovado**, incluindo KSP/Room e a geração da implementação do DAO.
- `assembleDebug`: **aprovado**, 40 tarefas (31 executadas, 9 atualizadas).

Toolchain: Gradle 9.6.0 e JDK 25; SDK e dependências nas versões declaradas pelo projeto. Os componentes foram obtidos por HTTPS com validação de certificados e checksums oficiais. Nenhuma versão do projeto foi trocada para fazer a compilação passar. O sdk.dir foi ajustado somente na cópia de compilação em nuvem; local.properties não é entregue no pacote.

## Preservação

Comparação byte a byte confirmou os recursos em `app/src/main/res`, os 50 arquivos do diretório do player e `M3uSourceSynchronizer.kt` sem alterações. O pacote contém 6 arquivos Kotlin existentes alterados e 4 novos, além de documentação, verificação e medição. Os recursos não foram recomprimidos e nenhum filtro de cor foi aplicado.

## O que falta medir no aparelho

- Tamanho real do banco, WAL, páginas livres, caches e atualizações.
- Espaço antes/depois e estabilidade após várias sincronizações com as mesmas listas.
- Tempo de carregamento, rolagem e retomada na TV/celular.
- Espaço de pico durante importação e atualização do APK.

Não foi afirmado ganho de velocidade, economia numérica real ou cumprimento do teto de 300 MB sem esses dados. Não foi executado VACUUM automático. As instruções de inicialização do ambiente de desenvolvimento foram salvas no campo start_skill para reutilização; isso não publica o ambiente nem o aplicativo.
