# IPTV Premium — armazenamento

Pacote preparado exclusivamente para o `projeto.zip` enviado nesta conversa. Não substitui local.properties, google-services.json, configurações de assinatura, versões do Gradle/SDK ou recursos visuais.

## Como aplicar

1. Extraia todo o conteúdo deste ZIP na raiz do seu projeto, junto de `gradlew.bat` e `settings.gradle.kts`.
2. Se possível, conecte o celular com depuração USB autorizada e gere o relatório **antes de instalar o app corrigido**:

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Medir-armazenamento.ps1
   ```

   O script apenas consulta tamanhos e registros específicos do diagnóstico. Não limpa dados nem altera o aparelho. A consulta das pastas privadas exige APK debug; em APK release, o diagnóstico numérico passa a ficar disponível após instalar esta correção. Com mais de um aparelho conectado, informe `-Serial CODIGO_DO_APARELHO`.

3. Aplique o pacote:

   ```powershell
   powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Aplicar-armazenamento.ps1
   .\gradlew.bat assembleDebug
   ```

   O instalador confere todos os arquivos antes de modificar qualquer código, salva backup dos arquivos anteriores em `.iptv-backups/armazenamento-*` e restaura os arquivos caso a cópia falhe. Uma segunda aplicação não duplica alterações. A opção `-Verificar` confere sem instalar. Se a versão for diferente, ele interrompe sem alterar o projeto.

4. Instale o APK da mesma variante por cima da versão atual, mantendo a assinatura. Não desinstale nem use “Limpar dados”, pois precisamos preservar e medir os dados existentes.
5. Abra o aplicativo, aguarde pelo menos 30 segundos e execute novamente `Medir-armazenamento.ps1`. A limpeza de um catálogo grande pode levar mais tempo, pois ocorre em lotes com pausas. O registro `phase=after` indica conclusão da passagem.
6. Envie o TXT gerado e uma nova captura da tela de armazenamento. Se houver atualizações grandes de catálogo, repita a medição depois para verificar se o crescimento estabilizou.

## O que mudou

- Capas, detalhes e imagens da Home compartilham um orçamento de **64 MiB em disco**, usando as pastas existentes.
- Os arquivos de imagem continuam com os mesmos bytes e qualidade. O cache em RAM e a resolução de decodificação foram mantidos.
- Arquivos em download/decodificação não são apagados pela limpeza. As capas da Home recebem prioridade, sem criar uma reserva ilimitada.
- Temporários entram na contabilização. Transferências simultâneas podem exceder o orçamento temporariamente; a liberação dos arquivos em uso tenta novamente a limpeza. Temporários reconhecidos, abandonados há mais de 24 horas, são removidos apenas em pastas sem arquivos em uso.
- A limpeza dos catálogos trabalha em segundo plano, em lotes, percorre todas as listas com gerações elegíveis e não é cancelada por navegação ou nova sincronização.
- A versão ativa, as versões READY e as importações em andamento são preservadas. Importações abandonadas há mais de 24 horas continuam protegidas por uma licença de uso do processo quando estiverem em andamento.
- A manutenção começa após 15 segundos na primeira abertura, reúne pedidos repetidos e verifica pendências novamente a cada 15 minutos enquanto o processo estiver vivo. Se o Android encerrar o processo, a próxima abertura retoma a limpeza.
- O diagnóstico registra apenas totais por pasta, tamanho do banco/WAL, páginas livres e contagem de gerações por estado. Não registra conteúdo das listas, URLs, credenciais, PIN ou nomes dos provedores.

## Decisões preservadas

Não houve alterações no player, teclado, temas, ícones, favoritos, histórico ou SharedSync. As legendas mantêm o limite de 5 MiB. O atualizador já remove temporários e limpa arquivos conforme sua política; não foi acrescentada limpeza que possa apagar um APK enquanto o instalador o utiliza. A pasta de atualizações aparece na medição.

Não foi adicionado VACUUM automático nem excluído catálogo ativo para tentar atingir 300 MB. Precisamos medir quanto do banco está ocupado por dados válidos e quanto é espaço reutilizável antes de decidir compactação. A compactação pode exigir espaço temporário e não deve ocorrer a cada abertura.

## Limite de 300 MB

A tela enviada mostra 131 MB de aplicativo e 594 MB de dados, totalizando 725 MB. O cache de 79,15 MB aparentemente já está incluído nos dados. Mesmo apagando esse cache inteiro, restariam cerca de 646 MB.

Por isso, este pacote corrige os caminhos de crescimento identificados, mas **não promete que o aparelho ficará abaixo de 300 MB**. O tamanho dos catálogos ativos, o espaço reutilizável do SQLite e os picos de importação/atualização ainda precisam ser medidos no celular. Imagens antigas removidas do cache serão baixadas novamente ao serem revisitadas.

## Verificação

Consulte `VALIDACAO.md` para os testes executados e seus limites. Os testes auxiliares ficam em `validacao/`; eles não entram no APK.
