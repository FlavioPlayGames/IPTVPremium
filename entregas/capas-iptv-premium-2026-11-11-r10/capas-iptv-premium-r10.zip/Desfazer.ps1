﻿param([Parameter(Mandatory=$true)][string]$Backup)
$ErrorActionPreference='Stop'
. "$PSScriptRoot\Seguranca.ps1"
$estado=Get-Content -Raw -LiteralPath (Join-Path $Backup 'estado.json')|ConvertFrom-Json
if($estado.desfeito){Write-Host 'Backup ja restaurado.';return}
$raiz=Projeto-Valido $estado.projeto
foreach($item in $estado.arquivos) {
    $p=Caminho-Seguro $raiz $item.path
    if((Test-Path -LiteralPath $p) -and !(Test-Path -LiteralPath $p -PathType Leaf)){throw 'Destino inesperado na restauracao.'}
    if((Hash-Arquivo $p) -ne $item.afterHash){throw "Arquivo mudou depois da limpeza: $($item.path)"}
    if((Hash-Arquivo (Join-Path "$Backup\arquivos" $item.path)) -ne $item.beforeHash){throw 'Backup nao confere.'}
}
foreach($item in $estado.arquivos){
    $p=Join-Path $raiz $item.path
    if($null -eq $item.beforeHash){Remove-Item -LiteralPath $p -Force}
    else {Copy-Item -LiteralPath (Join-Path "$Backup\arquivos" $item.path) -Destination $p -Force}
}
$estado.desfeito=$true
$estado|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $Backup 'estado.json') -Encoding UTF8
Write-Host 'Fontes e recursos restaurados. Recompile para restaurar o APK.'
