package br.com.flaviotorres.iptvpremium.data.cache.dao
import br.com.flaviotorres.iptvpremium.data.history.*
data class Generation(val generationId:String)
data class MovieRow(val name:String,val year:Int?,val streamUrl:String)
data class SeriesRow(val name:String,val year:Int?,val imdbId:String?,val tmdbId:String?)
class PlaylistCacheDao {
 val movies=mutableMapOf<String,List<SharedCatalogIdentity>>()
 val series=mutableMapOf<String,List<SharedCatalogIdentity>>()
 var generation="g"
 var pageReads=0
 suspend fun handoffMoviePage(playlist:String,generation:String,after:String)=movies[playlist].orEmpty().filter{it.contentId>after}.sortedBy{it.contentId}.take(256).also{pageReads++}
 suspend fun handoffSeriesPage(playlist:String,generation:String,after:String)=series[playlist].orEmpty().filter{it.contentId>after}.sortedBy{it.contentId}.take(256).also{pageReads++}
 suspend fun getActiveGeneration(playlist:String)=Generation(generation)
 suspend fun getActiveMovieById(playlist:String,id:String)=movies[playlist].orEmpty().firstOrNull{it.contentId==id}?.let{MovieRow(it.title,it.year,it.streamUrl.orEmpty())}
 suspend fun getParentalSeriesById(playlist:String,generation:String,id:String)=series[playlist].orEmpty().firstOrNull{it.contentId==id}?.let{SeriesRow(it.title,it.year,it.imdb,it.tmdb)}
}
