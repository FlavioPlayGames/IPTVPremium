package br.com.flaviotorres.iptvpremium.ui.movies
import android.content.Context
import androidx.compose.ui.graphics.ImageBitmap
import br.com.flaviotorres.iptvpremium.data.cache.PosterKind
internal object MoviePosterLoader {
 val compressed=java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
 suspend fun prefetch(context:Context,url:String?,kind:PosterKind,duringNavigation:Boolean):Boolean {
  if(url==null||url in broken)return false
  compressed.add(url);return true
 }
 var beforeLoad: (suspend (String)->Unit)? = null
 private val bitmaps=java.util.concurrent.ConcurrentHashMap<String,ImageBitmap>()
 fun peekBitmap(url:String?):ImageBitmap?=url?.let{bitmaps[it]}
 val broken=java.util.concurrent.ConcurrentHashMap.newKeySet<String>()
 fun knownMissing(url:String?)=url==null||url in broken
 suspend fun loadCached(context:Context,url:String?,kind:PosterKind=PosterKind.MOVIES):ImageBitmap?=peekBitmap(url)
 suspend fun loadWithRetry(context:Context,url:String?,kind:PosterKind):ImageBitmap? = url?.takeIf{it !in broken && (it.startsWith("https://")||it.startsWith("http://"))}?.let{beforeLoad?.invoke(it);bitmaps.getOrPut(it){ImageBitmap(it)}}
}
