package br.com.flaviotorres.iptvpremium.ui.movies
import android.content.Context
import br.com.flaviotorres.iptvpremium.data.cache.*
import br.com.flaviotorres.iptvpremium.data.remote.TmdbClientProvider
import br.com.flaviotorres.iptvpremium.data.repository.CatalogMetadataDiskCache
import kotlinx.coroutines.*
import java.nio.file.Files
fun main()=runBlocking {
 val context=Context(Files.createTempDirectory("iptv-visible-cache-").toFile());CatalogMetadataDiskCache.initialize(context)
 val api=TmdbClientProvider.client
 val provider="https://provider.example/series.jpg"
 val first=loadCatalogPoster(context,provider,PosterKind.SERIES,"Show123",2024,"123",null)
 check(first?.url==provider && api.requests.get()==0)
 val verified=loadCatalogPoster(context,null,PosterKind.SERIES,"Show123",2024,"123",null)
 check(verified?.url=="https://image.tmdb.org/t/p/w500/general123.jpg" && api.requests.get()==1)
 val season=loadCatalogPoster(context,null,PosterKind.SERIES,"Show123",2024,"123",null,1)
 check(season?.url?.endsWith("/season123.jpg")==true && api.requests.get()==1)
 val missingSeason=loadCatalogPoster(context,provider,PosterKind.SERIES,"Show123",2024,"123",null,9)
 check(missingSeason?.url==provider && api.requests.get()==1)
 check(peekCatalogPoster(null,PosterKind.SERIES,"Show123",2024,"123",null)?.url==verified.url)
 check(loadCatalogPoster(context,null,PosterKind.SERIES,"Wrong work",2024,"456",null)==null)
 val canonical=br.com.flaviotorres.iptvpremium.data.repository.SeriesCatalogPosterResolver.resolve("Show700",null,null,null,api::get,1)
 check(canonical?.url?.endsWith("/season700.jpg")==true)
 val beforeCanonical=api.requests.get()
 check(loadCatalogPoster(context,provider,PosterKind.SERIES,"Show700",2024,"700",null,1)?.url==provider)
 check(loadCatalogPoster(context,provider,PosterKind.SERIES,"Show700",null,null,null,1)?.url?.endsWith("/season700.jpg")==true)
 check(api.requests.get()==beforeCanonical)
 println("PASS: exact nullable catalogue identity reuses the playing-season cache without legacy ID/year contamination")
 println("PASS: provider first, verified missing-cover fallback, season cache reuse, wrong-work rejection")
 val before=api.requests.get();MediaOpeningPriority.busy.value=true
 val waiting=async{loadCatalogPoster(context,null,PosterKind.SERIES,"Show900",2024,"900",null)}
 delay(80);check(api.requests.get()==before);MediaOpeningPriority.busy.value=false;check(waiting.await()!=null)
 CatalogImportPriority.busy.value=true;val beforeImport=api.requests.get()
 val importing=async{loadCatalogPoster(context,null,PosterKind.SERIES,"Show901",2024,"901",null)}
 delay(80);check(api.requests.get()==beforeImport);CatalogImportPriority.busy.value=false;check(importing.await()!=null)
 coroutineScope{(200..207).map{id->async{loadCatalogPoster(context,null,PosterKind.SERIES,"Show$id",2024,id.toString(),null)}}.awaitAll()}
 check(api.peak.get()<=2)
 println("PASS: optional artwork waits for video/import priority; at most two verified lookups at once")
 testPosterNames()
 val blocked=CompletableDeferred<Unit>();val imageStarted=java.util.concurrent.atomic.AtomicInteger()
 MoviePosterLoader.beforeLoad={url->if(url.contains("general80")){imageStarted.incrementAndGet();blocked.await()}}
 val beforePipeline=api.requests.get()
 val pipeline=(800..803).map{id->async {loadCatalogPoster(context,null,PosterKind.SERIES,"Show$id",2024,id.toString(),null)}}
 withTimeout(3_000){while(api.requests.get()<beforePipeline+4 || imageStarted.get()<4)delay(10)}
 check(pipeline.none{it.isCompleted})
 blocked.complete(Unit);pipeline.awaitAll();MoviePosterLoader.beforeLoad=null
 println("PASS: four image downloads can wait while all four identities resolve; slow images release metadata slots")
 val beforePrefetch=api.requests.get()
 val ahead=prefetchCatalogPoster(context,PosterKind.SERIES,PosterCandidate(null,"Show850",2024,"850"))
 check(ahead?.endsWith("general850.jpg")==true && api.requests.get()==beforePrefetch+1)
 check(ahead in MoviePosterLoader.compressed && MoviePosterLoader.peekBitmap(ahead)==null)
 check(loadCatalogPoster(context,null,PosterKind.SERIES,"Show850",2024,"850",null)!=null)
 check(api.requests.get()==beforePrefetch+1)
 for(kind in PosterKind.entries) {
  val source="https://provider.example/${kind.name}.jpg"
  val before=api.requests.get()
  check(prefetchCatalogPoster(context,kind,PosterCandidate(source,"Provider"))==source)
  check(api.requests.get()==before)
 }
 println("PASS: off-screen missing M3U series resolves and stores compressed artwork; visible card reuses identity; both media kinds keep provider covers")
 context.cacheDir.deleteRecursively()
 Unit
}
