package br.com.flaviotorres.iptvpremium.data.cache

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*

/** Each card observes its own placement, independently of paging/history/category snapshots. */
internal suspend fun <T> loadWhilePosterVisible(visible: Flow<Boolean>, load: suspend () -> T): T = channelFlow {
    visible.distinctUntilChanged().collectLatest { placed ->
        if (placed) send(load())
    }
}.first()

/** Disconnect blocking HTTP on coroutine cancellation, including a category/viewport change. */
internal fun CoroutineScope.interruptPosterDownload(disconnect: () -> Unit): Job =
    launch(Dispatchers.IO, start = CoroutineStart.UNDISPATCHED) {
        try { awaitCancellation() }
        finally { runCatching(disconnect) }
    }

/** Keep failed cards reactive to re-entry/background completion, with one bounded transient retry. */
internal suspend fun <T> observeWhilePosterVisible(visible:Flow<Boolean>,updates:Flow<Unit>,
    load:suspend()->T,onResult:(T)->Unit) {
    combine(visible.distinctUntilChanged(),updates.onStart{emit(Unit)}) {placed,_->placed}.collectLatest { placed ->
        if(placed)for(attempt in 0..1) {
            val result=load()
            onResult(result)
            if(result!=null)break
            if(attempt==0)delay(1_500L)
        }
    }
}
