package br.com.flaviotorres.iptvpremium.data.cache

import java.net.URI

/** Select a usable image address, never an empty/placeholder value instead of a later cover. */
internal fun posterSourceUrl(raw:String?):String? {
    val value=raw?.trim()?.takeIf{it.isNotEmpty()}?.let{if(it.startsWith("//"))"https:$it"else it}?:return null
    val uri=try{URI(value.replace(" ","%20"))}catch(_:Exception){return null}
    if(!uri.scheme.equals("https",true)&&!uri.scheme.equals("http",true))return null
    if(uri.host.isNullOrBlank())return null
    return uri.toASCIIString()
}

/** Fetch a thumbnail near the 300x450 storage size; cache identity remains the provider's URL. */
internal fun posterDownloadUrl(raw:String):String {
    val uri=try{URI(raw)}catch(_:Exception){return raw}
    if(!uri.host.equals("image.tmdb.org",true)||uri.rawUserInfo!=null||uri.port !in listOf(-1,80,443))return raw
    val path=uri.rawPath?:return raw
    val match=Regex("^/t/p/(original|w([0-9]+)(?:_and_h[0-9]+_bestv2)?)/[^/]+$").matchEntire(path)?:return raw
    val size=match.groupValues[1]
    if(size!="original"&&(match.groupValues[2].toIntOrNull()?:return raw)<=342)return raw
    val start=raw.indexOf(path,raw.indexOf("://")+3)
    if(start<0)return raw
    return raw.replaceRange(start,start+path.length,path.replaceRange(5,5+size.length,"w342"))
}
