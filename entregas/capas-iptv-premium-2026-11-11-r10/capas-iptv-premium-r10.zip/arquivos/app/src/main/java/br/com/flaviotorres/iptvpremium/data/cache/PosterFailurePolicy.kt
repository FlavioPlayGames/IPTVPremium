package br.com.flaviotorres.iptvpremium.data.cache

/** Only definitive missing/invalid images warrant a long suppression; never timeouts or priority gates. */
internal fun persistentPosterFailure(outcome:String,httpStatus:Int):Boolean =
    outcome=="http_status"&&httpStatus in listOf(404,410) || outcome=="image_too_large"
