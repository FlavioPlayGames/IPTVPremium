﻿[CmdletBinding()]
param([string]$Site="$env:USERPROFILE\AndroidStudioProjects\Site IPTV",[string]$Downloads="$env:USERPROFILE\Downloads")
$ErrorActionPreference='Stop'
$items=Get-Content -LiteralPath "$PSScriptRoot\manifesto.json" -Raw|ConvertFrom-Json
$items=@($items|ForEach-Object {$_})
if(!$items.Count){throw 'Manifesto vazio.'}
$pending=@()
foreach($item in $items){
 $payload=Join-Path "$PSScriptRoot\arquivos" ([string]$item.path)
 if(!(Test-Path -LiteralPath $payload -PathType Leaf) -or (Get-FileHash -LiteralPath $payload -Algorithm SHA256).Hash -ne $item.after){throw "Pacote invalido: $($item.path)"}
 $path=Join-Path $Site ([string]$item.path)
 $actual=$null
 if(Test-Path -LiteralPath $path){
  if(!(Test-Path -LiteralPath $path -PathType Leaf)){throw "Destino invalido: $path"}
  $actual=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash
 }
 if($actual -eq $item.after){continue}
 if($actual -ne $item.before){throw "Base divergente: $($item.path). Nenhum arquivo alterado."}
 $pending+= $item
}
if(!$pending.Count){Write-Host 'Atualizacao D1 ja aplicada.';return}
$backup=Join-Path $Downloads ('IPTV-site-restauracao-r31-'+(Get-Date -Format 'yyyyMMdd-HHmmss-fff'))
New-Item -ItemType Directory -Path $backup -Force|Out-Null
foreach($item in $pending){
 if($item.before){
  $path=Join-Path $Site ([string]$item.path);$dest=Join-Path $backup ([string]$item.path)
  New-Item -ItemType Directory -Path (Split-Path -Parent $dest) -Force|Out-Null
  Copy-Item -LiteralPath $path -Destination $dest
  if((Get-FileHash -LiteralPath $dest -Algorithm SHA256).Hash -ne $item.before){throw 'O fonte mudou durante o backup. Nenhuma escrita feita.'}
 }
}
[PSCustomObject]@{site=[IO.Path]::GetFullPath($Site);files=@($pending)}|ConvertTo-Json -Depth 8|Set-Content -LiteralPath (Join-Path $backup 'restauracao.json') -Encoding UTF8
foreach($item in $pending){
 $path=Join-Path $Site ([string]$item.path);$actual=$null
 if(Test-Path -LiteralPath $path){$actual=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash}
 if($actual -ne $item.before){throw 'O destino mudou durante o backup. Nenhuma escrita feita.'}
}
try {
 foreach($item in $pending){
  $path=Join-Path $Site ([string]$item.path)
  New-Item -ItemType Directory -Path (Split-Path -Parent $path) -Force|Out-Null
  Copy-Item -LiteralPath (Join-Path "$PSScriptRoot\arquivos" ([string]$item.path)) -Destination $path -Force
  if((Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $item.after){throw "Falha de escrita: $($item.path)"}
 }
} catch {
 foreach($item in $pending){
  $path=Join-Path $Site ([string]$item.path)
  if($item.before){Copy-Item -LiteralPath (Join-Path $backup ([string]$item.path)) -Destination $path -Force}
  elseif(Test-Path -LiteralPath $path -PathType Leaf){Remove-Item -LiteralPath $path -Force}
 }
 throw
}
Write-Host "Atualizacao D1 aplicada. Recuperacao externa: $backup"
Write-Host 'Nenhum deploy ou migracao executado pelo aplicador.'
