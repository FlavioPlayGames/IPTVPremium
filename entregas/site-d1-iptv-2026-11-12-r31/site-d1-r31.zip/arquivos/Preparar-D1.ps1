﻿[CmdletBinding()]
param()
$ErrorActionPreference='Stop'
Push-Location -LiteralPath $PSScriptRoot
try {
 $config=Get-Content -LiteralPath "$PSScriptRoot\wrangler.jsonc" -Raw|ConvertFrom-Json
 $db=@($config.d1_databases|Where-Object {$_.binding -eq 'DB'})
 if($db.Count -ne 1 -or $db[0].database_name -ne 'central-iptv-premium'){throw 'Banco DB divergente. Nenhuma migracao solicitada.'}
 if($config.PSObject.Properties['r2_buckets']){throw 'Configuracao ainda contem R2. Aplique a atualizacao D1 antes de publicar.'}
 $cli=Join-Path $PSScriptRoot 'node_modules\wrangler\bin\wrangler.js'
 if(!(Test-Path -LiteralPath $cli -PathType Leaf)){throw 'Execute Testar-Site.ps1 antes.'}
 Write-Host 'Preparando somente duas tabelas temporarias no D1 existente. Sem R2, sem trocar dados de listas ou contas.'
 $previous=$ErrorActionPreference
 try {
  $ErrorActionPreference='Continue'
  & node $cli d1 execute 'central-iptv-premium' --remote --file "$PSScriptRoot\schema-manual.sql" --yes 2>&1|ForEach-Object {Write-Host "$_"}
  $code=$LASTEXITCODE
 } finally {$ErrorActionPreference=$previous}
 if($code -ne 0){throw 'A preparacao do D1 falhou. Nenhum deploy foi executado.'}
} finally {Pop-Location}
