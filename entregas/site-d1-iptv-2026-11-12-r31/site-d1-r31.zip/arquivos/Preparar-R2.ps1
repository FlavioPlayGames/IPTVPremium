﻿throw 'R2 nao e mais utilizado. Execute Publicar-Site.ps1 na pasta oficial; ele prepara o D1 existente.'
