import {sqliteD1} from './sqlite-d1.mjs';
import {createD1ManualStore} from '../manual-subtitle-store.js';
import assert from 'node:assert/strict';import {readFile,writeFile}from'node:fs/promises';import{webcrypto,randomUUID}from'node:crypto';
import{fileURLToPath,pathToFileURL}from'node:url';import{mkdtemp}from'node:fs/promises';import{tmpdir}from'node:os';import{join}from'node:path';
const {default:worker}=await import('../worker-atualizacao-abi.js');
const digest=async x=>Buffer.from(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(x))).toString('hex');
const secret='a'.repeat(64),secret2='b'.repeat(64),cookie='c'.repeat(64),cookie2='d'.repeat(64),id1=randomUUID(),id2=randomUUID();
const hashes=new Map([[await digest(secret),id1],[await digest(secret2),id2]]);const sessions=new Map([[await digest(cookie),id1],[await digest(cookie2),id2]]);
const storage=sqliteD1();storage.sqlite.exec(await readFile(new URL('../schema-manual.sql',import.meta.url),'utf8'));
const db={batch:statements=>storage.batch(statements),prepare(sql){
 if(sql.includes('manual_transfer_'))return storage.prepare(sql);
 let args=[];return{bind(...a){args=a;return this},async first(){
 if(sql.startsWith('SELECT * FROM devices WHERE credential_hash=')){const id=hashes.get(args[0]);return id?{id,code_hash:'test-code'}:null;}
 if(sql.startsWith('SELECT * FROM devices WHERE id='))return [id1,id2].includes(args[0])?{id:args[0],code_hash:'test-code'}:null;
 if(sql.startsWith('SELECT * FROM sessions')){const id=sessions.get(args[0]);return id?{device_id:id,role:'user',csrf:'csrf',token_hash:args[0]}:null;}
 if(sql.startsWith('INSERT INTO limits'))return{count:1};throw Error('Unexpected first SQL '+sql);
 },async run(){if(sql.startsWith('INSERT INTO qr_logins'))return{meta:{changes:1}};throw Error('Unexpected run '+sql);}}}};
const bucket=createD1ManualStore(db);let beforeBinary=null;
const realBatch=db.batch;db.batch=async statements=>{if(beforeBinary&&statements.length>1)await beforeBinary();return realBatch(statements)};
const pendingFiles=()=>storage.sqlite.prepare('SELECT COUNT(*) AS n FROM manual_transfer_objects WHERE value IS NULL').get().n;
const env={DB:db,APP_KEY:'0'.repeat(64),ADMIN_PASSWORD:'test-password-not-real'};
const origin='https://portal.test';
async function call(path,{method='GET',body,device=false,other=false,csrf=true,raw=false}={}){
 const headers=device?{Authorization:'Bearer '+(other?secret2:secret)}:{Cookie:'iptv_session='+(other?cookie2:cookie),Origin:origin,...csrf?{'X-CSRF-Token':'csrf'}:{}};
 if(body&&!raw)headers['Content-Type']='application/json';
 const r=await worker.fetch(new Request(origin+path,{method,headers,body:body==null?undefined:raw?body:JSON.stringify(body)}),env,{});return r;
}
const target={kind:'episode',playlistId:'list-a',contentId:'series-1',title:'Fear the Walking Dead',season:5,episode:1,kids:false};
async function create(t=target){const id=randomUUID(),r=await call('/api/device/manual-subtitles/request',{method:'POST',body:{id,target:t},device:true});assert.equal(r.status,200,await r.clone().text());const result=await r.json();assert.ok(result.url.startsWith(origin+'/#access='));assert.ok(result.url.includes('&view=manual&request='+id));return result.id;}
const bytes=Buffer.from('1\n00:00:01,000 --> 00:00:03,000\nOlá!\n');const uploaded=id=>call('/api/manual-subtitles/upload?id='+id+'&name=episode.srt',{method:'POST',body:bytes,raw:true});
let r=await worker.fetch(new Request(origin+'/api/device/manual-subtitles/request'),env,{});assert.equal(r.status,401);
const id=await create();r=await call('/api/manual-subtitles/request?id='+id,{other:true});assert.equal(r.status,404);
r=await call('/api/manual-subtitles/upload?id='+id+'&name=x.srt',{method:'POST',body:bytes,raw:true,csrf:false});assert.equal(r.status,403);
r=await uploaded(id);assert.equal(r.status,200,await r.clone().text());
r=await call('/api/device/manual-subtitles/file?id='+id,{device:true});assert.equal(r.status,200);assert.deepEqual(Buffer.from(await r.arrayBuffer()),bytes);assert.equal(r.headers.get('x-subtitle-sha256'),Buffer.from(await crypto.subtle.digest('SHA-256',bytes)).toString('hex'));
r=await call('/api/device/manual-subtitles/receipt?id='+id,{device:true,method:'POST',body:{success:true,count:1}});assert.equal(r.status,200);assert.equal(pendingFiles(),0);
r=await call('/api/manual-subtitles/request?id='+id);assert.equal((await r.json()).request.state,'received');assert.equal((await uploaded(id)).status,410);
const old=await create();await create();assert.equal((await uploaded(old)).status,410);
const cancelled=await create();assert.equal((await call('/api/device/manual-subtitles/request?id='+cancelled,{device:true,method:'DELETE'})).status,200);assert.equal((await uploaded(cancelled)).status,410);
const concurrent=await create();const results=await Promise.all([uploaded(concurrent),uploaded(concurrent)]);assert.deepEqual(results.map(x=>x.status).sort(),[200,409]);
await call('/api/device/manual-subtitles/request?id='+concurrent,{device:true,method:'DELETE'});
const racing=await create();let unblock,started;const gate=new Promise(r=>{unblock=r}),seen=new Promise(r=>{started=r});
beforeBinary=async()=>{started();await gate;};
const race=uploaded(racing);await seen;await call('/api/device/manual-subtitles/request?id='+racing,{device:true,method:'DELETE'});unblock();assert.equal((await race).status,409);beforeBinary=null;assert.equal(pendingFiles(),0);
const invalid=await create();r=await call('/api/manual-subtitles/upload?id='+invalid+'&name=x.exe',{method:'POST',body:bytes,raw:true});assert.equal(r.status,422);
r=await call('/api/device/manual-subtitles/request',{method:'POST',body:{id:randomUUID(),target:{...target,episode:-1}},device:true});assert.equal(r.status,422);
const season=await create({...target,kind:'season',episodes:[1,2,3]});r=await call('/api/manual-subtitles/upload?id='+season+'&name=x.zip',{method:'POST',body:bytes,raw:true});assert.equal(r.status,422);
const retryable=await create();assert.equal((await uploaded(retryable)).status,200);
r=await call('/api/device/manual-subtitles/receipt?id='+retryable,{device:true,method:'POST',body:{success:false,count:0}});assert.equal(r.status,200);
r=await call('/api/manual-subtitles/request?id='+retryable);assert.equal((await r.json()).request.state,'waiting');assert.equal((await uploaded(retryable)).status,200);
await call('/api/device/manual-subtitles/request?id='+retryable,{device:true,method:'DELETE'});
const expired=await create(),key=`manual/${id1}/${expired}/request.json`;const row=await (await bucket.get(key)).json();await bucket.put(key,JSON.stringify({...row,expires:Date.now()-1}));
r=await call('/api/manual-subtitles/request?id='+expired);assert.equal((await r.json()).request.state,'expired');assert.equal((await uploaded(expired)).status,410);
assert.equal((await call('/api/device/manual-subtitles/file?id='+expired,{device:true})).status,410);
const sizeLimited=await create();r=await call('/api/manual-subtitles/upload?id='+sizeLimited+'&name=x.zip',{method:'POST',body:Buffer.alloc(2*1024*1024+1),raw:true});assert.equal(r.status,413);
console.log('PASS adicional: QR aponta ao destino manual, rejeicao permite novo arquivo, expiracao recusa upload/download, limite real de 2 MB.');
console.log('PASS: autenticação, isolamento entre TVs, CSRF, ciclo de envio/recebimento, hash, descarte, substituição, cancelamento, uploads concorrentes e corrida cancelamento/upload.');

assert.equal(storage.sqlite.prepare('SELECT COUNT(*) AS n FROM manual_transfer_chunks').get().n,0);
console.log('PASS no binary chunks remain after receipts, rejection, cancellation and upload race.');

const fullId=await create();
storage.sqlite.prepare('INSERT INTO manual_transfer_objects VALUES(?,?,?,?,?)').run('capacity-test','{}','etag',Date.now()+900000,32*1024*1024);
r=await uploaded(fullId);assert.equal(r.status,503);assert.ok((await r.json()).error.includes('pendentes'));
r=await call('/api/manual-subtitles/request?id='+fullId);assert.equal((await r.json()).request.state,'waiting');
storage.sqlite.prepare("DELETE FROM manual_transfer_objects WHERE object_key='capacity-test'").run();
const largeZip=Buffer.alloc(2*1024*1024);largeZip[0]=80;largeZip[1]=75;
r=await call('/api/manual-subtitles/upload?id='+fullId+'&name=season.zip',{method:'POST',body:largeZip,raw:true});assert.equal(r.status,200);
r=await call('/api/device/manual-subtitles/file?id='+fullId,{device:true});assert.deepEqual(Buffer.from(await r.arrayBuffer()),largeZip);
assert.equal((await call('/api/device/manual-subtitles/receipt?id='+fullId,{device:true,method:'POST',body:{success:true,count:5}})).status,200);
assert.equal(storage.sqlite.prepare('SELECT COUNT(*) AS n FROM manual_transfer_chunks').get().n,0);
console.log('PASS API capacity returns 503 with retryable waiting state; full 2 MiB ZIP round trip and receipt delete all chunks.');
