# Validação D1 r31

- Fluxos manuais testados com SQLite real e a implementação nova, sem mock de armazenamento: autenticação, CSRF, isolamento entre TVs, envio/recebimento, rejeição/reenvio, cancelamento, substituição, expiração e concorrência.
- Armazenamento: CAS por etag, binário de 2 MiB em 16 blocos, integridade, exclusão em cascata, teto compartilhado e rollback transacional se um bloco falhar.
- Passaram 24 verificações existentes do servidor, 224 verificações de navegador e o empacotamento dry-run sem binding R2. Nenhuma alteração Cloudflare/TV é executada pelos testes.
- Limites D1 consultados em https://developers.cloudflare.com/d1/platform/limits/ (fonte https://raw.githubusercontent.com/cloudflare/cloudflare-docs/production/src/content/docs/d1/platform/limits.mdx): registro/BLOB 2.000.000 bytes; 100 parâmetros por consulta. Blocos de 131.072 bytes e consultas parametrizadas pequenas.
- Testes dos scripts em PowerShell 7 Linux, com comandos Cloudflare simulados. Compatibilidade Windows PowerShell 5.1 mantida com leitura explícita do array do manifesto; execução real será confirmada no PC.
- Aplicador/repetição/rollback e bloqueio de base divergente passaram. O pacote de manutenção inclui o SQL. Publicador foi testado com CLI simulada: falha de migração impede deploy, nenhum comando R2, comprovante apenas após sucesso.
- API testada com ZIP completo de 2 MiB e teto global atingido: resposta 503 permite reenvio, sem arquivo parcial.
- Nenhum deploy, migração remota ou teste de TV física feito neste ambiente.
