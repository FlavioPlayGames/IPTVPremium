import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';
import {sqliteD1} from './sqlite-d1.mjs';import{createD1ManualStore,purgeManualTransfers}from'../manual-subtitle-store.js';
const db=sqliteD1();db.sqlite.exec(await readFile(new URL('../schema-manual.sql',import.meta.url),'utf8'));const store=createD1ManualStore(db);
const get=(q,...a)=>db.sqlite.prepare(q).get(...a);
const key='manual/tv/id/request.json',text=JSON.stringify({id:'one',expires:Date.now()+900000});
const first=await store.put(key,text,{onlyIf:{etagDoesNotMatch:'*'}});assert.ok(first.etag);
assert.equal(await store.put(key,text,{onlyIf:{etagDoesNotMatch:'*'}}),null);
assert.equal(await store.put(key,text,{onlyIf:{etagMatches:'wrong'}}),null);
const result=await store.put(key,text,{onlyIf:{etagMatches:first.etag}});assert.notEqual(result.etag,first.etag);
const payload=crypto.getRandomValues(new Uint8Array(64000));const big=new Uint8Array(2*1024*1024);for(let x=0;x<big.length;x++)big[x]=payload[x%payload.length];
await store.put('test.bin',big);assert.deepEqual((await store.get('test.bin')).body,big);
assert.equal(get('SELECT COUNT(*) AS n FROM manual_transfer_chunks').n,16);
await store.delete('test.bin');assert.equal(get('SELECT COUNT(*) AS n FROM manual_transfer_chunks').n,0);
await assert.rejects(store.put('large',new Uint8Array(2*1024*1024+1)),e=>e.status===413);
await store.put('expired.bin',payload,{customMetadata:{expires:String(Date.now()-1)}});await purgeManualTransfers(db);
assert.equal(await store.get('expired.bin'),null);assert.equal(get('SELECT COUNT(*) AS n FROM manual_transfer_chunks').n,0);
// Artificial near-capacity metadata simulates other devices without allocating 32 MiB in the test.
db.sqlite.prepare('UPDATE manual_transfer_objects SET byte_size=?').run(32*1024*1024);
await assert.rejects(store.put('full.bin',payload),e=>e.status===503);assert.equal(await store.get('full.bin'),null);assert.equal(get('SELECT COUNT(*) AS n FROM manual_transfer_chunks').n,0);
db.sqlite.prepare('UPDATE manual_transfer_objects SET byte_size=1').run();
// An error while inserting chunks rolls back the capacity reservation and every earlier chunk.
db.sqlite.exec("CREATE TRIGGER fail_chunk BEFORE INSERT ON manual_transfer_chunks WHEN NEW.part=1 BEGIN SELECT RAISE(ABORT,'test failure'); END");
await assert.rejects(store.put('atomic.bin',new Uint8Array(300000)));assert.equal(await store.get('atomic.bin'),null);assert.equal(get('SELECT COUNT(*) AS n FROM manual_transfer_chunks').n,0);
console.log('PASS D1 SQLite real: CAS, 2 MiB in 16 chunks, binary integrity, cascade deletion, expiry, capacity and rollback. No cloud writes.');
