// Temporary private transfer storage in the existing D1 database; never used for provider credentials.
const CHUNK_BYTES=128*1024,MAX_FILE_BYTES=2*1024*1024,MAX_PENDING_BYTES=32*1024*1024;
const changes=result=>Number(result?.meta?.changes||0);
export async function purgeManualTransfers(db,now=Date.now()) {
 await db.prepare('DELETE FROM manual_transfer_objects WHERE expires <= ?').bind(now).run();
}
export function createD1ManualStore(db) {
 return {
  async get(key) {
   const row=await db.prepare('SELECT value,etag,byte_size FROM manual_transfer_objects WHERE object_key=?').bind(key).first();
   if(!row)return null;
   if(row.value!==null)return {etag:row.etag,json:async()=>JSON.parse(row.value)};
   const {results}=await db.prepare('SELECT payload FROM manual_transfer_chunks WHERE object_key=? ORDER BY part').bind(key).all();
   const bytes=new Uint8Array(row.byte_size);let offset=0;
   for(const part of results){const data=new Uint8Array(part.payload);bytes.set(data,offset);offset+=data.length;}
   if(offset!==bytes.length)throw Error('Incomplete manual subtitle transfer');
   return {etag:row.etag,body:bytes};
  },
  async put(key,body,options={}) {
   const etag=crypto.randomUUID(),condition=options.onlyIf,now=Date.now();
   if(typeof body==='string') {
    const data=JSON.parse(body),expires=Number(data.expires)||now+15*60*1000;
    // Keep the small status receipt for one hour after the transfer expires; binary expires in 15 minutes.
    let sql,args;
    if(condition?.etagMatches){
     sql='UPDATE manual_transfer_objects SET value=?,etag=?,expires=?,byte_size=? WHERE object_key=? AND etag=?';
     args=[body,etag,expires+3600000,new TextEncoder().encode(body).length,key,condition.etagMatches];
    }else if(condition?.etagDoesNotMatch==='*'){
     sql='INSERT OR IGNORE INTO manual_transfer_objects(object_key,value,etag,expires,byte_size) VALUES(?,?,?,?,?)';
     args=[key,body,etag,expires+3600000,new TextEncoder().encode(body).length];
    }else{
     sql='INSERT INTO manual_transfer_objects(object_key,value,etag,expires,byte_size) VALUES(?,?,?,?,?) ON CONFLICT(object_key) DO UPDATE SET value=excluded.value,etag=excluded.etag,expires=excluded.expires,byte_size=excluded.byte_size';
     args=[key,body,etag,expires+3600000,new TextEncoder().encode(body).length];
    }
    const result=await db.prepare(sql).bind(...args).run();return changes(result)?{etag}:null;
   }
   const bytes=body instanceof Uint8Array?body:new Uint8Array(body);
   if(bytes.length>MAX_FILE_BYTES)throw Object.assign(Error('Arquivo acima do limite.'),{status:413});
   const expires=Number(options.customMetadata?.expires)||now+15*60*1000;
   // Capacity reservation and every chunk are in the same D1 transaction; a failure leaves no partial file.
   const statements=[db.prepare('INSERT INTO manual_transfer_objects(object_key,value,etag,expires,byte_size) SELECT ?,NULL,?,?,? WHERE COALESCE((SELECT SUM(byte_size) FROM manual_transfer_objects),0)+?<=?').bind(key,etag,expires,bytes.length,bytes.length,MAX_PENDING_BYTES)];
   for(let offset=0,part=0;offset<bytes.length;offset+=CHUNK_BYTES,part++){
    statements.push(db.prepare('INSERT INTO manual_transfer_chunks(object_key,part,payload) SELECT ?,?,? WHERE EXISTS(SELECT 1 FROM manual_transfer_objects WHERE object_key=? AND etag=?)').bind(key,part,bytes.slice(offset,offset+CHUNK_BYTES).buffer,key,etag));
   }
   const results=await db.batch(statements);
   if(!changes(results[0]))throw Object.assign(Error('Muitos envios pendentes. Aguarde a TV receber e tente novamente.'),{status:503});
   return {etag};
  },
  async delete(key){await db.prepare('DELETE FROM manual_transfer_objects WHERE object_key=?').bind(key).run();}
 };
}
