# Site IPTV — pasta oficial, transferência D1 r31

Pasta oficial: C:\Users\flavi\AndroidStudioProjects\Site IPTV.
Todas as edições e publicações partem desta pasta. Downloads serve para receber entregas. O projeto Android permanece separado.

## Publicar e guardar os fontes

Execute `powershell -ExecutionPolicy Bypass -File .\Publicar-Site.ps1`.
A rotina testa, guarda uma cópia completa dos fontes, prepara duas tabelas temporárias no D1 existente e publica no Worker existente. Requer login Cloudflare na conta correta. Não usa R2, não exige ativá-lo e não cria outro banco ou Worker. Continua sujeita às cotas do plano D1/Workers já existente; não há promessa de uso ilimitado.

Para enviar o projeto atualizado a outra conversa: `powershell -ExecutionPolicy Bypass -File .\manutencao-iptv\Manter-Site.ps1 -Acao Pacote`. ZIPs em manutencao-iptv/pacotes, incluindo schema-manual.sql. Logs/comprovantes em manutencao-iptv/relatorios. Sempre aplicar as próximas entregas nesta pasta. Não editar arquivos gerados em .worker-preview.

## Envio manual sem R2

Celular → D1 temporário → TV. ZIP até 2 MiB; SRT até 1 MiB. A TV já aceita esses tamanhos sem alteração no APK. O servidor preserva os endpoints, QR, nome original, hash SHA256 e confirmação de salvamento existentes. Metadados e arquivos continuam privados, com autenticação, CSRF e isolamento por TV.

O arquivo fica disponível por 15 minutos e é excluído do armazenamento ativo após a TV confirmar, rejeitar, cancelar ou substituir o pedido. Não é apagado apenas porque houve download: se a resposta se perder ou a TV falhar antes de salvar, ela pode tentar de novo. Arquivos expirados são removidos na próxima requisição manual autenticada ou pelo cron horário existente; após 15 minutos o download é recusado, mesmo antes da limpeza física. O pequeno status de confirmação expira uma hora depois. O D1 pode reter versões em seus backups/Time Travel conforme o plano; exclusão ativa não é apagamento desses backups.

Arquivos são divididos em blocos de 128 KiB para respeitar o limite de registro do D1. Reserva de capacidade e blocos são gravados em uma transação. Limite compartilhado de 32 MiB para transferências pendentes/metadados, sem armazenar catálogo, histórico ou credenciais nessas tabelas. Se estiver cheio, o usuário recebe mensagem para aguardar; não é necessário contratar outro armazenamento.

A migração schema-manual.sql é aditiva/idempotente: manual_transfer_objects, manual_transfer_chunks e índice de expiração. Não altera listas, contas, histórico, credenciais ou dados antigos. Preparar-D1.ps1 executa essa migração REMOTA antes de publicar. Nenhum segredo muda; nunca trocar APP_KEY. Preparar-R2.ps1 é apenas um aviso e não faz chamadas externas.

## Testar

Testar-Site.ps1 executa testes e empacotamento dry-run sem publicar nem migrar. Testes locais usam SQLite e APIs simuladas; TV física e deploy real ainda precisam ser conferidos no PC. Consulte validacao/VALIDACAO-R31.md.

SubDL, SubSource, OpenSubtitles, envio direto de listas e visual atual foram preservados. O limite de 2 MiB se aplica apenas a ZIPs enviados manualmente pelo site, sem mudar os limites dos provedores ou cache do APK.

## Recuperação

Aplicar-D1.ps1 cria backup externo dos arquivos alterados e confere hashes antes de escrever. Desfazer-D1.ps1 recusa sobrescrever edições posteriores. A reversão local não faz deploy nem apaga as tabelas D1. Não remover tabelas com transferências pendentes; cópias antigas do publicador r30 dependiam de R2 e não devem ser publicadas sem revisão.
