-- Additive migration only. Does not change lists, accounts, credentials or history.
CREATE TABLE IF NOT EXISTS manual_transfer_objects (
 object_key TEXT PRIMARY KEY,
 value TEXT,
 etag TEXT NOT NULL,
 expires INTEGER NOT NULL,
 byte_size INTEGER NOT NULL CHECK(byte_size >= 0)
);
CREATE INDEX IF NOT EXISTS manual_transfer_expiry ON manual_transfer_objects(expires);
CREATE TABLE IF NOT EXISTS manual_transfer_chunks (
 object_key TEXT NOT NULL REFERENCES manual_transfer_objects(object_key) ON DELETE CASCADE,
 part INTEGER NOT NULL,
 payload BLOB NOT NULL,
 PRIMARY KEY(object_key,part)
);
