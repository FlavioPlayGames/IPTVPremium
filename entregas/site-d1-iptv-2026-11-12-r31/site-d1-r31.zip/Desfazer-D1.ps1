﻿[CmdletBinding()]
param([Parameter(Mandatory=$true)][string]$Backup)
$ErrorActionPreference='Stop'
$record=Get-Content -LiteralPath (Join-Path $Backup 'restauracao.json') -Raw|ConvertFrom-Json
foreach($item in $record.files){
 $path=Join-Path $record.site ([string]$item.path)
 if(!(Test-Path -LiteralPath $path -PathType Leaf) -or (Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash -ne $item.after){throw "Arquivo alterado apos atualizacao: $($item.path). Nenhuma restauracao feita."}
 if($item.before){
  $saved=Join-Path $Backup ([string]$item.path)
  if(!(Test-Path -LiteralPath $saved -PathType Leaf) -or (Get-FileHash -LiteralPath $saved -Algorithm SHA256).Hash -ne $item.before){throw 'Backup divergente.'}
 }
}
foreach($item in $record.files){
 $path=Join-Path $record.site ([string]$item.path)
 if($item.before){Copy-Item -LiteralPath (Join-Path $Backup ([string]$item.path)) -Destination $path -Force}
 else{Remove-Item -LiteralPath $path -Force}
}
Write-Host 'Fontes locais restaurados. Nenhum deploy ou alteracao D1 executado.'
