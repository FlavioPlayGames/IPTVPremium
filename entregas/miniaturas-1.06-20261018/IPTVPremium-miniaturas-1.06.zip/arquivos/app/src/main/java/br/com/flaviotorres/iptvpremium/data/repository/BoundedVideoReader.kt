package br.com.flaviotorres.iptvpremium.data.repository

import java.io.Closeable
import java.io.IOException
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

/** Leitura parcial limitada, inclusive prefixo progressivo se a origem ignorar Range. */
internal class BoundedVideoReader(
    private val url: String,
    private val active: () -> Boolean = { true },
    private val maxBytes: Long = 6L * 1024 * 1024,
    private val blockSize: Int = 256 * 1024,
    private val maxRequests: Int = 24,
    timeoutMs: Long = 10_000
) : Closeable {
    private val deadline = System.nanoTime() + timeoutMs * 1_000_000
    private var closed = false
    private var total = -1L
    private var received = 0L
    private var requests = 0
    private val blocks = LinkedHashMap<Long, ByteArray>(4, .75f, true)
    private var sequentialConnection: HttpURLConnection? = null
    private var sequentialInput: InputStream? = null
    private var prefix: ByteArray? = null
    private var prefixSize = 0
    private var sequentialEof = false
    init { require(maxBytes in 1..Int.MAX_VALUE.toLong() && blockSize > 0 && maxRequests > 0) }
    private fun checkActive() { if (closed || !active() || System.nanoTime() >= deadline) throw IOException("Preview encerrado") }
    @Synchronized fun size(): Long { checkActive(); if (prefix == null && total < 0) block(0); return total }
    @Synchronized fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int {
        checkActive()
        if (position < 0 || offset < 0 || size < 0 || offset > buffer.size - size) throw IOException("Posicao invalida")
        if (size == 0) return 0
        if (total >= 0 && position >= total) return -1
        val start = position / blockSize * blockSize
        val data = block(start)
        val index = (position - start).toInt()
        if (index >= data.size) return -1
        val count = minOf(size, data.size - index)
        data.copyInto(buffer, offset, index, index + count)
        return count
    }
    private fun block(start: Long): ByteArray {
        blocks[start]?.let { return it }
        checkActive()
        if (prefix != null) return sequentialBlock(start)
        if (requests++ >= maxRequests || received >= maxBytes) throw IOException("Limite de leitura do preview")
        val end = start + minOf(blockSize.toLong(), maxBytes - received) - 1
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            val remaining = ((deadline - System.nanoTime()) / 1_000_000).coerceIn(1, 4_000).toInt()
            connection.connectTimeout = remaining; connection.readTimeout = remaining
            connection.setRequestProperty("Range", "bytes=$start-$end")
            connection.setRequestProperty("Accept-Encoding", "identity")
            connection.setRequestProperty("User-Agent", "IPTVPremium/1.0")
            val status = connection.responseCode
            if (status == 206) {
                val range = Regex("bytes (\\d+)-(\\d+)/(\\d+)", RegexOption.IGNORE_CASE)
                    .matchEntire(connection.getHeaderField("Content-Range").orEmpty().trim()) ?: throw IOException("Faixa ausente")
                if (range.groupValues[1].toLong() != start || range.groupValues[2].toLong() < start) throw IOException("Faixa invalida")
                total = range.groupValues[3].toLong()
            } else if (status == 200 && start == 0L) {
                // Sem Range: somente avanca dentro de um prefixo de ate 6 MiB.
                // Um MP4 sem fast-start pode exigir a cauda: nesse caso falha
                // sem percorrer/baixar todo o episodio.
                total = connection.contentLengthLong.takeIf { it >= 0L } ?: -1L
                prefix = ByteArray(maxBytes.toInt())
                sequentialConnection = connection
                sequentialInput = connection.inputStream
                return sequentialBlock(0)
            } else throw IOException("Origem sem leitura parcial")
            val limit = minOf(end - start + 1, total - start).coerceAtLeast(0).toInt()
            val bytes = ByteArray(limit)
            var count = 0
            connection.inputStream.use { input ->
                while (count < limit) {
                    checkActive()
                    val n = input.read(bytes, count, minOf(16 * 1024, limit - count))
                    if (n < 0) break
                    count += n; received += n
                    if (received > maxBytes) throw IOException("Limite de dados")
                }
            }
            if (count == 0) throw IOException("Faixa vazia")
            return rememberBlock(start, if (count == bytes.size) bytes else bytes.copyOf(count))
        } finally { if (connection !== sequentialConnection) connection.disconnect() }
    }
    private fun sequentialBlock(start: Long): ByteArray {
        checkActive()
        val bytes = prefix ?: throw IOException("Prefixo ausente")
        if (start >= maxBytes) throw IOException("Limite de leitura do preview")
        val end = minOf(start + blockSize, maxBytes, if (total >= 0) total else maxBytes).toInt()
        while (prefixSize < end && !sequentialEof) {
            checkActive()
            val n = sequentialInput!!.read(bytes, prefixSize, minOf(16 * 1024, end - prefixSize))
            if (n < 0) { sequentialEof = true; total = prefixSize.toLong(); break }
            prefixSize += n; received += n
            if (received > maxBytes) throw IOException("Limite de dados")
        }
        val from = start.toInt().coerceAtMost(prefixSize)
        return rememberBlock(start, bytes.copyOfRange(from, minOf(end, prefixSize)))
    }
    private fun rememberBlock(start: Long, bytes: ByteArray): ByteArray {
        blocks[start] = bytes
        while (blocks.size > 4) blocks.remove(blocks.keys.first())
        return bytes
    }
    @Synchronized override fun close() {
        closed = true
        sequentialConnection?.disconnect()
        try { sequentialInput?.close() } catch (_: IOException) { }
        sequentialInput = null; sequentialConnection = null; prefix = null; blocks.clear()
    }
}
