package br.com.flaviotorres.iptvpremium.data.repository

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaDataSource
import android.media.MediaMetadataRetriever
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import br.com.flaviotorres.iptvpremium.core.storage.ImageDiskCache
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import java.io.File
import java.security.MessageDigest

/** Ultima alternativa de um card sem imagem; um extrator por vez, sem player adicional. */
internal object EpisodeFrameLoader {
    private val slot = Semaphore(1)
    private val failures = linkedMapOf<String, Long>()
    suspend fun load(context: Context, identity: String, width: Int, height: Int,
        cacheOnly: Boolean = false,
        resolveUrl: suspend () -> String?): ImageBitmap? = withContext(Dispatchers.IO) {
        val key = MessageDigest.getInstance("SHA-256").digest("episode-frame-v1:$identity".toByteArray())
            .joinToString("") { "%02x".format(it.toInt() and 255) }
        // Dentro do mesmo orcamento de 64 MiB das outras imagens, sem novas pastas.
        val directory = File(context.cacheDir, "movie_details_images")
        if (!directory.isDirectory && !directory.mkdirs() && !directory.isDirectory) return@withContext null
        val file = File(directory, "$key.img")
        val budget = ImageDiskCache.get(context)
        budget.retain(file).use {
            if (file.isFile) BitmapFactory.decodeFile(file.absolutePath)?.let { bitmap ->
                file.setLastModified(System.currentTimeMillis()); return@withContext bitmap.asImageBitmap()
            }
        }
        if (cacheOnly) return@withContext null
        if (synchronized(failures) { System.currentTimeMillis() - (failures[key] ?: 0L) < 2 * 60_000L }) return@withContext null
        delay(400) // Cancela rapidamente ao sair da pagina/rolar as capas.
        slot.withPermit {
            currentCoroutineContext().ensureActive()
            budget.retain(file).use {
                if (file.isFile) BitmapFactory.decodeFile(file.absolutePath)?.let { return@withContext it.asImageBitmap() }
                // A tela e a previa da animacao podem pedir o mesmo card.
                if (synchronized(failures) { System.currentTimeMillis() - (failures[key] ?: 0L) < 2 * 60_000L }) return@withContext null
                val url = resolveUrl()?.takeIf { it.startsWith("https://", true) || it.startsWith("http://", true) }
                if (url == null) {
                    android.util.Log.d("EpisodePreview", "url_episodio_indisponivel")
                    return@withContext null
                }
                val job = currentCoroutineContext()[Job]
                var frame: Bitmap? = null
                try {
                    BoundedVideoReader(url, active = { job?.isActive != false }).use { reader ->
                        val data = object : MediaDataSource() {
                            override fun getSize(): Long = reader.size()
                            override fun readAt(position: Long, buffer: ByteArray, offset: Int, size: Int): Int = reader.readAt(position, buffer, offset, size)
                            override fun close() = reader.close()
                        }
                        val retriever = MediaMetadataRetriever()
                        try {
                            retriever.setDataSource(data)
                            for (timeUs in listOf(1_000_000L, 0L, 5_000_000L)) {
                                currentCoroutineContext().ensureActive()
                                try {
                                    frame = retriever.getScaledFrameAtTime(timeUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC,
                                        width.coerceIn(160, 640), height.coerceIn(90, 360))
                                } catch (_: RuntimeException) { /* Tenta outro instante do mesmo video. */ }
                                if (frame != null) break
                            }
                        } finally { retriever.release() }
                    }
                    currentCoroutineContext().ensureActive()
                    val bitmap = frame
                    if (bitmap != null) {
                        val temp = File(directory, "$key.img.part")
                        try {
                            if (!directory.isDirectory) directory.mkdirs()
                            temp.outputStream().use { check(bitmap.compress(Bitmap.CompressFormat.JPEG, 82, it)) }
                            check(temp.renameTo(file))
                        } catch (_: Exception) {
                            // Uma falha ao gravar cache nao esconde o frame ja obtido.
                        } finally { temp.delete() }
                        android.util.Log.d("EpisodePreview", "frame_extraido")
                        return@withContext bitmap.asImageBitmap()
                    }
                } catch (cancelled: CancellationException) { frame?.recycle(); throw cancelled }
                catch (error: Exception) {
                    frame?.recycle()
                    android.util.Log.d("EpisodePreview", "extracao_indisponivel tipo=${error.javaClass.simpleName}")
                }
                catch (_: OutOfMemoryError) { frame?.recycle() }
                android.util.Log.d("EpisodePreview", "frame_ausente")
                synchronized(failures) {
                    if (failures.size >= 256) failures.remove(failures.keys.first())
                    failures[key] = System.currentTimeMillis()
                }
                null
            }
        }
    }
}
