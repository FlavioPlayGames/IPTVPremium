package br.com.flaviotorres.iptvpremium.data.repository

/** Preserva fotos normais; cache de frames aparece cedo e so extrai se faltarem imagens. */
internal suspend fun <T : Any> loadEpisodeThumbnail(
    images: List<String>,
    readyForFrame: Boolean,
    cachedFrame: suspend () -> T?,
    image: suspend (String) -> T?,
    frame: suspend () -> T?,
    show: (T) -> Unit
) {
    val cached = cachedFrame()
    if (cached != null) show(cached)
    for (url in images.distinct()) {
        image(url)?.let { show(it); return }
    }
    if (!readyForFrame) return
    if (cached != null) return
    // Somente cards sem foto tentam extrair o proprio episodio.
    frame()?.let(show)
}
