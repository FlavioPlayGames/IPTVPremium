package br.com.flaviotorres.iptvpremium.data.m3u

import br.com.flaviotorres.iptvpremium.data.repository.artworkTitle
import br.com.flaviotorres.iptvpremium.data.repository.seriesArtworkLookupTitle
import java.net.URI

/** Episode art is not a catalogue cover. No HTTP or per-episode image collection. */
internal object M3uSeriesPosterPolicy {
    private val dimensions=Regex("/w([0-9]+)_and_h([0-9]+)[^/]*/")
    private fun shape(url:String):Int {
        val uri=runCatching{URI(url)}.getOrNull()?:return 0
        if(!uri.host.equals("image.tmdb.org",true))return 0
        val path=uri.path.orEmpty()
        dimensions.find(path)?.let{m->
            val width=m.groupValues[1].toLongOrNull()?:return 0
            val height=m.groupValues[2].toLongOrNull()?:return 0
            return if(height>width)1 else -1
        }
        // This CDN rendition is used for the episode stills supplied by this M3U.
        return if(path.startsWith("/t/p/w1280/")) -1 else 0
    }
    class Candidate {
        private var first:String?=null
        private var same=true
        private var portrait:String?=null
        fun observe(url:String?) {
            val image=url?.trim()?.takeIf{it.startsWith("http://",true)||it.startsWith("https://",true)}?:return
            if(first==null)first=image else if(first!=image)same=false
            if(portrait==null&&shape(image)>0)portrait=image
        }
        fun cover():String?=portrait?:first?.takeIf{same&&shape(it)>=0}
    }
    data class Work(val id:String,val title:String,val year:Int?,val image:Candidate)
    data class Result(val urls:Map<String,String?>,val kept:Int,val reused:Int,val missing:Int)
    fun resolve(works:List<Work>):Result {
        fun name(w:Work)=artworkTitle(seriesArtworkLookupTitle(w.title))
        val names=works.associate{it.id to name(it)}
        val covers=works.associate{it.id to it.image.cover()}
        val owners=works.filter{covers[it.id]!=null}.groupBy{covers[it.id]!!}
        fun compatible(a:Work,b:Work)=names[a.id]==names[b.id]&&(a.year==null||b.year==null||a.year==b.year)
        fun safe(w:Work)=covers[w.id]?.takeIf{url->owners[url].orEmpty().all{compatible(w,it)}}
        val byName=works.groupBy{names[it.id]}
        var kept=0;var reused=0;var missing=0
        val result=linkedMapOf<String,String?>()
        for(w in works){
            val own=safe(w)
            val siblings=byName[names[w.id]].orEmpty().filter{compatible(w,it)&&safe(it)!=null}
            val years=siblings.mapNotNull{it.year}.distinct()
            val candidates=siblings.mapNotNull{safe(it)}.distinct()
            val resolved=own?:candidates.singleOrNull()?.takeIf{w.year!=null||years.size<=1}
            if(own!=null)kept++ else if(resolved!=null)reused++ else missing++
            result[w.id]=resolved
        }
        return Result(result,kept,reused,missing)
    }
}
