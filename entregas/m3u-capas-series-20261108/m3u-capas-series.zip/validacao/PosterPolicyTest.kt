package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.m3u.*
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.*
import br.com.flaviotorres.iptvpremium.data.repository.seriesArtworkLookupTitle
import java.io.*
import java.nio.file.Files

private fun image(vararg urls:String?)=M3uSeriesPosterPolicy.Candidate().also{c->urls.forEach{c.observe(it)}}
private fun work(id:String,name:String,year:Int?,vararg urls:String?)=M3uSeriesPosterPolicy.Work(id,name,year,image(*urls))
fun main(){
 val poster="https://image.tmdb.org/t/p/w600_and_h900_bestv2/aia.jpg"
 val still1="https://image.tmdb.org/t/p/w1280/episode1.jpg";val still2="https://image.tmdb.org/t/p/w1280/episode2.jpg"
 fun pass(s:String)=println("PASS $s")
 val result=M3uSeriesPosterPolicy.resolve(listOf(work("apple","O Conto Da Aia",null,poster,poster),work("disney","O Conto Da Aia 2017 (2017)",2017,still1,still2)))
 check(result.urls==mapOf("apple" to poster,"disney" to poster)&&result.reused==1);pass("O Conto da Aia borrows the unique compatible portrait cover, never the last episode still")
 check(M3uSeriesPosterPolicy.resolve(listOf(work("x","Show",2020,still1,still1))).urls["x"]==null);pass("repeated known still rendition does not become a series cover")
 check(M3uSeriesPosterPolicy.resolve(listOf(work("x","Show",2020,"https://example.invalid/a.jpg","https://example.invalid/b.jpg"))).urls["x"]==null);pass("different unclassified episode images cannot select the last frame as a cover")
 check(M3uSeriesPosterPolicy.resolve(listOf(work("x","Show",2020,"https://example.invalid/a.jpg",null,"https://example.invalid/a.jpg"))).urls["x"]=="https://example.invalid/a.jpg");pass("stable ordinary provider poster remains usable despite missing episode metadata")
 check(M3uSeriesPosterPolicy.resolve(listOf(work("x","Show X",2020,poster),work("y","Show Y",2020,poster))).urls.values.all{it==null});pass("image reused by unrelated series is rejected instead of leaking across titles")
 check(M3uSeriesPosterPolicy.resolve(listOf(work("x","Show",2020,poster),work("y","Show",2017,still1))).urls["y"]==null);pass("a known release-year mismatch cannot borrow another adaptation's poster")
 check(M3uSeriesPosterPolicy.resolve(listOf(work("x","Show",2020,poster),work("y","Show",2017,"https://image.tmdb.org/t/p/w600_and_h900_bestv2/other.jpg"),work("z","Show",null,still1))).urls["z"]==null);pass("unknown-year homonym with multiple compatible covers stays unresolved")
 check(seriesArtworkLookupTitle("O Conto Da Aia 2017 (2017)")=="O Conto Da Aia")
 for(s in listOf("1899","The 100","Class of 2017","Blade Runner 2049","O Conto da Aia (2017)"))check(seriesArtworkLookupTitle(s)==s)
 pass("lookup removes duplicated release year while preserving display names and genuine title numbers")
 val root=Files.createTempDirectory("m3u-aia").toFile()
 try{
  val store=DeferredM3uEpisodes(File(root,"sources"));val source=store.begin("p","g");val bytes=ByteArrayOutputStream()
  val input=listOf("#EXTM3U","""#EXTINF:-1 group-title="Apple" tvg-logo="$poster",O Conto Da Aia S01E01""","http://example.invalid/series/a", """#EXTINF:-1 group-title="Disney" tvg-logo="$still1",O Conto Da Aia 2017 (2017) S01E01""","http://example.invalid/series/b","""#EXTINF:-1 group-title="Disney" tvg-logo="$still2",O Conto Da Aia 2017 (2017) S01E02""","http://example.invalid/series/c").joinToString("\n")
  M3uCatalogParser.prepare(input.reader().buffered(),DataOutputStream(bytes),"p","g",episodeSource=source);source.finish()
  val series=mutableListOf<Array<Any?>>()
  DataInputStream(ByteArrayInputStream(bytes.toByteArray())).use{r->check(r.readInt()==0x4D335331);while(true){val (kind,row)=M3uCatalogParser.read(r)?:break;if(kind==3)series+=row}}
  check(series.size==2&&series.all{it[5]==poster});check(series[1][3]=="O Conto Da Aia 2017 (2017)")
  pass("real parser writes compatible series covers while preserving titles, edition grouping and provider order")
  val dir=File(File(root,"sources"),M3uEpisodeSource.hash("p"));val generation=File(dir,M3uEpisodeSource.hash("g"));val index=M3uEpisodeSource.index(generation,"p","g")!!
  val selected=M3uEpisodeSource.prepare(generation,index,series[1][2]as String){}!!
  selected.use{check(it.next(250).map{r->r.posterUrl}==listOf(still1,still2))}
  pass("episode source retains original individual stills for the episode screen")
 }finally{root.deleteRecursively()}
}
