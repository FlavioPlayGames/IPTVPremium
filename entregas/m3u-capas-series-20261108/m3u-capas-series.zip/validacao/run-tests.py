from pathlib import Path
import subprocess,sys
w=Path('/workspace/capas-series-m3u');tc=Path('/workspace/storage-toolchain');classes='/workspace/backup-reviewed-build/app/build/intermediates/built_in_kotlinc/desempenho/compileDesempenhoKotlin/classes'
cp=(tc/'tests/xtream.classpath').read_text().strip().replace('/workspace/storage-work/app/build/intermediates/built_in_kotlinc/debug/compileDebugKotlin/classes',classes)
cp='/workspace/m3u-episodios-demanda/android-classes:/workspace/xtream-direct-fix/tests/android-classes:'+str(next((tc/'gradle/caches/modules-2/files-2.1/org.xerial/sqlite-jdbc').rglob('*.jar')))+':'+cp
java=str(tc/'jdk-25.0.4.1/bin/java')
for name in sys.argv[1:2]:
 jar=w/(name+'.jar')
 subprocess.run([java,'-Xmx512m','-cp',str(tc/'gradle-9.6.0/lib/*'),'org.jetbrains.kotlin.cli.jvm.K2JVMCompiler','-no-stdlib','-no-reflect','-Xfriend-paths='+classes,'-classpath',cp,'-d',str(jar),str(w/(name+'.kt')),str(w/'ReferenceParser.kt'),str(w/'ReferenceSchema.kt'),str(w/'SqlFixtures.kt'),str(w/'NativeBridge.kt')],check=True)
 subprocess.run([java,'-Xmx128m','-cp',str(jar)+':'+cp,'br.com.flaviotorres.iptvpremium.data.cache.'+name+'Kt',*sys.argv[2:]],check=True,timeout=900)
