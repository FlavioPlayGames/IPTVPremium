package br.com.flaviotorres.iptvpremium.data.cache
import br.com.flaviotorres.iptvpremium.data.m3u.*
import br.com.flaviotorres.iptvpremium.data.m3uepisodes.*
import br.com.flaviotorres.iptvpremium.data.repository.resolveSeriesArtworkIdentity
import kotlinx.coroutines.runBlocking
import org.json.JSONArray
import java.io.*
import java.nio.file.Files
fun main()=runBlocking {
 val rows=JSONArray(File("/workspace/capas-series-m3u/related-private.json").readText())
 val expected="https://image.tmdb.org/t/p/w600_and_h900_bestv2/eJJvzADsstZAz4tmE5qa3jjPUkF.jpg"
 val root=Files.createTempDirectory("aia-fixture").toFile()
 try{
  val store=DeferredM3uEpisodes(File(root,"sources"));val source=store.begin("p","g");val out=ByteArrayOutputStream()
  val input=buildString{appendLine("#EXTM3U");repeat(rows.length()){i->val row=rows.getJSONArray(i);appendLine("#EXTINF:-1 group-title=\"${row.getString(1)}\" tvg-logo=\"${row.getString(2)}\",${row.getString(0)}");appendLine("http://example.invalid/series/$i")}}
  val c=M3uCatalogParser.prepare(input.reader().buffered(),DataOutputStream(out),"p","g",episodeSource=source);source.finish()
  check(c.series==3&&c.episodes==161L&&store.sourceCounts("p","g")== (3 to 161L))
  val posters=mutableListOf<String?>()
  DataInputStream(ByteArrayInputStream(out.toByteArray())).use{r->check(r.readInt()==0x4D335331);while(true){val (kind,row)=M3uCatalogParser.read(r)?:break;if(kind==3)posters+=row[5]as String?}}
  check(posters.size==3&&posters.all{it==null})
  println("PASS 132 real O Conto da Aia records plus 29 records of another series reject the shared incorrect image and retain all 161 episodes")
  var searches=0;var details=0
  val official=resolveSeriesArtworkIdentity("O Conto Da Aia 2017 (2017)",2017,null,null,{path,q->
   when{
    path=="/search/tv"->{check(q["query"]=="o conto da aia");searches++;"""{"results":[{"id":69478,"name":"O Conto da Aia","first_air_date":"2017-04-26"}]}"""}
    path=="/tv/69478"->{details++;"""{"id":69478,"name":"O Conto da Aia","first_air_date":"2017-04-26","poster_path":"/official.jpg"}"""}
    else->error("Unexpected path")
   }
  })
  check(official?.optInt("id")==69478&&searches==1&&details==1)
  println("PASS official lookup uses the cleaned series identity and exact year instead of searching the duplicated provider year (mocked metadata service)")
 }finally{root.deleteRecursively()}
 Unit
}
