import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

val localProperties =
    Properties().apply {
        val localPropertiesFile =
            rootProject.file(
                "local.properties"
            )

        if (localPropertiesFile.exists()) {
            localPropertiesFile
                .inputStream()
                .use {
                    load(it)
                }
        }
    }

val tmdbReadToken =
    localProperties
        .getProperty(
            "TMDB_READ_TOKEN"
        )
        ?.trim()
        .orEmpty()

android {
    namespace = "br.com.flaviotorres.iptvpremium"

    compileSdk {
        version = release(37)
    }

    defaultConfig {
        applicationId = "br.com.flaviotorres.iptvpremium"
        minSdk = 34
        targetSdk = 37
        versionCode = 1
        versionName = "1.0"

        buildConfigField(
            type = "String",
            name = "TMDB_READ_TOKEN",
            value = "\"${
                tmdbReadToken
                    .replace("\\", "\\\\")
                    .replace("\"", "\\\"")
            }\""
        )
    }

    buildTypes {
        release {
            optimization {
                enable = true
                packageScope = setOf(
                    "androidx.**",
                    "kotlin.**",
                    "kotlinx.**"
                )
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }
}

dependencies {
    implementation(
        platform(
            libs.androidx.compose.bom
        )
    )

    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.appcompat)
    implementation(libs.androidx.activity.compose)

    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(
        "androidx.lifecycle:lifecycle-viewmodel-ktx:2.11.0"
    )
    implementation(
        "androidx.lifecycle:lifecycle-viewmodel-compose:2.11.0"
    )

    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)

    implementation(libs.androidx.tv.material)

    implementation(libs.androidx.navigation.compose)

    implementation(
        "androidx.datastore:datastore-preferences:1.2.1"
    )

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    implementation(libs.androidx.room.paging)
    ksp(libs.androidx.room.compiler)

    implementation(libs.androidx.paging.runtime)
    implementation(libs.androidx.paging.compose)

    // IPTVPremium - dois mecanismos internos de reproducao.
    // Media3/ExoPlayer e o mecanismo principal para Android TV e HDR nativo.
    val media3Version = "1.11.1"
    implementation("androidx.media3:media3-exoplayer:$media3Version")
    implementation("androidx.media3:media3-exoplayer-hls:$media3Version")
    implementation("androidx.media3:media3-exoplayer-dash:$media3Version")
    implementation("androidx.media3:media3-exoplayer-rtsp:$media3Version")
    implementation("androidx.media3:media3-ui:$media3Version")

    // LibVLC integrado como player alternativo (nao abre app externo).
    // Biblioteca licenciada sob LGPL 2.1: observar obrigacoes na distribuicao.
    implementation("org.videolan.android:libvlc-all:3.7.7")

    androidTestImplementation(

        platform(
            libs.androidx.compose.bom
        )
    )
    androidTestImplementation(
        libs.androidx.compose.ui.test.junit4
    )

    debugImplementation(
        libs.androidx.compose.ui.tooling
    )
    debugImplementation(
        libs.androidx.compose.ui.test.manifest
    )
}
