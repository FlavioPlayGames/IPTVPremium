package br.com.flaviotorres.iptvpremium.core.player

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** Chave individual do SubDL: criptografada pelo Android Keystore, fora do backup. */
class SubdlCredentialStore(context: Context) {
    private val appContext = context.applicationContext
    private val credentialFile = File(appContext.noBackupFilesDir, "iptvpremium_subdl_account_v1.bin")
    private val alias = "iptvpremium_subdl_secret_v1"

    fun isConfigured(): Boolean = readKey() != null

    fun readKey(): String? = runCatching {
        if (!credentialFile.isFile) return@runCatching null
        val stored = DataInputStream(credentialFile.inputStream()).use { input ->
            if (input.readInt() != 1) return@use null
            val iv = ByteArray(12)
            input.readFully(iv)
            val encryptedLength = input.readInt()
            if (encryptedLength !in 17..2048) return@use null
            val encrypted = ByteArray(encryptedLength)
            input.readFully(encrypted)
            iv to encrypted
        } ?: return@runCatching null
        val secret = getOrCreateKey()
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, secret, GCMParameterSpec(128, stored.first))
        val decoded = String(cipher.doFinal(stored.second), Charsets.UTF_8).trim()
        decoded.takeIf { it.isNotEmpty() }
    }.getOrNull()

    private fun saveKey(value: String) {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
        val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
        val temp = File(credentialFile.parentFile, credentialFile.name + ".tmp")
        try {
            DataOutputStream(temp.outputStream()).use { out ->
                out.writeInt(1)
                out.write(cipher.iv)
                out.writeInt(encrypted.size)
                out.write(encrypted)
            }
            if (!temp.renameTo(credentialFile)) {
                temp.copyTo(credentialFile, overwrite = true)
                temp.delete()
            }
        } finally { temp.delete() }
    }

    fun disconnect() { credentialFile.delete() }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        ).setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setUserAuthenticationRequired(false)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    /** /api/v2/me valida a chave sem pesquisar legendas e sem consumir buscas do filme. */
    suspend fun connect(rawKey: String): SubdlConnectionResult = withContext(Dispatchers.IO) {
        val key = rawKey.trim()
        if (key.length !in 8..512 || key.any { it.isWhitespace() || it.isISOControl() })
            return@withContext SubdlConnectionResult.INVALID_FORMAT
        val status = try {
            val con = URL("https://api.subdl.com/api/v2/me").openConnection() as HttpURLConnection
            try {
                con.requestMethod = "GET"
                con.connectTimeout = 7_000
                con.readTimeout = 10_000
                con.setRequestProperty("Accept", "application/json")
                con.setRequestProperty("Authorization", "Bearer $key")
                con.responseCode
            } finally { con.disconnect() }
        } catch (_: Exception) { return@withContext SubdlConnectionResult.NETWORK_ERROR }
        when (status) {
            200 -> {
                try {
                    saveKey(key)
                    SubdlConnectionResult.CONNECTED
                } catch (_: Exception) { SubdlConnectionResult.STORAGE_ERROR }
            }
            401, 403 -> SubdlConnectionResult.INVALID_KEY
            429 -> SubdlConnectionResult.LIMITED
            else -> SubdlConnectionResult.SERVER_ERROR
        }
    }
}

enum class SubdlConnectionResult {
    CONNECTED, INVALID_FORMAT, INVALID_KEY, LIMITED, NETWORK_ERROR, STORAGE_ERROR, SERVER_ERROR
}