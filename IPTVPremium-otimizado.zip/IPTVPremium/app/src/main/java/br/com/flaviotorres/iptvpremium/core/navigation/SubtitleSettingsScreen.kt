package br.com.flaviotorres.iptvpremium.ui.settings

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.core.player.ExternalSubtitleRepository
import br.com.flaviotorres.iptvpremium.core.player.SubdlConnectionResult
import br.com.flaviotorres.iptvpremium.core.player.SubdlCredentialStore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val gold = Color(0xFFFFD54A)
private val panelShape = RoundedCornerShape(18.dp)

/** Entrada Configurações da Home. Não abre nenhuma pesquisa de legenda. */
@Composable
fun IPTVSettingsScreen(onBack: () -> Unit, onSubdlClick: () -> Unit) {
    BackHandler(onBack = onBack)
    SettingsLayout(title = "CONFIGURAÇÕES", onBack = onBack) {
        Text(
            "Legendas e idiomas",
            color = Color.White,
            fontSize = 19.sp,
            fontWeight = FontWeight.SemiBold
        )
        SettingsAction(
            title = "Legendas externas · SubDL + SubSource",
            description = "Configure suas chaves pessoais dos dois provedores",
            onClick = onSubdlClick
        )
        Text(
            "As buscas de legendas acontecem somente ao abrir um filme ou episódio.",
            color = Color.LightGray,
            fontSize = 13.sp
        )
    }
}

/** Conta individual: não solicita e não guarda senha do site SubDL. */
@Composable
fun SubdlAccountScreen(onBack: () -> Unit) {
    BackHandler(onBack = onBack)
    val context = LocalContext.current
    val credentials = remember(context) { SubdlCredentialStore(context.applicationContext) }
    val repo = remember(context) { ExternalSubtitleRepository(context.applicationContext) }
    val scope = rememberCoroutineScope()
    var connected by remember { mutableStateOf(credentials.isConfigured()) }
    var input by remember { mutableStateOf("") }
    var visible by remember { mutableStateOf(false) }
    var processing by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var focused by remember { mutableStateOf(false) }
    // Provedor independente: nunca substitui nem reutiliza a chave do SubDL.
    val subsourceCredentials = remember(context) {
        SubsourceCredentialStore(context.applicationContext)
    }
    var subsourceConfigured by remember { mutableStateOf(subsourceCredentials.isConfigured()) }
    var subsourceInput by remember { mutableStateOf("") }
    var subsourceVisible by remember { mutableStateOf(false) }
    var subsourceSaving by remember { mutableStateOf(false) }
    var subsourceMessage by remember { mutableStateOf<String?>(null) }
    var subsourceFocused by remember { mutableStateOf(false) }

    SettingsLayout(title = "LEGENDAS EXTERNAS", onBack = onBack) {
        Text("SubDL", color = gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(
            "Cada pessoa utiliza a própria conta e seus próprios limites. " +
                    "Crie uma conta no SubDL e copie a chave de API no painel do serviço.",
            color = Color.White.copy(alpha = 0.88f), fontSize = 14.sp
        )
        Box(Modifier.fillMaxWidth().clip(panelShape)
            .background(Color(0xFF171D22))
            .border(1.dp, gold.copy(alpha = .45f), panelShape)
            .padding(15.dp)) {
            Text(
                if (connected) "SubDL conectado neste dispositivo" else "SubDL não configurado",
                color = if (connected) Color(0xFFB8E7AF) else Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
        }
        SettingsAction(
            title = "Criar conta ou gerar chave de API",
            description = "Abrir o site oficial: subdl.com",
            onClick = {
                try {
                    context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://subdl.com"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: ActivityNotFoundException) {
                    message = "Sem navegador disponível. Abra subdl.com no celular ou computador."
                } catch (_: Exception) {
                    message = "Não foi possível abrir o navegador. Acesse subdl.com manualmente."
                }
            }
        )
        Text("Chave de API pessoal", color = Color.White, fontSize = 15.sp)
        BasicTextField(
            value = input,
            onValueChange = { if (it.length <= 512) input = it },
            singleLine = true,
            enabled = !processing,
            visualTransformation = if (visible) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            cursorBrush = SolidColor(gold),
            textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
            modifier = Modifier.fillMaxWidth()
                .onFocusChanged { focused = it.isFocused }
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF0E1317))
                .border(1.5.dp, if (focused) gold else Color.White.copy(alpha = .35f), RoundedCornerShape(10.dp))
                .padding(horizontal = 15.dp, vertical = 17.dp),
            decorationBox = { textField ->
                Box {
                    if (input.isBlank()) Text(
                        "Cole ou digite sua chave do SubDL",
                        color = Color.Gray, fontSize = 14.sp
                    )
                    textField()
                }
            }
        )
        SettingsAction(
            title = if (visible) "Ocultar chave" else "Mostrar chave",
            description = "A chave não é exibida depois de salva",
            onClick = { visible = !visible }
        )
        SettingsAction(
            title = if (processing) "Verificando…" else "Conectar / testar e salvar",
            description = "Valida a chave no SubDL sem pesquisar filmes",
            enabled = !processing && input.isNotBlank(),
            onClick = {
                if (!processing) {
                    processing = true
                    message = null
                    scope.launch {
                        val result = credentials.connect(input)
                        connected = credentials.isConfigured()
                        message = when (result) {
                            SubdlConnectionResult.CONNECTED -> {
                                withContext(Dispatchers.IO) { repo.clearCaches() }
                                input = ""
                                visible = false
                                "Conectado! As legendas serão procuradas quando você abrir o player."
                            }
                            SubdlConnectionResult.INVALID_FORMAT -> "A chave informada parece incompleta."
                            SubdlConnectionResult.INVALID_KEY -> "Chave recusada pelo SubDL. Confira sua conta."
                            SubdlConnectionResult.LIMITED -> "SubDL temporariamente indisponível por limite de requisições."
                            SubdlConnectionResult.NETWORK_ERROR -> "Falha de conexão. Verifique a internet e tente novamente."
                            SubdlConnectionResult.STORAGE_ERROR -> "Não foi possível proteger a chave neste dispositivo."
                            SubdlConnectionResult.SERVER_ERROR -> "O SubDL não confirmou a chave. Tente novamente mais tarde."
                        }
                        processing = false
                    }
                }
            }
        )
        if (connected) {
            SettingsAction(
                title = "Desconectar SubDL",
                description = "Apagar a chave deste dispositivo e limpar o cache de legendas externas",
                enabled = !processing,
                onClick = {
                    scope.launch {
                        processing = true
                        withContext(Dispatchers.IO) {
                            credentials.disconnect()
                            repo.clearCaches()
                        }
                        connected = false
                        input = ""
                        message = "Conta desconectada deste dispositivo."
                        processing = false
                    }
                }
            )
        }
        message?.let { Text(it, color = gold, fontSize = 14.sp) }
        Text(
            "Segurança: o IPTVPremium guarda somente a chave de API, criptografada " +
                    "no dispositivo. Não informe sua senha da conta SubDL aqui.",
            color = Color.LightGray, fontSize = 12.sp
        )

        // SubSource: cadastrado na mesma tela, sem alterar a chave SubDL.
        Spacer(Modifier.fillMaxWidth().height(1.dp).background(gold.copy(alpha = .38f)))
        Text("SubSource", color = gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text(
            "Segundo provedor de legendas. A chave é independente e será usada " +
                    "somente quando o player consultar o SubSource.",
            color = Color.White.copy(alpha = .88f), fontSize = 14.sp
        )
        Box(
            Modifier.fillMaxWidth().clip(panelShape)
                .background(Color(0xFF171D22))
                .border(1.dp, gold.copy(alpha = .45f), panelShape)
                .padding(15.dp)
        ) {
            Text(
                if (subsourceConfigured) "Chave SubSource salva neste dispositivo"
                else "SubSource não configurado",
                color = if (subsourceConfigured) Color(0xFFB8E7AF) else Color.White,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
        }
        SettingsAction(
            title = "Gerar chave do SubSource",
            description = "Abrir subsource.net; gere a chave no perfil da conta",
            onClick = {
                try {
                    context.startActivity(
                        Intent(Intent.ACTION_VIEW, Uri.parse("https://subsource.net"))
                            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    )
                } catch (_: Exception) {
                    subsourceMessage = "Abra subsource.net no celular ou computador."
                }
            }
        )
        Text("Chave de API do SubSource", color = Color.White, fontSize = 15.sp)
        BasicTextField(
            value = subsourceInput,
            onValueChange = { if (it.length <= 512) subsourceInput = it },
            singleLine = true,
            enabled = !subsourceSaving,
            visualTransformation = if (subsourceVisible) VisualTransformation.None
            else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            cursorBrush = SolidColor(gold),
            textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
            modifier = Modifier.fillMaxWidth()
                .onFocusChanged { subsourceFocused = it.isFocused }
                .clip(RoundedCornerShape(10.dp))
                .background(Color(0xFF0E1317))
                .border(
                    1.5.dp,
                    if (subsourceFocused) gold else Color.White.copy(alpha = .35f),
                    RoundedCornerShape(10.dp)
                )
                .padding(horizontal = 15.dp, vertical = 17.dp),
            decorationBox = { field ->
                Box {
                    if (subsourceInput.isBlank()) {
                        Text("Cole sua chave do SubSource", color = Color.Gray, fontSize = 14.sp)
                    }
                    field()
                }
            }
        )
        SettingsAction(
            title = if (subsourceVisible) "Ocultar chave SubSource" else "Mostrar chave SubSource",
            description = "A chave não será exibida depois de salva",
            onClick = { subsourceVisible = !subsourceVisible }
        )
        SettingsAction(
            title = if (subsourceSaving) "Salvando…" else "Salvar chave SubSource",
            description = "Salva com criptografia; a conexão será testada ao abrir o player",
            enabled = !subsourceSaving && subsourceInput.isNotBlank(),
            onClick = {
                if (!subsourceSaving) {
                    subsourceSaving = true
                    subsourceMessage = null
                    val typedKey = subsourceInput
                    scope.launch {
                        val saved = withContext(Dispatchers.IO) {
                            subsourceCredentials.saveKey(typedKey)
                        }
                        subsourceConfigured = subsourceCredentials.isConfigured()
                        subsourceMessage = if (saved) {
                            subsourceInput = ""
                            subsourceVisible = false
                            "Chave salva! A validação ocorrerá na pesquisa pelo player."
                        } else {
                            "Não foi possível salvar. Verifique a chave e tente novamente."
                        }
                        subsourceSaving = false
                    }
                }
            }
        )
        if (subsourceConfigured) {
            SettingsAction(
                title = "Remover chave SubSource",
                description = "Não altera o SubDL nem apaga legendas baixadas",
                enabled = !subsourceSaving,
                onClick = {
                    scope.launch {
                        subsourceSaving = true
                        withContext(Dispatchers.IO) { subsourceCredentials.disconnect() }
                        subsourceConfigured = false
                        subsourceInput = ""
                        subsourceVisible = false
                        subsourceMessage = "Chave SubSource removida deste dispositivo."
                        subsourceSaving = false
                    }
                }
            )
        }
        subsourceMessage?.let { Text(it, color = gold, fontSize = 14.sp) }
        Text(
            "Segurança: a chave SubSource é protegida pelo Android Keystore e " +
                    "não é incluída no backup. Não cole sua chave em conversas ou logs.",
            color = Color.LightGray, fontSize = 12.sp
        )
    }
}

@Composable
private fun SettingsLayout(
    title: String,
    onBack: () -> Unit,
    body: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit
) {
    Box(
        modifier = Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF10171C), Color(0xFF050608))))
            .padding(22.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(.94f)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.weight(1f)) {
                    Text(title, color = gold, fontWeight = FontWeight.Bold, fontSize = 22.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Spacer(Modifier.width(12.dp))
                SettingsAction("Voltar", "", onClick = onBack, compact = true)
            }
            Spacer(Modifier.fillMaxWidth().height(1.dp).background(gold.copy(alpha = .45f)))
            body()
        }
    }
}

@Composable
private fun SettingsAction(
    title: String,
    description: String,
    enabled: Boolean = true,
    compact: Boolean = false,
    onClick: () -> Unit
) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(12.dp)
    Column(
        modifier = (if (compact) Modifier else Modifier.fillMaxWidth())
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(if (focused) Color(0xFF4E3B13) else Color(0xFF182027))
            .border(1.dp, if (focused) gold else gold.copy(alpha = .38f), shape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = if (compact) 10.dp else 15.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(title, color = if (enabled) Color.White else Color.Gray,
            fontSize = if (compact) 13.sp else 16.sp, fontWeight = FontWeight.SemiBold)
        if (description.isNotEmpty() && !compact) Text(description,
            color = Color.LightGray, fontSize = 12.sp)
    }
}

/**
 * Armazena a chave pessoal do SubSource separadamente do SubDL.
 * O repositório de legendas pode acessar esta classe para ler a chave,
 * usando o cabeçalho X-API-Key (nunca parâmetros de URL).
 *
 * Esta classe não realiza buscas nem downloads e não afirma validar a chave.
 */
class SubsourceCredentialStore(context: android.content.Context) {
    private val appContext = context.applicationContext
    private val credentialFile = File(
        appContext.noBackupFilesDir, "iptvpremium_subsource_account_v1.bin"
    )
    private val alias = "iptvpremium_subsource_secret_v1"

    fun isConfigured(): Boolean = readKey() != null

    fun readKey(): String? = runCatching {
        if (!credentialFile.isFile) return@runCatching null
        val pair = DataInputStream(credentialFile.inputStream()).use { input ->
            if (input.readInt() != 1) return@use null
            val iv = ByteArray(12)
            input.readFully(iv)
            val length = input.readInt()
            if (length !in 17..2048) return@use null
            val encrypted = ByteArray(length)
            input.readFully(encrypted)
            iv to encrypted
        } ?: return@runCatching null
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, pair.first))
        String(cipher.doFinal(pair.second), Charsets.UTF_8)
            .trim().takeIf { it.isNotEmpty() }
    }.getOrNull()

    /** Salva sem consultar a API e sem consumir quota. Validação virá na busca. */
    fun saveKey(rawKey: String): Boolean {
        val key = rawKey.trim()
        if (key.length !in 8..512 || key.any { it.isWhitespace() || it.isISOControl() }) {
            return false
        }
        return runCatching {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val encrypted = cipher.doFinal(key.toByteArray(Charsets.UTF_8))
            val temp = File(credentialFile.parentFile, credentialFile.name + ".tmp")
            try {
                DataOutputStream(temp.outputStream()).use { output ->
                    output.writeInt(1)
                    output.write(cipher.iv)
                    output.writeInt(encrypted.size)
                    output.write(encrypted)
                }
                if (!temp.renameTo(credentialFile)) {
                    temp.copyTo(credentialFile, overwrite = true)
                    temp.delete()
                }
            } finally {
                temp.delete()
            }
            true
        }.getOrDefault(false)
    }

    fun disconnect() {
        credentialFile.delete()
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore"
        )
        generator.init(
            KeyGenParameterSpec.Builder(
                alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
            )
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setUserAuthenticationRequired(false)
                .build()
        )
        return generator.generateKey()
    }
}
