package br.com.flaviotorres.iptvpremium.data.remote

interface PlaylistHttpClient {

    /*
     * Mantido para respostas menores, como os endpoints JSON
     * do Xtream Codes.
     */
    suspend fun get(
        url: String
    ): String

    /*
     * Lê o conteúdo linha por linha sem transformar toda a resposta
     * em uma String gigante na memória.
     *
     * Será usado principalmente pelas listas M3U muito grandes.
     */
    suspend fun readLines(
        url: String,
        onLine: suspend (String) -> Unit
    )
}
