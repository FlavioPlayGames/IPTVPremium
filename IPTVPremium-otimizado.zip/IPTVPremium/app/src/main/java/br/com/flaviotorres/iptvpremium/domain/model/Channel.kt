package br.com.flaviotorres.iptvpremium.domain.model

data class Channel(
    val id: String,
    val name: String,
    val categoryId: String?,
    val logoUrl: String?,
    val streamUrl: String,
    val epgChannelId: String?
)