package br.com.flaviotorres.iptvpremium.domain.repository

import br.com.flaviotorres.iptvpremium.domain.model.PlaylistContent
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource

interface PlaylistRepository {

    suspend fun loadContent(
        source: PlaylistSource
    ): PlaylistContent
}