package br.com.flaviotorres.iptvpremium.data.cache.entity

import androidx.room.Entity
import androidx.room.Index

@Entity(
    tableName = "cached_channels",
    primaryKeys = [
        "playlistId",
        "generationId",
        "channelId"
    ],
    indices = [
        Index(
            value = [
                "playlistId",
                "generationId",
                "categoryId"
            ]
        ),
        Index(
            value = [
                "playlistId",
                "generationId",
                "name"
            ]
        )
    ]
)
data class CachedChannelEntity(
    val playlistId: String,
    val generationId: String,
    val channelId: String,
    val name: String,
    val categoryId: String?,
    val logoUrl: String?,
    val streamUrl: String,
    val epgChannelId: String?,
    val channelNumber: Int
)
