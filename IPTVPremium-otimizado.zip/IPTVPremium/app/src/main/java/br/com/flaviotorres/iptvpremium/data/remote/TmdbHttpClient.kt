package br.com.flaviotorres.iptvpremium.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.nio.charset.StandardCharsets

class TmdbHttpClient(
    private val readAccessToken: String,
    private val baseUrl: String = "https://api.themoviedb.org/3"
) {

    suspend fun get(
        path: String,
        queryParameters: Map<String, String> = emptyMap()
    ): String = withContext(Dispatchers.IO) {
        check(readAccessToken.isNotBlank()) {
            "TMDB_READ_TOKEN não foi configurado."
        }

        val normalizedPath =
            if (path.startsWith("/")) {
                path
            } else {
                "/$path"
            }

        val queryString =
            queryParameters
                .filterValues { it.isNotBlank() }
                .entries
                .joinToString("&") { (key, value) ->
                    "${encode(key)}=${encode(value)}"
                }

        val requestUrl =
            buildString {
                append(baseUrl)
                append(normalizedPath)

                if (queryString.isNotBlank()) {
                    append("?")
                    append(queryString)
                }
            }

        val connection =
            URL(requestUrl)
                .openConnection() as HttpURLConnection

        try {
            connection.requestMethod = "GET"

            connection.connectTimeout = 15_000
            connection.readTimeout = 30_000

            connection.instanceFollowRedirects = true
            connection.useCaches = false

            connection.setRequestProperty(
                "Accept",
                "application/json"
            )

            connection.setRequestProperty(
                "Authorization",
                "Bearer $readAccessToken"
            )

            connection.setRequestProperty(
                "User-Agent",
                "IPTVPremium/1.0"
            )

            val responseCode =
                connection.responseCode

            if (responseCode !in 200..299) {
                val errorBody =
                    connection.errorStream
                        ?.bufferedReader(Charsets.UTF_8)
                        ?.use { it.readText() }
                        .orEmpty()

                throw IllegalStateException(
                    buildString {
                        append("Erro HTTP ")
                        append(responseCode)
                        append(" ao acessar o TMDB.")

                        if (errorBody.isNotBlank()) {
                            append(" Resposta: ")
                            append(errorBody.take(500))
                        }
                    }
                )
            }

            connection.inputStream
                .bufferedReader(Charsets.UTF_8)
                .use { reader ->
                    reader.readText()
                }
        } finally {
            connection.disconnect()
        }
    }

    private fun encode(
        value: String
    ): String =
        URLEncoder.encode(
            value,
            StandardCharsets.UTF_8.toString()
        )
}
