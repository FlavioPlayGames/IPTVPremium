package br.com.flaviotorres.iptvpremium.data.resolver

import android.net.Uri
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import java.util.Locale

object M3uXtreamResolver {

    fun resolve(
        source: PlaylistSource.M3u
    ): PlaylistSource.XtreamCodes? {
        val playlistUrl =
            source.playlistUrl.trim()

        if (playlistUrl.isBlank()) {
            return null
        }

        val uri =
            runCatching {
                Uri.parse(playlistUrl)
            }.getOrNull()
                ?: return null

        val scheme =
            uri.scheme
                ?.lowercase(Locale.ROOT)
                ?: return null

        if (
            scheme != "http" &&
            scheme != "https"
        ) {
            return null
        }

        val authority =
            uri.encodedAuthority
                ?.takeIf {
                    it.isNotBlank()
                }
                ?: return null

        val path =
            uri.path
                .orEmpty()

        val normalizedPath =
            path.trimEnd('/')

        /*
         * O formato clássico do Xtream para exportar M3U é:
         *
         * /get.php?username=...&password=...&type=m3u_plus...
         *
         * Não exigimos "type=m3u_plus" porque alguns servidores omitem
         * esse parâmetro ou usam "m3u". O que realmente nos interessa
         * para detectar o Xtream é o endpoint get.php + as credenciais.
         */
        if (
            !normalizedPath.endsWith(
                "/get.php",
                ignoreCase = true
            ) &&
            !normalizedPath.equals(
                "get.php",
                ignoreCase = true
            )
        ) {
            return null
        }

        val username =
            uri.getQueryParameter("username")
                ?.trim()
                ?.takeIf {
                    it.isNotBlank()
                }
                ?: return null

        val password =
            uri.getQueryParameter("password")
                ?.takeIf {
                    it.isNotBlank()
                }
                ?: return null

        /*
         * Preserva um eventual prefixo do servidor.
         *
         * Exemplo:
         * https://servidor.com/iptv/get.php?...
         *
         * vira:
         * https://servidor.com/iptv
         */
        val parentPath =
            if (
                normalizedPath.equals(
                    "get.php",
                    ignoreCase = true
                )
            ) {
                ""
            } else {
                normalizedPath
                    .removeSuffixIgnoreCase(
                        "/get.php"
                    )
                    .trimEnd('/')
            }

        val serverUrl =
            buildString {
                append(scheme)
                append("://")
                append(authority)

                if (parentPath.isNotBlank()) {
                    if (!parentPath.startsWith("/")) {
                        append("/")
                    }

                    append(parentPath)
                }
            }

        /*
         * A conversão é somente em memória.
         *
         * A playlist cadastrada continua sendo PlaylistSource.M3u.
         * Não duplicamos username/senha no modelo persistido e não
         * alteramos a experiência do usuário.
         */
        return PlaylistSource.XtreamCodes(
            id = source.id,
            name = source.name,
            isEnabled = source.isEnabled,
            serverUrl = serverUrl,
            username = username,
            password = password
        )
    }

    private fun String.removeSuffixIgnoreCase(
        suffix: String
    ): String {
        return if (
            endsWith(
                suffix,
                ignoreCase = true
            )
        ) {
            dropLast(
                suffix.length
            )
        } else {
            this
        }
    }
}
