package br.com.flaviotorres.iptvpremium.data.history

import android.content.Context
import br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType
import br.com.flaviotorres.iptvpremium.core.player.PlaybackMedia
import org.json.JSONArray
import org.json.JSONObject

/**
 * Historico local de reproducao, separado do cache descartavel do catalogo.
 * Armazena somente IDs, titulos e posicoes; NUNCA guarda streamUrl, senha ou token.
 * Chave composta por playlist, tipo de midia e ID real do provedor.
 */
data class WatchHistoryEntry(
    val playlistId: String,
    val contentType: PlaybackContentType,
    val contentId: String,
    val seriesId: String? = null,
    val title: String,
    val posterUrl: String? = null,
    val seriesTitle: String? = null,
    val seriesPosterUrl: String? = null,
    val seasonNumber: Int? = null,
    val episodeNumber: Int? = null,
    val positionMs: Long,
    val durationMs: Long?,
    val updatedAtMs: Long
) {
    val fraction: Float?
        get() = durationMs?.takeIf { it > 0L }
            ?.let { (positionMs.toFloat() / it).coerceIn(0f, 1f) }

    val completed: Boolean
        get() = (fraction ?: 0f) >= 0.95f

    val inProgress: Boolean
        get() = positionMs >= 10_000L && !completed
}

class WatchHistoryStore(context: Context) {
    private val prefsContext = context.applicationContext
    private val prefs = prefsContext.getSharedPreferences(
        "iptvpremium_watch_history_v1", Context.MODE_PRIVATE
    )

    @Synchronized
    fun all(playlistId: String): List<WatchHistoryEntry> = readAll()
        .filter { it.playlistId == playlistId }
        .sortedByDescending { it.updatedAtMs }

    @Synchronized
    fun movie(playlistId: String, movieId: String): WatchHistoryEntry? =
        all(playlistId).firstOrNull {
            it.contentType == PlaybackContentType.MOVIE && it.contentId == movieId
        }

    @Synchronized
    fun lastEpisode(playlistId: String, seriesId: String): WatchHistoryEntry? =
        all(playlistId).firstOrNull {
            it.contentType == PlaybackContentType.EPISODE && it.seriesId == seriesId
        }

    @Synchronized
    fun save(
        playlistId: String,
        media: PlaybackMedia,
        positionMs: Long,
        durationMs: Long?,
        seriesTitle: String? = null,
        seriesPosterUrl: String? = null
    ) {
        if (playlistId.isBlank() || media.id.isBlank() ||
            media.type == PlaybackContentType.LIVE_CHANNEL || positionMs < 1_000L
        ) return
        val previous = all(playlistId).firstOrNull {
            it.contentType == media.type && it.contentId == media.id
        }
        val normalizedDuration = durationMs?.takeIf { it > 0L }
            ?: media.durationMs?.takeIf { it > 0L }
            ?: previous?.durationMs
        val entry = WatchHistoryEntry(
            playlistId = playlistId,
            contentType = media.type,
            contentId = media.id,
            seriesId = media.seriesId ?: previous?.seriesId,
            title = media.title,
            posterUrl = media.posterUrl ?: previous?.posterUrl,
            seriesTitle = seriesTitle ?: previous?.seriesTitle,
            seriesPosterUrl = seriesPosterUrl ?: previous?.seriesPosterUrl,
            seasonNumber = media.seasonNumber ?: previous?.seasonNumber,
            episodeNumber = media.episodeNumber ?: previous?.episodeNumber,
            positionMs = positionMs.coerceAtLeast(0L),
            durationMs = normalizedDuration,
            updatedAtMs = System.currentTimeMillis()
        )
        val kept = readAll().filterNot {
            it.playlistId == playlistId &&
                    it.contentType == media.type && it.contentId == media.id
        }
        writeAll((listOf(entry) + kept).sortedByDescending { it.updatedAtMs }.take(400))
    }

    @Synchronized
    fun remove(playlistId: String, type: PlaybackContentType, contentId: String) {
        if (playlistId.isBlank() || contentId.isBlank()) return
        val remaining = readAll().filterNot {
            it.playlistId == playlistId && it.contentType == type && it.contentId == contentId
        }
        writeAll(remaining)
    }

    /** Recupera posicoes da implementacao anterior sem alterar seus dados. */
    fun legacyMoviePositions(playlistId: String): List<Pair<String, Long>> {
        val old = prefsContext.getSharedPreferences(
            "iptvpremium_movies_assistir_v1", Context.MODE_PRIVATE
        )
        val prefix = "movie:${playlistId.length}:$playlistId:"
        return old.all.mapNotNull { (key, value) ->
            if (!key.startsWith(prefix)) return@mapNotNull null
            val tail = key.removePrefix(prefix)
            val declaredLength = tail.substringBefore(':').toIntOrNull() ?: return@mapNotNull null
            val id = tail.substringAfter(':', "")
            val position = (value as? Long) ?: return@mapNotNull null
            if (id.isBlank() || id.length != declaredLength || position < 10_000L) null
            else id to position
        }
    }

    /** Recupera o ultimo episodio visto de cada serie. */
    fun legacySeriesPositions(playlistId: String): List<Triple<String, String, Long>> {
        val old = prefsContext.getSharedPreferences(
            "iptvpremium_series_assistir_v1", Context.MODE_PRIVATE
        )
        val prefix = "last:${playlistId.length}:$playlistId:"
        return old.all.mapNotNull { (key, value) ->
            if (!key.startsWith(prefix)) return@mapNotNull null
            val tail = key.removePrefix(prefix)
            val declaredLength = tail.substringBefore(':').toIntOrNull() ?: return@mapNotNull null
            val seriesId = tail.substringAfter(':', "")
            val episodeId = (value as? String)?.takeIf(String::isNotBlank)
                ?: return@mapNotNull null
            if (seriesId.isBlank() || seriesId.length != declaredLength) return@mapNotNull null
            val positionKey = "position:${playlistId.length}:$playlistId:" +
                    "${seriesId.length}:$seriesId:${episodeId.length}:$episodeId"
            val position = old.getLong(positionKey, 0L)
            if (position < 10_000L) null else Triple(seriesId, episodeId, position)
        }
    }

    @Synchronized
    fun importLegacy(entry: WatchHistoryEntry): Boolean {
        if (entry.playlistId.isBlank() || !entry.inProgress ||
            all(entry.playlistId).any { it.contentType == entry.contentType &&
                    it.contentId == entry.contentId }
        ) return false
        writeAll((listOf(entry) + readAll()).sortedByDescending { it.updatedAtMs }.take(400))
        return true
    }

    private fun readAll(): List<WatchHistoryEntry> = runCatching {
        val array = JSONArray(prefs.getString("items", "[]") ?: "[]")
        buildList {
            for (index in 0 until array.length()) {
                val obj = array.optJSONObject(index) ?: continue
                val type = runCatching {
                    PlaybackContentType.valueOf(obj.optString("type"))
                }.getOrNull() ?: continue
                val playlist = obj.optString("playlistId")
                val id = obj.optString("contentId")
                if (playlist.isBlank() || id.isBlank()) continue
                add(WatchHistoryEntry(
                    playlistId = playlist,
                    contentType = type,
                    contentId = id,
                    seriesId = obj.optString("seriesId").takeIf { it.isNotBlank() },
                    title = obj.optString("title"),
                    posterUrl = obj.optString("posterUrl").takeIf { it.isNotBlank() },
                    seriesTitle = obj.optString("seriesTitle").takeIf { it.isNotBlank() },
                    seriesPosterUrl = obj.optString("seriesPosterUrl").takeIf { it.isNotBlank() },
                    seasonNumber = obj.optInt("seasonNumber", -1).takeIf { it >= 0 },
                    episodeNumber = obj.optInt("episodeNumber", -1).takeIf { it >= 0 },
                    positionMs = obj.optLong("positionMs").coerceAtLeast(0L),
                    durationMs = obj.optLong("durationMs").takeIf { it > 0L },
                    updatedAtMs = obj.optLong("updatedAtMs")
                ))
            }
        }
    }.getOrDefault(emptyList())

    private fun writeAll(items: List<WatchHistoryEntry>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject().apply {
                put("playlistId", item.playlistId)
                put("type", item.contentType.name)
                put("contentId", item.contentId)
                put("seriesId", item.seriesId ?: "")
                put("title", item.title)
                put("posterUrl", item.posterUrl ?: "")
                put("seriesTitle", item.seriesTitle ?: "")
                put("seriesPosterUrl", item.seriesPosterUrl ?: "")
                put("seasonNumber", item.seasonNumber ?: -1)
                put("episodeNumber", item.episodeNumber ?: -1)
                put("positionMs", item.positionMs)
                put("durationMs", item.durationMs ?: 0L)
                put("updatedAtMs", item.updatedAtMs)
            })
        }
        prefs.edit().putString("items", array.toString()).apply()
    }
}
