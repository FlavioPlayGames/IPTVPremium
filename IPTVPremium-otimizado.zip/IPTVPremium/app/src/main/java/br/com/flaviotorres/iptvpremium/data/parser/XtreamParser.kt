package br.com.flaviotorres.iptvpremium.data.parser

import br.com.flaviotorres.iptvpremium.domain.model.Category
import br.com.flaviotorres.iptvpremium.domain.model.Channel
import br.com.flaviotorres.iptvpremium.domain.model.Movie
import br.com.flaviotorres.iptvpremium.domain.model.MovieDetails
import br.com.flaviotorres.iptvpremium.domain.model.Series

interface XtreamParser {

    fun parseLiveCategories(
        content: String
    ): List<Category>

    fun parseLiveStreams(
        content: String
    ): List<Channel>

    fun parseMovieCategories(
        content: String
    ): List<Category>

    fun parseMovies(
        content: String
    ): List<Movie>

    fun parseMovieDetails(
        content: String,
        movieId: String
    ): MovieDetails?

    fun parseSeriesCategories(
        content: String
    ): List<Category>

    fun parseSeries(
        content: String
    ): List<Series>
}
