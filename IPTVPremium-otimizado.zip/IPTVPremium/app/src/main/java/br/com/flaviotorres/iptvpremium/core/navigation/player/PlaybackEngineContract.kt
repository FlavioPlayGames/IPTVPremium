
package br.com.flaviotorres.iptvpremium.core.player

import android.view.SurfaceHolder
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Contrato comum dos mecanismos Media3/ExoPlayer e LibVLC do IPTVPremium.
 *
 * A UI conversa somente com este contrato. Cada adaptador traduz os comandos
 * para sua biblioteca nativa, sem duplicar a interface preto/dourado.
 *
 * REGRAS DE CICLO DE VIDA
 * - Todos os comandos e callbacks de SurfaceHolder devem ocorrer na thread
 *   principal do Android. O adaptador publica estados pelos Flows.
 * - prepare() inicia a preparação sem bloquear a interface; ACCEPTED não quer
 *   dizer que o vídeo já está reproduzindo.
 * - release() é definitivo e deve ser idempotente. Depois disso, o adaptador
 *   não aceita comandos de reprodução.
 * - Apenas um mecanismo deve manter a superfície ativa por vez.
 * - Não incluir streamUrl nem exceções com URLs em logs ou mensagens públicas.
 *
 * Este arquivo NÃO cria players, não acessa Xtream, não grava Room/DataStore
 * e não muda as telas existentes.
 */

/** Parâmetros necessários para abrir mídia ou retomar após trocar de engine. */
data class PlaybackOpenRequest(
    val media: PlaybackMedia,
    val startPositionMs: Long = 0L,
    val playWhenReady: Boolean = true,
    val settings: PlaybackSettings = PlaybackSettings()
) {
    init {
        require(startPositionMs >= 0L) {
            "A posição inicial não pode ser negativa."
        }
    }
}

/**
 * Resultado imediato de um comando. O resultado final da operação é refletido
 * pelo state e, no caso de falha, por events.
 */
enum class PlaybackCommandResult {
    ACCEPTED,
    UNSUPPORTED,
    INVALID_STATE,
    INVALID_ARGUMENT,
    NOT_AVAILABLE
}

/**
 * Capacidade implementada pelo adaptador ATUAL e pela mídia detectada.
 *
 * Tudo começa como false: o menu não deve oferecer recursos que ainda não
 * foram identificados/implementados. Disponibilidade de faixas, resoluções e
 * formatos HDR é informada separadamente em PlaybackUiState.
 */
data class PlaybackEngineCapabilities(
    val supportsSeeking: Boolean = false,
    val supportsLiveTimeshift: Boolean = false,
    val supportsGoLive: Boolean = false,
    val supportsAudioTrackSelection: Boolean = false,
    val supportsSubtitleTrackSelection: Boolean = false,
    val supportsSubtitleStyling: Boolean = false,
    val supportsSubtitleTimingOffset: Boolean = false,
    val supportsManualQualitySelection: Boolean = false,
    val supportsHdrVariantSelection: Boolean = false,
    val supportsPlaybackSpeed: Boolean = false,
    val supportsVolumeControl: Boolean = false,
    val supportsVideoAspectModes: Boolean = false,
    val supportsManualZoomAndPan: Boolean = false,
    val supportsIndependentWidthHeight: Boolean = false,
    val supportsTechnicalDiagnostics: Boolean = false
)

/**
 * Eventos pontuais para a UI e para o futuro gerenciador de recuperação.
 * Não substituem PlaybackUiState, que contém o estado corrente.
 */
sealed interface PlaybackEngineEvent {

    /** Primeiro quadro foi realmente exibido, e não apenas preparado. */
    data object FirstVideoFrame : PlaybackEngineEvent

    /** Um seek solicitado terminou. A posição pode ter sido ajustada. */
    data class SeekCompleted(val actualPositionMs: Long) : PlaybackEngineEvent {
        init {
            require(actualPositionMs >= 0L)
        }
    }

    /** O conteúdo terminou; a lógica do próximo episódio fica fora do motor. */
    data object PlaybackEnded : PlaybackEngineEvent

    /**
     * Falha classificada, sem URLs/credenciais na mensagem. O controlador
     * decidirá se reconecta, muda de engine ou exibe erro.
     */
    data class Failure(val failure: PlaybackFailure) : PlaybackEngineEvent

    /** A superfície foi destruída pelo Android e precisa ser recriada. */
    data object VideoSurfaceLost : PlaybackEngineEvent
}

/**
 * Adaptador de um único mecanismo de reprodução.
 *
 * O Media3Adapter deverá declarar engine = MEDIA3; o LibVlcAdapter deverá
 * declarar engine = VLC. A troca automática será feita por um controlador
 * próprio, respeitando PlaybackRecoveryPolicy.
 */
interface PlaybackEngineAdapter {

    /** Identificação imutável do mecanismo responsável por este adaptador. */
    val engine: PlaybackEngine

    /** Estado atual, sempre consultável, inclusive depois de falhas. */
    val state: StateFlow<PlaybackUiState>

    /** Recursos realmente disponíveis na sessão atual. */
    val capabilities: StateFlow<PlaybackEngineCapabilities>

    /** Eventos ocasionais, sem duplicar continuamente o estado. */
    val events: SharedFlow<PlaybackEngineEvent>

    /**
     * Conecta uma SurfaceView existente aos decodificadores nativos.
     * O adaptador deve acompanhar SurfaceHolder.Callback para não usar uma
     * Surface destruída e não deverá ser dono da View.
     */
    fun attachVideoSurface(holder: SurfaceHolder): PlaybackCommandResult

    /** Remove a associação sem destruir a View pertencente à interface. */
    fun detachVideoSurface(holder: SurfaceHolder? = null)

    /**
     * Inicia a preparação, sem bloquear a thread principal.
     * A URL é usada APENAS internamente pelo adaptador.
     */
    fun prepare(request: PlaybackOpenRequest): PlaybackCommandResult

    /** Inicia ou retoma a mídia que foi preparada. */
    fun play(): PlaybackCommandResult

    /** Pausa, quando a fonte permitir. */
    fun pause(): PlaybackCommandResult

    /**
     * Interrompe a reprodução. Se clearMedia for true, remove também a mídia
     * atual e volta a IDLE; caso contrário, permite uma nova preparação.
     */
    fun stop(clearMedia: Boolean = false): PlaybackCommandResult

    /** Busca posição absoluta, em ms, dentro da janela válida da mídia. */
    fun seekTo(positionMs: Long): PlaybackCommandResult

    /** Avança ou retrocede pelo número de milissegundos especificado. */
    fun seekBy(deltaMs: Long): PlaybackCommandResult

    /** Vai à borda ao vivo, somente quando houver janela de timeshift. */
    fun goToLiveEdge(): PlaybackCommandResult

    /**
     * Seleciona uma faixa identificada na sessão atual.
     * - AUDIO + null: retorna à faixa de áudio padrão, quando suportado.
     * - SUBTITLE + null: desativa legendas, quando suportado.
     * - IDs não são reutilizados ao trocar de Media3 para VLC; o gerenciador
     *   restaurará, preferencialmente, pelo idioma salvo em PlaybackSettings.
     */
    fun selectTrack(
        type: PlaybackTrackType,
        trackId: String?
    ): PlaybackCommandResult

    /**
     * Seleciona uma representação que exista em availableVideoVariants.
     * null restaura o comportamento original/adaptativo da fonte.
     */
    fun selectVideoVariant(variantId: String?): PlaybackCommandResult

    /**
     * Solicita a melhor variante real correspondente à preferência HDR.
     * Não gera Dolby Vision/HDR10+ artificialmente e pode ser UNSUPPORTED.
     */
    fun setHdrPreference(
        preference: PlaybackHdrPreference
    ): PlaybackCommandResult

    /** Altera velocidade; valores aprovados ficam em PlaybackSettings. */
    fun setPlaybackSpeed(speed: Float): PlaybackCommandResult

    /** Volume normalizado de 0.0 a 1.0. */
    fun setVolume(volume: Float): PlaybackCommandResult

    /**
     * Modos NORMAL, FULL_SCREEN ou MANUAL, com zoom/posição/largura/altura.
     * O adaptador deve retornar UNSUPPORTED se não puder executar o ajuste,
     * especialmente quando a operação comprometer a saída HDR protegida.
     */
    fun setVideoLayout(layout: PlaybackVideoLayout): PlaybackCommandResult

    /**
     * Estilo e atraso de legendas. O adaptador só declara suporte aos itens
     * que realmente conseguir aplicar; não simula sincronização.
     */
    fun setSubtitleStyle(style: PlaybackSubtitleStyle): PlaybackCommandResult

    /**
     * Libera decodificador, streams, listeners e Surface callbacks.
     * Deve poder ser chamado várias vezes sem lançar exceção.
     */
    fun release()
}

/**
 * Fábrica para criar APENAS a engine solicitada.
 * O controlador de fallback utilizará esta fábrica e nunca manterá as duas
 * engines decodificando vídeo ao mesmo tempo.
 */
fun interface PlaybackEngineAdapterFactory {
    fun create(engine: PlaybackEngine): PlaybackEngineAdapter
}
