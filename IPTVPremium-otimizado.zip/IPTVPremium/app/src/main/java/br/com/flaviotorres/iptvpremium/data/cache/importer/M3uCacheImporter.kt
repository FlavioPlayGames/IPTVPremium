package br.com.flaviotorres.iptvpremium.data.cache.importer

import br.com.flaviotorres.iptvpremium.data.cache.PlaylistCacheGenerationManager
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedCategoryEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedChannelEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedEpisodeEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedMovieEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedSeriesEntity
import br.com.flaviotorres.iptvpremium.data.remote.PlaylistHttpClient
import java.nio.charset.StandardCharsets
import java.util.Locale
import java.util.UUID

class M3uCacheImporter(
    private val httpClient: PlaylistHttpClient,
    private val cacheDao: PlaylistCacheDao,
    private val generationManager: PlaylistCacheGenerationManager
) {

    suspend fun import(
        playlistId: String,
        playlistUrl: String
    ): String {
        require(playlistUrl.isNotBlank()) {
            "A URL da lista M3U está vazia."
        }

        val generationId =
            generationManager.beginImport(
                playlistId = playlistId
            )

        try {
            importIntoGeneration(
                playlistId = playlistId,
                generationId = generationId,
                playlistUrl = playlistUrl
            )

            generationManager.markImportReady(
                playlistId = playlistId,
                generationId = generationId
            )

            return generationId
        } catch (error: Throwable) {
            generationManager.discardImport(
                playlistId = playlistId,
                generationId = generationId
            )

            throw error
        }
    }

    private suspend fun importIntoGeneration(
        playlistId: String,
        generationId: String,
        playlistUrl: String
    ) {
        val categoryBatch =
            LinkedHashMap<String, CachedCategoryEntity>()

        val channelBatch =
            ArrayList<CachedChannelEntity>(BATCH_SIZE)

        val movieBatch =
            ArrayList<CachedMovieEntity>(BATCH_SIZE)

        val seriesBatch =
            LinkedHashMap<String, CachedSeriesEntity>()

        // A primeira aparicao de cada serie define sua posicao no provedor.
        // Mantemos esta ordem mesmo quando outros episodios chegam depois.
        val seriesFirstOrder = HashMap<String, Int>()

        val episodeBatch =
            ArrayList<CachedEpisodeEntity>(BATCH_SIZE)

        var pendingExtInf: String? = null
        var channelNumber = 0
        var foundExtInf = false
        var foundStream = false

        suspend fun flush() {
            if (categoryBatch.isNotEmpty()) {
                cacheDao.insertCategories(
                    categoryBatch.values.toList()
                )
                categoryBatch.clear()
            }

            if (channelBatch.isNotEmpty()) {
                cacheDao.insertChannels(
                    channelBatch.toList()
                )
                channelBatch.clear()
            }

            if (movieBatch.isNotEmpty()) {
                cacheDao.insertMovies(
                    movieBatch.toList()
                )
                movieBatch.clear()
            }

            if (seriesBatch.isNotEmpty()) {
                cacheDao.insertSeries(
                    seriesBatch.values.toList()
                )
                seriesBatch.clear()
            }

            if (episodeBatch.isNotEmpty()) {
                cacheDao.insertEpisodes(
                    episodeBatch.toList()
                )
                episodeBatch.clear()
            }
        }

        httpClient.readLines(
            url = playlistUrl
        ) { rawLine ->
            val line =
                rawLine
                    .removePrefix("\uFEFF")
                    .trim()

            if (line.isBlank()) {
                return@readLines
            }

            if (
                line.startsWith(
                    "#EXTINF",
                    ignoreCase = true
                )
            ) {
                foundExtInf = true
                pendingExtInf = line
                return@readLines
            }

            if (line.startsWith("#")) {
                return@readLines
            }

            val extInf =
                pendingExtInf
                    ?: return@readLines

            pendingExtInf = null
            foundStream = true

            val name =
                extractDisplayName(extInf)
                    .ifBlank {
                        "Conteúdo"
                    }

            val groupName =
                extractAttribute(
                    extInf = extInf,
                    attributeName = "group-title"
                )
                    ?.trim()
                    ?.takeIf {
                        it.isNotBlank()
                    }
                    ?: DEFAULT_CATEGORY_NAME

            val logoUrl =
                extractAttribute(
                    extInf = extInf,
                    attributeName = "tvg-logo"
                )
                    ?.trim()
                    ?.takeIf {
                        it.isNotBlank()
                    }

            val tvgId =
                extractAttribute(
                    extInf = extInf,
                    attributeName = "tvg-id"
                )
                    ?.trim()
                    ?.takeIf {
                        it.isNotBlank()
                    }

            when (
                classifyEntry(
                    streamUrl = line,
                    groupName = groupName,
                    name = name
                )
            ) {
                EntryType.LIVE_TV -> {
                    channelNumber += 1

                    val categoryId =
                        stableId(
                            "category:$TYPE_LIVE_TV:$groupName"
                        )

                    /*
                     * O ID não usa somente tvg-id.
                     * Muitos provedores repetem o mesmo EPG ID em versões
                     * SD/HD/FHD/4K; usar URL + nome evita que o Room substitua
                     * uma variante pela outra.
                     */
                    val channelId =
                        stableId(
                            "channel:$line:$name:${tvgId.orEmpty()}"
                        )

                    categoryBatch[
                        categoryKey(
                            type = TYPE_LIVE_TV,
                            categoryId = categoryId
                        )
                    ] =
                        CachedCategoryEntity(
                            playlistId = playlistId,
                            generationId = generationId,
                            categoryId = categoryId,
                            name = groupName,
                            type = TYPE_LIVE_TV,
                            source = SOURCE_M3U
                        )

                    channelBatch +=
                        CachedChannelEntity(
                            playlistId = playlistId,
                            generationId = generationId,
                            channelId = channelId,
                            name = name,
                            categoryId = categoryId,
                            logoUrl = logoUrl,
                            streamUrl = line,
                            epgChannelId = tvgId,
                            channelNumber = channelNumber
                        )
                }

                EntryType.MOVIE -> {
                    val categoryId =
                        stableId(
                            "category:$TYPE_MOVIES:$groupName"
                        )

                    val movieId =
                        stableId(
                            "movie:$line:$name"
                        )

                    categoryBatch[
                        categoryKey(
                            type = TYPE_MOVIES,
                            categoryId = categoryId
                        )
                    ] =
                        CachedCategoryEntity(
                            playlistId = playlistId,
                            generationId = generationId,
                            categoryId = categoryId,
                            name = groupName,
                            type = TYPE_MOVIES,
                            source = SOURCE_M3U
                        )

                    movieBatch +=
                        CachedMovieEntity(
                            playlistId = playlistId,
                            generationId = generationId,
                            movieId = movieId,
                            name = name,
                            categoryId = categoryId,
                            posterUrl = logoUrl,
                            backdropUrl = null,
                            streamUrl = line,
                            year = extractYear(name),
                            rating = null,
                            durationSeconds = null
                        )
                }

                EntryType.SERIES -> {
                    val categoryId =
                        stableId(
                            "category:$TYPE_SERIES:$groupName"
                        )

                    val episodeInfo =
                        extractEpisodeInfo(name)

                    val seriesName =
                        episodeInfo.seriesName
                            .ifBlank {
                                name
                            }

                    val seriesId =
                        stableId(
                            "series:$groupName:$seriesName"
                        )

                    val episodeId =
                        stableId(
                            "episode:$line:$name"
                        )

                    categoryBatch[
                        categoryKey(
                            type = TYPE_SERIES,
                            categoryId = categoryId
                        )
                    ] =
                        CachedCategoryEntity(
                            playlistId = playlistId,
                            generationId = generationId,
                            categoryId = categoryId,
                            name = groupName,
                            type = TYPE_SERIES,
                            source = SOURCE_M3U
                        )

                    val seriesProviderOrder = seriesFirstOrder.getOrPut(seriesId) {
                        seriesFirstOrder.size
                    }

                    seriesBatch[seriesId] =
                        CachedSeriesEntity(
                            playlistId = playlistId,
                            generationId = generationId,
                            seriesId = seriesId,
                            name = seriesName,
                            categoryId = categoryId,
                            posterUrl = logoUrl,
                            backdropUrl = null,
                            year = extractYear(seriesName),
                            rating = null,
                            plot = null,
                            titleLogoUrl = null,
                            imdbId = null,
                            tmdbId = null,
                            ratingSource = null,
                            durationSeconds = null,
                            genres = null,
                            trailerUrl = null,
                            providerOrder = seriesProviderOrder
                        )

                    episodeBatch +=
                        CachedEpisodeEntity(
                            playlistId = playlistId,
                            generationId = generationId,
                            episodeId = episodeId,
                            seriesId = seriesId,
                            seasonNumber = episodeInfo.seasonNumber,
                            episodeNumber = episodeInfo.episodeNumber,
                            name = name,
                            streamUrl = line,
                            posterUrl = logoUrl,
                            durationSeconds = null
                        )
                }
            }

            if (
                channelBatch.size >= BATCH_SIZE ||
                movieBatch.size >= BATCH_SIZE ||
                seriesBatch.size >= BATCH_SIZE ||
                episodeBatch.size >= BATCH_SIZE ||
                categoryBatch.size >= BATCH_SIZE
            ) {
                flush()
            }
        }

        flush()

        if (!foundExtInf || !foundStream) {
            throw IllegalStateException(
                "O endereço informado não retornou uma lista M3U válida."
            )
        }
    }

    private fun classifyEntry(
        streamUrl: String,
        groupName: String,
        name: String
    ): EntryType {
        val url =
            streamUrl.lowercase(Locale.ROOT)

        val group =
            normalizeForClassification(groupName)

        val title =
            normalizeForClassification(name)

        /*
         * O caminho do servidor é o sinal mais confiável quando existe.
         */
        if (
            "/series/" in url ||
            "/serie/" in url
        ) {
            return EntryType.SERIES
        }

        if (
            "/movie/" in url ||
            "/movies/" in url ||
            "/vod/" in url
        ) {
            return EntryType.MOVIE
        }

        if (
            "/live/" in url
        ) {
            return EntryType.LIVE_TV
        }

        /*
         * Em M3U Plus alguns provedores não usam /movie/ e /series/.
         * Nesse caso usamos os nomes dos grupos como segundo critério.
         */
        if (
            containsAny(
                group,
                SERIES_KEYWORDS
            ) ||
            containsAny(
                title,
                SERIES_TITLE_KEYWORDS
            ) ||
            looksLikeEpisode(name)
        ) {
            return EntryType.SERIES
        }

        if (
            containsAny(
                group,
                MOVIE_KEYWORDS
            )
        ) {
            return EntryType.MOVIE
        }

        /*
         * Arquivos de vídeo sob grupos de VOD também aparecem sem /movie/.
         * Não classificamos só pela extensão para não transformar canais
         * HLS/TS em filmes por engano.
         */
        return EntryType.LIVE_TV
    }

    private fun extractEpisodeInfo(
        name: String
    ): EpisodeInfo {
        val compactMatch =
            Regex(
                """(?i)\bS(\d{1,2})\s*E(\d{1,3})\b"""
            ).find(name)

        if (compactMatch != null) {
            val season =
                compactMatch.groupValues
                    .getOrNull(1)
                    ?.toIntOrNull()

            val episode =
                compactMatch.groupValues
                    .getOrNull(2)
                    ?.toIntOrNull()

            val cleanSeriesName =
                name
                    .removeRange(
                        compactMatch.range
                    )
                    .replace(
                        Regex("""[\s._\-–—|]+$"""),
                        ""
                    )
                    .trim()

            return EpisodeInfo(
                seriesName = cleanSeriesName,
                seasonNumber = season,
                episodeNumber = episode
            )
        }

        val verboseMatch =
            Regex(
                """(?i)\b(?:temporada|season)\s*(\d{1,2}).*?\b(?:epis[oó]dio|episode|ep)\s*(\d{1,3})\b"""
            ).find(name)

        if (verboseMatch != null) {
            val season =
                verboseMatch.groupValues
                    .getOrNull(1)
                    ?.toIntOrNull()

            val episode =
                verboseMatch.groupValues
                    .getOrNull(2)
                    ?.toIntOrNull()

            val cleanSeriesName =
                name
                    .substring(
                        0,
                        verboseMatch.range.first
                    )
                    .replace(
                        Regex("""[\s._\-–—|]+$"""),
                        ""
                    )
                    .trim()

            return EpisodeInfo(
                seriesName = cleanSeriesName,
                seasonNumber = season,
                episodeNumber = episode
            )
        }

        return EpisodeInfo(
            seriesName = name.trim(),
            seasonNumber = null,
            episodeNumber = null
        )
    }

    private fun looksLikeEpisode(
        name: String
    ): Boolean {
        return Regex(
            """(?i)\bS\d{1,2}\s*E\d{1,3}\b"""
        ).containsMatchIn(name) ||
                Regex(
                    """(?i)\b(?:temporada|season)\s*\d{1,2}.*?\b(?:epis[oó]dio|episode|ep)\s*\d{1,3}\b"""
                ).containsMatchIn(name)
    }

    private fun extractYear(
        value: String
    ): Int? {
        return Regex(
            """\b(19|20)\d{2}\b"""
        )
            .find(value)
            ?.value
            ?.toIntOrNull()
    }

    private fun normalizeForClassification(
        value: String
    ): String {
        return value
            .lowercase(Locale.ROOT)
            .replace('á', 'a')
            .replace('à', 'a')
            .replace('ã', 'a')
            .replace('â', 'a')
            .replace('ä', 'a')
            .replace('é', 'e')
            .replace('è', 'e')
            .replace('ê', 'e')
            .replace('ë', 'e')
            .replace('í', 'i')
            .replace('ì', 'i')
            .replace('î', 'i')
            .replace('ï', 'i')
            .replace('ó', 'o')
            .replace('ò', 'o')
            .replace('õ', 'o')
            .replace('ô', 'o')
            .replace('ö', 'o')
            .replace('ú', 'u')
            .replace('ù', 'u')
            .replace('û', 'u')
            .replace('ü', 'u')
            .replace('ç', 'c')
    }

    private fun containsAny(
        value: String,
        keywords: Set<String>
    ): Boolean {
        return keywords.any {
                keyword ->
            keyword in value
        }
    }

    private fun extractDisplayName(
        extInf: String
    ): String {
        val commaIndex =
            extInf.lastIndexOf(',')

        if (
            commaIndex < 0 ||
            commaIndex >= extInf.lastIndex
        ) {
            return ""
        }

        return extInf
            .substring(commaIndex + 1)
            .trim()
    }

    private fun extractAttribute(
        extInf: String,
        attributeName: String
    ): String? {
        val pattern =
            Regex(
                """(?:^|\s)${Regex.escape(attributeName)}\s*=\s*"([^"]*)"""",
                RegexOption.IGNORE_CASE
            )

        return pattern
            .find(extInf)
            ?.groupValues
            ?.getOrNull(1)
    }

    private fun stableId(
        value: String
    ): String {
        return UUID
            .nameUUIDFromBytes(
                value.toByteArray(
                    StandardCharsets.UTF_8
                )
            )
            .toString()
    }

    private fun categoryKey(
        type: String,
        categoryId: String
    ): String {
        return "$type:$categoryId"
    }

    private data class EpisodeInfo(
        val seriesName: String,
        val seasonNumber: Int?,
        val episodeNumber: Int?
    )

    private enum class EntryType {
        LIVE_TV,
        MOVIE,
        SERIES
    }

    private companion object {
        const val BATCH_SIZE = 250
        const val DEFAULT_CATEGORY_NAME = "Sem categoria"

        const val TYPE_LIVE_TV = "LIVE_TV"
        const val TYPE_MOVIES = "MOVIES"
        const val TYPE_SERIES = "SERIES"

        const val SOURCE_M3U = "M3U"

        val MOVIE_KEYWORDS =
            setOf(
                "filme",
                "filmes",
                "movie",
                "movies",
                "cinema",
                "vod",
                "lancamentos",
                "lancamento"
            )

        val SERIES_KEYWORDS =
            setOf(
                "serie",
                "series",
                "seriado",
                "seriados",
                "temporada",
                "season"
            )

        val SERIES_TITLE_KEYWORDS =
            setOf(
                "temporada",
                "season",
                "episodio",
                "episode"
            )
    }
}
