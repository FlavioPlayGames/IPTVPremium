package br.com.flaviotorres.iptvpremium.ui.theme

import androidx.compose.ui.graphics.Color

// Fundos
val AppBackground = Color(0xFF0B0B0D)
val AppSurface = Color(0xFF151518)
val AppSurfaceVariant = Color(0xFF202024)

// Dourado principal
val AppGold = Color(0xFFD4AF37)
val AppGoldLight = Color(0xFFF1D77A)
val AppGoldDark = Color(0xFF9E7C18)

// Textos
val AppTextPrimary = Color(0xFFF5F5F5)
val AppTextSecondary = Color(0xFFB7B7BD)

// Estados
val AppError = Color(0xFFFF6B6B)
