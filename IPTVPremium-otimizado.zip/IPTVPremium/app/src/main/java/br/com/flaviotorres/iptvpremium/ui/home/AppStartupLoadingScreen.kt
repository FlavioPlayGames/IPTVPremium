package br.com.flaviotorres.iptvpremium.ui.home

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.R
import kotlin.math.roundToInt

/**
 * Estado verdadeiro da preparação do catálogo.
 *
 * IMPORTANTE: os contadores devem ser atualizados pelo AppNavigation,
 * após a conclusão de cada operação real. A tela nunca simula progresso.
 */
enum class AppCatalogLoadingPhase {
    READING_CATALOG,
    SELECTING_TITLES,
    PREPARING_TITLES,
    FINISHING,
    COMPLETED,
    ERROR
}

@Immutable
data class AppCatalogLoadingState(
    val phase: AppCatalogLoadingPhase = AppCatalogLoadingPhase.READING_CATALOG,
    val preparedTitles: Int = 0,
    val totalTitles: Int = 0,
    val failedTitles: Int = 0,
    val currentTitle: String? = null,
    val currentCategory: String? = null,
    val errorMessage: String? = null,
    val isPlaylistRefresh: Boolean = false
) {
    val progress: Float
        get() = if (phase == AppCatalogLoadingPhase.COMPLETED) {
            1f
        } else if (totalTitles > 0) {
            (preparedTitles.toFloat() / totalTitles.toFloat()).coerceIn(0f, 1f)
        } else {
            0f
        }
}

private val StartupGold = Color(0xFFE0B747)
private val StartupCream = Color(0xFFFFE8A3)
private val StartupGrey = Color(0xFFA9A9AD)
private val StartupGoldGradient = Brush.horizontalGradient(
    listOf(
        Color(0xFF8B6419),
        Color(0xFFD3A531),
        Color(0xFFFFE9A5),
        Color(0xFFE0B747)
    )
)
private val StartupCinzel = FontFamily(
    Font(R.font.cinzel_semibold, weight = FontWeight.SemiBold)
)

/**
 * Tela de abertura e atualização de playlist do IPTVPremium.
 *
 * Esta tela APENAS exibe o estado. O AppNavigation deve:
 * 1. iniciar o carregamento toda vez que o aplicativo abrir;
 * 2. preparar até 10 títulos por categoria de Filmes e Séries, incluindo
 *    as capas e informações da tela de detalhes;
 * 3. repetir a preparação depois de atualizar a playlist;
 * 4. marcar COMPLETED apenas quando todas as tarefas terminarem;
 * 5. navegar automaticamente para Home quando COMPLETED;
 * 6. marcar ERROR quando não houver catálogo válido, permitindo tentar
 *    novamente sem mostrar uma conclusão falsa.
 *
 * Não adicione um botão "Entrar": a navegação é automática.
 */
@Composable
fun AppStartupLoadingScreen(
    state: AppCatalogLoadingState,
    modifier: Modifier = Modifier,
    onRetry: (() -> Unit)? = null,
    onOpenPlaylists: (() -> Unit)? = null
) {
    val isError = state.phase == AppCatalogLoadingPhase.ERROR
    val isCompleted = state.phase == AppCatalogLoadingPhase.COMPLETED
    val hasProgress = state.totalTitles > 0 || isCompleted

    val animatedProgress by animateFloatAsState(
        targetValue = state.progress,
        animationSpec = tween(durationMillis = 240),
        label = "iptvStartupRealProgress"
    )
    val transition = rememberInfiniteTransition(label = "iptvStartupSoftPulse")
    val pulse by transition.animateFloat(
        initialValue = 0.38f,
        targetValue = 0.95f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "iptvStartupPulseValue"
    )

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF060608)),
        contentAlignment = Alignment.Center
    ) {
        val compact = maxWidth < 720.dp || maxHeight < 380.dp

        // Luz ambiental dourada, suave e barata para renderizar na TV.
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.radialGradient(
                        listOf(
                            Color(0x382C2415),
                            Color(0x1A1C1820),
                            Color(0xFF060608)
                        )
                    )
                )
        )

        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width * 0.5f, size.height * 0.46f)
            val radius = size.minDimension * 0.42f
            drawCircle(
                color = StartupGold.copy(alpha = 0.04f * pulse),
                radius = radius,
                center = center
            )
            drawCircle(
                color = StartupGold.copy(alpha = 0.15f * pulse),
                radius = radius * 0.79f,
                center = center,
                style = Stroke(width = 1.5.dp.toPx())
            )
            // Friso fino na parte inferior, para preservar a identidade preta/dourada.
            drawLine(
                brush = Brush.horizontalGradient(
                    listOf(Color.Transparent, StartupGold.copy(alpha = 0.34f), Color.Transparent)
                ),
                start = Offset(size.width * 0.1f, size.height * 0.93f),
                end = Offset(size.width * 0.9f, size.height * 0.93f),
                strokeWidth = 1.dp.toPx(),
                cap = StrokeCap.Round
            )
        }

        Column(
            modifier = Modifier
                .fillMaxWidth(if (compact) 0.85f else 0.65f)
                .widthIn(max = 760.dp)
                .padding(vertical = if (compact) 10.dp else 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Image(
                painter = painterResource(R.drawable.iptv_premium_logo),
                contentDescription = "IPTV Premium",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .width(if (compact) 150.dp else 210.dp)
                    .height(if (compact) 68.dp else 105.dp)
            )

            Spacer(Modifier.height(if (compact) 12.dp else 24.dp))

            Text(
                text = if (isError) {
                    "NÃO FOI POSSÍVEL PREPARAR O CATÁLOGO"
                } else if (isCompleted) {
                    "CONCLUÍDO"
                } else if (state.isPlaylistRefresh) {
                    "ATUALIZANDO SUA BIBLIOTECA"
                } else {
                    "PREPARANDO SUA BIBLIOTECA"
                },
                fontFamily = StartupCinzel,
                fontSize = if (compact) 17.sp else 24.sp,
                fontWeight = FontWeight.SemiBold,
                letterSpacing = 1.1.sp,
                color = StartupCream,
                textAlign = TextAlign.Center,
                maxLines = 2
            )

            Spacer(Modifier.height(if (compact) 9.dp else 12.dp))

            Text(
                text = when (state.phase) {
                    AppCatalogLoadingPhase.READING_CATALOG -> "Lendo a playlist e preparando o catálogo..."
                    AppCatalogLoadingPhase.SELECTING_TITLES -> "Selecionando 10 títulos de cada categoria..."
                    AppCatalogLoadingPhase.PREPARING_TITLES -> "Armazenando capas e informações dos títulos..."
                    AppCatalogLoadingPhase.FINISHING -> "Finalizando a preparação da biblioteca..."
                    AppCatalogLoadingPhase.COMPLETED -> "Abrindo a Home automaticamente..."
                    AppCatalogLoadingPhase.ERROR -> state.errorMessage
                        ?.takeIf(String::isNotBlank)
                        ?: "Verifique sua conexão ou tente novamente."
                },
                fontSize = if (compact) 11.sp else 14.sp,
                color = if (isError) Color(0xFFFFC1AE) else StartupGrey,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(Modifier.height(if (compact) 15.dp else 25.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(if (compact) 7.dp else 9.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Color(0xFF28252B))
            ) {
                if (hasProgress) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(animatedProgress.coerceIn(0f, 1f))
                            .height(if (compact) 7.dp else 9.dp)
                            .background(StartupGoldGradient)
                    )
                } else {
                    // Sem total conhecido: indicamos atividade sem fingir porcentagem.
                    Box(
                        modifier = Modifier
                            .fillMaxWidth(0.16f + pulse * 0.13f)
                            .height(if (compact) 7.dp else 9.dp)
                            .background(StartupGoldGradient)
                    )
                }
            }

            Spacer(Modifier.height(if (compact) 10.dp else 14.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = when {
                        isError -> "AGUARDANDO NOVA TENTATIVA"
                        isCompleted -> "PRONTO"
                        state.totalTitles > 0 -> "${state.preparedTitles.coerceAtLeast(0)} DE ${state.totalTitles} TÍTULOS"
                        else -> "ORGANIZANDO CATÁLOGO"
                    },
                    color = StartupGrey,
                    fontSize = if (compact) 9.sp else 11.sp,
                    letterSpacing = 1.sp
                )
                Text(
                    text = if (hasProgress) {
                        "${(state.progress * 100f).roundToInt()}%"
                    } else {
                        "..."
                    },
                    color = StartupGold,
                    fontSize = if (compact) 12.sp else 15.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }

            if (!isError && !isCompleted) {
                val current = listOfNotNull(
                    state.currentCategory?.takeIf(String::isNotBlank),
                    state.currentTitle?.takeIf(String::isNotBlank)
                ).joinToString("  ·  ")
                Spacer(Modifier.height(if (compact) 10.dp else 17.dp))
                Text(
                    text = current.ifBlank { "Filmes e Séries · capas e detalhes" },
                    color = Color(0xFFCFC2A2),
                    fontSize = if (compact) 10.sp else 12.sp,
                    textAlign = TextAlign.Center,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (state.failedTitles > 0) {
                Spacer(Modifier.height(8.dp))
                Text(
                    text = "${state.failedTitles} título(s) com falha de preparação",
                    color = Color(0xFFE2A890),
                    fontSize = if (compact) 9.sp else 11.sp
                )
            }

            if (isError) {
                Spacer(Modifier.height(if (compact) 12.dp else 20.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (onRetry != null) {
                        LoadingAction(label = "TENTAR NOVAMENTE", onClick = onRetry)
                    }
                    if (onOpenPlaylists != null) {
                        LoadingAction(label = "MINHAS LISTAS", onClick = onOpenPlaylists)
                    }
                }
            }
        }
    }
}

@Composable
private fun LoadingAction(label: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(9.dp)
    Box(
        modifier = Modifier
            .clip(shape)
            .background(if (focused) Color(0xFFE0B747) else Color(0xFF232025))
            .border(
                width = if (focused) 2.dp else 1.dp,
                color = if (focused) StartupCream else Color(0xFF8E6F35),
                shape = shape
            )
            .onFocusChanged { focused = it.isFocused }
            .clickable(onClick = onClick)
            .focusable()
            .padding(horizontal = 17.dp, vertical = 11.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.7.sp,
            color = if (focused) Color(0xFF17110A) else StartupCream
        )
    }
}
