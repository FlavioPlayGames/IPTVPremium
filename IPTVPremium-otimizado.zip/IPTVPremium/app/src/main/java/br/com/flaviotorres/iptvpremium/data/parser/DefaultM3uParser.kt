package br.com.flaviotorres.iptvpremium.data.parser

import br.com.flaviotorres.iptvpremium.domain.model.Category
import br.com.flaviotorres.iptvpremium.domain.model.CategorySource
import br.com.flaviotorres.iptvpremium.domain.model.CategoryType
import br.com.flaviotorres.iptvpremium.domain.model.Channel
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistContent

class DefaultM3uParser : M3uParser {

    override fun parse(
        content: String
    ): PlaylistContent {

        if (content.isBlank()) {
            return PlaylistContent()
        }

        val entries = parseEntries(content)

        val categories = entries
            .mapNotNull { entry ->
                entry.groupTitle
                    ?.trim()
                    ?.takeIf { it.isNotEmpty() }
            }
            .distinct()
            .map { categoryName ->
                Category(
                    id = createCategoryId(categoryName),
                    name = categoryName,
                    type = CategoryType.LIVE_TV,
                    source = CategorySource.PROVIDER
                )
            }

        val channels = entries.mapIndexed { index, entry ->

            val categoryId = entry.groupTitle
                ?.trim()
                ?.takeIf { it.isNotEmpty() }
                ?.let(::createCategoryId)

            Channel(
                id = createChannelId(
                    index = index,
                    name = entry.name,
                    streamUrl = entry.streamUrl
                ),
                name = entry.name,
                categoryId = categoryId,
                logoUrl = entry.logoUrl,
                streamUrl = entry.streamUrl,
                epgChannelId = entry.tvgId
            )
        }

        return PlaylistContent(
            categories = categories,
            channels = channels
        )
    }

    private fun parseEntries(
        content: String
    ): List<M3uEntry> {

        val lines = content
            .lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toList()

        val entries = mutableListOf<M3uEntry>()

        var pendingInfo: ExtInfData? = null

        for (line in lines) {

            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    pendingInfo = parseExtInf(line)
                }

                line.startsWith("#") -> {
                    // Ignora outras diretivas M3U por enquanto.
                }

                pendingInfo != null -> {
                    val info = pendingInfo

                    entries += M3uEntry(
                        name = info.name.ifBlank {
                            "Canal"
                        },
                        tvgId = info.tvgId,
                        logoUrl = info.logoUrl,
                        groupTitle = info.groupTitle,
                        streamUrl = line
                    )

                    pendingInfo = null
                }
            }
        }

        return entries
    }

    private fun parseExtInf(
        line: String
    ): ExtInfData {

        val separatorIndex = line.indexOf(',')

        val metadata =
            if (separatorIndex >= 0) {
                line.substring(
                    startIndex = 0,
                    endIndex = separatorIndex
                )
            } else {
                line
            }

        val displayName =
            if (separatorIndex >= 0 &&
                separatorIndex < line.lastIndex
            ) {
                line.substring(separatorIndex + 1)
                    .trim()
            } else {
                ""
            }

        val tvgId = extractAttribute(
            text = metadata,
            attribute = "tvg-id"
        )

        val tvgName = extractAttribute(
            text = metadata,
            attribute = "tvg-name"
        )

        val logoUrl = extractAttribute(
            text = metadata,
            attribute = "tvg-logo"
        )

        val groupTitle = extractAttribute(
            text = metadata,
            attribute = "group-title"
        )

        val finalName = displayName
            .ifBlank {
                tvgName.orEmpty()
            }
            .ifBlank {
                "Canal"
            }

        return ExtInfData(
            name = finalName,
            tvgId = tvgId,
            logoUrl = logoUrl,
            groupTitle = groupTitle
        )
    }

    private fun extractAttribute(
        text: String,
        attribute: String
    ): String? {

        val regex = Regex(
            pattern = """$attribute\s*=\s*"([^"]*)"""",
            option = RegexOption.IGNORE_CASE
        )

        return regex
            .find(text)
            ?.groupValues
            ?.getOrNull(1)
            ?.trim()
            ?.takeIf { it.isNotEmpty() }
    }

    private fun createCategoryId(
        name: String
    ): String {
        return "m3u_category_${stableHash(name)}"
    }

    private fun createChannelId(
        index: Int,
        name: String,
        streamUrl: String
    ): String {
        return "m3u_channel_${stableHash("$index|$name|$streamUrl")}"
    }

    private fun stableHash(
        value: String
    ): String {
        return value.hashCode()
            .toUInt()
            .toString(16)
    }

    private data class ExtInfData(
        val name: String,
        val tvgId: String?,
        val logoUrl: String?,
        val groupTitle: String?
    )

    private data class M3uEntry(
        val name: String,
        val tvgId: String?,
        val logoUrl: String?,
        val groupTitle: String?,
        val streamUrl: String
    )
}