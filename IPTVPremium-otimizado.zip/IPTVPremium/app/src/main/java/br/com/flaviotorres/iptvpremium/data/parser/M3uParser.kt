package br.com.flaviotorres.iptvpremium.data.parser

import br.com.flaviotorres.iptvpremium.domain.model.PlaylistContent

interface M3uParser {

    fun parse(
        content: String
    ): PlaylistContent
}