package br.com.flaviotorres.iptvpremium.ui.series

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.tv.material3.Text
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Abertura cinematográfica de Séries: a câmera avança até a tela da TV.
 *
 * A tela dentro da TV deve ser a MESMA composição da tela de detalhes,
 * em resolução normal e apenas DESENHADA menor por graphicsLayer.
 *
 * Importante: para o encaixe perfeito, a navegação precisa fornecer
 * [detailsContent] = { SeriesDetailsScreen(...) } com OS MESMOS PARÂMETROS
 * que utiliza depois da animação. Sem [detailsContent], existe apenas um
 * fallback transitório e não é possível garantir correspondência 1:1.
 *
 * O fundo fotográfico é o arquivo opcional:
 * res/drawable-nodpi/series_living_room.webp
 *
 * A busca do recurso por nome evita erro de compilação enquanto o asset
 * ainda não foi adicionado. Para o resultado realista, instale o WebP.
 *
 * Duração habitual: ~2 segundos.
 * Limite alvo: ~2,5 segundos (com pequenas variações por renderização).
 * Nenhum carregamento de rede é iniciado aqui.
 */
@Composable
fun SeriesLoadingOverlay(
    seriesName: String,
    isSeriesReady: Boolean,
    onComplete: (isReady: Boolean) -> Unit,
    modifier: Modifier = Modifier,
    previewBackdrop: ImageBitmap? = null,
    detailsContent: (@Composable () -> Unit)? = null
) {
    val readyLatest by rememberUpdatedState(isSeriesReady)
    val onCompleteLatest by rememberUpdatedState(onComplete)

    var screenOn by remember(seriesName) { mutableStateOf(false) }
    var showScreenContent by remember(seriesName) { mutableStateOf(false) }

    val screenPower by animateFloatAsState(
        targetValue = if (screenOn) 1f else 0f,
        animationSpec = tween(durationMillis = 440),
        label = "seriesTvPower"
    )
    val screenContentAlpha by animateFloatAsState(
        targetValue = if (showScreenContent) 1f else 0f,
        animationSpec = tween(durationMillis = 360),
        label = "seriesTvRealContent"
    )

    val cameraApproach = remember(seriesName) { Animatable(0f) }
    val sceneAlpha = remember(seriesName) { Animatable(1f) }

    LaunchedEffect(seriesName) {
        val started = SystemClock.uptimeMillis()

        suspend fun waitFor(ms: Long) {
            val remaining = ms - (SystemClock.uptimeMillis() - started)
            if (remaining > 0L) delay(remaining)
        }

        // Primeiro vemos a sala e a TV realmente apagada.
        waitFor(500L)
        screenOn = true
        waitFor(780L)
        showScreenContent = true

        // A câmera só começa a se aproximar depois da TV ligar.
        waitFor(1580L)

        // Os dados, se prontos, evitam qualquer espera adicional.
        // Caso contrário, a câmera espera apenas até ~2,08 s.
        while (!readyLatest && SystemClock.uptimeMillis() - started < 2080L) {
            delay(32L)
        }

        coroutineScope {
            launch {
                cameraApproach.animateTo(
                    targetValue = 1f,
                    animationSpec = tween(
                        durationMillis = 420,
                        easing = FastOutSlowInEasing
                    )
                )
            }
            launch {
                // Só dissolve nos últimos instantes, quando as telas coincidem.
                delay(350L)
                sceneAlpha.animateTo(
                    targetValue = 0f,
                    animationSpec = tween(durationMillis = 70)
                )
            }
        }

        // Se a rede demorar, a tela final continua com o loading real.
        onCompleteLatest(readyLatest)
    }

    val context = LocalContext.current
    val roomDrawable = remember(context) {
        context.resources.getIdentifier(
            "series_living_room",
            "drawable",
            context.packageName
        )
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF070809))
            .semantics {
                contentDescription = "Abrindo detalhes da série $seriesName"
            }
    ) {
        // A imagem base é 16:9; a TV encontra-se no centro superior da sala.
        // Por usar um mesmo fator em X/Y, o conteúdo conserva a proporção
        // EXATA da tela da Android TV, sem redesenhar um layout compacto.
        val viewportWidth = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val viewportHeight = constraints.maxHeight.toFloat().coerceAtLeast(1f)

        // Coordenadas normalizadas do retângulo interior da televisão no WebP.
        // O tamanho da área ativa é uma miniatura proporcional ao viewport.
        val miniatureScale = 0.456f
        val tvLeft = viewportWidth * 0.275f
        val tvTop = viewportHeight * 0.125f
        val tvWidth = viewportWidth * miniatureScale
        val tvHeight = viewportHeight * miniatureScale

        // No último quadro, o retângulo da TV ocupa exatamente [0,W]×[0,H].
        // Apenas a câmera (cena inteira) muda, e NÃO a tela isoladamente.
        val finalZoom = 1f / miniatureScale
        val finalTranslationX = -tvLeft * finalZoom
        val finalTranslationY = -tvTop * finalZoom

        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    alpha = sceneAlpha.value
                    val approach = cameraApproach.value
                    val zoom = 1f + (finalZoom - 1f) * approach
                    transformOrigin = TransformOrigin(0f, 0f)
                    scaleX = zoom
                    scaleY = zoom
                    translationX = finalTranslationX * approach
                    translationY = finalTranslationY * approach
                }
        ) {
            if (roomDrawable != 0) {
                // Fotografia realista; carregada pelo sistema de recursos.
                Image(
                    painter = painterResource(roomDrawable),
                    contentDescription = null,
                    modifier = Modifier.fillMaxSize(),
                    contentScale = ContentScale.FillBounds
                )
            } else {
                // Fallback simples caso a imagem ainda não esteja instalada.
                RoomBackgroundFallback(modifier = Modifier.fillMaxSize())
            }

            // Antes de ligar, a foto da TV continua completamente apagada.
            // Depois, a própria tela Compose é revelada sob a máscara exata.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawWithContent {
                        // Preserva o ContentDrawScope original para drawContent().
                        // clipRect { } trocava o receiver para DrawScope e causava
                        // erro de compilação na chamada implícita de drawContent().
                        val canvas = drawContext.canvas
                        canvas.save()
                        try {
                            canvas.clipRect(
                                left = tvLeft,
                                top = tvTop,
                                right = tvLeft + tvWidth,
                                bottom = tvTop + tvHeight
                            )
                            drawContent()
                        } finally {
                            canvas.restore()
                        }
                    }
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            transformOrigin = TransformOrigin(0f, 0f)
                            translationX = tvLeft
                            translationY = tvTop
                            scaleX = miniatureScale
                            scaleY = miniatureScale
                            alpha = screenPower
                        }
                        .background(Color(0xFF080A0E))
                ) {
                    if (detailsContent != null) {
                        // COMPOSIÇÃO REAL: mesma dimensão, layout, imagens,
                        // episódios e metadados de SeriesDetailsScreen.
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer { alpha = screenContentAlpha }
                        ) {
                            detailsContent()
                        }
                    } else {
                        // Compatibilidade com o AppNavigation anterior.
                        // Essa imagem NÃO substitui a ligação da tela real.
                        LegacyImageFallback(
                            seriesName = seriesName,
                            previewBackdrop = previewBackdrop,
                            modifier = Modifier
                                .fillMaxSize()
                                .graphicsLayer { alpha = screenContentAlpha }
                        )
                    }
                }
            }

            // Um reflexo discreto acompanha a TV ligando. Após o avanço,
            // essa luz sai naturalmente da área visível junto com a sala.
            Canvas(modifier = Modifier.fillMaxSize()) {
                val powerGlow = screenPower * (1f - screenContentAlpha) *
                        (1f - cameraApproach.value)
                if (powerGlow > 0.001f) {
                    drawRect(
                        brush = Brush.verticalGradient(
                            colors = listOf(
                                Color.Transparent,
                                Color(0x88FFF0B9),
                                Color.Transparent
                            )
                        ),
                        topLeft = Offset(tvLeft, tvTop + tvHeight * 0.46f),
                        size = Size(tvWidth, tvHeight * 0.08f),
                        alpha = powerGlow
                    )
                }
            }
        }
    }
}

@Composable
private fun LegacyImageFallback(
    seriesName: String,
    previewBackdrop: ImageBitmap?,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.background(Color(0xFF08090B))) {
        if (previewBackdrop != null) {
            Image(
                bitmap = previewBackdrop,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xE9000000),
                                Color(0x80000000),
                                Color(0x20000000)
                            )
                        )
                    )
            )
        }
        Text(
            text = seriesName,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .fillMaxWidth(0.65f)
                .padding(start = 26.dp),
            color = Color(0xFFE9CC7A),
            fontSize = 30.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
private fun RoomBackgroundFallback(modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.background(
            Brush.verticalGradient(
                colors = listOf(
                    Color(0xFF292017),
                    Color(0xFF211B18),
                    Color(0xFF090A0D)
                )
            )
        )
    ) {
        Box(
            modifier = Modifier
                .align(Alignment.Center)
                .fillMaxWidth(0.456f)
                .fillMaxSize(0.456f)
                .background(Color.Black, RoundedCornerShape(4))
        )
    }
}
