package br.com.flaviotorres.iptvpremium.domain.model

data class Series(
    val id: String,
    val name: String,
    val categoryId: String?,
    val posterUrl: String?,
    val backdropUrl: String?,
    val year: Int?,
    val rating: Double?,
    val plot: String?,

    // Logo/título artístico oficial da série.
    // Quando não existir, usamos "name" como texto.
    val titleLogoUrl: String? = null,

    // IDs externos para identificação e enriquecimento futuro.
    val imdbId: String? = null,
    val tmdbId: String? = null,

    // Identifica de onde veio a avaliação.
    val ratingSource: RatingSource? = null,

    // Duração média ou informada pelo provedor, em segundos.
    val durationSeconds: Int? = null,

    // Exemplo: Drama, Ação, Ficção científica.
    val genres: List<String> = emptyList(),

    // Trailer fornecido pelo provedor ou obtido posteriormente.
    val trailerUrl: String? = null
)

enum class RatingSource {
    IMDB,
    TMDB,
    PROVIDER
}