package br.com.flaviotorres.iptvpremium.data.remote

import br.com.flaviotorres.iptvpremium.BuildConfig

object TmdbClientProvider {

    val client: TmdbHttpClient by lazy {
        TmdbHttpClient(
            readAccessToken = BuildConfig.TMDB_READ_TOKEN
        )
    }
}