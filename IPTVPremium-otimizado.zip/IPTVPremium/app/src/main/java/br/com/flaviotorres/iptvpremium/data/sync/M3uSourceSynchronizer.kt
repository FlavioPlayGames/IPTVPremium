package br.com.flaviotorres.iptvpremium.data.sync

import android.util.Log
import br.com.flaviotorres.iptvpremium.data.cache.PlaylistCacheGenerationManager
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedCategoryEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedChannelEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedEpisodeEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedMovieEntity
import br.com.flaviotorres.iptvpremium.data.cache.entity.CachedSeriesEntity
import br.com.flaviotorres.iptvpremium.data.cache.importer.M3uCacheImporter
import br.com.flaviotorres.iptvpremium.data.resolver.M3uXtreamResolver
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistContent
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import br.com.flaviotorres.iptvpremium.domain.repository.PlaylistRepository

class M3uSourceSynchronizer(
    private val playlistRepository: PlaylistRepository,
    private val m3uCacheImporter: M3uCacheImporter,
    private val cacheDao: PlaylistCacheDao,
    private val generationManager: PlaylistCacheGenerationManager
) {

    suspend fun sync(
        source: PlaylistSource.M3u
    ): String {
        val resolvedXtream =
            M3uXtreamResolver.resolve(
                source = source
            )

        if (resolvedXtream != null) {
            Log.i(
                TAG,
                "M3U detectada como Xtream-compatible; tentando sincronização pela API Xtream."
            )

            try {
                return syncFromXtream(
                    playlistId = source.id,
                    xtreamSource = resolvedXtream
                )
            } catch (error: Throwable) {
                Log.w(
                    TAG,
                    "A sincronização Xtream automática falhou; usando M3U nativa como fallback.",
                    error
                )
            }
        } else {
            Log.i(
                TAG,
                "M3U sem padrão Xtream detectável; usando importação M3U nativa."
            )
        }

        return m3uCacheImporter.import(
            playlistId = source.id,
            playlistUrl = source.playlistUrl
        )
    }


    /*
     * XTREAM CODES DIRETO
     *
     * Usa exatamente a mesma persistência já utilizada quando uma M3U
     * é reconhecida como Xtream-compatible.
     *
     * Dessa forma M3U e Xtream Codes direto passam a terminar no mesmo
     * catálogo Room, pronto para ser consumido por Paging.
     */
    suspend fun sync(
        source: PlaylistSource.XtreamCodes
    ): String {
        Log.i(
            TAG,
            "Xtream Codes direto; sincronizando catálogo para o Room."
        )

        return syncFromXtream(
            playlistId = source.id,
            xtreamSource = source
        )
    }

    private suspend fun syncFromXtream(
        playlistId: String,
        xtreamSource: PlaylistSource.XtreamCodes
    ): String {
        /*
         * Nesta etapa o Xtream ainda usa o repositório atual, que monta
         * PlaylistContent em memória. Isso vale tanto para Xtream Codes direto
         * quanto para M3U reconhecida como Xtream-compatible.
         *
         * O conteúdo resultante é persistido em uma nova geração do Room,
         * permitindo que a interface use o mesmo catálogo via Paging.
         *
         * Mais adiante substituiremos esta parte por parsing Xtream em
         * streaming direto para o Room.
         */
        val content =
            playlistRepository.loadContent(
                source = xtreamSource
            )

        if (
            content.categories.isEmpty() &&
            content.channels.isEmpty() &&
            content.movies.isEmpty() &&
            content.series.isEmpty()
        ) {
            throw IllegalStateException(
                "A API Xtream não retornou conteúdo para a lista."
            )
        }

        val generationId =
            generationManager.beginImport(
                playlistId = playlistId
            )

        try {
            persistContent(
                playlistId = playlistId,
                generationId = generationId,
                content = content
            )

            generationManager.markImportReady(
                playlistId = playlistId,
                generationId = generationId
            )

            Log.i(
                TAG,
                buildString {
                    append("Sincronização Xtream concluída. ")
                    append("canais=")
                    append(content.channels.size)
                    append(", filmes=")
                    append(content.movies.size)
                    append(", series=")
                    append(content.series.size)
                    append(", episodios=")
                    append(content.episodes.size)
                }
            )

            return generationId
        } catch (error: Throwable) {
            generationManager.discardImport(
                playlistId = playlistId,
                generationId = generationId
            )

            throw error
        }
    }

    private suspend fun persistContent(
        playlistId: String,
        generationId: String,
        content: PlaylistContent
    ) {
        persistCategories(
            playlistId = playlistId,
            generationId = generationId,
            content = content
        )

        persistChannels(
            playlistId = playlistId,
            generationId = generationId,
            content = content
        )

        persistMovies(
            playlistId = playlistId,
            generationId = generationId,
            content = content
        )

        persistSeries(
            playlistId = playlistId,
            generationId = generationId,
            content = content
        )

        persistEpisodes(
            playlistId = playlistId,
            generationId = generationId,
            content = content
        )
    }

    private suspend fun persistCategories(
        playlistId: String,
        generationId: String,
        content: PlaylistContent
    ) {
        val categories =
            content.categories
                .distinctBy { category ->
                    "${category.type.name}:${category.id}"
                }

        var startIndex = 0

        while (startIndex < categories.size) {
            val endIndex =
                minOf(
                    startIndex + BATCH_SIZE,
                    categories.size
                )

            val batch =
                ArrayList<CachedCategoryEntity>(
                    endIndex - startIndex
                )

            for (index in startIndex until endIndex) {
                val category =
                    categories[index]

                batch +=
                    CachedCategoryEntity(
                        playlistId = playlistId,
                        generationId = generationId,
                        categoryId = category.id,
                        name = category.name,
                        type = category.type.name,
                        source = SOURCE_XTREAM
                    )
            }

            cacheDao.insertCategories(
                batch
            )

            startIndex = endIndex
        }
    }

    private suspend fun persistChannels(
        playlistId: String,
        generationId: String,
        content: PlaylistContent
    ) {
        var startIndex = 0

        while (startIndex < content.channels.size) {
            val endIndex =
                minOf(
                    startIndex + BATCH_SIZE,
                    content.channels.size
                )

            val batch =
                ArrayList<CachedChannelEntity>(
                    endIndex - startIndex
                )

            for (index in startIndex until endIndex) {
                val channel =
                    content.channels[index]

                batch +=
                    CachedChannelEntity(
                        playlistId = playlistId,
                        generationId = generationId,
                        channelId = channel.id,
                        name = channel.name,
                        categoryId = channel.categoryId,
                        logoUrl = channel.logoUrl,
                        streamUrl = channel.streamUrl,
                        epgChannelId = channel.epgChannelId,
                        channelNumber = index + 1
                    )
            }

            cacheDao.insertChannels(
                batch
            )

            startIndex = endIndex
        }
    }

    private suspend fun persistMovies(
        playlistId: String,
        generationId: String,
        content: PlaylistContent
    ) {
        var startIndex = 0

        while (startIndex < content.movies.size) {
            val endIndex =
                minOf(
                    startIndex + BATCH_SIZE,
                    content.movies.size
                )

            val batch =
                ArrayList<CachedMovieEntity>(
                    endIndex - startIndex
                )

            for (index in startIndex until endIndex) {
                val movie =
                    content.movies[index]

                batch +=
                    CachedMovieEntity(
                        playlistId = playlistId,
                        generationId = generationId,
                        movieId = movie.id,
                        name = movie.name,
                        categoryId = movie.categoryId,
                        posterUrl = movie.posterUrl,
                        backdropUrl = movie.backdropUrl,
                        streamUrl = movie.streamUrl,
                        year = movie.year,
                        rating = movie.rating,
                        durationSeconds = movie.durationSeconds,
                        addedAtEpochSeconds =
                            movie.addedAtEpochSeconds,
                        providerOrder =
                            index
                    )
            }

            cacheDao.insertMovies(
                batch
            )

            startIndex = endIndex
        }
    }

    private suspend fun persistSeries(
        playlistId: String,
        generationId: String,
        content: PlaylistContent
    ) {
        var startIndex = 0

        while (startIndex < content.series.size) {
            val endIndex =
                minOf(
                    startIndex + BATCH_SIZE,
                    content.series.size
                )

            val batch =
                ArrayList<CachedSeriesEntity>(
                    endIndex - startIndex
                )

            for (index in startIndex until endIndex) {
                val series =
                    content.series[index]

                batch +=
                    CachedSeriesEntity(
                        playlistId = playlistId,
                        generationId = generationId,
                        seriesId = series.id,
                        name = series.name,
                        categoryId = series.categoryId,
                        posterUrl = series.posterUrl,
                        backdropUrl = series.backdropUrl,
                        year = series.year,
                        rating = series.rating,
                        plot = series.plot,
                        titleLogoUrl = series.titleLogoUrl,
                        imdbId = series.imdbId,
                        tmdbId = series.tmdbId,
                        ratingSource =
                            series.ratingSource
                                ?.name,
                        durationSeconds =
                            series.durationSeconds,
                        genres =
                            series.genres
                                .takeIf {
                                    it.isNotEmpty()
                                }
                                ?.joinToString("|"),
                        trailerUrl = series.trailerUrl,
                        providerOrder = index
                    )
            }

            cacheDao.insertSeries(
                batch
            )

            startIndex = endIndex
        }
    }

    private suspend fun persistEpisodes(
        playlistId: String,
        generationId: String,
        content: PlaylistContent
    ) {
        var startIndex = 0

        while (startIndex < content.episodes.size) {
            val endIndex =
                minOf(
                    startIndex + BATCH_SIZE,
                    content.episodes.size
                )

            val batch =
                ArrayList<CachedEpisodeEntity>(
                    endIndex - startIndex
                )

            for (index in startIndex until endIndex) {
                val episode =
                    content.episodes[index]

                batch +=
                    CachedEpisodeEntity(
                        playlistId = playlistId,
                        generationId = generationId,
                        episodeId = episode.id,
                        seriesId = episode.seriesId,
                        seasonNumber = episode.seasonNumber,
                        episodeNumber = episode.episodeNumber,
                        name = episode.name,
                        streamUrl = episode.streamUrl,
                        posterUrl = episode.posterUrl,
                        durationSeconds = episode.durationSeconds
                    )
            }

            cacheDao.insertEpisodes(
                batch
            )

            startIndex = endIndex
        }
    }

    private companion object {
        const val TAG = "M3uSourceSync"
        const val BATCH_SIZE = 500
        const val SOURCE_XTREAM = "XTREAM"
    }
}
