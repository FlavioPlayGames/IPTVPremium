package br.com.flaviotorres.iptvpremium.data.cache

import android.util.Log
import br.com.flaviotorres.iptvpremium.data.cache.dao.PlaylistCacheDao
import br.com.flaviotorres.iptvpremium.data.cache.entity.PlaylistCacheGenerationEntity
import kotlinx.coroutines.delay
import java.util.UUID

class PlaylistCacheGenerationManager(
    private val cacheDao: PlaylistCacheDao
) {

    suspend fun beginImport(
        playlistId: String
    ): String {
        val generationId = UUID
            .randomUUID()
            .toString()

        cacheDao.upsertGeneration(
            PlaylistCacheGenerationEntity(
                playlistId = playlistId,
                generationId = generationId,
                status = PlaylistCacheGenerationEntity.STATUS_IMPORTING,
                createdAtEpochMillis =
                    System.currentTimeMillis()
            )
        )

        return generationId
    }

    suspend fun markImportReady(
        playlistId: String,
        generationId: String
    ) {
        cacheDao.updateGenerationStatus(
            playlistId = playlistId,
            generationId = generationId,
            status = PlaylistCacheGenerationEntity.STATUS_READY,
            completedAtEpochMillis =
                System.currentTimeMillis()
        )
    }

    suspend fun discardImport(
        playlistId: String,
        generationId: String
    ) {
        cacheDao.deleteGeneration(
            playlistId = playlistId,
            generationId = generationId
        )
    }

    /*
     * Ativa a geração READY mais recente.
     *
     * A troca ACTIVE -> STALE e READY -> ACTIVE continua atômica dentro
     * de PlaylistCacheDao.switchToReadyGeneration().
     *
     * A geração ACTIVE anterior NÃO é apagada aqui. Ela fica STALE e será
     * removida depois por cleanupOldestStaleGeneration(), fora do caminho
     * crítico da atualização da playlist.
     */
    suspend fun activateReadyGenerationOnStartup(
        playlistId: String
    ): String? {
        val readyGeneration =
            cacheDao.getReadyGeneration(
                playlistId = playlistId
            ) ?: return cacheDao
                .getActiveGeneration(
                    playlistId = playlistId
                )
                ?.generationId

        /*
         * MEDIÇÃO DA TROCA READY -> ACTIVE
         *
         * Estes logs existem somente para medir quanto tempo a transação
         * switchToReadyGeneration() leva. Assim conseguimos separar o custo
         * da troca no Room/SQLite do que acontece depois dela na interface.
         */
        val switchStartedAt =
            System.currentTimeMillis()

        Log.i(
            TAG,
            "Troca READY -> ACTIVE iniciada."
        )

        cacheDao.switchToReadyGeneration(
            playlistId = playlistId,
            generationId =
                readyGeneration.generationId,
            activatedAtEpochMillis =
                System.currentTimeMillis()
        )

        val switchDurationMillis =
            System.currentTimeMillis() -
                    switchStartedAt

        Log.i(
            TAG,
            "Troca READY -> ACTIVE concluída. duracaoMs=$switchDurationMillis"
        )

        return readyGeneration.generationId
    }

    /*
     * Remove no máximo UMA geração STALE por chamada.
     *
     * A exclusão é dividida em pequenos lotes para evitar uma transação
     * gigantesca e reduzir picos de WAL/SQLite.
     *
     * Retorna true quando uma geração STALE foi completamente removida.
     * Retorna false quando não havia nenhuma geração STALE.
     */
    suspend fun cleanupOldestStaleGeneration(
        playlistId: String
    ): Boolean {
        val generationId =
            cacheDao.getOldestStaleGenerationId(
                playlistId = playlistId
            ) ?: run {
                Log.d(
                    TAG,
                    "Nenhuma geração STALE pendente para limpeza."
                )
                return false
            }

        val startedAt =
            System.currentTimeMillis()

        Log.i(
            TAG,
            "Limpeza STALE iniciada."
        )

        val deletedEpisodes =
            deleteInBatches {
                cacheDao.deleteEpisodesBatchForGeneration(
                    playlistId = playlistId,
                    generationId = generationId,
                    limit = CLEANUP_BATCH_SIZE
                )
            }

        val deletedSeries =
            deleteInBatches {
                cacheDao.deleteSeriesBatchForGeneration(
                    playlistId = playlistId,
                    generationId = generationId,
                    limit = CLEANUP_BATCH_SIZE
                )
            }

        val deletedMovies =
            deleteInBatches {
                cacheDao.deleteMoviesBatchForGeneration(
                    playlistId = playlistId,
                    generationId = generationId,
                    limit = CLEANUP_BATCH_SIZE
                )
            }

        val deletedChannels =
            deleteInBatches {
                cacheDao.deleteChannelsBatchForGeneration(
                    playlistId = playlistId,
                    generationId = generationId,
                    limit = CLEANUP_BATCH_SIZE
                )
            }

        val deletedCategories =
            deleteInBatches {
                cacheDao.deleteCategoriesBatchForGeneration(
                    playlistId = playlistId,
                    generationId = generationId,
                    limit = CLEANUP_BATCH_SIZE
                )
            }

        cacheDao.deleteGenerationRow(
            playlistId = playlistId,
            generationId = generationId
        )

        val durationMillis =
            System.currentTimeMillis() -
                    startedAt

        Log.i(
            TAG,
            buildString {
                append("Limpeza STALE concluída. ")
                append("categorias=")
                append(deletedCategories)
                append(", canais=")
                append(deletedChannels)
                append(", filmes=")
                append(deletedMovies)
                append(", series=")
                append(deletedSeries)
                append(", episodios=")
                append(deletedEpisodes)
                append(", duracaoMs=")
                append(durationMillis)
            }
        )

        return true
    }

    private suspend fun deleteInBatches(
        deleteBatch: suspend () -> Int
    ): Int {
        var totalDeleted = 0

        while (true) {
            val deletedRows =
                deleteBatch()

            if (deletedRows <= 0) {
                return totalDeleted
            }

            totalDeleted +=
                deletedRows

            /*
             * Pausa curta entre lotes pequenos.
             *
             * O objetivo desta configuração é priorizar a fluidez da interface:
             * cada transação apaga menos linhas e o SQLite recebe mais tempo
             * entre as escritas para reduzir picos durante a limpeza STALE.
             */
            delay(CLEANUP_PAUSE_MILLIS)
        }
    }

    suspend fun getActiveGenerationId(
        playlistId: String
    ): String? {
        return cacheDao
            .getActiveGeneration(
                playlistId = playlistId
            )
            ?.generationId
    }

    suspend fun deletePlaylistCache(
        playlistId: String
    ) {
        cacheDao.deletePlaylistCache(
            playlistId = playlistId
        )
    }

    private companion object {
        const val TAG = "CacheGeneration"
        const val CLEANUP_BATCH_SIZE = 100
        const val CLEANUP_PAUSE_MILLIS = 25L
    }
}
