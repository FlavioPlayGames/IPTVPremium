package br.com.flaviotorres.iptvpremium.ui.series

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.PagingData
import androidx.paging.cachedIn
import br.com.flaviotorres.iptvpremium.data.repository.PlaylistCatalogRepository
import br.com.flaviotorres.iptvpremium.domain.model.Category
import br.com.flaviotorres.iptvpremium.domain.model.Series
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.launch

/**
 * Mesmo modelo de filtros paginados de Filmes, adaptado para Séries.
 * Categoria, busca, favoritos e ordenação são consultas SQL no Room.
 * O histórico "Continuar assistindo" será ligado ao player futuramente.
 */
private data class SeriesCategoryFilter(
    val categoryId: String? = null,
    val favoritesOnly: Boolean = false
)

private data class SeriesQueryOptions(
    val categoryId: String?,
    val searchQuery: String,
    val favoritesOnly: Boolean,
    val favoriteSeriesIds: Set<String>,
    val sortMode: String
)

private data class SeriesPagingRequest(
    val playlistId: String?,
    val options: SeriesQueryOptions
)

class SeriesViewModel(
    private val repository: PlaylistCatalogRepository
) : ViewModel() {

    private val playlistId = MutableStateFlow<String?>(null)
    private val categoryFilter = MutableStateFlow(SeriesCategoryFilter())
    private val searchQuery = MutableStateFlow("")
    private val favoriteSeriesIds = MutableStateFlow<Set<String>>(emptySet())
    private val sortMode = MutableStateFlow(SORT_DEFAULT)

    private val _categories = MutableStateFlow<List<Category>>(emptyList())
    val categories: StateFlow<List<Category>> = _categories.asStateFlow()

    private val _seriesCount = MutableStateFlow(0)
    val seriesCount: StateFlow<Int> = _seriesCount.asStateFlow()

    private val _categoryCounts = MutableStateFlow<Map<String?, Int>>(emptyMap())
    val categoryCounts: StateFlow<Map<String?, Int>> = _categoryCounts.asStateFlow()

    private val _isLoadingMetadata = MutableStateFlow(false)
    val isLoadingMetadata: StateFlow<Boolean> = _isLoadingMetadata.asStateFlow()

    private val _metadataError = MutableStateFlow<String?>(null)
    val metadataError: StateFlow<String?> = _metadataError.asStateFlow()

    private var metadataRefreshJob: Job? = null

    // Um favorito só reinicia o Pager quando o filtro Favoritos estiver ativo.
    private val queryOptions = combine(
        searchQuery, categoryFilter, favoriteSeriesIds, sortMode
    ) { currentSearch, currentCategory, currentFavorites, currentSort ->
        SeriesQueryOptions(
            categoryId = currentCategory.categoryId,
            searchQuery = currentSearch,
            favoritesOnly = currentCategory.favoritesOnly,
            favoriteSeriesIds = if (currentCategory.favoritesOnly) {
                currentFavorites
            } else {
                emptySet()
            },
            sortMode = currentSort
        )
    }

    @OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
    val series: Flow<PagingData<Series>> = combine(
        playlistId, queryOptions
    ) { currentPlaylistId, options ->
        SeriesPagingRequest(currentPlaylistId, options)
    }
        .distinctUntilChanged()
        .flatMapLatest { request ->
            val currentPlaylistId = request.playlistId
            if (currentPlaylistId.isNullOrBlank()) {
                flowOf(PagingData.empty<Series>())
            } else {
                repository.series(
                    playlistId = currentPlaylistId,
                    categoryId = request.options.categoryId,
                    searchQuery = request.options.searchQuery,
                    favoritesOnly = request.options.favoritesOnly,
                    favoriteSeriesIds = request.options.favoriteSeriesIds,
                    sortMode = request.options.sortMode
                )
            }
        }
        .cachedIn(viewModelScope)

    fun setPlaylist(newPlaylistId: String) {
        val normalized = newPlaylistId.trim()
        if (normalized.isEmpty()) {
            clear()
            return
        }
        if (playlistId.value == normalized) {
            refreshMetadata()
            return
        }
        metadataRefreshJob?.cancel()
        categoryFilter.value = SeriesCategoryFilter()
        searchQuery.value = ""
        sortMode.value = SORT_DEFAULT
        clearMetadata()
        playlistId.value = normalized
        refreshMetadata()
    }

    /** Ao escolher uma categoria, sai automaticamente do modo Favoritos. */
    fun selectCategory(categoryId: String?) {
        categoryFilter.value = SeriesCategoryFilter(
            categoryId = categoryId?.trim()?.takeIf { it.isNotEmpty() },
            favoritesOnly = false
        )
    }

    fun selectFavorites() {
        categoryFilter.value = SeriesCategoryFilter(favoritesOnly = true)
    }

    fun setFavoriteSeriesIds(seriesIds: Set<String>) {
        favoriteSeriesIds.value = seriesIds.asSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() }
            .toSet()
    }

    fun setSearchQuery(query: String) {
        searchQuery.value = query
    }

    fun setSortMode(mode: String) {
        sortMode.value = when (mode.trim().uppercase()) {
            SORT_A_Z -> SORT_A_Z
            SORT_Z_A -> SORT_Z_A
            else -> SORT_DEFAULT
        }
    }

    fun refreshMetadata() {
        val currentPlaylistId = playlistId.value ?: return
        metadataRefreshJob?.cancel()
        metadataRefreshJob = viewModelScope.launch {
            _isLoadingMetadata.value = true
            _metadataError.value = null
            try {
                val counts = repository.getSeriesCountsByCategory(currentPlaylistId)
                val categories = repository.getSeriesCategories(currentPlaylistId)
                    .filter { (counts[it.id] ?: 0) > 0 }
                val totalCount = repository.getSeriesCount(currentPlaylistId)

                if (playlistId.value == currentPlaylistId) {
                    _categories.value = categories
                    _categoryCounts.value = counts
                    _seriesCount.value = totalCount
                }
            } catch (cancelled: CancellationException) {
                throw cancelled
            } catch (error: Exception) {
                if (playlistId.value == currentPlaylistId) {
                    _metadataError.value = error.message
                        ?: "Não foi possível carregar as séries."
                }
            } finally {
                if (playlistId.value == currentPlaylistId) {
                    _isLoadingMetadata.value = false
                }
            }
        }
    }

    fun clear() {
        metadataRefreshJob?.cancel()
        metadataRefreshJob = null
        playlistId.value = null
        categoryFilter.value = SeriesCategoryFilter()
        searchQuery.value = ""
        favoriteSeriesIds.value = emptySet()
        sortMode.value = SORT_DEFAULT
        clearMetadata()
    }

    private fun clearMetadata() {
        _categories.value = emptyList()
        _seriesCount.value = 0
        _categoryCounts.value = emptyMap()
        _isLoadingMetadata.value = false
        _metadataError.value = null
    }

    private companion object {
        const val SORT_DEFAULT = "DEFAULT"
        const val SORT_A_Z = "A_Z"
        const val SORT_Z_A = "Z_A"
    }
}
