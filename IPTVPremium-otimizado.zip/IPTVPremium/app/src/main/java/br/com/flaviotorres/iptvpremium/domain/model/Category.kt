package br.com.flaviotorres.iptvpremium.domain.model

data class Category(
    val id: String,
    val name: String,
    val type: CategoryType,
    val source: CategorySource
)

enum class CategoryType {
    LIVE_TV,
    MOVIES,
    SERIES
}

enum class CategorySource {
    PROVIDER,
    FAVORITES,
    CONTINUE_WATCHING,
    RECENT,
    RECENTLY_ADDED
}