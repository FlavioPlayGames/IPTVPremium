package br.com.flaviotorres.iptvpremium.ui.playlist

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.R
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import kotlinx.coroutines.delay

private val MetallicGoldBrush = Brush.linearGradient(
    colors = listOf(
        Color(0xFF8A6414),
        Color(0xFFD4AF37),
        Color(0xFFFFE991),
        Color(0xFFFFF4BD),
        Color(0xFFE3B83F),
        Color(0xFF9E761B)
    )
)

@Composable
fun PlaylistListScreen(
    playlists: List<PlaylistSource>,
    activePlaylistId: String? = null,
    loadingPlaylistId: String? = null,
    onPlaylistClick: (PlaylistSource) -> Unit,
    onAddClick: () -> Unit,
    onDeleteClick: (PlaylistSource) -> Unit
) {
    var selectionFeedback by remember {
        mutableStateOf<String?>(null)
    }

    LaunchedEffect(selectionFeedback) {
        if (selectionFeedback != null) {
            delay(2_500L)
            selectionFeedback = null
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF08090C))
    ) {

        /*
         * MESMO FUNDO DA HOME
         */
        Image(
            painter = painterResource(
                id = R.drawable.home_background
            ),
            contentDescription = null,
            modifier = Modifier
                .fillMaxSize()
                .blur(14.dp),
            contentScale = ContentScale.Crop
        )

        /*
         * ESCURECIMENTO DO FUNDO
         */
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Color.Black.copy(
                        alpha = 0.46f
                    )
                )
        )

        /*
         * PAINEL PRINCIPAL
         */
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(
                    horizontal = 36.dp,
                    vertical = 28.dp
                )
                .border(
                    width = 1.5.dp,
                    brush = MetallicGoldBrush,
                    shape = RoundedCornerShape(22.dp)
                )
                .background(
                    color = Color(0xD9080D16),
                    shape = RoundedCornerShape(22.dp)
                )
                .padding(28.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxSize()
            ) {

                /*
                 * CABEÇALHO
                 */
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp),
                    horizontalArrangement =
                        Arrangement.SpaceBetween,
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "MINHAS LISTAS",
                            style = TextStyle(
                                brush = MetallicGoldBrush,
                                fontSize = 27.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        )

                        Text(
                            text = "Selecione uma lista para utilizar",
                            color = Color(0xFFB7B7BD),
                            fontSize = 14.sp
                        )
                    }

                    AddPlaylistButton(
                        onClick = onAddClick
                    )
                }

                Box(
                    modifier = Modifier.height(20.dp)
                )

                /*
                 * CONTEÚDO
                 */
                if (playlists.isEmpty()) {
                    EmptyPlaylistState(
                        modifier = Modifier
                            .fillMaxSize()
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize(),
                        verticalArrangement =
                            Arrangement.spacedBy(12.dp)
                    ) {
                        items(
                            items = playlists,
                            key = { playlist ->
                                playlist.id
                            }
                        ) { playlist ->
                            PlaylistCard(
                                playlist = playlist,
                                isActive =
                                    playlist.id ==
                                            activePlaylistId,
                                isLoading =
                                    playlist.id ==
                                            loadingPlaylistId,
                                onClick = {
                                    if (
                                        playlist.id !=
                                        loadingPlaylistId
                                    ) {
                                        selectionFeedback =
                                            if (
                                                playlist.id ==
                                                activePlaylistId
                                            ) {
                                                "Atualizando lista: ${playlist.name}"
                                            } else {
                                                "Lista selecionada: ${playlist.name}"
                                            }

                                        onPlaylistClick(
                                            playlist
                                        )
                                    }
                                },
                                onDeleteClick = {
                                    if (
                                        playlist.id !=
                                        loadingPlaylistId
                                    ) {
                                        onDeleteClick(
                                            playlist
                                        )
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
        if (selectionFeedback != null) {
            Box(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 42.dp)
                    .background(
                        color = Color(0xF21A170E),
                        shape = RoundedCornerShape(12.dp)
                    )
                    .border(
                        width = 1.5.dp,
                        brush = MetallicGoldBrush,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(
                        horizontal = 22.dp,
                        vertical = 12.dp
                    )
            ) {
                Text(
                    text = selectionFeedback.orEmpty(),
                    color = Color(0xFFF1D77A),
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

@Composable
private fun AddPlaylistButton(
    onClick: () -> Unit
) {
    var isFocused by remember {
        mutableStateOf(false)
    }

    val shape =
        RoundedCornerShape(12.dp)

    Box(
        modifier = Modifier
            .size(48.dp)
            .scale(
                if (isFocused) {
                    1.08f
                } else {
                    1f
                }
            )
            .border(
                width =
                    if (isFocused) {
                        2.dp
                    } else {
                        1.5.dp
                    },
                brush = MetallicGoldBrush,
                shape = shape
            )
            .background(
                color = Color(0xD9151518),
                shape = shape
            )
            .onFocusChanged {
                isFocused = it.isFocused
            }
            .clickable(
                onClick = onClick
            )
            .focusable(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "+",
            style = TextStyle(
                brush = MetallicGoldBrush,
                fontSize = 30.sp,
                fontWeight = FontWeight.Normal
            )
        )
    }
}

@Composable
private fun PlaylistCard(
    playlist: PlaylistSource,
    isActive: Boolean,
    isLoading: Boolean,
    onClick: () -> Unit,
    onDeleteClick: () -> Unit
) {
    var isFocused by remember {
        mutableStateOf(false)
    }

    val shape =
        RoundedCornerShape(14.dp)

    val typeText =
        when (playlist) {
            is PlaylistSource.XtreamCodes -> {
                "XTREAM CODES"
            }

            is PlaylistSource.M3u -> {
                "M3U"
            }
        }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(82.dp)
            .then(
                if (isFocused || isActive || isLoading) {
                    Modifier.border(
                        width = 2.dp,
                        brush = MetallicGoldBrush,
                        shape = shape
                    )
                } else {
                    Modifier.border(
                        width = 1.dp,
                        color = Color(0xFF343841),
                        shape = shape
                    )
                }
            )
            .background(
                color =
                    if (isActive) {
                        Color(0xE61A170E)
                    } else {
                        Color(0xE615181E)
                    },
                shape = shape
            )
            .onFocusChanged {
                isFocused = it.isFocused
            }
            .clickable(
                onClick = onClick
            )
            .focusable()
            .padding(
                start = 20.dp,
                end = 12.dp
            )
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize(),
            horizontalArrangement =
                Arrangement.SpaceBetween,
            verticalAlignment =
                Alignment.CenterVertically
        ) {
            Row(
                verticalAlignment =
                    Alignment.CenterVertically,
                horizontalArrangement =
                    Arrangement.spacedBy(18.dp)
            ) {
                PlaylistTypeBadge(
                    type = typeText,
                    highlighted =
                        isFocused || isActive || isLoading
                )

                Column(
                    verticalArrangement =
                        Arrangement.spacedBy(4.dp)
                ) {
                    Text(
                        text = playlist.name,
                        color = Color(0xFFF5F5F5),
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Medium
                    )

                    Text(
                        text =
                            when {
                                isLoading && isActive ->
                                    "$typeText • ATUALIZANDO..."

                                isLoading ->
                                    "$typeText • CARREGANDO..."

                                isActive ->
                                    "$typeText • LISTA ATIVA"

                                else ->
                                    typeText
                            },
                        color =
                            if (isActive || isLoading) {
                                Color(0xFFF1D77A)
                            } else {
                                Color(0xFF9498A3)
                            },
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            if (isLoading) {
                PlaylistLoadingIndicator()
            } else {
                DeletePlaylistButton(
                    onClick = onDeleteClick
                )
            }
        }
    }
}

@Composable
private fun PlaylistLoadingIndicator() {
    val transition =
        rememberInfiniteTransition(
            label = "playlistLoading"
        )

    val rotation by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = 900,
                easing = LinearEasing
            )
        ),
        label = "playlistLoadingRotation"
    )

    Canvas(
        modifier = Modifier.size(34.dp)
    ) {
        drawArc(
            brush = MetallicGoldBrush,
            startAngle = rotation,
            sweepAngle = 265f,
            useCenter = false,
            style = Stroke(
                width = 3.dp.toPx(),
                cap = StrokeCap.Round
            )
        )
    }
}

@Composable
private fun PlaylistTypeBadge(
    type: String,
    highlighted: Boolean
) {
    Box(
        modifier = Modifier
            .width(112.dp)
            .height(34.dp)
            .then(
                if (highlighted) {
                    Modifier.border(
                        width = 1.5.dp,
                        brush = MetallicGoldBrush,
                        shape = RoundedCornerShape(8.dp)
                    )
                } else {
                    Modifier.border(
                        width = 1.dp,
                        color = Color(0xFF454A55),
                        shape = RoundedCornerShape(8.dp)
                    )
                }
            )
            .background(
                color = Color(0xB50C1119),
                shape = RoundedCornerShape(8.dp)
            ),
        contentAlignment =
            Alignment.Center
    ) {
        if (highlighted) {
            Text(
                text = type,
                style = TextStyle(
                    brush = MetallicGoldBrush,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            )
        } else {
            Text(
                text = type,
                color = Color(0xFFB7B7BD),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun DeletePlaylistButton(
    onClick: () -> Unit
) {
    var isFocused by remember {
        mutableStateOf(false)
    }

    val shape =
        RoundedCornerShape(9.dp)

    Box(
        modifier = Modifier
            .size(40.dp)
            .scale(
                if (isFocused) {
                    1.08f
                } else {
                    1f
                }
            )
            .border(
                width =
                    if (isFocused) {
                        1.5.dp
                    } else {
                        1.dp
                    },
                color =
                    if (isFocused) {
                        Color(0xFFE8C55B)
                    } else {
                        Color(0xFF4A4D55)
                    },
                shape = shape
            )
            .background(
                color = Color(0xAA111318),
                shape = shape
            )
            .onFocusChanged {
                isFocused = it.isFocused
            }
            .clickable(
                onClick = onClick
            )
            .focusable(),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = "×",
            color =
                if (isFocused) {
                    Color(0xFFF1D77A)
                } else {
                    Color(0xFFB7B7BD)
                },
            fontSize = 24.sp,
            fontWeight = FontWeight.Normal
        )
    }
}

@Composable
private fun EmptyPlaylistState(
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier,
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment =
                Alignment.CenterHorizontally,
            verticalArrangement =
                Arrangement.spacedBy(8.dp)
        ) {
            Text(
                text = "Nenhuma lista cadastrada",
                color = Color(0xFFF5F5F5),
                fontSize = 19.sp,
                fontWeight = FontWeight.Medium
            )

            Text(
                text = "Use o botão + para adicionar sua primeira lista.",
                color = Color(0xFF9FA2AA),
                fontSize = 14.sp
            )
        }
    }
}
