package br.com.flaviotorres.iptvpremium.domain.model

data class PlaylistContent(
    val categories: List<Category> = emptyList(),
    val channels: List<Channel> = emptyList(),
    val movies: List<Movie> = emptyList(),
    val series: List<Series> = emptyList(),
    val episodes: List<Episode> = emptyList()
)