package br.com.flaviotorres.iptvpremium.core.navigation

import android.net.Uri
import br.com.flaviotorres.iptvpremium.core.player.PlaybackContentType

/**
 * Destinos da navegação do IPTVPremium.
 *
 * A rota do reprodutor leva somente tipo + identificador do conteúdo.
 * Nunca coloque streamUrl, usuário, senha ou token Xtream na navegação.
 */
sealed class AppDestination(
    val route: String
) {
    data object Home : AppDestination(
        "home"
    )

    data object LiveTv : AppDestination(
        "live_tv"
    )

    data object Movies : AppDestination(
        "movies"
    )

    data object MovieDetails : AppDestination(
        "movie_details/{movieId}"
    ) {
        fun createRoute(
            movieId: String
        ): String {
            return "movie_details/$movieId"
        }
    }

    data object Series : AppDestination(
        "series"
    )

    data object SeriesDetails : AppDestination(
        "series_details/{seriesId}"
    ) {
        fun createRoute(
            seriesId: String
        ): String {
            return "series_details/$seriesId"
        }
    }

    /**
     * Rota comum ao Media3 e VLC. A escolha do mecanismo é feita dentro
     * do PlaybackController, sem criar duas telas diferentes.
     *
     * Exemplos:
     * playback/MOVIE/123
     * playback/EPISODE/456
     * playback/LIVE_CHANNEL/789
     *
     * O AppNavigation buscará o conteúdo na playlist ativa usando o ID.
     */
    data object Playback : AppDestination(
        "playback/{contentType}/{contentId}"
    ) {
        fun createRoute(
            contentType: PlaybackContentType,
            contentId: String
        ): String {
            require(contentId.isNotBlank()) {
                "O ID do conteúdo não pode ser vazio."
            }

            return "playback/${contentType.name}/${Uri.encode(contentId)}"
        }
    }

    data object Settings : AppDestination(
        "settings"
    )

    data object SubdlSettings : AppDestination(
        "settings/subdl"
    )
}