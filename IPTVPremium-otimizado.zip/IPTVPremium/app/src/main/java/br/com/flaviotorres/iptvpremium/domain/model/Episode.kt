package br.com.flaviotorres.iptvpremium.domain.model

data class Episode(
    val id: String,
    val seriesId: String,
    val name: String,
    val seasonNumber: Int,
    val episodeNumber: Int,
    val streamUrl: String,
    val posterUrl: String?,
    val durationSeconds: Long?,
    val plot: String?
)