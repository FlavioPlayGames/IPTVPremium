package br.com.flaviotorres.iptvpremium.data.storage

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import br.com.flaviotorres.iptvpremium.domain.model.PlaylistSource
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject

private val Context.playlistDataStore by preferencesDataStore(
    name = "playlist_storage"
)

class PlaylistStorage(
    private val context: Context
) {

    private val playlistsKey =
        stringPreferencesKey("playlists")

    private val activePlaylistIdKey =
        stringPreferencesKey("active_playlist_id")

    val playlists: Flow<List<PlaylistSource>> =
        context.playlistDataStore.data.map { preferences ->
            decodePlaylists(
                preferences[playlistsKey]
                    .orEmpty()
            )
        }

    val activePlaylistId: Flow<String?> =
        context.playlistDataStore.data.map { preferences ->
            preferences[activePlaylistIdKey]
                ?.takeIf { it.isNotBlank() }
        }

    suspend fun savePlaylists(
        playlists: List<PlaylistSource>
    ) {
        context.playlistDataStore.edit { preferences ->
            preferences[playlistsKey] =
                encodePlaylists(playlists)
        }
    }

    suspend fun saveActivePlaylistId(
        playlistId: String?
    ) {
        context.playlistDataStore.edit { preferences ->
            if (playlistId.isNullOrBlank()) {
                preferences.remove(
                    activePlaylistIdKey
                )
            } else {
                preferences[activePlaylistIdKey] =
                    playlistId
            }
        }
    }

    suspend fun clear() {
        context.playlistDataStore.edit { preferences ->
            preferences.remove(playlistsKey)
            preferences.remove(activePlaylistIdKey)
        }
    }

    private fun encodePlaylists(
        playlists: List<PlaylistSource>
    ): String {
        val array = JSONArray()

        playlists.forEach { playlist ->
            val item = JSONObject()

            item.put(
                "id",
                playlist.id
            )

            item.put(
                "name",
                playlist.name
            )

            item.put(
                "isEnabled",
                playlist.isEnabled
            )

            when (playlist) {
                is PlaylistSource.XtreamCodes -> {
                    item.put(
                        "type",
                        "xtream"
                    )

                    item.put(
                        "serverUrl",
                        playlist.serverUrl
                    )

                    item.put(
                        "username",
                        playlist.username
                    )

                    item.put(
                        "password",
                        playlist.password
                    )
                }

                is PlaylistSource.M3u -> {
                    item.put(
                        "type",
                        "m3u"
                    )

                    item.put(
                        "playlistUrl",
                        playlist.playlistUrl
                    )
                }
            }

            array.put(item)
        }

        return array.toString()
    }

    private fun decodePlaylists(
        raw: String
    ): List<PlaylistSource> {
        if (raw.isBlank()) {
            return emptyList()
        }

        return runCatching {
            val array = JSONArray(raw)

            buildList {
                for (
                index in 0 until array.length()
                ) {
                    val item =
                        array.optJSONObject(index)
                            ?: continue

                    val id =
                        item.optString("id")

                    val name =
                        item.optString("name")

                    val isEnabled =
                        item.optBoolean(
                            "isEnabled",
                            true
                        )

                    when (
                        item.optString("type")
                    ) {
                        "xtream" -> {
                            add(
                                PlaylistSource.XtreamCodes(
                                    id = id,
                                    name = name,
                                    isEnabled = isEnabled,
                                    serverUrl =
                                        item.optString(
                                            "serverUrl"
                                        ),
                                    username =
                                        item.optString(
                                            "username"
                                        ),
                                    password =
                                        item.optString(
                                            "password"
                                        )
                                )
                            )
                        }

                        "m3u" -> {
                            add(
                                PlaylistSource.M3u(
                                    id = id,
                                    name = name,
                                    isEnabled = isEnabled,
                                    playlistUrl =
                                        item.optString(
                                            "playlistUrl"
                                        )
                                )
                            )
                        }
                    }
                }
            }
        }.getOrElse {
            emptyList()
        }
    }
}