
package br.com.flaviotorres.iptvpremium.ui.components

import android.view.InputDevice
import android.view.KeyCharacterMap
import androidx.compose.ui.input.key.KeyEvent
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.type

/**
 * Identifica teclas pressionadas em teclado físico USB/Bluetooth.
 */
fun isPhysicalKeyboardKeyDown(event: KeyEvent): Boolean {
    if (event.type != KeyEventType.KeyDown) return false

    val native = event.nativeKeyEvent

    return InputDevice.getDevice(native.deviceId)?.keyboardType ==
            InputDevice.KEYBOARD_TYPE_ALPHABETIC
}

/**
 * Representa o caractere digitado e um possível acento pendente.
 */
data class PhysicalCharacter(
    val text: String?,
    val deadAccent: Int
)

/**
 * Processa caracteres de teclado físico, incluindo AltGr e
 * acentos compostos de teclados brasileiros ABNT2.
 */
fun physicalTypedCharacter(
    event: KeyEvent,
    previousDeadAccent: Int = 0
): PhysicalCharacter {

    if (!isPhysicalKeyboardKeyDown(event)) {
        return PhysicalCharacter(null, previousDeadAccent)
    }

    val native = event.nativeKeyEvent

    // Preserva atalhos Ctrl e permite AltGr.
    if (native.isMetaPressed ||
        (native.isCtrlPressed && !native.isAltPressed)
    ) {
        return PhysicalCharacter(null, previousDeadAccent)
    }

    val code = native.getUnicodeChar(native.metaState)

    // Detecta teclas de acento.
    if ((code and KeyCharacterMap.COMBINING_ACCENT) != 0) {
        return PhysicalCharacter(
            null,
            code and KeyCharacterMap.COMBINING_ACCENT_MASK
        )
    }

    if (code <= 0 ||
        !Character.isValidCodePoint(code) ||
        Character.isISOControl(code)
    ) {
        return PhysicalCharacter(null, previousDeadAccent)
    }

    // Combina acento pendente com a letra digitada.
    val composed = if (previousDeadAccent != 0) {
        KeyCharacterMap.getDeadChar(
            previousDeadAccent,
            code
        ).takeIf { it > 0 } ?: code
    } else {
        code
    }

    return PhysicalCharacter(
        String(Character.toChars(composed)),
        0
    )
}
