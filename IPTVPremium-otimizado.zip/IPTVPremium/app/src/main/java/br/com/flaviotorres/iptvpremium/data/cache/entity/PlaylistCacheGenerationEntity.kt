package br.com.flaviotorres.iptvpremium.data.cache.entity

import androidx.room.Entity
import androidx.room.Index

/*
 * Representa uma geração completa do cache de uma playlist.
 *
 * Fluxo esperado:
 *
 * IMPORTING
 *     A nova versão da lista está sendo baixada e gravada.
 *
 * READY
 *     A importação terminou com sucesso, mas esta geração ainda
 *     NÃO deve aparecer para o usuário durante a sessão atual.
 *
 * ACTIVE
 *     É a geração que o aplicativo deve utilizar para leitura.
 *
 * Cada playlist pode possuir mais de uma geração temporariamente.
 * Isso permite atualizar em segundo plano sem alterar o conteúdo
 * que o usuário já está utilizando.
 */
@Entity(
    tableName = "playlist_cache_generations",
    primaryKeys = [
        "playlistId",
        "generationId"
    ],
    indices = [
        Index(
            value = [
                "playlistId",
                "status"
            ]
        )
    ]
)
data class PlaylistCacheGenerationEntity(
    /*
     * Mesmo ID utilizado em PlaylistSource.
     *
     * Quando a playlist for excluída, todos os registros de cache
     * associados a este ID também serão removidos.
     */
    val playlistId: String,

    /*
     * Identificador único deste snapshot.
     *
     * Será criado antes de iniciar cada importação/atualização.
     */
    val generationId: String,

    /*
     * IMPORTING, READY ou ACTIVE.
     *
     * Mantemos como String para não precisar de TypeConverter
     * nesta primeira etapa do banco.
     */
    val status: String,

    /*
     * Momento em que a geração começou a ser criada.
     */
    val createdAtEpochMillis: Long,

    /*
     * Momento em que toda a importação terminou com sucesso.
     * Enquanto estiver IMPORTING, normalmente será null.
     */
    val completedAtEpochMillis: Long? = null,

    /*
     * Momento em que a geração passou a ser a geração ACTIVE.
     */
    val activatedAtEpochMillis: Long? = null
) {
    companion object {
        const val STATUS_IMPORTING = "IMPORTING"
        const val STATUS_READY = "READY"
    }
}
