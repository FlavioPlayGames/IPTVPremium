package br.com.flaviotorres.iptvpremium.ui.components

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.annotation.DrawableRes
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.produceState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

private val MetallicGoldBrush = Brush.linearGradient(
    colors = listOf(
        Color(0xFFFFF4CE),
        Color(0xFFFFD083),
        Color(0xFFFFAC45),
        Color(0xFFB9742A),
        Color(0xFFFFCE78),
        Color(0xFFFFEDAD)
    )
)

@Composable
fun HomeMenuCard(
    title: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    @DrawableRes imageResId: Int? = null
) {
    var isFocused by remember { mutableStateOf(false) }
    val interactionSource = remember { MutableInteractionSource() }
    val screenWidthDp = LocalConfiguration.current.screenWidthDp
    val isWideScreen = screenWidthDp >= 700

    val slotWidth = if (isWideScreen) {
        ((screenWidthDp - 108) / 4).coerceIn(120, 190).dp
    } else {
        ((screenWidthDp - 64) / 2).coerceIn(96, 170).dp
    }
    val frameWidth = minOf(slotWidth, 132.dp)
    val frameHeight = frameWidth
    val artworkSize = frameWidth * 0.68f
    val titleGap = 14.dp
    val verticalAdjustment = if (isWideScreen) (-22).dp else 0.dp
    val titleFontSize = if (isWideScreen) 17.sp else 16.sp

    val cardScale by animateFloatAsState(
        targetValue = if (isFocused) 1.06f else 1f,
        animationSpec = tween(durationMillis = 180),
        label = "HomeMenuCardScale"
    )

    Column(
        modifier = modifier
            .width(slotWidth)
            .offset(y = verticalAdjustment)
            .scale(cardScale)
            .onFocusChanged { isFocused = it.isFocused }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            )
            .focusable(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(width = frameWidth, height = frameHeight)
                .clip(RoundedCornerShape(18.dp))
                .background(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF6C421F).copy(alpha = if (isFocused) 0.48f else 0.32f),
                            Color(0xFF20160F).copy(alpha = if (isFocused) 0.58f else 0.42f)
                        )
                    )
                )
                .drawBehind {
                    val center = Offset(size.width / 2f, size.height)
                    drawRect(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0xFFFFB52E).copy(alpha = if (isFocused) 0.48f else 0.28f),
                                Color.Transparent
                            ),
                            center = center,
                            radius = size.width * 0.48f
                        )
                    )
                }
                .border(
                    border = BorderStroke(
                        width = if (isFocused) 3.dp else 1.5.dp,
                        brush = MetallicGoldBrush
                    ),
                    shape = RoundedCornerShape(18.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            if (title in listOf("Canais", "Filmes", "Séries", "Listas")) {
                HomeMenuOutlineIcon(title, Modifier.size(artworkSize))
            } else if (imageResId != null) {
                // Mesmo tamanho, mesma arte e mesma proporcao do card original.
                // Somente o bitmap e decodificado fora da thread principal.
                HomeMenuArtwork(
                    imageResId = imageResId,
                    contentDescription = title,
                    artworkSize = artworkSize
                )
            }
        }

        Spacer(modifier = Modifier.height(titleGap))

        Text(
            text = title.uppercase(),
            style = TextStyle(
                fontFamily = FontFamily.SansSerif,
                fontWeight = FontWeight.Medium,
                fontSize = titleFontSize,
                letterSpacing = 3.sp,
                color = Color(0xFFFFF8E8),
                shadow = Shadow(
                    color = Color.Black.copy(alpha = 0.90f),
                    offset = Offset(x = 0f, y = 2f),
                    blurRadius = 6f
                )
            )
        )
    }
}


@Composable
private fun HomeMenuOutlineIcon(title: String, modifier: Modifier) {
    Canvas(modifier) {
        val ink = Color(0xFFFFF1C8)
        val stroke = Stroke(width = 2.8f)
        scale(size.width / 100f, size.height / 100f, pivot = Offset.Zero) {
            fun line(x1: Float, y1: Float, x2: Float, y2: Float) {
                drawLine(ink, Offset(x1, y1), Offset(x2, y2), strokeWidth = 2.8f)
            }
            fun triangle() {
                val path = Path().apply {
                    moveTo(43f, 39f)
                    lineTo(43f, 63f)
                    lineTo(65f, 51f)
                    close()
                }
                drawPath(path, ink, style = stroke)
            }
            when (title) {
                "Canais" -> {
                    drawRoundRect(ink, Offset(5f, 15f), Size(90f, 61f), CornerRadius(4f), style = stroke)
                    line(6f, 69f, 94f, 69f)
                    line(41f, 77f, 36f, 89f)
                    line(59f, 77f, 64f, 89f)
                    line(27f, 89f, 73f, 89f)
                }
                "Filmes" -> {
                    drawRoundRect(ink, Offset(11f, 9f), Size(78f, 82f), CornerRadius(5f), style = stroke)
                    line(24f, 10f, 24f, 90f)
                    line(76f, 10f, 76f, 90f)
                    for (y in listOf(24f, 40f, 56f, 72f)) {
                        line(12f, y, 23f, y)
                        line(77f, y, 88f, y)
                    }
                    triangle()
                }
                "Séries" -> {
                    drawRoundRect(ink, Offset(12f, 39f), Size(76f, 51f), CornerRadius(4f), style = stroke)
                    val clap = Path().apply {
                        moveTo(10f, 37f)
                        lineTo(7f, 23f)
                        lineTo(82f, 7f)
                        lineTo(85f, 21f)
                        close()
                    }
                    drawPath(clap, ink, style = stroke)
                    line(22f, 21f, 31f, 31f)
                    line(44f, 16f, 53f, 27f)
                    line(66f, 12f, 75f, 22f)
                    val play = Path().apply {
                        moveTo(44f, 50f)
                        lineTo(44f, 77f)
                        lineTo(66f, 63.5f)
                        close()
                    }
                    drawPath(play, ink, style = stroke)
                }
                "Listas" -> {
                    for (y in listOf(24f, 50f, 76f)) {
                        drawCircle(ink, radius = 4.5f, center = Offset(14f, y), style = stroke)
                        drawRoundRect(ink, Offset(30f, y - 4f), Size(59f, 8f), CornerRadius(4f), style = stroke)
                    }
                }
            }
        }
    }
}

/**
 * Decodificacao economica das 3 artes grandes da Home.
 *
 * Conserva ARGB_8888 (inclusive alfa), sem recomprimir os PNGs ou mudar
 * os dp da interface. 2x da imagem efetivamente desenhada + folga para
 * o aumento de 6% no foco. Cache fica restrito a 10 MiB na RAM.
 */
private object HomeMenuArtworkCache {
    private const val MAX_CACHE_KB = 10 * 1024
    private val decodeSlot = Semaphore(1)

    private val images = object : LruCache<String, ImageBitmap>(MAX_CACHE_KB) {
        override fun sizeOf(key: String, value: ImageBitmap): Int =
            ((value.width.toLong() * value.height.toLong() * 4L + 1023L) / 1024L)
                .coerceAtLeast(1L)
                .coerceAtMost(Int.MAX_VALUE.toLong())
                .toInt()
    }

    private fun cacheKey(drawableId: Int, widthPx: Int, heightPx: Int): String =
        "$drawableId:$widthPx:$heightPx"

    fun cached(drawableId: Int, widthPx: Int, heightPx: Int): ImageBitmap? =
        images.get(cacheKey(drawableId, widthPx, heightPx))

    suspend fun load(
        context: Context,
        @DrawableRes drawableId: Int,
        widthPx: Int,
        heightPx: Int
    ): ImageBitmap? {
        val cacheKey = cacheKey(drawableId, widthPx, heightPx)
        images.get(cacheKey)?.let { return it }

        return withContext(Dispatchers.Default) {
            decodeSlot.withPermit {
                images.get(cacheKey)?.let { return@withPermit it }

                try {
                    val resources = context.applicationContext.resources
                    val bounds = BitmapFactory.Options().apply {
                        inJustDecodeBounds = true
                        inScaled = false
                    }
                    BitmapFactory.decodeResource(resources, drawableId, bounds)

                    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                        return@withPermit null
                    }

                    var sample = 1
                    while (
                        sample < 128 &&
                        bounds.outWidth / (sample * 2) >= widthPx &&
                        bounds.outHeight / (sample * 2) >= heightPx
                    ) {
                        sample *= 2
                    }

                    val decodeOptions = BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inScaled = false
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                    }
                    val bitmap = BitmapFactory.decodeResource(
                        resources,
                        drawableId,
                        decodeOptions
                    )?.asImageBitmap()

                    if (bitmap != null) images.put(cacheKey, bitmap)
                    bitmap
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (_: OutOfMemoryError) {
                    images.evictAll()
                    null
                } catch (_: Exception) {
                    // Uma falha isolada de arte nao impede navegar pela Home.
                    null
                }
            }
        }
    }
}

@Composable
private fun HomeMenuArtwork(
    @DrawableRes imageResId: Int,
    contentDescription: String,
    artworkSize: androidx.compose.ui.unit.Dp
) {
    val context = LocalContext.current
    val density = LocalDensity.current

    // Margem de resolucao >2x para o zoom 1.06f, sem carregar 1254x1254
    // em uma TV onde a arte ocupa apenas 155 ou 200 dp.
    val requiredPixels = with(density) {
        (artworkSize * 2.12f).roundToPx()
    }.coerceAtLeast(1)

    // Ao reutilizar um composable com outra imagem, nunca mostramos a
    // imagem antiga enquanto a nova e carregada em background.
    key(imageResId, requiredPixels) {
        val bitmap by produceState<ImageBitmap?>(
            initialValue = HomeMenuArtworkCache.cached(
                imageResId, requiredPixels, requiredPixels
            ),
            key1 = imageResId,
            key2 = requiredPixels
        ) {
            value = HomeMenuArtworkCache.load(
                context.applicationContext,
                imageResId,
                requiredPixels,
                requiredPixels
            )
        }

        bitmap?.let { loaded ->
            Image(
                bitmap = loaded,
                contentDescription = contentDescription,
                modifier = Modifier.requiredSize(artworkSize),
                contentScale = ContentScale.Fit
            )
        }
    }
}
