package br.com.flaviotorres.iptvpremium.ui.home

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.annotation.DrawableRes
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.tv.material3.MaterialTheme
import br.com.flaviotorres.iptvpremium.R
import br.com.flaviotorres.iptvpremium.ui.components.HomeMenuCard
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

// Mesmo dourado metálico usado no contorno dos ícones principais.
private val MetallicGoldBrush = Brush.linearGradient(
    colors = listOf(
        Color(0xFF8A6414),
        Color(0xFFD4AF37),
        Color(0xFFFFE991),
        Color(0xFFFFF4BD),
        Color(0xFFE3B83F),
        Color(0xFF9E761B)
    )
)

@Composable
fun HomeScreen(
    onLiveTvClick: () -> Unit,
    onMoviesClick: () -> Unit,
    onSeriesClick: () -> Unit,
    onListaClick: () -> Unit = {},
    onAtualizarClick: () -> Unit = {},
    onConfiguracoesClick: () -> Unit = {}
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Image(
            painter = painterResource(
                id = R.drawable.home_background
            ),
            contentDescription = null,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop
        )

        /*
         * ESCURECIMENTO DO FUNDO
         *
         * Antes: 0.50f
         * Agora: 0.20f
         */
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Color.Black.copy(
                        alpha = 0.20f
                    )
                )
        )

        BoxWithConstraints(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp)
        ) {
            val isWideScreen =
                maxWidth >= 700.dp

            /*
             * LOGO IPTV PREMIUM
             */
            HomeScaledResourceImage(
                imageResId = R.drawable.iptv_premium_logo,
                contentDescription = "IPTV Premium",
                targetWidth = if (isWideScreen) 220.dp else 165.dp,
                targetHeight = if (isWideScreen) 105.dp else 80.dp,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(
                        top = if (isWideScreen) {
                            0.dp
                        } else {
                            18.dp
                        }
                    )
                    .width(
                        if (isWideScreen) {
                            220.dp
                        } else {
                            165.dp
                        }
                    )
                    .height(
                        if (isWideScreen) {
                            105.dp
                        } else {
                            80.dp
                        }
                    ),
                contentScale = ContentScale.Fit
            )

            /*
             * ÍCONES DO TOPO DIREITO
             */
            Row(
                modifier = Modifier
                    .align(Alignment.TopEnd),
                horizontalArrangement =
                    Arrangement.spacedBy(
                        if (isWideScreen) {
                            10.dp
                        } else {
                            8.dp
                        }
                    ),
                verticalAlignment =
                    Alignment.CenterVertically
            ) {
                HomeTopIconButton(
                    imageResId = R.drawable.icon_atualizar,
                    contentDescription = "Atualizar",
                    isWideScreen = isWideScreen,
                    onClick = onAtualizarClick
                )

                HomeTopIconButton(
                    imageResId = R.drawable.icon_configuracoes,
                    contentDescription = "Configurações",
                    isWideScreen = isWideScreen,
                    onClick = onConfiguracoesClick
                )
            }

            if (isWideScreen) {
                Row(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(y = 38.dp),
                    horizontalArrangement =
                        Arrangement.spacedBy(20.dp),
                    verticalAlignment =
                        Alignment.CenterVertically
                ) {
                    HomeMenuCard(
                        title = "Canais",
                        imageResId =
                            R.drawable.home_channels,
                        onClick = onLiveTvClick
                    )

                    HomeMenuCard(
                        title = "Filmes",
                        imageResId =
                            R.drawable.home_movies,
                        onClick = onMoviesClick
                    )

                    HomeMenuCard(
                        title = "Séries",
                        imageResId =
                            R.drawable.home_series,
                        onClick = onSeriesClick
                    )

                    HomeMenuCard(
                        title = "Listas",
                        imageResId = R.drawable.icon_lista,
                        onClick = onListaClick
                    )
                }
            } else {
                Column(
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(y = 38.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(20.dp)
                ) {
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        HomeMenuCard(
                            title = "Canais",
                            imageResId = R.drawable.home_channels,
                            onClick = onLiveTvClick
                        )
                        HomeMenuCard(
                            title = "Filmes",
                            imageResId = R.drawable.home_movies,
                            onClick = onMoviesClick
                        )
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        HomeMenuCard(
                            title = "Séries",
                            imageResId = R.drawable.home_series,
                            onClick = onSeriesClick
                        )
                        HomeMenuCard(
                            title = "Listas",
                            imageResId = R.drawable.icon_lista,
                            onClick = onListaClick
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HomeTopIconButton(
    imageResId: Int,
    contentDescription: String,
    isWideScreen: Boolean,
    onClick: () -> Unit
) {
    var isFocused by remember {
        mutableStateOf(false)
    }

    val touchAreaSize =
        if (isWideScreen) {
            46.dp
        } else {
            40.dp
        }

    val iconSize =
        if (isWideScreen) {
            30.dp
        } else {
            26.dp
        }

    // Fundo transparente. Só o contorno dourado aparece ao ganhar foco.
    // O clique continua sem ripple retangular e a área de toque não muda.
    val interactionSource = remember { MutableInteractionSource() }
    val focusShape = RoundedCornerShape(if (isWideScreen) 11.dp else 9.dp)

    Box(
        modifier = Modifier
            .size(touchAreaSize)
            .then(
                if (isFocused) {
                    Modifier.border(
                        border = BorderStroke(
                            width = 2.dp,
                            brush = MetallicGoldBrush
                        ),
                        shape = focusShape
                    )
                } else {
                    Modifier
                }
            )
            .onFocusChanged { focusState ->
                isFocused = focusState.isFocused
            }
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        HomeScaledResourceImage(
            imageResId = imageResId,
            contentDescription = contentDescription,
            targetWidth = iconSize * 1.12f,
            targetHeight = iconSize * 1.12f,
            modifier = Modifier
                .size(iconSize)
                .scale(if (isFocused) 1.12f else 1f),
            contentScale = ContentScale.Fit
        )
    }
}

/**
 * Home: decodifica os recursos de logo e dos icones pequenos fora da UI.
 *
 * - conserva ARGB_8888 (cores e transparencia originais);
 * - trabalha com no minimo 2x o tamanho de desenho para preservar nitidez
 *   inclusive com o aumento de 12% que ocorre ao focar;
 * - cache pequeno em RAM evita repetir a decodificacao ao voltar para Home;
 * - o fundo da Home permanece no carregamento original, sem downsampling.
 */
private object HomeArtworkCache {
    private const val MEMORY_LIMIT_KB = 8 * 1024
    // TV com poucos nucleos: apenas uma decodificacao por vez.
    private val decodeSlot = Semaphore(1)

    private val bitmaps = object : LruCache<String, ImageBitmap>(MEMORY_LIMIT_KB) {
        override fun sizeOf(key: String, value: ImageBitmap): Int =
            ((value.width.toLong() * value.height.toLong() * 4L + 1023L) / 1024L)
                .coerceAtLeast(1L)
                .coerceAtMost(Int.MAX_VALUE.toLong())
                .toInt()
    }

    private fun cacheKey(imageResId: Int, requiredWidth: Int, requiredHeight: Int): String =
        "$imageResId:$requiredWidth:$requiredHeight"

    fun cached(imageResId: Int, requiredWidth: Int, requiredHeight: Int): ImageBitmap? =
        bitmaps.get(cacheKey(imageResId, requiredWidth, requiredHeight))

    suspend fun load(
        context: Context,
        @DrawableRes imageResId: Int,
        requiredWidth: Int,
        requiredHeight: Int
    ): ImageBitmap? {
        val key = cacheKey(imageResId, requiredWidth, requiredHeight)
        bitmaps.get(key)?.let { return it }

        return withContext(Dispatchers.Default) {
            decodeSlot.withPermit {
                bitmaps.get(key)?.let { return@withPermit it }

                try {
                    val resources = context.applicationContext.resources
                    val bounds = BitmapFactory.Options().apply {
                        inJustDecodeBounds = true
                        inScaled = false
                    }
                    BitmapFactory.decodeResource(resources, imageResId, bounds)

                    if (bounds.outWidth <= 0 || bounds.outHeight <= 0) {
                        return@withPermit null
                    }

                    var sample = 1
                    while (
                        sample < 128 &&
                        bounds.outWidth / (sample * 2) >= requiredWidth &&
                        bounds.outHeight / (sample * 2) >= requiredHeight
                    ) {
                        sample *= 2
                    }

                    val options = BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inScaled = false
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                    }
                    val image = BitmapFactory.decodeResource(resources, imageResId, options)
                        ?.asImageBitmap()
                    if (image != null) bitmaps.put(key, image)
                    image
                } catch (cancelled: CancellationException) {
                    throw cancelled
                } catch (error: OutOfMemoryError) {
                    bitmaps.evictAll()
                    null
                } catch (_: Exception) {
                    // Falha isolada de recurso nunca derruba a Home.
                    null
                }
            }
        }
    }
}

@Composable
private fun HomeScaledResourceImage(
    @DrawableRes imageResId: Int,
    contentDescription: String?,
    targetWidth: Dp,
    targetHeight: Dp,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Fit
) {
    val context = LocalContext.current
    val density = LocalDensity.current

    // Margem 2x: conserva detalhes sem alocar um bitmap 1254x1254
    // para um icone que ocupa somente 30 dp na TV.
    val widthPx = with(density) { (targetWidth * 2f).roundToPx() }.coerceAtLeast(1)
    val heightPx = with(density) { (targetHeight * 2f).roundToPx() }.coerceAtLeast(1)

    val image by produceState(
        initialValue = HomeArtworkCache.cached(imageResId, widthPx, heightPx),
        key1 = imageResId,
        key2 = widthPx,
        key3 = heightPx
    ) {
        value = HomeArtworkCache.load(context, imageResId, widthPx, heightPx)
    }

    image?.let { bitmap ->
        Image(
            bitmap = bitmap,
            contentDescription = contentDescription,
            modifier = modifier,
            contentScale = contentScale
        )
    }
}
