package br.com.flaviotorres.iptvpremium.ui.series

import android.os.SystemClock
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Text
import br.com.flaviotorres.iptvpremium.R
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/**
 * A TV da sala liga antes de a camera se aproximar: ponto, linha, abertura
 * vertical e imagem. O encaixe usa os pixels do painel no asset original.
 * Apenas desenha dados ja preparados, sem iniciar carregamentos de rede.
 */
@Composable
fun SeriesLoadingOverlay(
    seriesName: String,
    isSeriesReady: Boolean,
    onComplete: (isReady: Boolean) -> Unit,
    modifier: Modifier = Modifier,
    previewBackdrop: ImageBitmap? = null,
    detailsContent: (@Composable () -> Unit)? = null,
    openingKey: String = seriesName
) {
    val readyLatest by rememberUpdatedState(isSeriesReady)
    val onCompleteLatest by rememberUpdatedState(onComplete)
    val tvPower = remember(openingKey) { Animatable(0f) }
    val cameraApproach = remember(openingKey) { Animatable(0f) }
    val sceneAlpha = remember(openingKey) { Animatable(1f) }

    LaunchedEffect(openingKey) {
        // SERIES_REAL_TV_PAGE_V1
        // A TV fica desligada ate os detalhes estarem preparados.
        // Se o provedor nao concluir, libera a pagina sem simular
        // que a televisao ligou.
        val ready = withTimeoutOrNull(25_000L) {
            while (!readyLatest) {
                delay(32L)
            }
            true
        } == true

        if (!ready) {
            onCompleteLatest(false)
            return@LaunchedEffect
        }

        // Permite ao Compose desenhar a pagina atualizada antes
        // de iniciar a animacao original.
        withFrameNanos { }

        val started = SystemClock.uptimeMillis()
        suspend fun waitFor(ms: Long) {
            val remaining = ms - (SystemClock.uptimeMillis() - started)
            if (remaining > 0L) delay(remaining)
        }

        // A foto fica intacta durante a pausa com a TV realmente apagada.
        waitFor(350L)
        tvPower.animateTo(
            targetValue = 1f,
            animationSpec = tween(durationMillis = 680, easing = LinearEasing)
        )
        // A imagem precisa estar visivel antes de a camera comecar a avancar.
        waitFor(1580L)
        coroutineScope {
            launch {
                cameraApproach.animateTo(
                    targetValue = 1f,
                    animationSpec = tween(420, easing = FastOutSlowInEasing)
                )
            }
            launch {
                delay(350L)
                sceneAlpha.animateTo(0f, animationSpec = tween(70))
            }
        }
        // A animacao termina com os detalhes ja preparados.
        onCompleteLatest(true)
    }

    val density = LocalDensity.current
    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .clipToBounds()
            .background(Color(0xFF070809))
            .semantics { contentDescription = "Abrindo detalhes da série $seriesName" }
    ) {
        val viewportWidth = constraints.maxWidth.toFloat().coerceAtLeast(1f)
        val viewportHeight = constraints.maxHeight.toFloat().coerceAtLeast(1f)
        val geometry = remember(viewportWidth, viewportHeight) {
            seriesTvGeometry(viewportWidth, viewportHeight)
        }
        val screen = geometry.screen
        val power = seriesTvPowerFrame(tvPower.value)
        val panelWidth = with(density) { screen.width.toDp() }
        val panelHeight = with(density) { screen.height.toDp() }
        val textScale = screen.width / viewportWidth
        val screenMask = remember(geometry) {
            Path().apply {
                addRoundRect(
                    RoundRect(
                        left = screen.left,
                        top = screen.top,
                        right = screen.right,
                        bottom = screen.bottom,
                        cornerRadius = CornerRadius(geometry.cornerRadius)
                    )
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    alpha = sceneAlpha.value
                    val approach = cameraApproach.value
                    val zoom = 1f + (geometry.finalZoom - 1f) * approach
                    transformOrigin = TransformOrigin(0f, 0f)
                    scaleX = zoom
                    scaleY = zoom
                    translationX = geometry.finalTranslationX * approach
                    translationY = geometry.finalTranslationY * approach
                }
        ) {
            Image(
                painter = painterResource(R.drawable.series_living_room),
                contentDescription = null,
                modifier = Modifier.fillMaxSize(),
                alignment = Alignment.Center,
                contentScale = ContentScale.Crop
            )

            // Uma unica mascara limita a imagem e a luz ao interior do painel.
            // Nao usamos dimensoes proporcionais ao viewport para adivinhar a TV.
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .drawWithContent {
                        if (tvPower.value > 0f) {
                            val frame = seriesTvPowerFrame(tvPower.value)
                            val revealedWidth = (screen.width * frame.widthFraction)
                                .coerceAtLeast(2f * geometry.roomScale)
                            val revealedHeight = (screen.height * frame.heightFraction)
                                .coerceAtLeast(2f * geometry.roomScale)
                            val canvas = drawContext.canvas
                            canvas.save()
                            try {
                                canvas.clipPath(screenMask)
                                canvas.clipRect(
                                    screen.centerX - revealedWidth / 2f,
                                    screen.centerY - revealedHeight / 2f,
                                    screen.centerX + revealedWidth / 2f,
                                    screen.centerY + revealedHeight / 2f
                                )
                                drawContent()
                            } finally {
                                canvas.restore()
                            }
                        }
                    }
            ) {
                // O painel e medido na proporcao real da TV. Crop preenche-o
                // sem esticar a foto; a moldura do asset fica sempre descoberta.
                Box(
                    modifier = Modifier
                        .wrapContentSize(Alignment.TopStart, unbounded = true)
                        .size(panelWidth, panelHeight)
                        .graphicsLayer {
                            translationX = screen.left
                            translationY = screen.top
                        }
                        .clipToBounds()
                        .background(Color(0xFF05070A))
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer { alpha = power.pictureAlpha }
                    ) {
                        if (detailsContent != null) {
                            // Usa a mesma pagina da rota de detalhes.
                            // Mantem o tamanho logico da tela inteira e
                            // reduz apenas a renderizacao para caber na TV.
                            // O painel continua com o recorte original.
                            Box(
                                modifier = Modifier
                                    .wrapContentSize(
                                        Alignment.TopStart,
                                        unbounded = true
                                    )
                                    .requiredSize(
                                        with(density) { viewportWidth.toDp() },
                                        with(density) { viewportHeight.toDp() }
                                    )
                                    .graphicsLayer {
                                        transformOrigin = TransformOrigin(0f, 0f)
                                        scaleX = screen.width / viewportWidth
                                        scaleY = screen.height / viewportHeight
                                    }
                            ) {
                                detailsContent()
                            }
                        } else {
                            SeriesPreviewPicture(
                                seriesName = seriesName,
                                previewBackdrop = previewBackdrop,
                                textScale = textScale,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }

            // A luz pertence ao painel: um ponto vira linha e abre na vertical.
            // Ela some gradualmente para revelar a foto, em vez de apenas dar
            // fade no retangulo inteiro sobre a fotografia da sala.
            Canvas(modifier = Modifier.fillMaxSize()) {
                val frame = seriesTvPowerFrame(tvPower.value)
                if (tvPower.value > 0f && frame.flashAlpha > 0f) {
                    val width = (screen.width * frame.widthFraction)
                        .coerceAtLeast(2f * geometry.roomScale)
                    val height = (screen.height * frame.heightFraction)
                        .coerceAtLeast(2f * geometry.roomScale)
                    val canvas = drawContext.canvas
                    canvas.save()
                    try {
                        canvas.clipPath(screenMask)
                        drawRoundRect(
                            brush = Brush.verticalGradient(
                                listOf(
                                    Color(0xFFC7D9E8),
                                    Color(0xFFFFFFFF),
                                    Color(0xFFC7D9E8)
                                ),
                                startY = screen.centerY - height / 2f,
                                endY = screen.centerY + height / 2f
                            ),
                            topLeft = Offset(screen.centerX - width / 2f, screen.centerY - height / 2f),
                            size = Size(width, height),
                            cornerRadius = CornerRadius(geometry.roomScale),
                            alpha = frame.flashAlpha * 0.82f
                        )
                        if (frame.sparkAlpha > 0f) {
                            drawCircle(
                                brush = Brush.radialGradient(
                                    listOf(Color(0xCCECF7FF), Color.Transparent),
                                    center = Offset(screen.centerX, screen.centerY),
                                    radius = screen.width * 0.075f
                                ),
                                radius = screen.width * 0.075f,
                                center = Offset(screen.centerX, screen.centerY),
                                alpha = frame.sparkAlpha
                            )
                        }
                    } finally {
                        canvas.restore()
                    }
                }
            }
        }
    }
}

@Composable
private fun SeriesPreviewPicture(
    seriesName: String,
    previewBackdrop: ImageBitmap?,
    textScale: Float,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.background(Color(0xFF08090B))) {
        if (previewBackdrop != null) {
            Image(
                bitmap = previewBackdrop,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            Box(
                modifier = Modifier.fillMaxSize().background(
                    Brush.horizontalGradient(
                        listOf(Color(0xE9000000), Color(0x80000000), Color(0x20000000))
                    )
                )
            )
        }
        Text(
            text = seriesName,
            modifier = Modifier
                .align(Alignment.CenterStart)
                .fillMaxWidth(0.65f)
                .padding(start = 26.dp * textScale),
            color = Color(0xFFE9CC7A),
            fontSize = 30.sp * textScale,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
    }
}
